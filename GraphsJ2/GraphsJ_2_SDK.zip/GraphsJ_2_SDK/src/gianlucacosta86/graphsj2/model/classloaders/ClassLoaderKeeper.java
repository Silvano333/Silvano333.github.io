/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.classloaders;

import java.net.URL;

/**
 * This class manages the class loader to use to load classes at runtime.
 *
 * @author Gianluca Costa
 */
public final class ClassLoaderKeeper {

    private static final ClassLoaderKeeper instance = new ClassLoaderKeeper();
    private ClassLoader loader = ClassLoaderKeeper.class.getClassLoader();
    private URL sourceUrl;

    public static ClassLoaderKeeper getInstance() {
        return instance;
    }

    private ClassLoaderKeeper() {
    }

    /**
     *
     * @return The class loader to use to dynamically load classes
     */
    public ClassLoader getDynamicLoader() {
        return loader;
    }

    /**
     * Sets the class loader to use in order to load classes first from the specified URL (for example, a jar file), then from the default  JVM loader.
     * @param sourceUrl The URL containing the extension classes.
     */
    public void setAlgorithmUrl(URL sourceUrl) {
        if (sourceUrl == null) {
            loader = ClassLoaderKeeper.class.getClassLoader();
        } else {
            loader = new UrlFallbackClassLoader(sourceUrl);
        }

        this.sourceUrl = sourceUrl;
    }

    public URL getSourceUrl() {
        return sourceUrl;
    }
}
