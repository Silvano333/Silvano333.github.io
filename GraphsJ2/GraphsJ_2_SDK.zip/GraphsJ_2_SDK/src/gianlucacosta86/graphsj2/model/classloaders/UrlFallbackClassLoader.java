/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.classloaders;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * Loads classes from the specified URL, if possible. Otherwise, it tries to load them by using the default JVM loader.
 * @author Gianluca Costa
 */
public class UrlFallbackClassLoader extends URLClassLoader {

    /**
     * Creates the loader
     * @param sourceUrl The URL of the source path (for example, a jar file) containing the classes.
     */
    protected UrlFallbackClassLoader(URL sourceUrl) {
        super(new URL[]{sourceUrl});
    }

    @Override
    public Class<?> loadClass(String name) throws ClassNotFoundException {

        try {
            return super.loadClass(name);
        } catch (ClassNotFoundException ex) {
            return UrlFallbackClassLoader.class.getClassLoader().loadClass(name);
        }
    }

    @Override
    public String toString() {
        return String.format("{%s}", getURLs()[0]);
    }
}
