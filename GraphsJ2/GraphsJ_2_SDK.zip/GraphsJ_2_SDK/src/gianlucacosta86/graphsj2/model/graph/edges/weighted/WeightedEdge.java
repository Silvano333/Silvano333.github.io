/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.graph.edges.weighted;

import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.GraphObject;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.exceptions.GraphException;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;

/**
 * 
 * @author Gianluca Costa
 */
public abstract class WeightedEdge<Q extends WeightQuantity<?>> extends Edge {

    private static final long serialVersionUID = 1L;
    private final boolean showMinWeight;
    private final boolean showMaxWeight;
    private Q minWeight;
    private Q maxWeight;
    private Q weight;

    public WeightedEdge(Vertex source, Vertex target, Q minWeight, Q maxWeight, Q weight, boolean showMinWeight, boolean showMaxWeight) {
        super(source, target);

        try {
            setQuantities(minWeight, maxWeight, weight);
        } catch (InvalidWeightException ex) {
            throw new IllegalArgumentException();
        }


        this.showMinWeight = showMinWeight;
        this.showMaxWeight = showMaxWeight;
    }

    public Q getMinWeight() {
        return minWeight;
    }

    protected void setMinWeight(Q minWeight) throws InvalidWeightException {
        setQuantities(minWeight, maxWeight, weight);
    }

    public Q getMaxWeight() {
        return maxWeight;
    }

    protected void setMaxWeight(Q maxWeight) throws InvalidWeightException {
        setQuantities(minWeight, maxWeight, weight);
    }

    public Q getWeight() {
        return weight;
    }

    public void setWeight(Q weight) throws InvalidWeightException {
        setQuantities(minWeight, maxWeight, weight);
    }

    protected void setQuantities(Q minWeight, Q maxWeight, Q weight) throws InvalidWeightException {
        if (minWeight == null || maxWeight == null || weight == null) {
            throw new IllegalArgumentException("The 3 weight quantities must all be != null");
        }

        if (minWeight.compareTo(maxWeight) > 0) {
            throw new InvalidWeightException("It must be minWeight <= maxWeight");
        }

        if (weight.compareTo(minWeight) < 0 || weight.compareTo(maxWeight) > 0) {
            throw new InvalidWeightException("It must be minWeight <= weight <= maxWeight");
        }

        this.weight = weight;
        this.minWeight = minWeight;
        this.maxWeight = maxWeight;

    }

    @Override
    protected abstract boolean askUserForEditData(GraphCanvas canvas) throws GraphException;

    @Override
    protected void restoreFromObject(GraphObject obj) {
        WeightedEdge<Q> original = (WeightedEdge<Q>) obj;
        this.weight = original.weight;
        this.minWeight = original.minWeight;
        this.maxWeight = original.maxWeight;

    }

    protected boolean isShowMinWeight() {
        return showMinWeight;
    }

    protected boolean isShowMaxWeight() {
        return showMaxWeight;
    }

    /**
     *
     * @return A string containing, in order, the edge weight and the edge capacity.
     */
    @Override
    public String toString() {

        if (!showMinWeight && !showMaxWeight) {

            return weight.toString();

        } else if (showMinWeight && !showMaxWeight) {

            return String.format("(%s, %s)", weight, minWeight);

        } else if (!showMinWeight && showMaxWeight) {

            return String.format("(%s, %s)", weight, maxWeight);

        } else {

            return String.format("(%s, [%s, %s])", weight, minWeight, maxWeight);

        }

    }
}
