/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.graph.edges.weighted.integer;

import gianlucacosta86.graphsj2.model.graph.edges.weighted.WeightQuantity;

/**
 *
 * @author Gianluca Costa
 */
public class IntegerWeightQuantity extends WeightQuantity<Integer> {

    private static final long serialVersionUID = 1;
    public static final IntegerWeightQuantity ZERO = new IntegerWeightQuantity(0);
    public static final IntegerWeightQuantity PLUS_INF = new IntegerWeightQuantity(Integer.MAX_VALUE);
    public static final IntegerWeightQuantity MINUS_INF = new IntegerWeightQuantity(-Integer.MAX_VALUE);

    public IntegerWeightQuantity(int value) {
        super(value);
    }

    @Override
    public IntegerWeightQuantity negate() {
        return new IntegerWeightQuantity(-getValue());
    }

    @Override
    public IntegerWeightQuantity subtract(WeightQuantity<Integer> other) {
        return sum(other.negate());
    }

    @Override
    public IntegerWeightQuantity sum(WeightQuantity<Integer> other) {

        boolean thisIsInf = this.isInf();
        boolean otherIsInf = other.isInf();

        if (thisIsInf || otherIsInf) {
            if (thisIsInf && otherIsInf && !other.equals(this)) {
                throw new IllegalArgumentException("Cannot sum opposite infinite quantities");
            }

            if (thisIsInf) {
                return this;
            } else {
                return (IntegerWeightQuantity) other;
            }
        } else {
            return new IntegerWeightQuantity(getValue() + other.getValue());
        }
    }

    @Override
    public IntegerWeightQuantity min(WeightQuantity<Integer> other) {
        return (IntegerWeightQuantity) super.min(other);
    }

    @Override
    public IntegerWeightQuantity max(WeightQuantity<Integer> other) {
        return (IntegerWeightQuantity) super.max(other);
    }

    @Override
    public int compareTo(Object o) {
        if (o instanceof IntegerWeightQuantity) {
            IntegerWeightQuantity other = (IntegerWeightQuantity) o;
            return getValue().compareTo(other.getValue());
        } else if (o instanceof Integer) {
            Integer other = (Integer) o;
            return getValue().compareTo(other);
        }

        throw new IllegalArgumentException("Cannot compare a WeightQuantity with the specified argument");
    }

    @Override
    public boolean isPlusInf() {
        return getValue().equals(PLUS_INF.getValue());
    }

    @Override
    public boolean isMinusInf() {
        return getValue().equals(MINUS_INF.getValue());
    }
}
