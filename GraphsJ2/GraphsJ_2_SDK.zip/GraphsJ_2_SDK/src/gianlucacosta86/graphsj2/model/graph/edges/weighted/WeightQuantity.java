/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.graph.edges.weighted;

import gianlucacosta86.graphsj2.AppConstants;
import java.io.Serializable;

/**
 *
 * @author Gianluca Costa
 * @param <T>
 */
public abstract class WeightQuantity<T> implements Comparable<Object>, Serializable {

    private static final long serialVersionUID = 1;
    private final T value;

    public WeightQuantity(T value) {
        this.value = value;
    }

    public T getValue() {
        return value;
    }

    @Override
    public String toString() {

        if (isPlusInf()) {
            return AppConstants.PLUS_INF_STRING;
        } else if (isMinusInf()) {
            return AppConstants.MINUS_INF_STRING;
        }

        return value.toString();
    }

    public abstract WeightQuantity<T> negate();

    public abstract WeightQuantity<T> subtract(WeightQuantity<T> other);

    public abstract WeightQuantity<T> sum(WeightQuantity<T> other);

    public abstract boolean isPlusInf();

    public abstract boolean isMinusInf();

    public boolean isInf() {
        return isPlusInf() || isMinusInf();
    }

    public WeightQuantity<T> min(WeightQuantity<T> other) {
        if (compareTo(other) <= 0) {
            return this;
        } else {
            return other;
        }
    }

    public WeightQuantity<T> max(WeightQuantity<T> other) {
        if (compareTo(other) >= 0) {
            return this;
        } else {
            return other;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof WeightQuantity)) {
            return false;
        }

        WeightQuantity<T> other = (WeightQuantity<T>) obj;
        return value.equals(other.value);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
