/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.graph.edges.weighted.integer;

import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.WeightedEdge;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.InvalidWeightException;
import gianlucacosta86.graphsj2.model.graph.exceptions.GraphException;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;

/**
 *
 * @author Gianluca Costa
 */
public class IntegerWeightedEdge extends WeightedEdge<IntegerWeightQuantity> {

    private static final long serialVersionUID = 1;

    public IntegerWeightedEdge(Vertex source, Vertex target, IntegerWeightQuantity minWeight, IntegerWeightQuantity maxWeight, IntegerWeightQuantity weight, boolean showMinWeight, boolean showMaxWeight) {
        super(
                source,
                target,
                minWeight != null ? minWeight : IntegerWeightQuantity.MINUS_INF,
                maxWeight != null ? maxWeight : IntegerWeightQuantity.PLUS_INF,
                weight != null ? weight : IntegerWeightQuantity.ZERO,
                showMinWeight,
                showMaxWeight);
    }

    @Override
    protected boolean askUserForEditData(GraphCanvas canvas) throws GraphException {
        Integer newMinWeightVal;
        Integer newMaxWeightVal;
        Integer newWeightVal;


        while (true) {
            if (isShowMinWeight()) {

                newMinWeightVal = MessageProvider.getInstance().askForInteger("Minimum weight:", "Edit edge...", getMinWeight().getValue(), null, null);
                if (newMinWeightVal == null) {
                    return false;
                }
            } else {
                newMinWeightVal = getMinWeight().getValue();
            }


            if (isShowMaxWeight()) {
                newMaxWeightVal = MessageProvider.getInstance().askForInteger("Maximum weight:", "Edit edge...", getMaxWeight().getValue(), newMinWeightVal, null);
                if (newMaxWeightVal == null) {
                    return false;
                }
            } else {
                newMaxWeightVal = getMaxWeight().getValue();
            }



            newWeightVal = MessageProvider.getInstance().askForInteger("Weight:", "Edit edge...", getWeight().getValue(), newMinWeightVal, newMaxWeightVal);

            if (newWeightVal == null) {
                return false;
            }


            try {
                setQuantities(
                        new IntegerWeightQuantity(newMinWeightVal),
                        new IntegerWeightQuantity(newMaxWeightVal),
                        new IntegerWeightQuantity(newWeightVal));
            } catch (InvalidWeightException ex) {
                MessageProvider.getInstance().showWarningBox(ex);
            }


            return true;
        }

    }
}
