/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.graph;

import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.sets.EdgeSet;
import gianlucacosta86.graphsj2.model.collections.graphoriented.sets.VertexSet;
import gianlucacosta86.graphsj2.model.graph.exceptions.DuplicateVertexException;
import gianlucacosta86.graphsj2.model.graph.exceptions.GraphException;
import gianlucacosta86.graphsj2.model.graph.uniquefield.UniqueVertexField;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;
import gianlucacosta86.graphsj2.model.utils.namevalidator.NameValidator;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;

/**
 *
 * @author Gianluca Costa
 */
public abstract class Vertex extends GraphObject implements Comparable<Object> {

    private static final long serialVersionUID = 1;
    private final UniqueVertexField<String> name;
    private final EdgeSet<Edge> enteringEdges = new EdgeSet<Edge>();
    private final EdgeSet<Edge> exitingEdges = new EdgeSet<Edge>();

    public Vertex(String name) throws InvalidNameException {
        NameValidator.getInstance().validateName(name);

        this.name = new UniqueVertexField<String>(this, name);
    }

    public String getName() {
        return name.getValue();
    }

    public void setName(String name) throws InvalidNameException, DuplicateVertexException {
        NameValidator.getInstance().validateName(name);

        this.name.setValue(name);
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Vertex)) {
            return false;
        }

        Vertex other = (Vertex) obj;
        return name.equals(other.name);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public int compareTo(Object obj) {
        Vertex other = (Vertex) obj;
        return name.compareTo(other.name);
    }

    void addEnteringEdge(Edge e) {
        enteringEdges.add(e);
    }

    void addExitingEdge(Edge e) {
        exitingEdges.add(e);
    }

    void removeLinkedEdge(Edge e) {
        if (!enteringEdges.remove(e) && !exitingEdges.remove(e)) {
            throw new IllegalArgumentException("The specified edge is not connected to the vertex!");
        }
    }

    public <E extends Edge> EdgeSet<E> getEnteringEdges() {
        return (EdgeSet<E>) new EdgeSet<Edge>(enteringEdges);
    }

    public <E extends Edge> EdgeSet<E> getExitingEdges() {
        return (EdgeSet<E>) new EdgeSet<Edge>(exitingEdges);
    }

    public <E extends Edge> EdgeSet<E> getLinkedEdges() {
        EdgeSet<Edge> result = new EdgeSet<Edge>(enteringEdges);
        result.addAll(exitingEdges);
        return (EdgeSet<E>) result;
    }

    public <V extends Vertex> VertexList<V> getEnteringVertexes() {
        VertexList<V> result = new VertexList<V>();

        for (Edge edge : getEnteringEdges()) {
            result.add((V) edge.getSource());
        }

        return result;
    }

    public <V extends Vertex> VertexList<V> getExitingVertexes() {
        VertexList<V> result = new VertexList<V>();

        for (Edge edge : getExitingEdges()) {
            result.add((V) edge.getTarget());
        }

        return result;
    }

    public <V extends Vertex> VertexSet<V> getLinkedVertexes() {
        VertexSet<Vertex> result = new VertexSet<Vertex>(getEnteringVertexes());
        result.addAll(getExitingVertexes());
        return (VertexSet<V>) result;
    }

    public int getInDegree() {
        return enteringEdges.size();
    }

    public int getOutDegree() {
        return exitingEdges.size();
    }

    public int getDegree() {
        return enteringEdges.size() + exitingEdges.size();
    }

    @Override
    public String toString() {
        return name.getValue();
    }

    @Override
    protected boolean askUserForEditData(GraphCanvas canvas) throws GraphException {
        String newName = MessageProvider.getInstance().askForString("Please, input the vertex name:", "Vertex title...", name.getValue());

        if (newName == null) {
            return false;
        }


        name.setValue(newName);
        return true;
    }

    @Override
    protected void restoreFromObject(GraphObject obj) {
        Vertex other = (Vertex) obj;
        try {
            name.setValue(other.name.getValue());
        } catch (DuplicateVertexException ex) {
            throw new AssertionError();
        }
    }
}
