/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.graph;

import gianlucacosta86.graphsj2.model.graph.exceptions.GraphException;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import java.io.Serializable;

/**
 *
 * @author Gianluca Costa
 */
public abstract class GraphObject implements Cloneable, Serializable {

    private static final long serialVersionUID = 1;
    private IGraph parent;

    public IGraph getParent() {
        return parent;
    }

    void setParent(IGraph parent) {
        this.parent = parent;
    }

    @Override
    protected GraphObject clone() {
        try {
            GraphObject result = (GraphObject) super.clone();
            result.parent = null;
            return result;
        } catch (CloneNotSupportedException ex) {
            throw new AssertionError();
        }
    }

    public final boolean edit(GraphCanvas canvas) throws GraphException {
        GraphObject initialStateObject = (GraphObject) clone();


        try {
            if (!askUserForEditData(canvas)) {
                restoreFromObject(initialStateObject);
                return false;
            }

            return true;
        } catch (GraphException ex) {
            restoreFromObject(initialStateObject);
            throw ex;
        }

    }

    protected abstract void restoreFromObject(GraphObject obj);

    protected abstract boolean askUserForEditData(GraphCanvas canvas) throws GraphException;
}
