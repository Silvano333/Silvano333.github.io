/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.graph.exceptions;

import gianlucacosta86.graphsj2.model.graph.Edge;

/**
 * Thrown when a duplicate edge would be going to be inserted into a graph.
 *
 * @author Gianluca Costa
 */
public class DuplicateEdgeException extends DuplicateObjectException {

    public DuplicateEdgeException() {
        super("A duplicate of the edge already belongs to the graph!");
    }

    public DuplicateEdgeException(Edge edge) {
        super(String.format("Edge '%s' already belongs to the graph!", edge.getBounds()));
    }
}
