/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.graph;

import gianlucacosta86.graphsj2.model.collections.graphoriented.VertexPair;

/**
 *
 * @author Gianluca Costa
 */
public abstract class Edge extends GraphObject implements Comparable<Object> {

    private static final long serialVersionUID = 1;
    private final VertexPair<Vertex> bounds;

    public Edge(Vertex source, Vertex target) {
        bounds = new VertexPair<Vertex>(source, target);
    }

    public Vertex getSource() {
        return bounds.getSource();
    }

    public Vertex getTarget() {
        return bounds.getTarget();
    }

    public VertexPair<Vertex> getBounds() {
        return bounds;
    }

    @Override
    public int compareTo(Object obj) {
        Edge other = (Edge) obj;
        int sourceComparison = bounds.getSource().compareTo(other.bounds.getSource());

        if (sourceComparison != 0) {
            return sourceComparison;
        }

        return bounds.getTarget().compareTo(other.bounds.getTarget());
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Edge)) {
            return false;
        }

        Edge other = (Edge) obj;
        return bounds.getSource().equals(other.bounds.getSource()) &&
                bounds.getTarget().equals(other.bounds.getTarget());
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public String toString() {
        return bounds.toString();
    }
}
