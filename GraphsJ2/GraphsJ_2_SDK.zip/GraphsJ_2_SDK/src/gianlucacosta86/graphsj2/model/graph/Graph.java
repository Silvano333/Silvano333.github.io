/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.graph;

import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.sets.EdgeSet;
import gianlucacosta86.graphsj2.model.collections.graphoriented.sets.VertexSet;

import gianlucacosta86.graphsj2.model.graph.exceptions.DuplicateEdgeException;
import gianlucacosta86.graphsj2.model.graph.exceptions.DuplicateVertexException;
import gianlucacosta86.graphsj2.model.graph.topologyevent.CustomTopologyEvent;
import gianlucacosta86.graphsj2.model.utils.events.EventKey;

/**
 *
 * @author Gianluca Costa
 * @param <V>
 * @param <E>
 */
public class Graph<V extends Vertex, E extends Edge> implements IGraph {

    private static final long serialVersionUID = 1;
    private final EventKey EVENT_KEY = new EventKey();
    private final VertexSet<V> vertexes = new VertexSet<V>();
    private final EdgeSet<E> edges = new EdgeSet<E>();
    private final CustomTopologyEvent onVertexAdded = new CustomTopologyEvent(this, EVENT_KEY);
    private final CustomTopologyEvent onVertexRemoving = new CustomTopologyEvent(this, EVENT_KEY);
    private final CustomTopologyEvent onEdgeAdded = new CustomTopologyEvent(this, EVENT_KEY);
    private final CustomTopologyEvent onEdgeRemoving = new CustomTopologyEvent(this, EVENT_KEY);
    private final boolean oriented;

    public Graph(boolean oriented) {
        this.oriented = oriented;
    }

    @Override
    public boolean isOriented() {
        return oriented;
    }

    public void addVertex(V vertex) throws DuplicateVertexException {
        if (vertex.getParent() != null) {
            throw new IllegalArgumentException("The vertex already belongs to a graph!");
        }


        if (hasConflictingVertex(vertex)) {
            throw new DuplicateVertexException(vertex);
        }


        if (!vertexes.add(vertex)) {
            throw new DuplicateVertexException(vertex);
        }


        vertex.setParent(this);

        onVertexAdded.fire(EVENT_KEY, vertex);
    }

    public void removeVertex(V vertex) {
        if (vertex.getParent() != this) {
            throw new IllegalArgumentException(String.format("Vertex '%s' does not belong to the graph!", vertex.getName()));
        }


        onVertexRemoving.fire(EVENT_KEY, vertex);


        for (Edge edge : vertex.getLinkedEdges()) {
            removeEdge((E) edge);
        }


        if (!vertexes.remove(vertex)) {
            throw new AssertionError();
        }

        vertex.setParent(null);
    }

    public void addEdge(E edge) throws DuplicateEdgeException {
        if (edge.getParent() != null) {
            throw new IllegalArgumentException("The edge already belongs to a graph!");
        }

        if (edge.getSource().getParent() != this) {
            throw new IllegalArgumentException(String.format("Source vertex '%s' does not belong to the graph!", edge.getSource().getName()));
        }


        if (edge.getTarget().getParent() != this) {
            throw new IllegalArgumentException(String.format("Target vertex '%s' does not belong to the graph!", edge.getTarget().getName()));
        }


        if (hasConflictingEdge(edge)) {
            throw new DuplicateEdgeException(edge);
        }


        if (!edges.add(edge)) {
            throw new DuplicateEdgeException(edge);
        }


        edge.getSource().addExitingEdge(edge);
        edge.getTarget().addEnteringEdge(edge);

        edge.setParent(this);

        onEdgeAdded.fire(EVENT_KEY, edge);
    }

    public void removeEdge(E edge) {
        if (edge.getParent() != this) {
            throw new IllegalArgumentException(String.format("Edge '%s' does not belong to the graph!", edge.getBounds()));
        }

        onEdgeRemoving.fire(EVENT_KEY, edge);

        edge.getSource().removeLinkedEdge(edge);
        edge.getTarget().removeLinkedEdge(edge);

        if (!edges.remove(edge)) {
            throw new AssertionError();
        }

        edge.setParent(null);
    }

    protected boolean hasConflictingVertex(V vertex) {
        for (Vertex currentVertex : vertexes) {
            if (currentVertex == vertex) {
                continue;
            }

            if (currentVertex.equals(vertex)) {
                return true;
            }
        }

        return false;
    }

    protected boolean hasConflictingEdge(E edge) {
        for (Edge currentEdge : edges) {
            if (currentEdge == edge) {
                continue;
            }

            if (currentEdge.equals(edge)) {
                return true;
            }
        }

        return false;
    }

    public VertexSet<V> getVertexSet() {
        return new VertexSet<V>(vertexes);
    }

    public EdgeSet<E> getEdgeSet() {
        return new EdgeSet<E>(edges);
    }

    public VertexList<V> getVertexList(boolean sorted) {
        return new VertexList(vertexes, sorted);
    }

    public EdgeList<E> getEdgeList(boolean sorted) {
        return new EdgeList<E>(edges, sorted);
    }

    public E getEdge(V startVertex, V stopVertex) {
        for (Edge edge : startVertex.getExitingEdges()) {
            if (edge.getTarget() == stopVertex) {
                return (E) edge;
            }
        }

        if (isOriented()) {
            return null;
        }


        for (Edge edge : stopVertex.getExitingEdges()) {
            if (edge.getTarget() == startVertex) {
                return (E) edge;
            }
        }

        return null;
    }

    @Override
    public final boolean hasConflictingVertexGeneral(Vertex vertex) {
        return hasConflictingVertex((V) vertex);
    }

    @Override
    public final boolean hasConflictingEdgeGeneral(Edge edge) {
        return hasConflictingEdge((E) edge);
    }

    @Override
    public void addVertexGeneral(Vertex vertex) throws DuplicateVertexException {
        addVertex((V) vertex);
    }

    @Override
    public void addEdgeGeneral(Edge edge) throws DuplicateEdgeException {
        addEdge((E) edge);
    }

    @Override
    public final void removeVertexGeneral(Vertex vertex) {
        removeVertex((V) vertex);
    }

    @Override
    public final void removeEdgeGeneral(Edge edge) {
        removeEdge((E) edge);
    }

    @Override
    public CustomTopologyEvent getOnVertexAdded() {
        return onVertexAdded;
    }

    @Override
    public CustomTopologyEvent getOnVertexRemoving() {
        return onVertexRemoving;
    }

    @Override
    public CustomTopologyEvent getOnEdgeAdded() {
        return onEdgeAdded;
    }

    @Override
    public CustomTopologyEvent getOnEdgeRemoving() {
        return onEdgeRemoving;
    }
}
