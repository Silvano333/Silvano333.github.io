/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.standard;

import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.Algorithm;
import gianlucacosta86.graphsj2.model.algorithms.RunStateEnum;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmEdge;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmVertex;
import gianlucacosta86.graphsj2.model.algorithms.standard.optionsdialog.StandardOptionsDialog;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.Graph;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.utils.TimeInterval;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.edgedrawer.EdgeDrawerProperties;
import java.awt.Color;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * @author Gianluca Costa
 */
public abstract class StandardAlgorithm<V extends Vertex & IAlgorithmVertex, E extends Edge & IAlgorithmEdge, G extends Graph<V, E>> extends Algorithm<V, E, G> implements IStandardAlgorithm {

    private static final long serialVersionUID = 1;
    protected static final Color DEFAULT_STEP_SOLUTION_EDGE_COLOR = Color.GREEN;
    protected static final Color DEFAULT_SOLUTION_EDGE_COLOR = Color.RED;
    protected static final int ENHANCED_EDGE_WIDTH_ADDEND = 3;
    private StandardOptionsDialog optionsDialog;
    private Long startMillis;
    //These fields must be saved with the algorithm, since they contain user-defined options.
    private Color stepSolutionEdgeColor = DEFAULT_STEP_SOLUTION_EDGE_COLOR;
    private Color solutionEdgeColor = DEFAULT_SOLUTION_EDGE_COLOR;

    @Override
    public Color getSolutionEdgeColor() {
        return solutionEdgeColor;
    }

    @Override
    public Color getStepSolutionEdgeColor() {
        return stepSolutionEdgeColor;
    }

    @Override
    public void initializeRun(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        if (getRunController().getRunState() == RunStateEnum.FULL_RUNNING) {
            startMillis = System.currentTimeMillis();
        } else {
            startMillis = null;
        }

        console.writeSeparator();
        console.writeLine(getAlgorithmName().toUpperCase());
        console.writeLine();



        if (graph.getVertexSet().isEmpty()) {
            throw new AlgorithmRunException("Cannot run the algorithm - the graph is empty!");
        }


        canvas.resetEdgeProperties();

        for (V vertex : graph.getVertexSet()) {
            if (vertex.getDegree() == 0) {
                throw new AlgorithmRunException(String.format("Vertex '%s' is not connected to other vertexes", vertex.getName()));
            }
        }
    }

    protected abstract void standardRunStep(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException;

    @Override
    protected void runStep(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        canvas.resetEdgeProperties();

        standardRunStep(canvas, graph, console, verboseRun, currentStep);


        Iterable<E> stepSolutionEdges = getStepSolutionEdges(currentStep);


        if (stepSolutionEdges != null) {

            for (E edge : stepSolutionEdges) {
                EdgeDrawerProperties properties = canvas.getPropertiesFor(edge);
                properties.setLineSize(properties.getLineSize() + ENHANCED_EDGE_WIDTH_ADDEND);
                properties.setColor(stepSolutionEdgeColor);
            }

        }

        if (verboseRun) {
            console.writeLine();

            console.writeLine("Vertex labels at the end of the current step are:");
            console.writeLine();
            for (V vertex : graph.getVertexList(true)) {
                console.writeLine(vertex.toString());
            }
            console.writeLine();

        }
    }

    protected abstract void standardOnEndRun(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException;

    @Override
    protected void onEndRun(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        canvas.resetEdgeProperties();

        standardOnEndRun(canvas, graph, console, verboseRun, currentStep);

        Iterable<E> solutionEdges = getSolutionEdges();


        if (solutionEdges != null) {
            for (E edge : solutionEdges) {
                EdgeDrawerProperties properties = canvas.getPropertiesFor(edge);
                properties.setLineSize(properties.getLineSize() + ENHANCED_EDGE_WIDTH_ADDEND);
                properties.setColor(solutionEdgeColor);
            }
        }



        if (startMillis != null) {
            long stopMillis = System.currentTimeMillis();

            long delta = stopMillis - startMillis;

            TimeInterval executionInterval = new TimeInterval(delta);

            console.writeLine(String.format("The algorithm execution lasted %s", executionInterval));
        }


        console.writeLine();
        console.writeSeparator();

    }

    @Override
    public boolean showOptionsDialog() {
        if (optionsDialog == null) {
            optionsDialog = new StandardOptionsDialog(this);
        }

        optionsDialog.setVisible(true);
        boolean result = optionsDialog.isConfirmed();

        if (result) {
            stepSolutionEdgeColor = optionsDialog.getStepSolutionColor();
            solutionEdgeColor = optionsDialog.getSolutionColor();
        }

        return result;
    }

    @Override
    protected String getStepDescription(int currentStep) {
        return "";
    }

    @Override
    protected String getCompletedStepDescription(int completedStepNumber) {
        return "";
    }

    @Override
    public GraphCanvas buildGraphCanvas() {
        return new GraphCanvas(buildGraphFactory());
    }

    protected abstract Iterable<E> getSolutionEdges();

    protected abstract Iterable<E> getStepSolutionEdges(int currentStep);

    protected abstract IGraphFactory buildGraphFactory();

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        stepSolutionEdgeColor = (Color) in.readObject();
        solutionEdgeColor = (Color) in.readObject();
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(stepSolutionEdgeColor);
        out.writeObject(solutionEdgeColor);
    }
}
