/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.concrete.cpm;

import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.startstop.StartStopAlgorithm;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;

/**
 * CPM algorithm.
 *
 * @author Gianluca Costa
 */
public class Cpm extends StartStopAlgorithm<CpmVertex, CpmEdge, IntegerWeightedGraph<CpmVertex, CpmEdge>> {

    private static final long serialVersionUID = 1L;
    public static final int MIN_LABELING_STEP = 1;
    public static final int MAX_LABELING_STEP = 2;
    private CpmVertex startVertex;
    private CpmVertex stopVertex;
    private int numVertexes;
    private VertexList<CpmVertex> indexedVertexList;
    private EdgeList<CpmEdge> criticalActivities;

    @Override
    protected Iterable<CpmEdge> getStepSolutionEdges(int currentStep) {
        return null;
    }

    @Override
    protected Iterable<CpmEdge> getSolutionEdges() {
        return criticalActivities;
    }

    @Override
    public String getAlgorithmName() {
        return "Task management (CPM)";
    }

    @Override
    protected IGraphFactory buildGraphFactory() {
        return new CpmFactory();
    }

    @Override
    public void initializeRun(GraphCanvas canvas, IntegerWeightedGraph<CpmVertex, CpmEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(canvas, graph, console, verboseRun);


        startVertex = getStartVertex();
        stopVertex = getStopVertex();

        VertexList<CpmVertex> vList = graph.getVertexList(true);
        numVertexes = vList.size();
        indexedVertexList = new VertexList<CpmVertex>();

        startVertex.setIndex(0);
        indexedVertexList.add(startVertex);
        vList.remove(startVertex);


        stopVertex.setIndex(numVertexes - 1);
        vList.remove(stopVertex);

        //Enumerating vertexes
        for (int counter = 1; counter <= numVertexes - 2; counter++) {
            CpmVertex indexedVertex = null;

            for (CpmVertex vertex : vList) {
                boolean vertexHasGammaMinus = false;

                for (CpmVertex gammaMinusVertex : vertex.<CpmVertex>getEnteringVertexes()) {
                    if (vList.contains(gammaMinusVertex)) {
                        vertexHasGammaMinus = true;
                        break;
                    }
                }

                if (!vertexHasGammaMinus) {
                    vertex.setIndex(counter);
                    indexedVertex = vertex;
                    indexedVertexList.add(vertex);
                    break;
                }
            }

            if (indexedVertex == null) {
                throw new AlgorithmRunException("Could not index vertexes. Algorithm Error");
            }
            vList.remove(indexedVertex);
        }


        indexedVertexList.add(stopVertex);
    }

    @Override
    protected void postInitializeRun(GraphCanvas canvas, IntegerWeightedGraph<CpmVertex, CpmEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        //Just do nothing
    }

    @Override
    protected void standardRunStep(GraphCanvas canvas, IntegerWeightedGraph<CpmVertex, CpmEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        if (verboseRun) {
            console.writeHeader("Step " + currentStep);
        }


        if (currentStep == 1) {


            startVertex.setTmin(IntegerWeightQuantity.ZERO);

            for (int k = 1; k <= numVertexes - 1; k++) {
                CpmVertex currentVertex = indexedVertexList.get(k);

                IntegerWeightQuantity tMin = IntegerWeightQuantity.ZERO;

                for (CpmEdge edge : currentVertex.<CpmEdge>getEnteringEdges()) {
                    CpmVertex source = (CpmVertex) edge.getSource();
                    IntegerWeightQuantity val = source.getTmin().sum(edge.getWeight());
                    if (val.getValue() > tMin.getValue()) {
                        tMin = val;
                    }
                }

                currentVertex.setTmin(tMin);
            }
        } else if (currentStep == 2) {
            stopVertex.setTmax(stopVertex.getTmin());

            for (int k = numVertexes - 2; k >= 0; k--) {
                CpmVertex currentVertex = indexedVertexList.get(k);
                IntegerWeightQuantity tMax = IntegerWeightQuantity.PLUS_INF;

                for (CpmEdge edge : currentVertex.<CpmEdge>getExitingEdges()) {
                    CpmVertex target = (CpmVertex) edge.getTarget();
                    IntegerWeightQuantity val = target.getTmax().subtract(edge.getWeight());
                    if (val.getValue() < tMax.getValue()) {
                        tMax = val;
                    }
                }

                currentVertex.setTmax(tMax);
            }
        } else {
            throw new AlgorithmEndedException();
        }

    }

    @Override
    protected void standardOnEndRun(GraphCanvas canvas, IntegerWeightedGraph<CpmVertex, CpmEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        criticalActivities = new EdgeList<CpmEdge>();

        for (CpmEdge edge : graph.getEdgeSet()) {
            if (edge.isCritical()) {
                criticalActivities.add(edge);
            }
        }

        criticalActivities.sort();


        console.writeHeader("Activity Table");
        console.writeLine(String.format("%30s\t%15s\t%15s\t%15s\t%15s", "Activity", "Duration", "EST", "LST", "S"));
        for (CpmEdge edge : graph.getEdgeList(true)) {
            if (edge.getActivityName().equals("")) {
                continue;
            }

            console.writeLine(String.format("%30s\t%15s\t%15s\t%15s\t%15s", edge.getActivityName(), edge.getWeight(), edge.getEST(), edge.getLST(), edge.getS()));
        }
        console.writeLine();
        console.writeHeader("Critical activities");
        for (CpmEdge edge : criticalActivities) {
            if (edge.getActivityName().equals("")) {
                continue;
            }

            console.writeLine(edge.toString());
        }

        if (criticalActivities.isEmpty()) {
            console.writeLine("(no critical activities)");
        }
    }

    @Override
    protected void onInterruptedRun(GraphCanvas canvas, IntegerWeightedGraph<CpmVertex, CpmEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    protected String getCompletedStepDescription(int completedStepNumber) {
        switch (completedStepNumber) {
            case 1:
                return "Minimum times set";
            case 2:
                return "Maximum times set";
            case 3:
                return "Critical activities determined";
            default:
                return null;
        }
    }
}
