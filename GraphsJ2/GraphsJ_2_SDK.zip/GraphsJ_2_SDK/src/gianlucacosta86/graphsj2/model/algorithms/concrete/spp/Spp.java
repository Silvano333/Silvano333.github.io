/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.concrete.spp;

import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.standard.StandardAlgorithm;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.exceptions.EmptyGraphException;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.VertexChooser;

/**
 * Dijkstra's SPP algorithm.
 *
 * @author Gianluca Costa
 */
public class Spp extends StandardAlgorithm<SppVertex, SppEdge, IntegerWeightedGraph<SppVertex, SppEdge>> {

    private static final long serialVersionUID = 1L;
    private VertexList<SppVertex> vList;
    private VertexList<SppVertex> pathVertexes;
    private EdgeList<SppEdge> pathEdges;
    private SppVertex vBar;

    @Override
    protected Iterable<SppEdge> getSolutionEdges() {
        return pathEdges;
    }

    @Override
    public String getAlgorithmName() {
        return "Dijkstra's Shortest Path Problem (SPP)";
    }

    @Override
    public void initializeRun(GraphCanvas canvas, IntegerWeightedGraph<SppVertex, SppEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(canvas, graph, console, verboseRun);

        vList = graph.getVertexList(true);
        pathVertexes = new VertexList<SppVertex>(true);


        SppVertex startVertex;
        try {
            startVertex = new VertexChooser<SppVertex, SppEdge>(graph).askForVertex("Choose start vertex:", getAlgorithmName());
            if (startVertex == null) {
                throw new AlgorithmInterruptedException();
            }
        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException(ex);
        }

        pathVertexes.add(startVertex);
        vList.remove(startVertex);

        pathEdges = new EdgeList<SppEdge>();


        //I initialize the vertex labels
        startVertex.setPreviousVertex(null);
        startVertex.setPathLength(IntegerWeightQuantity.ZERO);


        for (SppVertex vertex : vList) {
            vertex.setPreviousVertex(startVertex);
            vertex.setPathLength(graph.getDistanceBetween(startVertex, vertex));
        }

        if (verboseRun) {
            console.writeHeader("Legend");
            console.writeLine();
            console.writeLine("Vbar", "Vertex added to the shortest path in the current step");
            console.writeLine();
            console.writeHeader("Before step 1");
            console.writeLine();
            console.writeLine("Path vertexes", pathVertexes.getNamesList());
            console.writeLine("Path edges", pathEdges.getBoundsList());
            console.writeLine();
        }
    }

    @Override
    protected void postInitializeRun(GraphCanvas canvas, IntegerWeightedGraph<SppVertex, SppEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        //
    }

    @Override
    protected void standardRunStep(GraphCanvas canvas, IntegerWeightedGraph<SppVertex, SppEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {


        if (verboseRun) {
            console.writeHeader("Step " + currentStep);
        }

        if (currentStep > 1) {

            for (SppVertex vertex : vList) {
                IntegerWeightQuantity vertexPathLenFromStart = vBar.getPathLength().sum(graph.getDistanceBetween(vBar, vertex));

                if (vertexPathLenFromStart.getValue() < vertex.getPathLength().getValue()) {
                    vertex.setPathLength(vertexPathLenFromStart);
                    vertex.setPreviousVertex(vBar);
                }
            }
        }



        IntegerWeightQuantity minPathLength = IntegerWeightQuantity.PLUS_INF;

        //I find out the "vBar" vertex
        for (SppVertex vertex : vList) {
            if (vertex.getPathLength().getValue() < minPathLength.getValue()) {
                vBar = vertex;
                minPathLength = vertex.getPathLength();
            }
        }

        if (vBar == null) {
            throw new AlgorithmRunException("Cannot determine Vbar. Algorithm Error");
        }

        //I update the sets
        pathVertexes.add(vBar);
        vList.remove(vBar);

        SppEdge arcToAdd = graph.getEdge(vBar.getPreviousVertex(), vBar);

        if (arcToAdd == null) {
            throw new AlgorithmRunException("Cannot determine the arc to add");
        }

        pathEdges.add(arcToAdd);


        if (verboseRun) {
            console.writeLine();
            console.writeLine("At the end of the step:");
            console.writeLine();
            console.writeLine("Vbar", vBar);
            console.writeLine("Path vertexes", pathVertexes.getNamesList());
            console.writeLine("Path edges", pathEdges.getBoundsList());
            console.writeLine();
        }

        if (vList.isEmpty()) {
            throw new AlgorithmEndedException();
        }
    }

    @Override
    protected void onInterruptedRun(GraphCanvas canvas, IntegerWeightedGraph<SppVertex, SppEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    protected void standardOnEndRun(GraphCanvas canvas, IntegerWeightedGraph<SppVertex, SppEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        console.writeLine("The edges used by the shortest paths are: " + pathEdges.getBoundsList());
    }

    @Override
    protected Iterable<SppEdge> getStepSolutionEdges(int currentStep) {
        return pathEdges;
    }

    @Override
    protected IGraphFactory buildGraphFactory() {
        return new SppFactory();
    }
}
