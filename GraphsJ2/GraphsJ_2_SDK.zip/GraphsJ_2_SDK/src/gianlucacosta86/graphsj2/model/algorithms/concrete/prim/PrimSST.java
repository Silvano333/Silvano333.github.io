/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.concrete.prim;

import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.standard.StandardAlgorithm;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.exceptions.EmptyGraphException;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.VertexChooser;

/**
 * Prim's SST algorithm.
 * 
 * @author Gianluca Costa
 */
public class PrimSST extends StandardAlgorithm<PrimVertex, PrimEdge, IntegerWeightedGraph<PrimVertex, PrimEdge>> {

    private static final long serialVersionUID = 1L;
    private VertexList<PrimVertex> vList;
    private VertexList<PrimVertex> wList;
    private EdgeList<PrimEdge> treeEdges;
    private PrimVertex vBar;

    @Override
    public void initializeRun(GraphCanvas canvas, IntegerWeightedGraph<PrimVertex, PrimEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(canvas, graph, console, verboseRun);


        vList = graph.getVertexList(true);
        wList = new VertexList<PrimVertex>(true);

        PrimVertex v1;

        try {
            v1 = new VertexChooser<PrimVertex, PrimEdge>(graph).askForVertex("Choose the initial vertex:", this.toString());
            if (v1 == null) {
                throw new AlgorithmInterruptedException();
            }
        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException(ex);
        }

        v1.setBestVertex(v1);
        v1.setWeightFromBestVertex(IntegerWeightQuantity.ZERO);

        wList.add(v1);
        vList.remove(v1);
        vBar = v1;

        treeEdges = new EdgeList<PrimEdge>(false);

        for (PrimVertex vertex : vList) {
            vertex.setBestVertex(v1);
            IntegerWeightQuantity distance = graph.getDistanceBetween(v1, vertex);
            vertex.setWeightFromBestVertex(distance);
        }


        if (verboseRun) {
            console.writeHeader("Legend");
            console.writeLine();
            console.writeLine("V", "The graph vertexes");
            console.writeLine("W", "Vertexes belonging to the tree in the current step");
            console.writeLine("E", "Edges belonging to the tree in the current step");
            console.writeLine("Vbar", "Vertex added to the tree in the current step");
            console.writeLine();

            console.writeHeader("Before step 1");

            console.writeLine("W", wList.getNamesList());
            console.writeLine("V\\W", vList.getNamesList());
            console.writeLine("E", treeEdges.getBoundsList());
        }
    }

    @Override
    protected void postInitializeRun(GraphCanvas canvas, IntegerWeightedGraph<PrimVertex, PrimEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
    }

    @Override
    protected void standardRunStep(GraphCanvas canvas, IntegerWeightedGraph<PrimVertex, PrimEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        if (verboseRun) {
            console.writeHeader("Step " + currentStep);
            console.writeLine();
        }


        for (PrimVertex vertex : vList) {
            IntegerWeightQuantity distanceFromVBar = graph.getDistanceBetween(vBar, vertex);

            if (distanceFromVBar.getValue() < vertex.getWeightFromBestVertex().getValue()) {
                vertex.setBestVertex(vBar);
                vertex.setWeightFromBestVertex(distanceFromVBar);
            }
        }


        //Now, I determine the "vBar" vertex        
        IntegerWeightQuantity minBest = IntegerWeightQuantity.PLUS_INF;
        vBar = null;

        for (PrimVertex vertex : vList) {
            if (vertex.getWeightFromBestVertex().getValue() < minBest.getValue()) {
                vBar = vertex;
                minBest = vertex.getWeightFromBestVertex();
            }
        }

        if (vBar == null) {
            throw new AlgorithmRunException("Could not determine vBar! Error in the algorithm!");
        }


        //I add vBar to the "W" set, and remove it from the "V" set
        wList.add(vBar);
        vList.remove(vBar);

        //I also add the corresponding link to E
        PrimEdge chosenEdge = graph.getEdge(vBar, vBar.getBestVertex());
        treeEdges.add(chosenEdge);

        if (verboseRun) {
            console.writeLine("At the end of the step:");
            console.writeLine();
            console.writeLine("Vbar", vBar);
            console.writeLine("W", wList.getNamesList());
            console.writeLine("V \\ W", vList.getNamesList());
            console.writeLine("E", treeEdges.getBoundsList());
            console.writeLine();
            console.writeLine();
        }

        if (vList.isEmpty()) {
            throw new AlgorithmEndedException();
        }


    }

    @Override
    protected void standardOnEndRun(GraphCanvas canvas, IntegerWeightedGraph<PrimVertex, PrimEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Now, I find out the total weight of the spanning tree
        int totalWeight = 0;
        for (PrimEdge edge : treeEdges) {
            totalWeight += edge.getWeight().getValue();
        }


        console.writeLine("The branches of the spanning tree are: " + treeEdges.getBoundsList());
        console.writeLine();
        console.writeLine("The total weight of the spanning tree is: " + totalWeight);
    }

    @Override
    public String getAlgorithmName() {
        return "Prim's Shortest Spanning Tree (SST)";
    }

    @Override
    protected void onInterruptedRun(GraphCanvas canvas, IntegerWeightedGraph<PrimVertex, PrimEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    protected Iterable<PrimEdge> getSolutionEdges() {
        return treeEdges;
    }

    @Override
    protected IGraphFactory buildGraphFactory() {
        return new PrimFactory();
    }

    @Override
    protected Iterable<PrimEdge> getStepSolutionEdges(int currentStep) {
        return treeEdges;
    }
}
