/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms;

import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmEdge;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmVertex;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.Graph;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import java.net.URL;

/**
 *
 * @author Gianluca Costa
 * @param <V>
 * @param <E>
 * @param <G>
 */
public abstract class Algorithm<V extends Vertex & IAlgorithmVertex, E extends Edge & IAlgorithmEdge, G extends Graph<V, E>> implements IAlgorithm {

    private static final long serialVersionUID = 1;
    private transient RunController<V, E, G> runController;

    @Override
    public RunController<V, E, G> getRunController() {
        if (runController == null) {
            runController = new RunController<V, E, G>(this);
        }
        return runController;
    }

    /**
     * Creates the algorithm
     */
    public Algorithm() {
        super();
    }

    /**
     * @return By default, the algorithm name is returned.
     */
    @Override
    public String toString() {
        return getAlgorithmName();
    }

    @Override
    public abstract String getAlgorithmName();

    protected abstract void initializeRun(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException;

    protected abstract void postInitializeRun(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException;

    protected abstract void runStep(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException;

    protected abstract void onInterruptedRun(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException;

    protected abstract void onEndRun(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException;

    @Override
    public abstract boolean showOptionsDialog();

    protected abstract String getStepDescription(int currentStep);

    protected abstract String getCompletedStepDescription(int completedStepNumber);

    @Override
    public abstract GraphCanvas buildGraphCanvas();

    @Override
    public URL getHelpUrl() {
        return getClass().getResource("Help.html");
    }
}
