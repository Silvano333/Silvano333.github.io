/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.algorithmconsole;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gianluca Costa
 */
public class AlgorithmConsole {

    private final List<IAlgorithmConsoleWriter> writers = new ArrayList();

    public void addWriter(IAlgorithmConsoleWriter writer) {
        writers.add(writer);
    }

    public void removeWriter(IAlgorithmConsoleWriter writer) {
        writers.remove(writer);
    }

    public void write(String text) {
        for (IAlgorithmConsoleWriter writer : writers) {
            writer.write(text);
        }
    }

    public void writeLine(String line) {
        for (IAlgorithmConsoleWriter writer : writers) {
            writer.writeLine(line);
        }
    }

    public void writeLine() {
        writeLine("");
    }

    /**
     * Prints a textual separator.
     */
    public void writeSeparator() {
        writeLine("--------------------------");
    }

    /**
     * Prints a textual header.
     * @param header The header.
     */
    public void writeHeader(String header) {
        writeLine();
        writeLine();
        writeLine("---=== " + header + " ===---");
    }

    /**
     * Prints the prompt and the "value" object in a form like "prompt = value".
     * @param prompt The prompt.
     * @param value The value.
     */
    public void writeLine(String prompt, Object value) {
        writeLine(String.format("%s = %s", prompt, value.toString()));
    }
}
