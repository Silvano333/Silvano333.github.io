/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms;

import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmEdge;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmVertex;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.Graph;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.utils.events.CustomActionEvent;
import gianlucacosta86.graphsj2.model.utils.events.EventKey;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;

/**
 *
 * @author Gianluca Costa
 * @param <V>
 * @param <E>
 * @param <G>
 */
public class RunController<V extends Vertex & IAlgorithmVertex, E extends Edge & IAlgorithmEdge, G extends Graph<V, E>> implements IRunController {

    private final EventKey EVENT_KEY = new EventKey();
    private final AlgorithmConsole console;
    private final Algorithm<V, E, G> algorithm;
    private final CustomActionEvent onRunStateChanged = new CustomActionEvent(this, EVENT_KEY);
    private final CustomActionEvent onStepInitiated = new CustomActionEvent(this, EVENT_KEY);
    private final CustomActionEvent onStepCompleted = new CustomActionEvent(this, EVENT_KEY);
    private RunStateEnum runState = RunStateEnum.NOT_RUNNING;
    private GraphCanvas outputCanvas;
    private boolean verboseRun;
    private int currentStep;
    private int completedStep;

    protected RunController(Algorithm<V, E, G> algorithm) {
        this.algorithm = algorithm;

        console = new AlgorithmConsole();
    }

    @Override
    public AlgorithmConsole getConsole() {
        return console;
    }

    @Override
    public GraphCanvas getOutputCanvas() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }
        return outputCanvas;
    }

    @Override
    public G getGraph() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }
        return (G) outputCanvas.getGraph();
    }

    @Override
    public boolean isVerboseRun() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }

        return verboseRun;
    }

    @Override
    public int getCurrentStep() {
        if (!isRunning()) {
            throw new IllegalStateException("Cannot get the current step if the algorithm is not running");
        }
        return currentStep;
    }

    @Override
    public int getCompletedStep() {
        if (!isRunning()) {
            throw new IllegalStateException("Cannot get the completed step if the algorithm is not running");
        }
        return completedStep;
    }

    private void performAlgorithmInitialization() throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        currentStep = 0;
        completedStep = -1;

        G graph = getGraph();


        algorithm.initializeRun(outputCanvas, graph, console, verboseRun);

        for (IAlgorithmVertex vertex : graph.getVertexSet()) {
            vertex.setAlgorithm(algorithm);
        }

        for (IAlgorithmEdge edge : graph.getEdgeSet()) {
            edge.setAlgorithm(algorithm);
        }

        algorithm.postInitializeRun(outputCanvas, getGraph(), console, verboseRun);


        completedStep = 0;
        outputCanvas.fullRepaint();
    }

    private void beginRun(RunStateEnum runState, GraphCanvas outputCanvas, boolean verboseRun) throws AlgorithmRunException {
        if (isRunning()) {
            throw new IllegalStateException("Cannot run : the controller is already running");
        }


        this.outputCanvas = outputCanvas;
        this.verboseRun = verboseRun;

        setRunState(runState);

        try {
            performAlgorithmInitialization();
        } catch (AlgorithmRunException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
            throw ex;
        } catch (AlgorithmInterruptedException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
        } catch (AlgorithmEndedException ex) {
            setRunState(RunStateEnum.ENDED_RUNNING);
        } catch (RuntimeException ex) {
            ex.printStackTrace();
            MessageProvider.getInstance().showErrorBox(ex);
            setRunState(RunStateEnum.NOT_RUNNING);
        }
    }

    @Override
    public void fullRun(GraphCanvas outputCanvas, boolean verboseRun) throws AlgorithmRunException {
        beginRun(RunStateEnum.FULL_RUNNING, outputCanvas, verboseRun);

        while (runState == RunStateEnum.FULL_RUNNING) {
            nextStep();
        }
    }

    @Override
    public void enterStepByStepRun(GraphCanvas outputCanvas, boolean verboseRun) throws AlgorithmRunException {
        beginRun(RunStateEnum.STEP_RUNNING, outputCanvas, verboseRun);
    }

    private void increaseCompletedStepAndNotify() {
        completedStep++;

        onStepCompleted.fire(EVENT_KEY);
    }

    @Override
    public void nextStep() throws AlgorithmRunException {
        if (runState != RunStateEnum.FULL_RUNNING && runState != RunStateEnum.STEP_RUNNING) {
            throw new IllegalStateException("Cannot perform a step: invalid controller mode");
        }


        try {
            currentStep++;
            onStepInitiated.fire(EVENT_KEY);

            algorithm.runStep(outputCanvas, getGraph(), console, verboseRun, currentStep);

            increaseCompletedStepAndNotify();
        } catch (AlgorithmRunException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
            throw ex;
        } catch (AlgorithmInterruptedException ex) {
            algorithm.onInterruptedRun(outputCanvas, getGraph(), console, verboseRun, currentStep);
            setRunState(RunStateEnum.NOT_RUNNING);
        } catch (AlgorithmEndedException ex) {
            algorithm.onEndRun(outputCanvas, getGraph(), console, verboseRun, currentStep);

            increaseCompletedStepAndNotify();
            setRunState(RunStateEnum.ENDED_RUNNING);
        } catch (RuntimeException ex) {
            ex.printStackTrace();
            MessageProvider.getInstance().showErrorBox(ex);
            setRunState(RunStateEnum.NOT_RUNNING);
        } finally {
            outputCanvas.fullRepaint();
        }
    }

    @Override
    public void stopRun() throws AlgorithmRunException {
        if (!isRunning()) {
            throw new IllegalStateException("Cannot stop running, because the RunController is not running");
        }


        try {
            if (runState != RunStateEnum.ENDED_RUNNING) {
                algorithm.onInterruptedRun(outputCanvas, getGraph(), console, verboseRun, currentStep);
            }
        } catch (RuntimeException ex) {
            ex.printStackTrace();
            MessageProvider.getInstance().showErrorBox(ex);
        } finally {
            setRunState(RunStateEnum.NOT_RUNNING);
        }
    }

    @Override
    public void safeStop() throws AlgorithmRunException {
        switch (runState) {
            case FULL_RUNNING:
            case STEP_RUNNING:
            case ENDED_RUNNING:
                stopRun();
                break;
        }

    }

    @Override
    public RunStateEnum getRunState() {
        return runState;
    }

    private void setRunState(RunStateEnum runState) {
        boolean runStateChanged = (runState != this.runState);

        this.runState = runState;

        if (runStateChanged) {
            onRunStateChanged.fire(EVENT_KEY);
        }
    }

    @Override
    public boolean isRunning() {
        return runState != RunStateEnum.NOT_RUNNING;
    }

    @Override
    public String getStepDescription() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }

        return algorithm.getStepDescription(currentStep);
    }

    @Override
    public String getCompletedStepDescription() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }

        return algorithm.getCompletedStepDescription(completedStep);
    }

    @Override
    public CustomActionEvent getOnRunStateChanged() {
        return onRunStateChanged;
    }

    @Override
    public CustomActionEvent getOnStepInitiated() {
        return onStepInitiated;
    }

    @Override
    public CustomActionEvent getOnStepCompleted() {
        return onStepCompleted;
    }
}
