/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.concrete.cpm;

import gianlucacosta86.graphsj2.model.algorithms.standard.StandardVertex;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;

/**
 * The vertex class used by CPM.
 *
 * @author Gianluca Costa
 */
public class CpmVertex extends StandardVertex {

    private static final long serialVersionUID = 1L;
    private int index;
    private IntegerWeightQuantity tmin;
    private IntegerWeightQuantity tmax;

    public CpmVertex(String name) throws InvalidNameException {
        super(name);
    }

    protected int getIndex() {
        return index;
    }

    protected void setIndex(int index) {
        this.index = index;
    }

    protected IntegerWeightQuantity getTmax() {
        return tmax;
    }

    protected void setTmax(IntegerWeightQuantity tmax) {
        this.tmax = tmax;
    }

    protected IntegerWeightQuantity getTmin() {
        return tmin;
    }

    protected void setTmin(IntegerWeightQuantity tmin) {
        this.tmin = tmin;
    }

    @Override
    public int compareTo(Object o) {
        CpmVertex other = (CpmVertex) o;

        int comparisonResult = new Integer(index).compareTo(other.index);

        if (comparisonResult == 0) {
            return super.compareTo(o);
        }

        return comparisonResult;
    }

    @Override
    protected String getRunningLabel() {
        switch (getAlgorithm().getRunController().getCompletedStep()) {
            case 0:
                return String.format("%s {%d}", getName(), index);

            case 1:
                return String.format("%s {%d, %s}", getName(), index, tmin.toString());

            default:
                return String.format("%s {%d, %s, %s}", getName(), index, tmin.toString(), tmax.toString());
        }
    }
}
