/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.standard.optionsdialog;

import gianlucacosta86.graphsj2.model.algorithms.standard.StandardAlgorithm;
import gianlucacosta86.graphsj2.view.dialogs.customdialog.CustomDialog;
import java.awt.Color;

/**
 *
 * @author Gianluca Costa
 */
public class StandardOptionsDialog extends CustomDialog<StandardOptionsPanel> {

    public StandardOptionsDialog(StandardAlgorithm algorithm) {
        super(
                String.format("Options for '%s'...", algorithm.getAlgorithmName()),
                true,
                new StandardOptionsPanel(algorithm));
    }

    /**
     *
     * @return The color used to enhance the edges contained in step-by-step solutions.
     */
    public Color getStepSolutionColor() {
        return getPanel().getStepSolutionColor();
    }

    /**
     * Sets the color used to enhance edges contained in step-by-step solutions.
     * @param newColor The new color
     */
    public void setStepSolutionColor(Color newColor) {
        getPanel().setStepSolutionColor(newColor);
    }

    /**
     *
     * @return The color used to enhance edges in the last solution.
     */
    public Color getSolutionColor() {
        return getPanel().getSolutionColor();
    }

    /**
     * Sets the color used to enhance edges in the last solution.
     * @param newColor The new color
     */
    public void setSolutionColor(Color newColor) {
        getPanel().setSolutionColor(newColor);
    }
}
