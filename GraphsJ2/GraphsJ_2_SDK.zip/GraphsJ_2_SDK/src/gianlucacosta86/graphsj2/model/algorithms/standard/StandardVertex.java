/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.standard;

import gianlucacosta86.graphsj2.model.algorithms.IAlgorithm;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmVertex;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;

/**
 * @author Gianluca Costa
 */
public abstract class StandardVertex extends Vertex implements IAlgorithmVertex {

    private static final long serialVersionUID = 1;
    private IAlgorithm algorithm;

    public StandardVertex(String name) throws InvalidNameException {
        super(name);
    }

    @Override
    public void setAlgorithm(IAlgorithm algorithm) {
        this.algorithm = algorithm;
    }

    /**
     *
     * @return The string representation of the vertex.
     */
    @Override
    public String toString() {
        if (algorithm != null) {
            return getRunningLabel();
        } else {
            return super.toString();
        }
    }

    /**
     *
     * @return The vertex label to show during the algorithm execution.
     */
    protected abstract String getRunningLabel();

    /**
     *
     * @return The algorithm with which the vertex is associated.
     * It is set by the StandardAlgorithm when the algorithm execution begins.
     */
    protected IAlgorithm getAlgorithm() {
        return algorithm;
    }
}
