/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.concrete.fordfulkerson;

import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.startstop.StartStopAlgorithm;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.InvalidWeightException;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import java.util.Collections;

/**
 * Ford-Fulkerson's flow algorithm.
 *
 * @author Gianluca Costa
 */
public class FordFulkerson extends StartStopAlgorithm<FordFulkersonVertex, FordFulkersonEdge, IntegerWeightedGraph<FordFulkersonVertex, FordFulkersonEdge>> {

    private static final long serialVersionUID = 1L;
    private FordFulkersonVertex startVertex;
    private FordFulkersonVertex stopVertex;
    private EdgeList<FordFulkersonEdge> incChain;

    @Override
    protected Iterable<FordFulkersonEdge> getStepSolutionEdges(int currentStep) {
        return incChain;
    }

    @Override
    protected Iterable<FordFulkersonEdge> getSolutionEdges() {
        return incChain;
    }

    @Override
    protected IGraphFactory buildGraphFactory() {
        return new FordFulkersonFactory();
    }

    @Override
    public String getAlgorithmName() {
        return "Ford-Fulkerson's flow algorithm";
    }

    @Override
    public void initializeRun(GraphCanvas canvas, IntegerWeightedGraph<FordFulkersonVertex, FordFulkersonEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(canvas, graph, console, verboseRun);
        startVertex = getStartVertex();
        stopVertex = getStopVertex();
        incChain = null;
    }

    @Override
    protected void postInitializeRun(GraphCanvas canvas, IntegerWeightedGraph<FordFulkersonVertex, FordFulkersonEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        //Just do nothing
    }

    @Override
    protected void onInterruptedRun(GraphCanvas canvas, IntegerWeightedGraph<FordFulkersonVertex, FordFulkersonEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    protected void standardRunStep(GraphCanvas canvas, IntegerWeightedGraph<FordFulkersonVertex, FordFulkersonEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        if (verboseRun) {
            console.writeLine();
            console.writeHeader("Step " + currentStep);
            console.writeLine();
        }


        int currentStepInSeries = currentStep % 3;

        if (currentStepInSeries == 1) {


            incChain = null;

            for (FordFulkersonVertex vertex : graph.getVertexSet()) {
                vertex.setLabeled(false);
                vertex.setExplored(false);
            }

            startVertex.setLabeled(true);
            startVertex.setPlusVk(true);
            startVertex.setVk(null);
            startVertex.setDelta(IntegerWeightQuantity.PLUS_INF);
            startVertex.setExplored(false);



            //The internal iterations begin here
            for (int intraIndex = 1; intraIndex <= graph.getVertexSet().size(); intraIndex++) {

                FordFulkersonVertex vi = null;

                //Here, I get the first vertex available, and set it as "Vi"
                for (FordFulkersonVertex vertex : graph.getVertexList(true)) {

                    if (vertex.isLabeled() && !vertex.isExplored()) {
                        vi = vertex;
                        break;
                    }
                }

                if (vi == null) {
                    break;
                }


                vi.setExplored(true);


                //Here, I set the label for the vertexes belonging to the "gamma+" of Vi
                for (FordFulkersonVertex vj : vi.<FordFulkersonVertex>getExitingVertexes()) {


                    if (vj.isLabeled()) {
                        continue;
                    }

                    FordFulkersonEdge edgeIJ = graph.getEdge(vi, vj);

                    if (edgeIJ.getWeight().getValue() < edgeIJ.getMaxWeight().getValue()) {
                        vj.setLabeled(true);
                        vj.setPlusVk(true);
                        vj.setVk(vi);

                        IntegerWeightQuantity subtraction = edgeIJ.getMaxWeight().subtract(edgeIJ.getWeight());
                        vj.setDelta(vi.getDelta().min(subtraction));
                    }
                }

                //Here, I set the label for the vertexes belonging to the "gamma-" of Vi
                for (FordFulkersonVertex vj : vi.<FordFulkersonVertex>getEnteringVertexes()) {


                    if (vj.isLabeled()) {
                        continue;
                    }

                    FordFulkersonEdge linkJI = graph.getEdge(vj, vi);
                    if (linkJI.getWeight().getValue() > 0) {
                        vj.setLabeled(true);
                        vj.setPlusVk(false);
                        vj.setVk(vi);
                        vj.setDelta(vi.getDelta().min(linkJI.getWeight()));
                    }
                }



                if (stopVertex.isLabeled()) {
                    break;
                }

            }


            //The internal iteration has just ended: I can show the resulting edge weights now, as well as the labels
            if (verboseRun) {
                console.writeLine("Edges at the end of the step: ");

                for (FordFulkersonEdge edge : graph.getEdgeSet()) {
                    console.writeLine(String.format("%s -- %s", edge.getBounds(), edge.toString()));
                }

                console.writeLine();
                console.writeLine();
            }


            if (!stopVertex.isLabeled()) {
                throw new AlgorithmEndedException();
            }

        } else if (currentStepInSeries == 2) {
            //Now I set up the increasing chain
            incChain = new EdgeList<FordFulkersonEdge>();

            FordFulkersonVertex x = stopVertex;
            FordFulkersonVertex y;

            //I update link flows now, by using the "delta*"
            while (x != startVertex) {
                y = x.getVk();
                FordFulkersonEdge augEdge = null;


                if (x.isPlusVk()) {
                    augEdge = graph.getEdge(y, x);
                } else {
                    augEdge = graph.getEdge(x, y);
                }


                x = y;
                incChain.add(augEdge);
            }

            if (verboseRun) {
                Collections.reverse(incChain);
                console.writeLine("Increasing chain", incChain);
                console.writeLine();
            }
        } else { //The last step in a step sequence

            //Here, I get the "delta*" variable for this iteration
            IntegerWeightQuantity deltaStar = stopVertex.getDelta();

            FordFulkersonVertex x = stopVertex;
            FordFulkersonVertex y;


            if (verboseRun) {
                console.writeLine("Delta*", deltaStar);
            }

            //I update link flows now, by using the "delta*"
            while (x != startVertex) {
                y = x.getVk();
                FordFulkersonEdge augEdge = null;

                try {
                    if (x.isPlusVk()) {
                        augEdge = graph.getEdge(y, x);
                        augEdge.setWeight(augEdge.getWeight().sum(deltaStar));
                    } else {
                        augEdge = graph.getEdge(x, y);
                        augEdge.setWeight(augEdge.getWeight().subtract(deltaStar));
                    }
                } catch (InvalidWeightException ex) {
                    throw new AlgorithmRunException(ex);
                }

                x = y;
            }

        }

    }

    @Override
    protected void standardOnEndRun(GraphCanvas canvas, IntegerWeightedGraph<FordFulkersonVertex, FordFulkersonEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //I can get the resulting sets of vertexes
        VertexList<FordFulkersonVertex> v1Set = new VertexList<FordFulkersonVertex>();
        VertexList<FordFulkersonVertex> v2Set = new VertexList<FordFulkersonVertex>();


        for (FordFulkersonVertex vertex : graph.getVertexList(true)) {
            if (vertex.isLabeled()) {
                v1Set.add(vertex);
            } else {
                v2Set.add(vertex);
            }
        }

        v1Set.sort();
        v2Set.sort();

        //Now, I also get the maximum flow value
        IntegerWeightQuantity maxFlow = IntegerWeightQuantity.ZERO;

        incChain = new EdgeList<FordFulkersonEdge>();
        for (FordFulkersonEdge edge : graph.getEdgeSet()) {
            if (v1Set.contains((FordFulkersonVertex) edge.getSource()) && v2Set.contains((FordFulkersonVertex) edge.getTarget())) {
                maxFlow = maxFlow.sum(edge.getMaxWeight());
                incChain.add(edge);
            }
        }

        //I print out the results
        console.writeLine("V1", v1Set.getNamesList());
        console.writeLine("V2", v2Set.getNamesList());

        console.writeLine();

        console.writeLine(String.format("Maximum flow from '%s' to '%s'", startVertex.getName(), stopVertex.getName()), maxFlow);

        console.writeLine("\nThe highlighted edges show the min cut.");
    }
}
