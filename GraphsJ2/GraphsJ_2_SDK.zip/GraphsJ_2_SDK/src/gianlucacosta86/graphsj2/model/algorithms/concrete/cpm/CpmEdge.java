/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.concrete.cpm;

import gianlucacosta86.graphsj2.model.algorithms.IAlgorithm;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmEdge;
import gianlucacosta86.graphsj2.model.graph.GraphObject;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.InvalidWeightException;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.NonNegativeIntegerWeightedEdge;
import gianlucacosta86.graphsj2.model.graph.exceptions.DuplicateEdgeException;
import gianlucacosta86.graphsj2.model.graph.exceptions.GraphException;
import gianlucacosta86.graphsj2.model.graph.uniquefield.UniqueEdgeField;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;
import gianlucacosta86.graphsj2.model.utils.namevalidator.NameValidator;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;

/**
 * The edge class used by CPM.
 *
 * @author Gianluca Costa
 */
public class CpmEdge extends NonNegativeIntegerWeightedEdge implements IAlgorithmEdge {

    private static final long serialVersionUID = 1L;
    private UniqueEdgeField<String> activityName = new UniqueEdgeField<String>(this, "");
    private Cpm algorithm;

    public CpmEdge(Vertex source, Vertex target) {
        super(source, target);
    }

    protected String getActivityName() {
        return activityName.getValue();
    }

    protected void setActivityName(String activityName) throws InvalidNameException, DuplicateActivityException {

        try {
            if (activityName.equals("")) {
                try {
                    setWeight(IntegerWeightQuantity.ZERO);
                } catch (InvalidWeightException ex) {
                    throw new AssertionError();
                }
            } else {
                NameValidator.getInstance().validateName(activityName);
            }

            this.activityName.setValue(activityName);
        } catch (DuplicateEdgeException ex) {
            throw new DuplicateActivityException(String.format("Activity '%s' already exists!", activityName));
        }

    }

    /**
     * @return If the activity name is an empty string, returns an empty string. Otherwise, both the activity name and its duration (the edge weight) are returned in a formatted string.
     */
    @Override
    public String toString() {
        if (activityName.getValue().equals("")) {
            return "";
        } else {
            return String.format("%s, %s", activityName, getWeight().toString());
        }
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return The EST for this activity.
     */
    public IntegerWeightQuantity getEST() {
        if (algorithm == null) {
            throw new IllegalStateException("No algorithm is running now!");
        }

        if (algorithm.getRunController().getCompletedStep() < Cpm.MAX_LABELING_STEP) {
            throw new IllegalStateException("You cannot call this method during this algorithm step!");
        }
        CpmVertex source = (CpmVertex) getSource();
        return source.getTmin();
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return The LST for this activity.
     */
    public IntegerWeightQuantity getLST() {
        if (algorithm == null) {
            throw new IllegalStateException("No algorithm is running now!");
        }

        if (algorithm.getRunController().getCompletedStep() < Cpm.MAX_LABELING_STEP) {
            throw new IllegalStateException("You cannot call this method during this algorithm step!");
        }


        CpmVertex target = (CpmVertex) getTarget();
        return target.getTmax().subtract(getWeight());
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return The S for this activity.
     */
    public IntegerWeightQuantity getS() {
        return getLST().subtract(getEST());
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return True if the activity is critical.
     */
    public boolean isCritical() {
        return getS().getValue() == 0;
    }

    /**
     * Two CPM edges are compared according to the string order of their activity name.
     * @param obj The other edge.
     * @return A proper integer value.
     */
    @Override
    public int compareTo(Object obj) {
        CpmEdge other = (CpmEdge) obj;

        int result = activityName.compareTo(other.activityName);

        if (result != 0) {
            return result;
        }

        return super.compareTo(other);
    }

    @Override
    protected boolean askUserForEditData(GraphCanvas canvas) throws GraphException {
        String newActivityName = MessageProvider.getInstance().askForString("Activity name:", "Edit edge...", activityName.getValue());

        if (newActivityName == null) {
            return false;
        }

        setActivityName(newActivityName);

        if (!newActivityName.equals("")) {
            return super.askUserForEditData(canvas);
        } else {
            return true;
        }
    }

    @Override
    protected void restoreFromObject(GraphObject obj) {
        CpmEdge other = (CpmEdge) obj;
        activityName = other.activityName;

        super.restoreFromObject(obj);
    }

    @Override
    public void setAlgorithm(IAlgorithm algorithm) {
        this.algorithm = (Cpm) algorithm;
    }
}
