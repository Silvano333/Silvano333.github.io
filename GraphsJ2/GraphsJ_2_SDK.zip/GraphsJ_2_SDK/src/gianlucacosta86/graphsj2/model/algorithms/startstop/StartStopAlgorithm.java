/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.algorithms.startstop;

import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmEdge;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmVertex;
import gianlucacosta86.graphsj2.model.algorithms.standard.StandardAlgorithm;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.Graph;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.exceptions.EmptyGraphException;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.VertexChooser;

/**
 * @author Gianluca Costa
 */
public abstract class StartStopAlgorithm<V extends Vertex & IAlgorithmVertex, E extends Edge & IAlgorithmEdge, G extends Graph<V, E>> extends StandardAlgorithm<V, E, G> {

    private static final long serialVersionUID = 1;
    private V startVertex = null;
    private V stopVertex = null;

    @Override
    public void initializeRun(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(canvas, graph, console, verboseRun);


        VertexChooser<V, E> vertexChooser = new VertexChooser<V, E>(graph);
        try {
            startVertex = vertexChooser.askForVertex("Choose the source ('start') vertex:", getAlgorithmName());
            if (startVertex == null) {
                throw new AlgorithmInterruptedException();
            }

            if (startVertex.getInDegree() > 0) {
                throw new AlgorithmRunException("The source vertex cannot have incoming edges");
            }


            stopVertex = vertexChooser.askForVertex("Choose the target ('stop') vertex:", getAlgorithmName());
            if (stopVertex == null) {
                throw new AlgorithmInterruptedException();
            }


            if (stopVertex.getOutDegree() > 0) {
                throw new AlgorithmRunException("The target vertex cannot have outgoing edges");
            }

        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException("No vertexes in this graph!");
        }


        if (startVertex == stopVertex) {
            throw new AlgorithmRunException("The source vertex and the target vertex cannot be the same!");
        }
    }

    /**
     *
     * @return The start vertex provided by the user.
     */
    protected V getStartVertex() {
        return startVertex;
    }

    /**
     *
     * @return The stop vertex provided by the user.
     */
    protected V getStopVertex() {
        return stopVertex;
    }
}
