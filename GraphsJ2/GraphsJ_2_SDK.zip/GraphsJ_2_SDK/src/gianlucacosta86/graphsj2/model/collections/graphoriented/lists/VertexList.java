/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.collections.graphoriented.lists;

import gianlucacosta86.graphsj2.model.collections.graphoriented.IVertexCollection;
import java.util.Collection;
import java.util.Collections;

import gianlucacosta86.graphsj2.model.graph.Vertex;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gianluca Costa
 * @param <V>
 */
public class VertexList<V extends Vertex> extends GraphObjectList<V> implements IVertexCollection<V> {

    private static final long serialVersionUID = 1;

    public VertexList() {
        super();
    }

    public VertexList(boolean keepSorted) {
        super(keepSorted);
    }

    public VertexList(Collection<? extends V> source, boolean keepSorted) {
        super(source, keepSorted);
    }

    @Override
    public void sort() {
        Collections.sort(getInternalList());
    }

    /**
     * @return A list of the vertex names, in the list order
     */
    @Override
    public List<String> getNamesList() {
        List<String> result = new ArrayList<String>();

        for (V vertex : this) {
            result.add(vertex.getName());
        }

        return result;
    }
}
