/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.collections.general;

import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 *
 * @author Gianluca Costa
 */
public class SimpleStack<T> implements Serializable {

    private static final long serialVersionUID = 1;
    private final Deque<T> internalDeque = new ArrayDeque<T>();
    private final int maxSize;

    public SimpleStack() {
        this(0);
    }

    public SimpleStack(int maxSize) {
        if (maxSize < 0) {
            throw new IllegalArgumentException("It must be maxSize >= 0");
        }

        this.maxSize = maxSize;
    }

    public void push(T element) {
        if (maxSize > 0 && internalDeque.size() == maxSize) {
            internalDeque.removeFirst();
        }

        internalDeque.addLast(element);
    }

    public T pop() {
        return internalDeque.removeLast();
    }

    public T peek() {
        return internalDeque.peekLast();
    }

    public boolean isEmpty() {
        return internalDeque.isEmpty();
    }

    public void clear() {
        internalDeque.clear();
    }

    public int size() {
        return internalDeque.size();
    }

    public int getMaxSize() {
        return maxSize;
    }

    @Override
    public String toString() {
        return internalDeque.toString();
    }
}
