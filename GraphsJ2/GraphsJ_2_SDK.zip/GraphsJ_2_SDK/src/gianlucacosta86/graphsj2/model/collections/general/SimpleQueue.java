/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.collections.general;

import gianlucacosta86.graphsj2.model.utils.events.CustomActionEvent;
import gianlucacosta86.graphsj2.model.utils.events.EventKey;
import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Iterator;

/**
 *
 * @author Gianluca Costa
 */
public class SimpleQueue<T> implements Collection<T>, Serializable {

    private static final long serialVersionUID = 1;
    private final EventKey EVENT_KEY = new EventKey();
    private final boolean useReversedIterator;
    private final CustomActionEvent onModified = new CustomActionEvent(this, EVENT_KEY);
    private final ArrayDeque<T> internalDeque;

    public SimpleQueue() {
        this(false);
    }

    public SimpleQueue(boolean useReversedIterator) {
        this.useReversedIterator = useReversedIterator;
        internalDeque = new ArrayDeque<T>();
    }

    public SimpleQueue(Collection<? extends T> source) {
        this(source, false);
    }

    public SimpleQueue(Collection<? extends T> source, boolean useReversedIterator) {
        this.useReversedIterator = useReversedIterator;
        internalDeque = new ArrayDeque<T>(source);
    }

    protected ArrayDeque<T> getInternalDeque() {
        return internalDeque;
    }

    @Override
    public boolean add(T element) {
        internalDeque.addLast(element);

        onModified.fire(EVENT_KEY);
        return true;
    }

    public T remove() {
        T result = internalDeque.removeFirst();
        onModified.fire(EVENT_KEY);
        return result;
    }

    @Override
    public boolean remove(Object element) {
        boolean result = internalDeque.remove((T) element);

        if (result) {
            onModified.fire(EVENT_KEY);
        }

        return result;
    }

    @Override
    public void clear() {
        int initialSize = size();
        internalDeque.clear();

        if (initialSize > 0) {
            onModified.fire(EVENT_KEY);
        }
    }

    @Override
    public boolean addAll(Collection<? extends T> c) {
        boolean result = internalDeque.addAll(c);

        if (result) {
            onModified.fire(EVENT_KEY);
        }

        return result;
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        boolean result = internalDeque.removeAll(c);

        if (result) {
            onModified.fire(EVENT_KEY);
        }

        return result;
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        boolean result = internalDeque.retainAll(c);

        if (result) {
            onModified.fire(EVENT_KEY);
        }

        return result;
    }

    @Override
    public int size() {
        return internalDeque.size();
    }

    @Override
    public boolean isEmpty() {
        return internalDeque.isEmpty();
    }

    public T peek() {
        return internalDeque.peekFirst();
    }

    @Override
    public Iterator<T> iterator() {
        if (useReversedIterator) {
            return getReversedIterator();
        } else {
            return getDirectIterator();
        }
    }

    public Iterator<T> getDirectIterator() {
        return internalDeque.iterator();
    }

    public Iterator<T> getReversedIterator() {
        return internalDeque.descendingIterator();
    }

    @Override
    public String toString() {
        return internalDeque.toString();
    }

    public CustomActionEvent getOnModified() {
        return onModified;
    }

    @Override
    public boolean contains(Object o) {
        return internalDeque.contains((T) o);
    }

    @Override
    public Object[] toArray() {
        return internalDeque.toArray();
    }

    @Override
    public <T> T[] toArray(T[] a) {
        return internalDeque.toArray(a);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return internalDeque.containsAll(c);
    }
}
