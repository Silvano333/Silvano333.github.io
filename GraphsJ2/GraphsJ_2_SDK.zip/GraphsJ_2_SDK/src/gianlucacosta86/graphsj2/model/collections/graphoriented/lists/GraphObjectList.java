/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.collections.graphoriented.lists;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import gianlucacosta86.graphsj2.model.graph.GraphObject;

/**
 *
 * @author Gianluca Costa
 * @param <T>
 */
public abstract class GraphObjectList<T extends GraphObject> implements List<T> {

    private static final long serialVersionUID = 1;
    private final List<T> internalList;
    private boolean keepSorted;

    public GraphObjectList() {
        this(null, false);
    }

    public GraphObjectList(boolean keepSorted) {
        this(null, keepSorted);
    }

    public GraphObjectList(Collection<? extends T> source, boolean keepSorted) {
        if (source == null) {
            internalList = new ArrayList<T>();
        } else {
            internalList = new ArrayList<T>(source);

            if (keepSorted) {
                sort();
            }
        }
    }

    public boolean isKeepSorted() {
        return keepSorted;
    }

    public void setKeepSorted(boolean keepSorted) {
        this.keepSorted = keepSorted;

        if (keepSorted) {
            sort();
        }
    }

    protected void tryToSort(boolean operationResult) {
        if (operationResult && keepSorted) {
            sort();
        }
    }

    public abstract void sort();

    protected List<T> getInternalList() {
        return internalList;
    }

    
    @Override
    public void add(int index, T element) {
        internalList.add(index, element);
    }

    @Override
    public boolean add(T e) {
        boolean result = internalList.add(e);

        tryToSort(result);

        return result;
    }

    @Override
    public boolean addAll(Collection<? extends T> c) {
        boolean result = internalList.addAll(c);

        tryToSort(result);

        return result;
    }

    @Override
    public boolean addAll(int index, Collection<? extends T> c) {
        return internalList.addAll(index, c);
    }

    @Override
    public void clear() {
        internalList.clear();
    }

    @Override
    public boolean contains(Object o) {
        return internalList.contains((T) o);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return internalList.containsAll(c);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof GraphObjectList)) {
            return false;
        }

        GraphObjectList other = (GraphObjectList) o;
        return internalList.equals(other.internalList);
    }

    @Override
    public T get(int index) {
        return internalList.get(index);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public int indexOf(Object o) {
        return internalList.indexOf(o);
    }

    @Override
    public boolean isEmpty() {
        return internalList.isEmpty();
    }

    @Override
    public Iterator<T> iterator() {
        return internalList.iterator();
    }

    @Override
    public int lastIndexOf(Object o) {
        return internalList.lastIndexOf(o);
    }

    @Override
    public ListIterator<T> listIterator() {
        return internalList.listIterator();
    }

    @Override
    public ListIterator<T> listIterator(int index) {
        return internalList.listIterator(index);
    }

    @Override
    public T remove(int index) {
        return internalList.remove(index);
    }

    @Override
    public boolean remove(Object o) {
        return internalList.remove((T) o);
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return internalList.removeAll(c);
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        return internalList.retainAll(c);
    }

    @Override
    public T set(int index, T element) {
        T result = internalList.set(index, element);

        tryToSort(true);

        return result;
    }

    @Override
    public int size() {
        return internalList.size();
    }

    @Override
    public List<T> subList(int fromIndex, int toIndex) {
        return internalList.subList(fromIndex, toIndex);
    }

    @Override
    public Object[] toArray() {
        return internalList.toArray();
    }

    @Override
    public <T2> T2[] toArray(T2[] a) {
        return internalList.toArray(a);
    }

    @Override
    public String toString() {
        return internalList.toString();
    }
}
