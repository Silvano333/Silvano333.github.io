/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.utils.events;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.EventListener;
import java.util.EventObject;
import java.util.List;

/**
 *
 * @author Gianluca Costa
 */
public abstract class CustomEvent<ListenerType extends EventListener, EventType extends EventObject> implements Serializable {

    private static final long serialVersionUID = 1;
    private transient List<ListenerType> listeners = new ArrayList<ListenerType>();
    private final Object sender;
    private final EventKey key;

    public CustomEvent(Object sender, EventKey key) {
        this.sender = sender;
        this.key = key;
    }

    protected Object getSender() {
        return sender;
    }

    public void add(ListenerType listener) {
        listeners.add(listener);
    }

    public void remove(ListenerType listener) {
        listeners.remove(listener);
    }

    protected void fire(EventKey key, Object... eventCreationArgs) {
        validateCaller(key);

        EventType event = createEvent(eventCreationArgs);

        for (ListenerType listener : listeners) {
            notifyListener(listener, event);
        }
    }

    protected void validateCaller(EventKey key) {
        if (this.key != null && this.key != key) {
            throw new IllegalArgumentException("Cannot fire an event without the proper key!");
        }
    }

    protected abstract EventType createEvent(Object... eventCreationArgs);

    protected abstract void notifyListener(ListenerType listener, EventType event);

    public void clear(EventKey key) {
        validateCaller(key);
        listeners.clear();
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        listeners = new ArrayList<ListenerType>();
    }
}
