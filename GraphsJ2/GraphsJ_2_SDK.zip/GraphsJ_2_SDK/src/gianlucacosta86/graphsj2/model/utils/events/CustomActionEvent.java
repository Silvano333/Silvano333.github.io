/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.utils.events;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Gianluca Costa
 */
public class CustomActionEvent extends CustomEvent<ActionListener, ActionEvent> {

    private static final long serialVersionUID = 1;

    public CustomActionEvent(Object sender, EventKey key) {
        super(sender, key);
    }

    @Override
    protected ActionEvent createEvent(Object... eventCreationArgs) {
        return new ActionEvent(getSender(), 0, null);
    }

    @Override
    protected void notifyListener(ActionListener listener, ActionEvent event) {
        listener.actionPerformed(event);
    }

    public void fire(EventKey key) {
        super.fire(key);
    }
}
