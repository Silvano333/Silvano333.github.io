/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.utils.undoprovider;

import gianlucacosta86.graphsj2.model.collections.general.SimpleStack;
import gianlucacosta86.graphsj2.model.utils.Duplicator;
import gianlucacosta86.graphsj2.model.utils.events.CustomActionEvent;
import gianlucacosta86.graphsj2.model.utils.events.EventKey;
import java.io.Serializable;

/**
 *
 * @author Gianluca Costa
 */
public class UndoProvider<T extends Serializable> implements IReadOnlyUndoProvider<T> {

    private final EventKey EVENT_KEY = new EventKey();
    private final SimpleStack<T> stateStack;
    private final SimpleStack<T> undoneStack;
    private final CustomActionEvent onStateChanged = new CustomActionEvent(this, EVENT_KEY);
    private boolean undoable;
    private boolean redoable;

    public UndoProvider(T initialState, int maxUndoCount) {

        stateStack = new SimpleStack<T>(maxUndoCount + 1);
        undoneStack = new SimpleStack<T>(maxUndoCount);

        stateStack.push((T) Duplicator.singleCopy(initialState));
    }

    @Override
    public CustomActionEvent getOnStateChanged() {
        return onStateChanged;
    }

    @Override
    public boolean isUndoable() {
        return undoable;
    }

    @Override
    public boolean isRedoable() {
        return redoable;
    }

    private void refreshState() {
        boolean oldUndoable = undoable;
        boolean oldRedoable = redoable;

        undoable = stateStack.size() > 1;
        redoable = undoneStack.size() > 0;

        boolean changed = (undoable != oldUndoable) || (redoable != oldRedoable);

        if (changed) {
            onStateChanged.fire(EVENT_KEY);
        }
    }

    @Override
    public T undo() {
        if (!undoable) {
            throw new IllegalStateException("Cannot undo!");
        }

        T undoneState = stateStack.pop();

        undoneStack.push(undoneState);

        refreshState();

        return (T) Duplicator.singleCopy(stateStack.peek());
    }

    @Override
    public T redo() {
        if (!redoable) {
            throw new IllegalStateException("Cannot redo!");
        }

        T lastState = undoneStack.pop();
        stateStack.push(lastState);

        refreshState();

        return (T) Duplicator.singleCopy(lastState);
    }

    public void put(T state) {
        T stateCopy = (T) Duplicator.singleCopy(state);

        stateStack.push(stateCopy);
        undoneStack.clear();

        refreshState();
    }

    public void clear() {
        stateStack.clear();
        undoneStack.clear();

        refreshState();
    }
}
