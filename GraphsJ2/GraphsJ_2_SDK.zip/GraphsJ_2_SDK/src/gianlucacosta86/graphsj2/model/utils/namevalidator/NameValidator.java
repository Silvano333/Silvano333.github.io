/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.utils.namevalidator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Validates names, for example for vertexes.
 *
 * @author Gianluca Costa
 */
public final class NameValidator {

    private static final NameValidator instance = new NameValidator();
    private static final Pattern VALID_PATTERN = Pattern.compile("\\A[\\w\\ _]+\\z");

    private NameValidator() {
    }

    public static NameValidator getInstance() {
        return instance;

    }

    public void validateName(String name) throws InvalidNameException {
        if (name == null) {
            throw new InvalidNameException("The name cannot be null");
        }

        if (name.equals("")) {
            throw new InvalidNameException("The name cannot be empty");
        }


        Matcher matcher = VALID_PATTERN.matcher(name);
        if (!matcher.matches()) {
            throw new InvalidNameException("Invalid name: only letters, digits, the underscore and the space are accepted");
        }

    }
}
