/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 *
 * @author Gianluca Costa
 */
public final class PropertyManager {

    private static final PropertyManager instance = new PropertyManager();

    public static PropertyManager getInstance() {
        return instance;
    }

    private PropertyManager() {
    }

    public Method getGetter(Object target, String propertyName) {
        try {
            return target.getClass().getMethod("get" + propertyName);
        } catch (NoSuchMethodException ex) {
            return null;
        } catch (SecurityException ex) {
            return null;
        }
    }

    public Method getSetter(Object target, String propertyName, Class<?> propertyClass) {
        try {
            return target.getClass().getMethod("set" + propertyName, propertyClass);
        } catch (NoSuchMethodException ex) {
            return null;
        } catch (SecurityException ex) {
            return null;
        }
    }

    public boolean propertyExists(Object target, String propertyName, Class<?> propertyClass) {
        return (getGetter(target, propertyName) != null) && (getSetter(target, propertyName, propertyClass) != null);
    }

    public void assertPropertyExistence(Object target, String propertyName, Class<?> propertyClass) {
        if (!propertyExists(target, propertyName, propertyClass)) {
            throw new IllegalArgumentException("Inexisting property: " + propertyName);
        }
    }

    public Object readProperty(Object target, String propertyName) throws InvocationTargetException {

        try {
            Method getter = getGetter(target, propertyName);

            if (getter == null) {
                throw new IllegalArgumentException("Inexisting getter");
            }

            return getter.invoke(target);
        } catch (SecurityException ex) {
            throw new IllegalArgumentException();
        } catch (IllegalAccessException ex) {
            throw new IllegalArgumentException();
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException();
        }
    }

    public <T> void setProperty(Object target, String propertyName, Class<T> propertyType, T value) throws InvocationTargetException {
        try {
            Method setter = getSetter(target, propertyName, propertyType);

            if (setter == null) {
                throw new IllegalArgumentException("Inexisting setter");
            }

            setter.invoke(target, value);
        } catch (SecurityException ex) {
            throw new IllegalArgumentException();
        } catch (IllegalAccessException ex) {
            throw new IllegalArgumentException();
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException();
        }
    }
}
