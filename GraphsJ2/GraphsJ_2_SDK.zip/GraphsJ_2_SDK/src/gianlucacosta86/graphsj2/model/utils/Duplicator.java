/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.utils;

import gianlucacosta86.graphsj2.model.utils.io.LoaderBasedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author Gianluca Costa
 */
public class Duplicator {

    private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();
    private ObjectOutputStream outputStream;
    private LoaderBasedInputStream inputStream;
    private boolean inReadMode;

    public Duplicator() {
        try {
            outputStream = new ObjectOutputStream(buffer);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public void put(Serializable obj) {
        if (inReadMode) {
            throw new IllegalStateException("You cannot write objects after the first reading call");
        }

        try {
            outputStream.writeObject(obj);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public Object get() {

        try {
            if (!inReadMode) {
                outputStream.close();
                inputStream = new LoaderBasedInputStream(new ByteArrayInputStream(buffer.toByteArray()));
                inReadMode = true;
            }

            return inputStream.readObject();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }
    }

    public void close() {
        try {
            if (inputStream != null) {
                inputStream.close();
            } else {
                outputStream.close();
            }


            buffer.reset();
            buffer.close();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static Object singleCopy(Serializable obj) {
        Duplicator singleDuplicator = new Duplicator();
        singleDuplicator.put(obj);
        return singleDuplicator.get();
    }
}
