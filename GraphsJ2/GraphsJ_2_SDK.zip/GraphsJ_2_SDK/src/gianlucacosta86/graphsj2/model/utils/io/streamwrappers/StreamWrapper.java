/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.model.utils.io.streamwrappers;

import java.io.IOException;

/**
 *
 * @author Gianluca Costa
 */
public abstract class StreamWrapper<T> {

    private IOException performanceException;
    private IOException closingException;

    public boolean perform() {
        boolean result = false;
        T stream = null;

        try {
            stream = buildStream();
            useStream(stream);
            result = true;
        } catch (IOException ex) {
            performanceException = ex;
            handleIOException(ex);
        } finally {
            if (stream != null) {
                try {
                    closeStream(stream);
                } catch (IOException ex) {
                    closingException = ex;
                    handleCloseException(ex);
                    result = false;
                }
            }
        }

        return result;
    }

    protected abstract T buildStream() throws IOException;

    protected abstract void useStream(T stream) throws IOException;

    protected abstract void closeStream(T stream) throws IOException;

    protected abstract void handleIOException(IOException ex);

    protected abstract void handleCloseException(IOException ex);

    public IOException getPerformanceException() {
        return performanceException;
    }

    public IOException getClosingException() {
        return closingException;
    }
}
