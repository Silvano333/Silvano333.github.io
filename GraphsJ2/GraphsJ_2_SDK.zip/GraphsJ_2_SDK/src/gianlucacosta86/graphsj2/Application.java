/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2;

import gianlucacosta86.graphsj2.view.frames.main.MainFrame;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.metal.MetalLookAndFeel;

/**
 *
 * @author Gianluca Costa
 */
public final class Application {

    public static final String NAME = "GraphsJ";
    public static final String VERSION = "2.5";
    public static final String TITLE = NAME + " " + VERSION;
    public static final ImageIcon SMALL_ICON = new ImageIcon(Application.class.getResource("SmallIcon.png"));
    public static final ImageIcon BIG_ICON = new ImageIcon(Application.class.getResource("BigIcon.png"));
    public static final ImageIcon HUGE_ICON = new ImageIcon(Application.class.getResource("HugeIcon.png"));
    private static final Pattern LAF_PATTERN = Pattern.compile("-{1,2}laf=(\\S+)");

    private Application() {
    }

    /**
     * The program's entry point
     * @param args The command-line arguments
     */
    public static void main(String[] args) {
        setLookAndFeel(args);
        MainFrame mainFrame = new MainFrame();
        mainFrame.setVisible(true);
    }

    private static void setLookAndFeel(String[] args) {
        String desiredLookAndFeelName = UIManager.getSystemLookAndFeelClassName();


        for (String arg : args) {
            Matcher lafMatcher = LAF_PATTERN.matcher(arg);

            if (lafMatcher.matches()) {
                desiredLookAndFeelName = lafMatcher.group(1);
                break;
            }
        }

        try {
            Class<? extends LookAndFeel> desiredLookAndFeel = (Class<? extends LookAndFeel>) Class.forName(desiredLookAndFeelName);

            UIManager.setLookAndFeel(desiredLookAndFeel.newInstance());
        } catch (Exception ex) {
            try {
                UIManager.setLookAndFeel(new MetalLookAndFeel());
            } catch (UnsupportedLookAndFeelException ex2) {
                //Just do nothing
            }
        }
    }
}
