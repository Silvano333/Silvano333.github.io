/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.components.graphcanvas.drawers;

/**
 *
 * @author Gianluca Costa
 */
public class DrawerSelection extends DrawerQueue {

    private static final long serialVersionUID = 1;

    public DrawerSelection() {
        super(false);
    }

    @Override
    public void add(Drawer drawer) {
        super.add(drawer);
        drawer.setSelected(true);
    }

    @Override
    public void remove(Drawer drawer) {
        drawer.setSelected(false);
        super.remove(drawer);
    }

    @Override
    public void clear() {

        for (Drawer drawer : this) {
            drawer.setSelected(false);
        }

        super.clear();
    }
}
