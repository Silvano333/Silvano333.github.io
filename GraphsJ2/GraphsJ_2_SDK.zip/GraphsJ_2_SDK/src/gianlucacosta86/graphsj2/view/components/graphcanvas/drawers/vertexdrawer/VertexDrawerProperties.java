/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.vertexdrawer;

import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.DrawerProperties;
import java.awt.Color;
import java.awt.Font;

/**
 *
 * @author Gianluca Costa
 */
public class VertexDrawerProperties extends DrawerProperties {

    private static final long serialVersionUID = 1;
    private static Font DEFAULT_FONT = new Font("Arial", Font.BOLD, 16);
    private Font font = DEFAULT_FONT;
    private Color fontColor = Color.BLACK;
    private Color color = Color.ORANGE;
    private Color selectedFontColor = Color.BLACK;
    private Color selectedColor = Color.decode("#CCFFFF");
    private int padding = 3;
    private int borderSize = 2;
    private Color borderColor = Color.BLACK;
    private Color selectedBorderColor = Color.GRAY;

    public Font getFont() {
        return font;
    }

    public void setFont(Font font) {
        if (font == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.font = font;
    }

    public int getFontSize() {
        return font.getSize();
    }

    public void setFontSize(int size) {
        font = new Font(font.getName(), font.getStyle(), size);
    }

    public Color getFontColor() {
        return fontColor;
    }

    public void setFontColor(Color fontColor) {
        if (fontColor == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.fontColor = fontColor;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        if (color == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.color = color;
    }

    public Color getSelectedFontColor() {
        return selectedFontColor;
    }

    public void setSelectedFontColor(Color selectedFontColor) {
        if (selectedFontColor == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.selectedFontColor = selectedFontColor;
    }

    public Color getSelectedColor() {
        return selectedColor;
    }

    public void setSelectedColor(Color selectedColor) {
        if (selectedColor == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }
        this.selectedColor = selectedColor;
    }

    public int getPadding() {
        return padding;
    }

    public void setPadding(int padding) {
        if (padding < 0) {
            throw new IllegalArgumentException("The value must be >= 0");
        }

        this.padding = padding;
    }

    public Color getBorderColor() {
        return borderColor;
    }

    public void setBorderColor(Color borderColor) {
        if (borderColor == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.borderColor = borderColor;
    }

    public Color getSelectedBorderColor() {
        return selectedBorderColor;
    }

    public void setSelectedBorderColor(Color selectedBorderColor) {
        if (selectedBorderColor == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.selectedBorderColor = selectedBorderColor;
    }

    public int getBorderSize() {
        return borderSize;
    }

    public void setBorderSize(int borderSize) {
        if (borderSize < 0) {
            throw new IllegalArgumentException("The value must be >= 0");
        }

        this.borderSize = borderSize;
    }

    @Override
    public VertexDrawerProperties clone() {
        return (VertexDrawerProperties) super.clone();
    }
}
