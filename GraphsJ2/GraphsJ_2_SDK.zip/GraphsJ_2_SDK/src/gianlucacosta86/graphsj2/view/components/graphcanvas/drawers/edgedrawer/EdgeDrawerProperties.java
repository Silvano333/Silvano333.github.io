/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.edgedrawer;

import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.DrawerProperties;
import java.awt.Color;
import java.awt.Font;

/**
 *
 * @author Gianluca Costa
 */
public class EdgeDrawerProperties extends DrawerProperties {

    private static final long serialVersionUID = 1;
    private static Font DEFAULT_FONT = new Font("Arial", Font.BOLD, 14);
    private Font font = DEFAULT_FONT;
    private Color fontColor = Color.BLACK;
    private Color color = Color.decode("#99FF99");
    private Color selectedFontColor = Color.BLACK;
    private Color selectedColor = Color.decode("#CCCCFF");
    private int lineSize = 3;

    public Font getFont() {
        return font;
    }

    public void setFont(Font font) {
        if (font == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.font = font;
    }

    public int getFontSize() {
        return font.getSize();
    }

    public void setFontSize(int size) {
        font = new Font(font.getName(), font.getStyle(), size);
    }

    public Color getFontColor() {
        return fontColor;
    }

    public void setFontColor(Color fontColor) {
        if (fontColor == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.fontColor = fontColor;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        if (color == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.color = color;
    }

    public Color getSelectedFontColor() {
        return selectedFontColor;
    }

    public void setSelectedFontColor(Color selectedFontColor) {
        if (selectedFontColor == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }

        this.selectedFontColor = selectedFontColor;
    }

    public Color getSelectedColor() {
        return selectedColor;
    }

    public void setSelectedColor(Color selectedColor) {
        if (selectedColor == null) {
            throw new IllegalArgumentException("The value cannot be null");
        }
        this.selectedColor = selectedColor;
    }

    public int getLineSize() {
        return lineSize;
    }

    public void setLineSize(int lineSize) {
        if (lineSize <= 0) {
            throw new IllegalArgumentException("The value must be >= 1");
        }

        this.lineSize = lineSize;
    }

    @Override
    public EdgeDrawerProperties clone() {
        return (EdgeDrawerProperties) super.clone();
    }
}
