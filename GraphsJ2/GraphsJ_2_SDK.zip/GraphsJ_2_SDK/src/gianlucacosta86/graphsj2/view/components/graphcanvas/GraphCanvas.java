/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.components.graphcanvas;

import gianlucacosta86.graphsj2.AppPreferences;
import gianlucacosta86.graphsj2.Application;
import gianlucacosta86.graphsj2.model.graph.topologyevent.TopologyEvent;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.Drawer;
import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.IGraph;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.exceptions.DuplicateEdgeException;
import gianlucacosta86.graphsj2.model.graph.exceptions.DuplicateVertexException;
import gianlucacosta86.graphsj2.model.graph.topologyevent.TopologyListener;
import gianlucacosta86.graphsj2.model.utils.Duplicator;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;
import gianlucacosta86.graphsj2.model.utils.namevalidator.NameValidator;
import gianlucacosta86.graphsj2.model.utils.undoprovider.UndoProvider;
import gianlucacosta86.graphsj2.model.utils.events.CustomActionEvent;
import gianlucacosta86.graphsj2.model.utils.events.EventKey;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.DrawerQueue;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.edgedrawer.EdgeDrawer;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.vertexdrawer.VertexDrawer;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.DrawerSelection;

import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.edgedrawer.EdgeDrawerProperties;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.vertexdrawer.VertexDrawerProperties;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;

import gianlucacosta86.graphsj2.view.geometric.PointUtils;
import gianlucacosta86.graphsj2.view.geometric.rectangles.PreciseRectangle;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 *
 * @author Gianluca Costa
 */
public class GraphCanvas extends JPanel implements Cloneable {

    private static final long serialVersionUID = 1;
    private static final Dimension DEFAULT_SIZE = new Dimension(800, 600);
    private static final int USELESS_SELECTION_RECTANGLE_SIZE = 3;
    private final EventKey EVENT_KEY = new EventKey();
    private IGraphFactory graphFactory;
    private IGraph graph;
    private DrawerQueue drawers;
    private final DrawerSelection selectedDrawers;
    private String vertexNameRoot = "V";
    private int vertexNameCounter = 1;
    private boolean editable = true;
    private boolean responsive = true;
    private transient PreciseRectangle selectionRectangle;
    private transient Point lastLeftDragPoint;
    private transient EdgeDrawer rightClickedEdgeDrawer;
    private transient Point rightClickedEdgePoint;
    private transient Point draggedEdgeSplitPoint;
    private transient boolean forbidModificationMarking;
    private transient boolean selectionWasMoved;
    private transient boolean modified;
    private transient UndoProvider<GraphCanvasUndoToken> undoProvider;
    private transient int lastClickCount;
    private VertexDrawerProperties defaultVertexDrawerProperties = new VertexDrawerProperties();
    private EdgeDrawerProperties defaultEdgeDrawerProperties = new EdgeDrawerProperties();
    private final CustomActionEvent onModifiedChanged = new CustomActionEvent(this, EVENT_KEY);

    public GraphCanvas(IGraphFactory graphFactory) {
        this.graphFactory = graphFactory;

        this.drawers = buildDrawerQueue();
        this.selectedDrawers = buildDrawerSelectionQueue();


        attachGuiListeners();

        setGraph(graphFactory.createGraph());


        undoProvider = buildUndoProvider();


        setBackground(Color.WHITE);

        setPreferredSize(DEFAULT_SIZE);
        setSize(DEFAULT_SIZE);
    }

    private void attachGuiListeners() {
        addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);

                requestFocusInWindow();

                if (!responsive) {
                    return;
                }


                if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2) {
                    onLeftDoubleClick(e, e.getPoint());
                }

            }

            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);

                requestFocusInWindow();

                if (!responsive) {
                    return;
                }


                lastClickCount = e.getClickCount();

                if (e.getClickCount() == 1) {
                    switch (e.getButton()) {
                        case MouseEvent.BUTTON1:
                            onLeftButtonDown(e, e.getPoint());
                            break;

                        case MouseEvent.BUTTON2:
                            onCenterButtonDown(e, e.getPoint());
                            break;

                        case MouseEvent.BUTTON3:
                            onRightButtonDown(e, e.getPoint());
                            break;
                    }
                }

            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);

                requestFocusInWindow();

                if (!responsive) {
                    return;
                }


                if (e.getClickCount() == 1) {
                    switch (e.getButton()) {
                        case MouseEvent.BUTTON1:
                            onLeftButtonUp(e, e.getPoint());
                            break;
                        case MouseEvent.BUTTON3:
                            onRightButtonUp(e, e.getPoint());
                            break;
                    }
                }


            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {

            @Override
            public void mouseDragged(MouseEvent e) {
                super.mouseDragged(e);

                if (!responsive) {
                    return;
                }

                if (lastClickCount != 1) {
                    return;
                }

                Point point = e.getPoint();


                if (point.x < 0 || point.y < 0 || point.x > getWidth() || point.y > getHeight()) {
                    return;
                }

                if (SwingUtilities.isLeftMouseButton(e)) {
                    onLeftDragging(e, point);
                } else if (SwingUtilities.isRightMouseButton(e)) {
                    onRightDragging(e, point);
                }


            }
        });


        addKeyListener(new KeyAdapter() {

            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                onKeyPressed(e, e.getKeyCode());
            }

            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                onKeyReleased(e, e.getKeyCode());
            }
        });

    }

    private UndoProvider<GraphCanvasUndoToken> buildUndoProvider() {
        GraphCanvasUndoToken initialUndoToken = new GraphCanvasUndoToken(graphFactory, graph, drawers);
        return new UndoProvider<GraphCanvasUndoToken>(initialUndoToken, AppPreferences.getInstance().getUndoMaxSize());
    }

    private void setGraph(IGraph graph) {
        this.graph = graph;

        TopologyListener vertexAdditionListener = new TopologyListener() {

            @Override
            public void topologyChanged(TopologyEvent e) {
                Vertex vertex = (Vertex) e.getGraphObject();
                VertexDrawer drawer = buildVertexDrawer(new Point(0, 0), vertex);
                drawers.add(drawer);
                markAsModified();
            }
        };

        TopologyListener vertexRemovalListener = new TopologyListener() {

            @Override
            public void topologyChanged(TopologyEvent e) {
                Vertex vertex = (Vertex) e.getGraphObject();
                VertexDrawer drawer = getDrawerFor(vertex);
                removeDrawer(drawer);
                markAsModified();
            }
        };


        TopologyListener edgeAdditionListener = new TopologyListener() {

            @Override
            public void topologyChanged(TopologyEvent e) {
                Edge edge = (Edge) e.getGraphObject();
                VertexDrawer sourceDrawer = getDrawerFor(edge.getSource());
                VertexDrawer targetDrawer = getDrawerFor(edge.getTarget());

                EdgeDrawer drawer = buildEdgeDrawer(sourceDrawer, targetDrawer, edge);
                drawers.add(drawer);
                markAsModified();
            }
        };

        TopologyListener edgeRemovalListener = new TopologyListener() {

            @Override
            public void topologyChanged(TopologyEvent e) {
                Edge edge = (Edge) e.getGraphObject();
                EdgeDrawer drawer = getDrawerFor(edge);
                removeDrawer(drawer);
                markAsModified();
            }
        };

        graph.getOnVertexAdded().add(vertexAdditionListener);
        graph.getOnVertexRemoving().add(vertexRemovalListener);
        graph.getOnEdgeAdded().add(edgeAdditionListener);
        graph.getOnEdgeRemoving().add(edgeRemovalListener);
    }

    protected void onLeftButtonDown(MouseEvent e, Point point) {
        try {
            selectionRectangle = null;
            lastLeftDragPoint = point;
            selectionWasMoved = false;

            boolean outOfSelection = !selectedDrawers.containsPoint(point);


            if (outOfSelection) {
                boolean wantsToCreateEdge = e.isShiftDown();

                if (wantsToCreateEdge) {
                    tryToCreateEdge(point);
                } else {

                    selectedDrawers.clear();
                    Drawer newSelection = drawers.getDrawerAtPoint(point);

                    if (newSelection != null) {
                        selectedDrawers.add(newSelection);
                    }
                }
            }
        } finally {
            repaint();
        }
    }

    protected void onLeftDragging(MouseEvent e, Point point) {
        try {
            if (selectedDrawers.isEmpty()) {
                selectionRectangle = new PreciseRectangle(lastLeftDragPoint, point);
            } else {
                for (Drawer drawer : selectedDrawers) {

                    Point delta = new Point();
                    delta.x = point.x - lastLeftDragPoint.x;
                    delta.y = point.y - lastLeftDragPoint.y;

                    drawer.moveBy(delta, getSize());
                }


                selectionWasMoved = true;
                lastLeftDragPoint = point;
            }
        } finally {
            repaint();
        }
    }

    protected void onLeftButtonUp(MouseEvent e, Point point) {
        try {
            if (selectedDrawers.isEmpty()) {
                if (selectionRectangle == null || (selectionRectangle.width <= USELESS_SELECTION_RECTANGLE_SIZE && selectionRectangle.height <= USELESS_SELECTION_RECTANGLE_SIZE)) {
                    tryToCreateVertex(point);
                } else {
                    selectedDrawers.addAll(drawers.getDrawersInRect(selectionRectangle));
                }
            } else {
                if (selectionWasMoved) {
                    markAsModified();
                }
            }
        } finally {
            selectionRectangle = null;
            repaint();
        }
    }

    protected void onLeftDoubleClick(MouseEvent e, Point point) {

        try {
            //verifyOrRemakeSelectionFromPoint(point);
            switch (selectedDrawers.size()) {
                case 1:
                    tryToEditSelectedDrawer(point);

                    break;

            }
        } finally {
            repaint();
        }
    }

    protected void onCenterButtonDown(MouseEvent e, Point point) {
        if (tryToCreateEdge(point)) {
            repaint();
        }
    }

    protected void onRightButtonDown(MouseEvent e, Point point) {
        try {
            rightClickedEdgeDrawer = null;
            rightClickedEdgePoint = null;
            draggedEdgeSplitPoint = null;

            for (EdgeDrawer drawer : drawers.getEdgeDrawers()) {
                if (drawer.containsPoint(point)) {
                    rightClickedEdgeDrawer = drawer;
                    rightClickedEdgePoint = point;

                    if (!selectedDrawers.contains(drawer)) {
                        selectedDrawers.clear();
                        selectedDrawers.add(drawer);
                    }

                    return;
                }
            }


            if (rightClickedEdgeDrawer == null) {
                if (!selectedDrawers.containsPoint(point)) {
                    selectedDrawers.clear();
                }

                Drawer newSelection = drawers.getDrawerAtPoint(point);
                if (newSelection != null) {
                    selectedDrawers.add(newSelection);
                }
            }
        } finally {
            repaint();
        }
    }

    protected void onRightDragging(MouseEvent e, Point point) {


        try {
            if (rightClickedEdgeDrawer == null) {
                return;
            }

            if (draggedEdgeSplitPoint == null) {
                draggedEdgeSplitPoint = rightClickedEdgeDrawer.getOrCreateSplitPoint(rightClickedEdgePoint);
            }

            draggedEdgeSplitPoint.x = point.x;
            draggedEdgeSplitPoint.y = point.y;
            PointUtils.forceIntoDimension(draggedEdgeSplitPoint, getSize());

            rightClickedEdgeDrawer.invalidateCache();


        } finally {
            repaint();
        }
    }

    protected void onRightButtonUp(MouseEvent e, Point point) {

        try {
            if (draggedEdgeSplitPoint == null) {
                if (selectedDrawers.containsPoint(point)) {
                    tryToRemoveSelection();
                } else {
                    selectedDrawers.clear();
                }
            } else {
                markAsModified();
            }
        } finally {
            repaint();
        }
    }

    protected void onKeyPressed(KeyEvent e, int keyCode) {
    }

    protected void onKeyReleased(KeyEvent e, int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_ENTER:

                if (!e.isControlDown()) {
                    return;
                }

                if (selectedDrawers.size() == 1) {
                    try {
                        tryToEditSelectedDrawer(null);
                    } finally {
                        repaint();
                    }
                }

                break;

        }


    }

    public boolean tryToRemoveSelection() {
        if (!editable || selectedDrawers.isEmpty()) {
            return false;
        }


        forbidModificationMarking = true;

        try {
            Collection<VertexDrawer> selectedVertexDrawers = new ArrayList<VertexDrawer>(selectedDrawers.getVertexDrawers());
            Collection<EdgeDrawer> selectedEdgeDrawers = new ArrayList<EdgeDrawer>(selectedDrawers.getEdgeDrawers());


            for (EdgeDrawer drawer : selectedEdgeDrawers) {
                graph.removeEdgeGeneral(drawer.getEdge());
            }

            for (VertexDrawer drawer : selectedVertexDrawers) {
                graph.removeVertexGeneral(drawer.getVertex());
            }
        } finally {
            forbidModificationMarking = false;
        }


        markAsModified();
        return true;
    }

    protected boolean tryToCreateVertex(Point point) {
        if (!editable) {
            return false;
        }


        forbidModificationMarking = true;
        try {
            while (true) {
                String newVertexName = String.format("%s%d", vertexNameRoot, vertexNameCounter);
                vertexNameCounter++;

                try {
                    Vertex newVertex = graphFactory.createVertex(newVertexName);
                    graph.addVertexGeneral(newVertex);
                    VertexDrawer createdDrawer = getDrawerFor(newVertex);
                    createdDrawer.setProperties(defaultVertexDrawerProperties.clone());
                    createdDrawer.setCenter(point);
                    break;
                } catch (DuplicateVertexException ex) {
                    //Just do nothing
                } catch (InvalidNameException ex) {
                    throw new AssertionError("The vertex name should be constructed from valid name elements");
                }
            }
        } finally {
            forbidModificationMarking = false;
        }


        markAsModified();
        return true;
    }

    protected boolean tryToCreateEdge(VertexDrawer sourceDrawer, VertexDrawer targetDrawer) {
        if (sourceDrawer == targetDrawer) {
            throw new IllegalArgumentException("Cannot connect a vertex to itself");
        }

        try {

            forbidModificationMarking = true;

            try {
                Edge newEdge = graphFactory.createEdge(sourceDrawer.getVertex(), targetDrawer.getVertex());
                graph.addEdgeGeneral(newEdge);
                EdgeDrawer createdDrawer = getDrawerFor(newEdge);
                createdDrawer.setProperties(defaultEdgeDrawerProperties.clone());
            } finally {
                forbidModificationMarking = false;
            }

            markAsModified();
            return true;
        } catch (DuplicateEdgeException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
            return false;
        }
    }

    private boolean tryToCreateEdge(Point targetPoint) {
        if (!editable) {
            return false;
        }

        VertexDrawer sourceDrawer = null;
        VertexDrawer targetDrawer = null;

        if (selectedDrawers.size() == 1) {
            try {
                sourceDrawer = (VertexDrawer) selectedDrawers.peekUnique();
            } catch (ClassCastException ex) {
                return false;
            }
        }

        if (sourceDrawer == null) {
            return false;
        }

        for (VertexDrawer drawer : drawers.getVertexDrawers()) {
            if (drawer.containsPoint(targetPoint)) {
                if (drawer == sourceDrawer) {
                    return false;
                } else {
                    targetDrawer = drawer;
                    break;
                }
            }
        }


        if (targetDrawer == null) {
            return false;
        }


        return tryToCreateEdge(sourceDrawer, targetDrawer);

    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        BufferedImage buffer = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);

        Graphics2D hyperGraphics = (Graphics2D) buffer.getGraphics();


        hyperGraphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        hyperGraphics.setColor(getBackground());
        hyperGraphics.fillRect(0, 0, getWidth(), getHeight());




        for (VertexDrawer drawer : drawers.getVertexDrawers()) {
            drawer.draw(hyperGraphics);
        }

        for (EdgeDrawer drawer : drawers.getEdgeDrawers()) {
            drawer.draw(hyperGraphics);
        }


        if (selectionRectangle != null) {
            hyperGraphics.setColor(Color.BLACK);
            hyperGraphics.setStroke(new BasicStroke(1));
            selectionRectangle.drawOn(hyperGraphics);
        }


        g.drawImage(buffer, 0, 0, null);

    }

    public IGraphFactory getGraphFactory() {
        return graphFactory;
    }

    public int getVertexNameCounter() {
        return vertexNameCounter;
    }

    public void setVertexNameCounter(int vertexNameCounter) {
        this.vertexNameCounter = vertexNameCounter;

        this.markAsModified(false);
    }

    public String getVertexNameRoot() {
        return vertexNameRoot;
    }

    public void setVertexNameRoot(String vertexNameRoot) throws InvalidNameException {

        NameValidator.getInstance().validateName(vertexNameRoot);

        this.vertexNameRoot = vertexNameRoot;

        this.markAsModified(false);
    }

    public VertexDrawer getDrawerFor(Vertex vertex) {
        return drawers.getDrawerFor(vertex);
    }

    public EdgeDrawer getDrawerFor(Edge edge) {
        return drawers.getDrawerFor(edge);
    }

    public boolean isEditable() {
        return editable;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    public boolean isResponsive() {
        return responsive;
    }

    public void setResponsive(boolean responsive) {
        this.responsive = responsive;
    }

    private void removeDrawer(Drawer drawer) {
        drawers.remove(drawer);

        if (selectedDrawers.contains(drawer)) {
            selectedDrawers.remove(drawer);
        }
    }

    protected DrawerQueue buildDrawerQueue() {
        return new DrawerQueue();
    }

    protected DrawerSelection buildDrawerSelectionQueue() {
        return new DrawerSelection();
    }

    public EdgeDrawerProperties getDefaultEdgeDrawerProperties() {
        return defaultEdgeDrawerProperties;
    }

    public void setDefaultEdgeDrawerProperties(EdgeDrawerProperties defaultEdgeDrawerProperties) {
        this.defaultEdgeDrawerProperties = defaultEdgeDrawerProperties;
    }

    public VertexDrawerProperties getDefaultVertexDrawerProperties() {
        return defaultVertexDrawerProperties;
    }

    public void setDefaultVertexDrawerProperties(VertexDrawerProperties defaultVertexProperties) {
        this.defaultVertexDrawerProperties = defaultVertexProperties;
    }

    protected VertexDrawer buildVertexDrawer(Point center, Vertex vertex) {
        return new VertexDrawer(center, vertex, defaultVertexDrawerProperties);
    }

    protected EdgeDrawer buildEdgeDrawer(VertexDrawer sourceVertexDrawer, VertexDrawer targetVertexDrawer, Edge edge) {
        return new EdgeDrawer(sourceVertexDrawer, targetVertexDrawer, edge, defaultEdgeDrawerProperties);
    }

    public CustomActionEvent getOnModifiedChanged() {
        return onModifiedChanged;
    }

    public boolean isModified() {
        return modified;
    }

    public void markAsModified() {
        this.markAsModified(true);
    }

    public void markAsModified(boolean mustTakeUndoSnapshot) {

        if (forbidModificationMarking) {
            return;
        }

        if (mustTakeUndoSnapshot) {
            takeUndoSnapshot();
        }

        setModified(true);
    }

    private void takeUndoSnapshot() {
        GraphCanvasUndoToken undoToken = new GraphCanvasUndoToken(graphFactory, graph, drawers);
        undoProvider.put(undoToken);
    }

    public void setModified(boolean modified) {
        boolean changed = (modified != this.modified);
        this.modified = modified;

        if (changed) {
            onModifiedChanged.fire(EVENT_KEY);
        }
    }

    private void tryToEditSelectedDrawer(Point point) {
        if (!editable) {
            return;
        }

        if (selectedDrawers.peekUnique().edit(this, point)) {
            markAsModified();
        }
    }

    public void resetVertexProperties() {
        for (VertexDrawer drawer : drawers.getVertexDrawers()) {
            drawer.setProperties(defaultVertexDrawerProperties.clone());
        }
    }

    public void resetEdgeProperties() {
        for (EdgeDrawer drawer : drawers.getEdgeDrawers()) {
            drawer.setProperties(defaultEdgeDrawerProperties.clone());
        }
    }

    public VertexDrawerProperties getPropertiesFor(Vertex vertex) {
        return getDrawerFor(vertex).getProperties();
    }

    public EdgeDrawerProperties getPropertiesFor(Edge edge) {
        return getDrawerFor(edge).getProperties();
    }

    public void selectAll() {
        selectedDrawers.clear();

        for (Drawer drawer : drawers) {
            selectedDrawers.add(drawer);
        }
    }

    public IGraph getGraph() {
        return graph;
    }

    @Override
    public GraphCanvas clone() {
        return (GraphCanvas) Duplicator.singleCopy(this);
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();

        undoProvider = buildUndoProvider();
        attachGuiListeners();
        setGraph(graph);
        selectedDrawers.clear();
    }

    public DrawerQueue getDrawersCopy() {
        return drawers.clone();
    }

    public Color getBackgroundWithModification() {
        return getBackground();
    }

    public void setBackgroundWithModification(Color color) {
        boolean changed = !color.equals(getBackground());

        setBackground(color);

        if (changed) {
            markAsModified(false);
        }
    }

    public Dimension getSizeWithModification() {
        return getSize();
    }

    public void setSizeWithModification(Dimension size) {
        List<VertexDrawer> outsideVertexDrawers = new ArrayList<VertexDrawer>();

        for (VertexDrawer drawer : drawers.getVertexDrawers()) {
            Point center = drawer.getCenter();

            if (center.x > size.width || center.y > size.height) {
                outsideVertexDrawers.add(drawer);
            }
        }

        if (!outsideVertexDrawers.isEmpty()) {
            if (!MessageProvider.getInstance().askQuestion("Some vertexes are outside the new graph size, and must be deleted.\nWould you like to continue?", Application.TITLE, false, false)) {
                return;
            }

            undoProvider.clear();
        }



        boolean changed = !size.equals(getSize());
        setPreferredSize(size);
        setSize(size);

        forbidModificationMarking = true;
        try {
            for (VertexDrawer drawer : outsideVertexDrawers) {
                graph.removeVertexGeneral(drawer.getVertex());
            }
        } finally {
            forbidModificationMarking = false;
        }

        if (changed) {
            revalidate();
            markAsModified(false);
        }


    }

    private void restoreUndoToken(GraphCanvasUndoToken undoToken) {

        this.graphFactory = undoToken.getGraphFactory();
        setGraph(undoToken.getGraph());
        drawers = undoToken.getDrawers();

        for (VertexDrawer drawer : drawers.getVertexDrawers()) {
            drawer.setProperties(defaultVertexDrawerProperties.clone());
        }

        for (EdgeDrawer drawer : drawers.getEdgeDrawers()) {
            drawer.setProperties(defaultEdgeDrawerProperties.clone());
        }

        markAsModified(false);

        selectedDrawers.clear();
        repaint();
    }

    public void undo() {
        GraphCanvasUndoToken undoToken = undoProvider.undo();
        restoreUndoToken(undoToken);
    }

    public void redo() {
        GraphCanvasUndoToken undoToken = undoProvider.redo();
        restoreUndoToken(undoToken);
    }

    public CustomActionEvent getOnUndoProviderStateChanged() {
        return undoProvider.getOnStateChanged();
    }

    public boolean isUndoable() {
        return undoProvider.isUndoable();
    }

    public boolean isRedoable() {
        return undoProvider.isRedoable();
    }

    public void fullRepaint() {
        for (Drawer drawer : drawers) {
            drawer.invalidateCache();
        }

        repaint();
    }
}
