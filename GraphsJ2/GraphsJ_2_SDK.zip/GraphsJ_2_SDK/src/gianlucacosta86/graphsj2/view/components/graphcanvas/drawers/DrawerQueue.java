/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.components.graphcanvas.drawers;

import gianlucacosta86.graphsj2.model.collections.general.SimpleQueue;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.GraphObject;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.edgedrawer.EdgeDrawer;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.vertexdrawer.VertexDrawer;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Gianluca Costa
 */
public class DrawerQueue implements Iterable<Drawer>, Serializable, Cloneable {

    private static final long serialVersionUID = 1;
    private final SimpleQueue<Drawer> internalQueue = new SimpleQueue<Drawer>();
    private final SimpleQueue<VertexDrawer> vertexDrawers = new SimpleQueue<VertexDrawer>();
    private final SimpleQueue<EdgeDrawer> edgeDrawers = new SimpleQueue<EdgeDrawer>();
    private final Map<GraphObject, Drawer> graphObjectCache;

    public DrawerQueue() {
        this(true);
    }

    public DrawerQueue(boolean useCacheForGraphObjects) {
        if (useCacheForGraphObjects) {
            graphObjectCache = new HashMap<GraphObject, Drawer>();
        } else {
            graphObjectCache = null;
        }
    }

    public void add(Drawer drawer) {
        if (drawer == null) {
            throw new IllegalArgumentException("Cannot add a null reference to the selection");
        }

        if (internalQueue.contains(drawer)) {
            remove(drawer);
        }

        internalQueue.add(drawer);


        if (drawer instanceof VertexDrawer) {
            vertexDrawers.add((VertexDrawer) drawer);
        } else if (drawer instanceof EdgeDrawer) {
            edgeDrawers.add((EdgeDrawer) drawer);
        }

        if (graphObjectCache != null) {
            graphObjectCache.put(drawer.getGraphObject(), drawer);
        }
    }

    public void addAll(Collection<? extends Drawer> drawers) {
        for (Drawer drawer : drawers) {
            add(drawer);
        }
    }

    public void remove(Drawer drawer) {
        if (!internalQueue.contains(drawer)) {
            throw new IllegalArgumentException("The specified drawer does not belong to the queue!");
        }


        internalQueue.remove(drawer);

        if (drawer instanceof VertexDrawer) {
            vertexDrawers.remove((VertexDrawer) drawer);
        } else if (drawer instanceof EdgeDrawer) {
            edgeDrawers.remove((EdgeDrawer) drawer);
        }

        if (graphObjectCache != null) {
            graphObjectCache.remove(drawer.getGraphObject());
        }
    }

    public void clear() {
        internalQueue.clear();
        vertexDrawers.clear();
        edgeDrawers.clear();

        if (graphObjectCache != null) {
            graphObjectCache.clear();
        }
    }

    @Override
    public Iterator<Drawer> iterator() {
        return internalQueue.iterator();
    }

    public Collection<VertexDrawer> getVertexDrawers() {
        return Collections.unmodifiableCollection(vertexDrawers);
    }

    public Collection<EdgeDrawer> getEdgeDrawers() {
        return Collections.unmodifiableCollection(edgeDrawers);
    }

    public int size() {
        return internalQueue.size();
    }

    public Drawer peek() {
        return internalQueue.peek();
    }

    public boolean isEmpty() {
        return internalQueue.isEmpty();
    }

    public boolean contains(Drawer drawer) {
        return internalQueue.contains(drawer);
    }

    public Drawer peekUnique() {
        if (internalQueue.size() != 1) {
            throw new IllegalStateException("The number of drawers is != 1");
        }

        return internalQueue.peek();
    }

    public VertexDrawer getDrawerFor(Vertex vertex) {
        if (graphObjectCache != null) {
            return (VertexDrawer) graphObjectCache.get(vertex);
        }

        for (VertexDrawer drawer : vertexDrawers) {
            if (drawer.getVertex() == vertex) {
                return drawer;
            }
        }

        return null;
    }

    public EdgeDrawer getDrawerFor(Edge edge) {
        if (graphObjectCache != null) {
            return (EdgeDrawer) graphObjectCache.get(edge);
        }

        for (EdgeDrawer drawer : edgeDrawers) {
            if (drawer.getEdge() == edge) {
                return drawer;
            }
        }

        return null;
    }

    @Override
    public DrawerQueue clone() {
        try {
            return (DrawerQueue) super.clone();
        } catch (CloneNotSupportedException ex) {
            throw new AssertionError();
        }
    }

    public Collection<Drawer> getDrawersInRect(Rectangle rect) {
        List<Drawer> result = new ArrayList<Drawer>();

        for (Drawer drawer : internalQueue) {
            if (drawer.isInRect(rect)) {
                result.add(drawer);
            }
        }

        return result;
    }

    public Drawer getDrawerAtPoint(Point point) {
        for (VertexDrawer drawer : vertexDrawers) {
            if (drawer.containsPoint(point)) {
                return drawer;
            }
        }

        for (EdgeDrawer drawer : edgeDrawers) {
            if (drawer.containsPoint(point)) {
                return drawer;
            }
        }

        return null;
    }

    public boolean containsPoint(Point point) {
        return getDrawerAtPoint(point) != null;
    }
}
