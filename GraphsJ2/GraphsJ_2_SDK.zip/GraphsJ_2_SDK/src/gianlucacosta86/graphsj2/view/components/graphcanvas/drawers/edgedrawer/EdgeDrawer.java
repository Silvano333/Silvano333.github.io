/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.edgedrawer;

import gianlucacosta86.graphsj2.model.graph.GraphObject;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.vertexdrawer.VertexDrawer;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.exceptions.GraphException;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.Drawer;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;


import gianlucacosta86.graphsj2.view.geometric.lines.Arrow;
import gianlucacosta86.graphsj2.view.geometric.text.CenteredLabel;
import gianlucacosta86.graphsj2.view.geometric.PointUtils;
import gianlucacosta86.graphsj2.view.geometric.RoundedStroke;
import gianlucacosta86.graphsj2.view.geometric.lines.Segment;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gianluca Costa
 */
public class EdgeDrawer extends Drawer {

    private static final long serialVersionUID = 1;
    protected static final int GRAVITY_SPLIT_POINT_DISTANCE = 8;
    private final VertexDrawer sourceVertexDrawer;
    private final VertexDrawer targetVertexDrawer;
    private final Edge edge;
    private Point labelCenter;
    private final List<Point> splitPoints = new ArrayList<Point>();
    private final List<Segment> edgeSegments = new ArrayList<Segment>();

    public EdgeDrawer(VertexDrawer sourceVertexDrawer,
            VertexDrawer targetVertexDrawer, Edge edge, EdgeDrawerProperties properties) {

        super(properties);

        this.sourceVertexDrawer = sourceVertexDrawer;
        this.targetVertexDrawer = targetVertexDrawer;
        this.edge = edge;


        labelCenter = PointUtils.getHalfway(sourceVertexDrawer.getCenter(), targetVertexDrawer.getCenter());
        buildSegmentList();
    }

    private void buildSegmentList() {
        edgeSegments.clear();

        Rectangle sourceRect = sourceVertexDrawer.getVertexRect();
        Rectangle targetRect = targetVertexDrawer.getVertexRect();

        if (sourceRect.intersects(targetRect) || sourceRect.contains(targetRect) || targetRect.contains(sourceRect)) {
            return;
        }


        EdgeDrawerProperties properties = getProperties();

        int lineSize = properties.getLineSize();
        Point sourceCenter = sourceVertexDrawer.getCenter();
        Point targetCenter = targetVertexDrawer.getCenter();

        Point sourceIntersectionPoint;
        Point targetIntersectionPoint;

        if (splitPoints.isEmpty()) {
            Segment centersSegment = new Segment(sourceCenter, targetCenter, lineSize);
            sourceIntersectionPoint = centersSegment.getIntersection(sourceVertexDrawer.getVertexRect());
            targetIntersectionPoint = centersSegment.getIntersection(targetVertexDrawer.getVertexRect());

            Segment lastSegment = buildLastSegment(sourceIntersectionPoint, targetIntersectionPoint, lineSize);
            edgeSegments.add(lastSegment);
        } else {
            Point firstSplitPoint = splitPoints.get(0);
            Segment sourceSegment = new Segment(sourceCenter, firstSplitPoint, lineSize);
            sourceIntersectionPoint = sourceSegment.getIntersection(sourceVertexDrawer.getVertexRect());

            Point lastSplitPoint = splitPoints.get(splitPoints.size() - 1);
            Segment targetSegment = new Segment(lastSplitPoint, targetCenter, lineSize);
            targetIntersectionPoint = targetSegment.getIntersection(targetVertexDrawer.getVertexRect());

            Segment firstSegment = new Segment(sourceIntersectionPoint, firstSplitPoint, lineSize);
            edgeSegments.add(firstSegment);

            for (int i = 0; i <= splitPoints.size() - 2; i++) {
                Point fromPoint = splitPoints.get(i);
                Point toPoint = splitPoints.get(i + 1);

                Segment currentSegment = new Segment(fromPoint, toPoint, lineSize);
                edgeSegments.add(currentSegment);
            }

            Segment lastSegment = buildLastSegment(lastSplitPoint, targetIntersectionPoint, lineSize);
            edgeSegments.add(lastSegment);
        }
    }

    private Segment buildLastSegment(Point fromPoint, Point toPoint, int lineSize) {
        if (edge.getParent().isOriented()) {
            return new Arrow(fromPoint, toPoint, lineSize, 25);
        } else {
            return new Segment(fromPoint, toPoint, lineSize);
        }
    }

    @Override
    public boolean isCacheValid() {
        if (sourceVertexDrawer.isLatestDrawRebuiltCache() || targetVertexDrawer.isLatestDrawRebuiltCache() || !sourceVertexDrawer.isCacheValid() || !targetVertexDrawer.isCacheValid()) {
            return false;
        }

        return super.isCacheValid();
    }

    @Override
    protected void rebuildCache(Graphics2D g) {
        buildSegmentList();
    }

    @Override
    protected void doPaint(Graphics2D g) {
        if (edgeSegments.isEmpty()) {
            return;
        }


        EdgeDrawerProperties properties = getProperties();


        if (isSelected()) {
            g.setColor(properties.getSelectedColor());
        } else {
            g.setColor(properties.getColor());
        }
        g.setStroke(new RoundedStroke(properties.getLineSize()));



        for (Segment segment : edgeSegments) {
            segment.drawOn(g);
        }


        if (splitPoints.isEmpty()) {
            labelCenter = PointUtils.getHalfway(sourceVertexDrawer.getCenter(), targetVertexDrawer.getCenter());
        }


        CenteredLabel label = new CenteredLabel(edge.toString(), labelCenter);

        if (isSelected()) {
            g.setColor(properties.getSelectedFontColor());
        } else {
            g.setColor(properties.getFontColor());
        }

        g.setFont(properties.getFont());
        label.drawOn(g);
    }

    public Point getOrCreateSplitPoint(Point point) {
        for (Point splitPoint : splitPoints) {
            double distance = point.distance(splitPoint);

            if (distance <= GRAVITY_SPLIT_POINT_DISTANCE) {
                labelCenter = splitPoint;
                return splitPoint;
            }
        }


        Segment containingSegment = null;

        for (Segment segment : edgeSegments) {
            if (segment.containsPoint(point)) {
                containingSegment = segment;
                break;
            }
        }


        if (containingSegment == null) {
            throw new IllegalArgumentException("The requested point is not within the edge");
        }


        int segmentIndex = edgeSegments.indexOf(containingSegment);

        splitPoints.add(segmentIndex, point);
        labelCenter = point;

        invalidateCache();

        return point;
    }

    @Override
    public void moveBy(Point delta, Dimension canvasSize) {
        if (splitPoints.isEmpty()) {
            PointUtils.moveByDelta(labelCenter, delta);
        } else {

            for (Point splitPoint : splitPoints) {
                PointUtils.moveByDelta(splitPoint, delta);
            }
        }

        invalidateCache();
    }

    public Edge getEdge() {
        return edge;
    }

    @Override
    public boolean containsPoint(Point point) {
        for (Segment segment : edgeSegments) {
            if (segment.containsPoint(point)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean edit(GraphCanvas canvas, Point point) {
        try {
            if (edge.edit(canvas)) {
                invalidateCache();
                return true;
            }
        } catch (GraphException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
        }

        return false;
    }

    @Override
    public boolean isInRect(Rectangle rect) {
        for (Segment segment : edgeSegments) {
            if (segment.intersects(rect)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public GraphObject getGraphObject() {
        return edge;
    }

    @Override
    public EdgeDrawerProperties getProperties() {
        return (EdgeDrawerProperties) super.getProperties();
    }

    public void setProperties(EdgeDrawerProperties properties) {
        super.setProperties(properties);
    }

    @Override
    public String toString() {
        return edge.toString();
    }
}
