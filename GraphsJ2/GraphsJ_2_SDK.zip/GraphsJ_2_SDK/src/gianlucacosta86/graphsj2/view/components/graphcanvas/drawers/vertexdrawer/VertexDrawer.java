/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.vertexdrawer;

import gianlucacosta86.graphsj2.model.graph.GraphObject;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.exceptions.GraphException;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.Drawer;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;

import gianlucacosta86.graphsj2.view.geometric.PointUtils;
import gianlucacosta86.graphsj2.view.geometric.rectangles.BorderedBox;
import gianlucacosta86.graphsj2.view.geometric.text.CenteredLabel;
import gianlucacosta86.graphsj2.view.geometric.rectangles.PreciseRectangle;
import java.awt.Dimension;
import java.awt.FontMetrics;

/**
 *
 * @author Gianluca Costa
 */
public class VertexDrawer extends Drawer {

    private static final long serialVersionUID = 1;
    private final Vertex vertex;
    private Point center;
    private CenteredLabel vertexLabel;
    private BorderedBox vertexBox;

    public VertexDrawer(Point center, Vertex vertex, VertexDrawerProperties properties) {
        super(properties);

        this.center = center;
        this.vertex = vertex;
    }

    public Vertex getVertex() {
        return vertex;
    }

    public Point getCenter() {
        return center;
    }

    public void setCenter(Point center) {
        this.center = center;
        invalidateCache();
    }

    @Override
    public void moveBy(Point delta, Dimension canvasSize) {
        center.x += delta.x;
        center.y += delta.y;

        PointUtils.forceIntoDimension(center, canvasSize);

        invalidateCache();
    }

    @Override
    public boolean containsPoint(Point point) {
        return vertexBox.containsPoint(point);
    }

    @Override
    public boolean isInRect(Rectangle rect) {
        Rectangle vertexRect = getVertexRect();

        return rect.contains(vertexRect) || rect.intersects(vertexRect);
    }

    @Override
    protected void rebuildCache(Graphics2D g) {
        VertexDrawerProperties properties = getProperties();

        int borderSize = properties.getBorderSize();
        int padding = properties.getPadding();

        g.setFont(properties.getFont());
        FontMetrics metrics = g.getFontMetrics();

        String vertexString = vertex.toString();
        int labelWidth = metrics.stringWidth(vertexString);
        int labelHeight = metrics.getAscent() + metrics.getDescent();

        vertexBox = new BorderedBox(center, labelWidth + 2 * padding, labelHeight + 2 * padding, borderSize);
        vertexLabel = new CenteredLabel(vertexString, center);
    }

    @Override
    protected void doPaint(Graphics2D g) {
        VertexDrawerProperties properties = getProperties();

        if (isSelected()) {
            vertexBox.setInternalColor(properties.getSelectedColor());
            vertexBox.setBorderColor(properties.getSelectedBorderColor());
        } else {
            vertexBox.setInternalColor(properties.getColor());
            vertexBox.setBorderColor(properties.getBorderColor());
        }

        vertexBox.drawOn(g);


        g.setFont(properties.getFont());

        if (isSelected()) {
            g.setColor(properties.getSelectedFontColor());
        } else {
            g.setColor(properties.getFontColor());
        }

        vertexLabel.drawOn(g);
    }

    @Override
    public boolean edit(GraphCanvas canvas, Point point) {
        try {
            if (vertex.edit(canvas)) {
                invalidateCache();
                return true;
            }
        } catch (GraphException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
        }

        return false;
    }

    public Dimension getSize() {
        return vertexBox.getSize();
    }

    @Override
    public GraphObject getGraphObject() {
        return vertex;
    }

    public PreciseRectangle getVertexRect() {
        return vertexBox.getExternalRect();
    }

    @Override
    public VertexDrawerProperties getProperties() {
        return (VertexDrawerProperties) super.getProperties();
    }

    public void setProperties(VertexDrawerProperties properties) {
        super.setProperties(properties);
    }

    @Override
    public String toString() {
        return vertex.toString();
    }
}
