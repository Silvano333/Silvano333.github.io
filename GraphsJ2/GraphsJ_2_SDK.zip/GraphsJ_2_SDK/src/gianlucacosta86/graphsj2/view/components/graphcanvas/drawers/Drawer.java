/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.components.graphcanvas.drawers;

import gianlucacosta86.graphsj2.model.graph.GraphObject;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.Serializable;

/**
 *
 * @author Gianluca Costa
 */
public abstract class Drawer implements Serializable {

    private static final long serialVersionUID = 1;
    private transient boolean selected;
    private transient boolean cacheValid;
    private transient boolean latestDrawRebuiltCache;
    private DrawerProperties properties;

    protected Drawer(DrawerProperties properties) {
        this.properties = properties;
    }

    protected boolean isSelected() {
        return selected;
    }

    void setSelected(boolean selected) {
        this.selected = selected;
    }

    protected abstract void rebuildCache(Graphics2D g);

    protected abstract void doPaint(Graphics2D g);

    public final void draw(Graphics2D g) {
        if (!isCacheValid()) {
            rebuildCache(g);
            cacheValid = true;
            latestDrawRebuiltCache = true;
        } else {
            latestDrawRebuiltCache = false;
        }

        doPaint(g);
    }

    public boolean isCacheValid() {
        return cacheValid;
    }

    public void invalidateCache() {
        cacheValid = false;
    }

    public boolean isLatestDrawRebuiltCache() {
        return latestDrawRebuiltCache;
    }

    public abstract boolean containsPoint(Point point);

    public abstract boolean isInRect(Rectangle rect);

    public abstract boolean edit(GraphCanvas canvas, Point point);

    public abstract void moveBy(Point delta, Dimension canvasSize);

    public abstract GraphObject getGraphObject();

    public DrawerProperties getProperties() {
        return properties;
    }

    protected void setProperties(DrawerProperties properties) {
        this.properties = properties;
    }
}
