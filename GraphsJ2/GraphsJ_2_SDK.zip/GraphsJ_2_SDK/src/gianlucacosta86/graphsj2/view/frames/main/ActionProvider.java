/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.frames.main;

import gianlucacosta86.graphsj2.view.actionclasses.StartRunAction;
import gianlucacosta86.graphsj2.view.actionclasses.RunControllerAction;
import gianlucacosta86.graphsj2.view.actionclasses.DocumentGraphCanvasAction;
import gianlucacosta86.graphsj2.Application;
import gianlucacosta86.graphsj2.controller.graphdocument.DocumentManager;
import gianlucacosta86.graphsj2.controller.graphdocument.GraphDocument;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.IRunController;
import gianlucacosta86.graphsj2.model.algorithms.RunStateEnum;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.aboutdialog.AboutDialog;
import gianlucacosta86.graphsj2.view.dialogs.helpdialog.HelpDialog;
import gianlucacosta86.graphsj2.view.actionclasses.BasicGraphsJAction;
import gianlucacosta86.graphsj2.view.frames.main.actionicons.ActionIconsProvider;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import javax.swing.Action;
import javax.swing.KeyStroke;

/**
 *
 * @author Gianluca Costa
 */
final class ActionProvider {

    private static final ActionProvider instance = new ActionProvider();
    private boolean verboseRun = true;
    private final Action newAction = new BasicGraphsJAction("New...", ActionIconsProvider.NEW_ICON) {

        @Override
        public void actionPerformed(ActionEvent e) {
            DocumentManager.getInstance().doNew();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK);
        }
    };
    private final Action openAction = new BasicGraphsJAction("Open...", ActionIconsProvider.OPEN_ICON) {

        @Override
        public void actionPerformed(ActionEvent e) {
            DocumentManager.getInstance().doOpen();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK);
        }
    };
    private final Action saveAction = new BasicGraphsJAction("Save", ActionIconsProvider.SAVE_ICON) {

        @Override
        public void actionPerformed(ActionEvent e) {
            DocumentManager.getInstance().doSave();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK);
        }
    };
    private final Action saveAsAction = new BasicGraphsJAction("Save as...", ActionIconsProvider.SAVE_AS_ICON) {

        @Override
        public void actionPerformed(ActionEvent e) {
            DocumentManager.getInstance().doSaveAs();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK);
        }
    };
    private final Action closeAction = new BasicGraphsJAction("Close", null) {

        @Override
        public void actionPerformed(ActionEvent e) {
            DocumentManager.getInstance().doClose();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_DOWN_MASK);
        }
    };
    private final Action undoAction = new DocumentGraphCanvasAction("Undo", ActionIconsProvider.UNDO_ICON) {

        @Override
        protected void perform(String actionTitle, GraphCanvas canvas) {
            canvas.undo();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK);
        }
    };
    private final Action redoAction = new DocumentGraphCanvasAction("Redo", ActionIconsProvider.REDO_ICON) {

        @Override
        protected void perform(String actionTitle, GraphCanvas canvas) {
            canvas.redo();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_DOWN_MASK);
        }
    };
    private final Action selectAllAction = new DocumentGraphCanvasAction("Select all", ActionIconsProvider.SELECT_ALL_ICON) {

        @Override
        protected void perform(String actionTitle, GraphCanvas canvas) {
            canvas.selectAll();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0);
        }
    };
    private final Action deleteAction = new DocumentGraphCanvasAction("Delete", ActionIconsProvider.DELETE_ICON) {

        @Override
        protected void perform(String actionTitle, GraphCanvas canvas) {
            canvas.tryToRemoveSelection();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0);
        }
    };
    private final Action runAction = new StartRunAction("Run", ActionIconsProvider.RUN_ICON) {

        @Override
        protected void startRun(IRunController runController, GraphCanvas outputCanvas) throws AlgorithmException {
            runController.fullRun(outputCanvas, verboseRun);
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0);
        }
    };
    private final Action runStepByStepAction = new StartRunAction("Step by step", ActionIconsProvider.RUN_STEP_BY_STEP_ICON) {

        @Override
        protected void startRun(IRunController runController, GraphCanvas outputCanvas) throws AlgorithmException {
            runController.enterStepByStepRun(outputCanvas, verboseRun);
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_F7, 0);
        }
    };
    private final Action nextStepAction = new RunControllerAction("Next step", ActionIconsProvider.NEXT_STEP_ICON) {

        @Override
        protected void perform(String actionTitle, IRunController runController) throws AlgorithmException {
            runController.nextStep();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_F9, 0);
        }
    };
    private final Action stopAction = new RunControllerAction("Stop", ActionIconsProvider.STOP_ICON) {

        @Override
        protected void perform(String actionTitle, IRunController runController) throws AlgorithmRunException {
            runController.stopRun();
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0);
        }
    };
    private final Action verboseAction = new BasicGraphsJAction("Verbose", null) {

        @Override
        public void actionPerformed(ActionEvent e) {
            verboseRun = !verboseRun;
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0);
        }
    };
    private final Action helpAction = new BasicGraphsJAction("Help", ActionIconsProvider.HELP_ICON) {

        private final HelpDialog mainHelpDialog = new HelpDialog(Application.class.getResource("Help.html"));
        
        {
            mainHelpDialog.setModal(false);        
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            mainHelpDialog.setVisible(true);
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0);
        }
    };
    private final Action aboutAction = new BasicGraphsJAction("About...", ActionIconsProvider.ABOUT_ICON) {

        private AboutDialog aboutDialog = new AboutDialog();

        @Override
        public void actionPerformed(ActionEvent e) {
            aboutDialog.setVisible(true);
        }

        @Override
        protected KeyStroke getAccelerator() {
            return KeyStroke.getKeyStroke(KeyEvent.VK_F12, 0);
        }
    };

    public static ActionProvider getInstance() {
        return instance;
    }

    public Action getNewAction() {
        return newAction;
    }

    public Action getOpenAction() {
        return openAction;
    }

    public Action getSaveAction() {
        return saveAction;
    }

    public Action getSaveAsAction() {
        return saveAsAction;
    }

    public Action getCloseAction() {
        return closeAction;
    }

    public Action getUndoAction() {
        return undoAction;
    }

    public Action getRedoAction() {
        return redoAction;
    }

    public Action getSelectAllAction() {
        return selectAllAction;
    }

    public Action getDeleteAction() {
        return deleteAction;
    }

    public Action getRunAction() {
        return runAction;
    }

    public Action getRunStepByStepAction() {
        return runStepByStepAction;
    }

    public Action getNextStepAction() {
        return nextStepAction;
    }

    public Action getStopAction() {
        return stopAction;
    }

    public Action getVerboseAction() {
        return verboseAction;
    }

    public Action getHelpAction() {
        return helpAction;
    }

    public Action getAboutAction() {
        return aboutAction;
    }

    private void refreshActionsForDocumentAndRunState() {
        GraphDocument document = DocumentManager.getInstance().getDocument();
        boolean hasDocument = document != null;

        boolean running = false;
        IRunController runController = null;
        GraphCanvas canvas = null;

        if (hasDocument) {
            runController = document.getAlgorithm().getRunController();
            running = runController.isRunning();
            canvas = document.getGraphCanvas();
        }


        undoAction.setEnabled(hasDocument && canvas.isUndoable() && !running);
        redoAction.setEnabled(hasDocument && canvas.isRedoable() && !running);
        selectAllAction.setEnabled(hasDocument && !running);
        deleteAction.setEnabled(hasDocument && !running);

        runAction.setEnabled(hasDocument && !running);
        runStepByStepAction.setEnabled(hasDocument && !running);
        nextStepAction.setEnabled(hasDocument && runController.getRunState() == RunStateEnum.STEP_RUNNING);
        stopAction.setEnabled(hasDocument && running);
        verboseAction.setEnabled(hasDocument && !running);
    }
    private final ActionListener onDocumentChangedHandler = new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
            final GraphDocument document = DocumentManager.getInstance().getDocument();


            boolean hasDocument = (document != null);
            saveAction.setEnabled(hasDocument);
            saveAsAction.setEnabled(hasDocument);
            closeAction.setEnabled(hasDocument);

            refreshActionsForDocumentAndRunState();


            if (document == null) {
                return;
            }


            final GraphCanvas canvas = document.getGraphCanvas();

            ActionListener saveListener = new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    saveAction.setEnabled(document.isModified());
                }
            };

            saveListener.actionPerformed(null);
            document.getOnModifiedChanged().add(saveListener);

            document.getAlgorithm().getRunController().getOnRunStateChanged().add(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    refreshActionsForDocumentAndRunState();
                }
            });



            ActionListener undoListener = new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    undoAction.setEnabled(canvas.isUndoable());
                    redoAction.setEnabled(canvas.isRedoable());
                }
            };

            undoListener.actionPerformed(null);
            canvas.getOnUndoProviderStateChanged().add(undoListener);
        }
    };

    private ActionProvider() {
        onDocumentChangedHandler.actionPerformed(null);
        DocumentManager.getInstance().getOnDocumentChanged().add(onDocumentChangedHandler);
    }
}
