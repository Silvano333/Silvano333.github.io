/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.frames.main;

import gianlucacosta86.graphsj2.AppPreferences;
import gianlucacosta86.graphsj2.model.algorithms.IAlgorithm;
import gianlucacosta86.graphsj2.Application;
import gianlucacosta86.graphsj2.controller.RecentDocumentsQueue;
import gianlucacosta86.graphsj2.controller.graphdocument.DocumentManager;
import gianlucacosta86.graphsj2.controller.graphdocument.GraphDocument;
import gianlucacosta86.graphsj2.model.algorithms.IRunController;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.IAlgorithmConsoleWriter;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;
import gianlucacosta86.graphsj2.view.dialogs.helpdialog.HelpDialog;
import gianlucacosta86.graphsj2.view.actionclasses.AlgorithmAction;
import gianlucacosta86.graphsj2.view.actionclasses.RecentDocumentAction;
import gianlucacosta86.graphsj2.view.actionclasses.drawerspropertyaction.reflective.edgedrawers.EdgeDrawersColorAction;
import gianlucacosta86.graphsj2.view.actionclasses.drawerspropertyaction.reflective.edgedrawers.EdgeDrawersIntegerAction;
import gianlucacosta86.graphsj2.view.actionclasses.drawerspropertyaction.reflective.vertexdrawers.VertexDrawersColorAction;
import gianlucacosta86.graphsj2.view.actionclasses.drawerspropertyaction.reflective.vertexdrawers.VertexDrawersIntegerAction;
import gianlucacosta86.graphsj2.view.actionclasses.reflective.DocumentGraphCanvasPropertyAction;
import gianlucacosta86.graphsj2.view.dialogs.filechoicekeeper.EnhancedFileFilter;
import gianlucacosta86.graphsj2.view.dialogs.filechoicekeeper.FileChoiceKeeper;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import javax.swing.JFrame;
import javax.swing.KeyStroke;

/**
 *
 * @author Gianluca Costa
 */
public class MainFrame extends javax.swing.JFrame {

    private final ActionListener onDocumentChangedListener = new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
            final GraphDocument currentDocument = DocumentManager.getInstance().getDocument();

            setStatusText("");
            refreshGUIforDocumentChange();

            boolean hasDocument = (currentDocument != null);

            if (!hasDocument) {
                return;
            }


            bindNonProvidedActions();


            currentDocument.getOnFileChanged().add(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    refreshTitle();
                }
            });



            currentDocument.getOnModifiedChanged().add(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    refreshTitle();
                }
            });



            final IRunController runController = currentDocument.getAlgorithm().getRunController();

            runController.getConsole().addWriter(new IAlgorithmConsoleWriter() {

                @Override
                public void write(String text) {
                    consoleArea.append(text);
                }

                @Override
                public void writeLine(String text) {
                    consoleArea.append(text + "\n");
                }
            });


            refreshGUIforRunState();

            runController.getOnRunStateChanged().add(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    refreshGUIforRunState();
                }
            });



            runController.getOnStepInitiated().add(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    String stepDescription = runController.getStepDescription();

                    if (stepDescription == null || stepDescription.equals("")) {
                        setStatusText(String.format("Step %d...", runController.getCurrentStep()));
                    } else {
                        setStatusText(String.format("Step %d - %s", runController.getCurrentStep(), stepDescription));
                    }
                }
            });



            runController.getOnStepCompleted().add(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    String completedStepDescription = runController.getCompletedStepDescription();

                    if (completedStepDescription == null || completedStepDescription.equals("")) {
                        setStatusText(String.format("Step %d completed", runController.getCurrentStep()));
                    } else {
                        setStatusText(String.format("Step %d completed - %s", runController.getCurrentStep(), completedStepDescription));
                    }
                }
            });

        }
    };
    private final EnhancedFileFilter textFileFilter = new EnhancedFileFilter("Text file", ".txt");
    private final FileChoiceKeeper outputChoiceKeeper = new FileChoiceKeeper("console output", textFileFilter);

    /** Creates new form MainFrame */
    public MainFrame() {
        initComponents();
        setSize(640, 480);
        setIconImage(Application.SMALL_ICON.getImage());
        setLocationRelativeTo(null);

        try {
            rebuildRecentMenu();
        } catch (Exception ex) {
            AppPreferences.getInstance().clearRecentDocumentQueueSettings();
            rebuildRecentMenu();
        }

        RecentDocumentsQueue.getInstance().getOnModified().add(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                rebuildRecentMenu();
            }
        });



        onDocumentChangedListener.actionPerformed(null);
        DocumentManager.getInstance().getOnDocumentChanged().add(onDocumentChangedListener);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        toolbarPanel = new javax.swing.JPanel();
        fileToolbar = new javax.swing.JToolBar();
        newButton = new javax.swing.JButton();
        openButton = new javax.swing.JButton();
        jSeparator15 = new javax.swing.JToolBar.Separator();
        saveButton = new javax.swing.JButton();
        saveAsButton = new javax.swing.JButton();
        editToolbar = new javax.swing.JToolBar();
        undoButton = new javax.swing.JButton();
        redoButton = new javax.swing.JButton();
        runToolbar = new javax.swing.JToolBar();
        runButton = new javax.swing.JButton();
        runStepByStepButton = new javax.swing.JButton();
        jSeparator21 = new javax.swing.JToolBar.Separator();
        nextStepButton = new javax.swing.JButton();
        stopButton = new javax.swing.JButton();
        helpToolbar = new javax.swing.JToolBar();
        helpButton = new javax.swing.JButton();
        aboutButton = new javax.swing.JButton();
        mainPanel = new javax.swing.JPanel();
        mainSplitter = new javax.swing.JSplitPane();
        consoleScrollPane = new javax.swing.JScrollPane();
        consoleArea = new javax.swing.JTextArea();
        canvasScrollPane = new javax.swing.JScrollPane();
        canvasPanel = new javax.swing.JPanel();
        statusBar = new javax.swing.JPanel();
        statusLabel = new javax.swing.JLabel();
        mainMenuBar = new javax.swing.JMenuBar();
        graphMenu = new javax.swing.JMenu();
        newMenuItem = new javax.swing.JMenuItem();
        openMenuItem = new javax.swing.JMenuItem();
        jSeparator10 = new javax.swing.JSeparator();
        recentDocumentsMenu = new javax.swing.JMenu();
        jSeparator11 = new javax.swing.JSeparator();
        saveMenuItem = new javax.swing.JMenuItem();
        saveAsMenuItem = new javax.swing.JMenuItem();
        closeMenuItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        exitMenuItem = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        undoMenuItem = new javax.swing.JMenuItem();
        redoMenuItem = new javax.swing.JMenuItem();
        jSeparator18 = new javax.swing.JSeparator();
        selectAllMenuItem = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JSeparator();
        deleteMenuItem = new javax.swing.JMenuItem();
        consoleMenu = new javax.swing.JMenu();
        saveConsoleAsMenuItem = new javax.swing.JMenuItem();
        clearConsoleMenuItem = new javax.swing.JMenuItem();
        runMenu = new javax.swing.JMenu();
        runMenuItem = new javax.swing.JMenuItem();
        runStepByStepMenuItem = new javax.swing.JMenuItem();
        jSeparator14 = new javax.swing.JSeparator();
        nextStepMenuItem = new javax.swing.JMenuItem();
        stopMenuItem = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JSeparator();
        verboseMenuItem = new javax.swing.JCheckBoxMenuItem();
        algorithmMenu = new javax.swing.JMenu();
        algorithmNameMenuItem = new javax.swing.JMenuItem();
        algorithmHelpMenuItem = new javax.swing.JMenuItem();
        jSeparator13 = new javax.swing.JSeparator();
        algorithmOptionsMenuItem = new javax.swing.JMenuItem();
        optionsMenu = new javax.swing.JMenu();
        jMenu9 = new javax.swing.JMenu();
        maximumUndoCountMenuItem = new javax.swing.JMenuItem();
        clearRecentDocumentsQueueMenuItem = new javax.swing.JMenuItem();
        jSeparator17 = new javax.swing.JSeparator();
        canvasPropertiesMenu = new javax.swing.JMenu();
        canvasColorMenuItem = new javax.swing.JMenuItem();
        canvasSizeMenuItem = new javax.swing.JMenuItem();
        jSeparator12 = new javax.swing.JSeparator();
        vertexNameRootMenuItem = new javax.swing.JMenuItem();
        vertexNameCounterMenuItem = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JSeparator();
        vertexPropertiesMenu = new javax.swing.JMenu();
        vertexColorMenuItem = new javax.swing.JMenuItem();
        vertexBorderColorMenuItem = new javax.swing.JMenuItem();
        vertexBorderSizeMenuItem = new javax.swing.JMenuItem();
        vertexPaddingMenuItem = new javax.swing.JMenuItem();
        jSeparator8 = new javax.swing.JSeparator();
        vertexFontSizeMenuItem = new javax.swing.JMenuItem();
        vertexFontColorMenuItem = new javax.swing.JMenuItem();
        vertexSelectedFontColorMenuItem = new javax.swing.JMenuItem();
        jSeparator9 = new javax.swing.JSeparator();
        vertexSelectedColorMenuItem = new javax.swing.JMenuItem();
        vertexSelectedBorderColorMenuItem = new javax.swing.JMenuItem();
        edgePropertiesMenu = new javax.swing.JMenu();
        edgeColorMenuItem = new javax.swing.JMenuItem();
        edgeLineSizeMenuItem = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JSeparator();
        edgeFontColorMenuItem = new javax.swing.JMenuItem();
        edgeFontSizeMenuItem = new javax.swing.JMenuItem();
        edgeSelectedFontColorMenuItem = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JSeparator();
        edgeSelectedColorMenuItem = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        helpMenuItem = new javax.swing.JMenuItem();
        aboutMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {

            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        toolbarPanel.setLayout(new javax.swing.BoxLayout(toolbarPanel, javax.swing.BoxLayout.LINE_AXIS));

        fileToolbar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        fileToolbar.setFloatable(false);
        fileToolbar.setRollover(true);
        fileToolbar.setName("File Toolbar"); // NOI18N

        newButton.setAction(ActionProvider.getInstance().getNewAction());
        newButton.setFocusable(false);
        newButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        newButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        fileToolbar.add(newButton);

        openButton.setAction(ActionProvider.getInstance().getOpenAction());
        openButton.setFocusable(false);
        openButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        openButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        fileToolbar.add(openButton);
        fileToolbar.add(jSeparator15);

        saveButton.setAction(ActionProvider.getInstance().getSaveAction());
        saveButton.setFocusable(false);
        saveButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        fileToolbar.add(saveButton);

        saveAsButton.setAction(ActionProvider.getInstance().getSaveAsAction());
        saveAsButton.setFocusable(false);
        saveAsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveAsButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        fileToolbar.add(saveAsButton);

        toolbarPanel.add(fileToolbar);

        editToolbar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        editToolbar.setFloatable(false);
        editToolbar.setRollover(true);
        editToolbar.setName("Edit Toolbar"); // NOI18N

        undoButton.setAction(ActionProvider.getInstance().getUndoAction());
        undoButton.setFocusable(false);
        undoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        undoButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editToolbar.add(undoButton);

        redoButton.setAction(ActionProvider.getInstance().getRedoAction());
        redoButton.setFocusable(false);
        redoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        redoButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editToolbar.add(redoButton);

        toolbarPanel.add(editToolbar);

        runToolbar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        runToolbar.setFloatable(false);
        runToolbar.setRollover(true);
        runToolbar.setName("Run Toolbar"); // NOI18N

        runButton.setAction(ActionProvider.getInstance().getRunAction());
        runButton.setFocusable(false);
        runButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        runButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        runToolbar.add(runButton);

        runStepByStepButton.setAction(ActionProvider.getInstance().getRunStepByStepAction());
        runStepByStepButton.setFocusable(false);
        runStepByStepButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        runStepByStepButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        runToolbar.add(runStepByStepButton);
        runToolbar.add(jSeparator21);

        nextStepButton.setAction(ActionProvider.getInstance().getNextStepAction());
        nextStepButton.setFocusable(false);
        nextStepButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        nextStepButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        runToolbar.add(nextStepButton);

        stopButton.setAction(ActionProvider.getInstance().getStopAction());
        stopButton.setFocusable(false);
        stopButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        stopButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        runToolbar.add(stopButton);

        toolbarPanel.add(runToolbar);

        helpToolbar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        helpToolbar.setFloatable(false);
        helpToolbar.setRollover(true);
        helpToolbar.setName("Help Toolbar"); // NOI18N

        helpButton.setAction(ActionProvider.getInstance().getHelpAction());
        helpButton.setFocusable(false);
        helpButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        helpButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        helpToolbar.add(helpButton);

        aboutButton.setAction(ActionProvider.getInstance().getAboutAction());
        aboutButton.setFocusable(false);
        aboutButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        aboutButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        helpToolbar.add(aboutButton);

        toolbarPanel.add(helpToolbar);

        getContentPane().add(toolbarPanel, java.awt.BorderLayout.PAGE_START);

        mainPanel.setLayout(new java.awt.BorderLayout());

        mainSplitter.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        mainSplitter.setResizeWeight(0.75);

        consoleArea.setColumns(20);
        consoleArea.setEditable(false);
        consoleArea.setFont(new java.awt.Font("Courier New", 0, 13));
        consoleArea.setRows(5);
        consoleScrollPane.setViewportView(consoleArea);

        mainSplitter.setBottomComponent(consoleScrollPane);

        canvasPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        canvasScrollPane.setViewportView(canvasPanel);

        mainSplitter.setLeftComponent(canvasScrollPane);

        mainPanel.add(mainSplitter, java.awt.BorderLayout.CENTER);

        getContentPane().add(mainPanel, java.awt.BorderLayout.CENTER);

        statusBar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        statusBar.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        statusLabel.setText(" ");
        statusBar.add(statusLabel);

        getContentPane().add(statusBar, java.awt.BorderLayout.PAGE_END);

        graphMenu.setMnemonic('G');
        graphMenu.setText("Graph");

        newMenuItem.setAction(ActionProvider.getInstance().getNewAction());
        graphMenu.add(newMenuItem);

        openMenuItem.setAction(ActionProvider.getInstance().getOpenAction());
        graphMenu.add(openMenuItem);
        graphMenu.add(jSeparator10);

        recentDocumentsMenu.setText("Recent documents");
        graphMenu.add(recentDocumentsMenu);
        graphMenu.add(jSeparator11);

        saveMenuItem.setAction(ActionProvider.getInstance().getSaveAction());
        graphMenu.add(saveMenuItem);

        saveAsMenuItem.setAction(ActionProvider.getInstance().getSaveAsAction());
        graphMenu.add(saveAsMenuItem);

        closeMenuItem.setAction(ActionProvider.getInstance().getCloseAction());
        graphMenu.add(closeMenuItem);
        graphMenu.add(jSeparator1);

        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        graphMenu.add(exitMenuItem);

        mainMenuBar.add(graphMenu);

        editMenu.setMnemonic('E');
        editMenu.setText("Edit");

        undoMenuItem.setAction(ActionProvider.getInstance().getUndoAction());
        editMenu.add(undoMenuItem);

        redoMenuItem.setAction(ActionProvider.getInstance().getRedoAction());
        editMenu.add(redoMenuItem);
        editMenu.add(jSeparator18);

        selectAllMenuItem.setAction(ActionProvider.getInstance().getSelectAllAction());
        editMenu.add(selectAllMenuItem);
        editMenu.add(jSeparator2);

        deleteMenuItem.setAction(ActionProvider.getInstance().getDeleteAction());
        editMenu.add(deleteMenuItem);

        mainMenuBar.add(editMenu);

        consoleMenu.setMnemonic('C');
        consoleMenu.setText("Console");

        saveConsoleAsMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        saveConsoleAsMenuItem.setText("Save as...");
        saveConsoleAsMenuItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveConsoleAsMenuItemActionPerformed(evt);
            }
        });
        consoleMenu.add(saveConsoleAsMenuItem);

        clearConsoleMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        clearConsoleMenuItem.setText("Clear");
        clearConsoleMenuItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearConsoleMenuItemActionPerformed(evt);
            }
        });
        consoleMenu.add(clearConsoleMenuItem);

        mainMenuBar.add(consoleMenu);

        runMenu.setMnemonic('R');
        runMenu.setText("Run");

        runMenuItem.setAction(ActionProvider.getInstance().getRunAction());
        runMenu.add(runMenuItem);

        runStepByStepMenuItem.setAction(ActionProvider.getInstance().getRunStepByStepAction());
        runMenu.add(runStepByStepMenuItem);
        runMenu.add(jSeparator14);

        nextStepMenuItem.setAction(ActionProvider.getInstance().getNextStepAction());
        runMenu.add(nextStepMenuItem);

        stopMenuItem.setAction(ActionProvider.getInstance().getStopAction());
        runMenu.add(stopMenuItem);
        runMenu.add(jSeparator4);

        verboseMenuItem.setAction(ActionProvider.getInstance().getVerboseAction());
        verboseMenuItem.setSelected(true);
        runMenu.add(verboseMenuItem);

        mainMenuBar.add(runMenu);

        algorithmMenu.setMnemonic('A');
        algorithmMenu.setText("Algorithm");
        algorithmMenu.add(algorithmNameMenuItem);
        algorithmMenu.add(algorithmHelpMenuItem);
        algorithmMenu.add(jSeparator13);
        algorithmMenu.add(algorithmOptionsMenuItem);

        mainMenuBar.add(algorithmMenu);

        optionsMenu.setMnemonic('O');
        optionsMenu.setText("Options");

        jMenu9.setText("Application");

        maximumUndoCountMenuItem.setText("Maximum undo count...");
        maximumUndoCountMenuItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maximumUndoCountMenuItemActionPerformed(evt);
            }
        });
        jMenu9.add(maximumUndoCountMenuItem);

        clearRecentDocumentsQueueMenuItem.setText("Clear recent documents queue");
        clearRecentDocumentsQueueMenuItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearRecentDocumentsQueueMenuItemActionPerformed(evt);
            }
        });
        jMenu9.add(clearRecentDocumentsQueueMenuItem);

        optionsMenu.add(jMenu9);
        optionsMenu.add(jSeparator17);

        canvasPropertiesMenu.setText("Canvas properties");
        canvasPropertiesMenu.add(canvasColorMenuItem);
        canvasPropertiesMenu.add(canvasSizeMenuItem);
        canvasPropertiesMenu.add(jSeparator12);
        canvasPropertiesMenu.add(vertexNameRootMenuItem);
        canvasPropertiesMenu.add(vertexNameCounterMenuItem);

        optionsMenu.add(canvasPropertiesMenu);
        optionsMenu.add(jSeparator5);

        vertexPropertiesMenu.setText("Vertex properties");
        vertexPropertiesMenu.add(vertexColorMenuItem);
        vertexPropertiesMenu.add(vertexBorderColorMenuItem);
        vertexPropertiesMenu.add(vertexBorderSizeMenuItem);
        vertexPropertiesMenu.add(vertexPaddingMenuItem);
        vertexPropertiesMenu.add(jSeparator8);
        vertexPropertiesMenu.add(vertexFontSizeMenuItem);
        vertexPropertiesMenu.add(vertexFontColorMenuItem);
        vertexPropertiesMenu.add(vertexSelectedFontColorMenuItem);
        vertexPropertiesMenu.add(jSeparator9);
        vertexPropertiesMenu.add(vertexSelectedColorMenuItem);
        vertexPropertiesMenu.add(vertexSelectedBorderColorMenuItem);

        optionsMenu.add(vertexPropertiesMenu);

        edgePropertiesMenu.setText("Edge properties");
        edgePropertiesMenu.add(edgeColorMenuItem);
        edgePropertiesMenu.add(edgeLineSizeMenuItem);
        edgePropertiesMenu.add(jSeparator7);
        edgePropertiesMenu.add(edgeFontColorMenuItem);
        edgePropertiesMenu.add(edgeFontSizeMenuItem);
        edgePropertiesMenu.add(edgeSelectedFontColorMenuItem);
        edgePropertiesMenu.add(jSeparator6);
        edgePropertiesMenu.add(edgeSelectedColorMenuItem);

        optionsMenu.add(edgePropertiesMenu);

        mainMenuBar.add(optionsMenu);

        helpMenu.setMnemonic('H');
        helpMenu.setText("Help");

        helpMenuItem.setAction(ActionProvider.getInstance().getHelpAction());
        helpMenu.add(helpMenuItem);

        aboutMenuItem.setAction(ActionProvider.getInstance().getAboutAction());
        helpMenu.add(aboutMenuItem);

        mainMenuBar.add(helpMenu);

        setJMenuBar(mainMenuBar);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        if (DocumentManager.getInstance().doClose()) {
            System.exit(0);
        }
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void clearConsoleMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearConsoleMenuItemActionPerformed
        consoleArea.setText("");
    }//GEN-LAST:event_clearConsoleMenuItemActionPerformed

    private void saveConsoleAsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveConsoleAsMenuItemActionPerformed
        File chosenFile = outputChoiceKeeper.askToSave();

        if (chosenFile == null) {
            return;
        }


        try {
            FileWriter writer = new FileWriter(chosenFile);

            try {
                writer.write(consoleArea.getText());
            } finally {
                writer.close();
            }
        } catch (IOException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
        }
    }//GEN-LAST:event_saveConsoleAsMenuItemActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        exitMenuItemActionPerformed(null);
    }//GEN-LAST:event_formWindowClosing

    private void clearRecentDocumentsQueueMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearRecentDocumentsQueueMenuItemActionPerformed
        RecentDocumentsQueue.getInstance().clear();
    }//GEN-LAST:event_clearRecentDocumentsQueueMenuItemActionPerformed

    private void maximumUndoCountMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maximumUndoCountMenuItemActionPerformed
        Integer newVal = MessageProvider.getInstance().askForInteger("Please, input the desired number of actions that can be undone:", maximumUndoCountMenuItem.getText(), AppPreferences.getInstance().getUndoMaxSize(), 1, null);

        if (newVal == null) {
            return;
        }

        AppPreferences.getInstance().setUndoMaxSize(newVal);

        if (DocumentManager.getInstance().getDocument() != null) {
            MessageProvider.getInstance().showInfoBox("The undo/redo settings have been correctly saved, but they will be effective starting from the next document.");
        }

    }//GEN-LAST:event_maximumUndoCountMenuItemActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton aboutButton;
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.JMenuItem algorithmHelpMenuItem;
    private javax.swing.JMenu algorithmMenu;
    private javax.swing.JMenuItem algorithmNameMenuItem;
    private javax.swing.JMenuItem algorithmOptionsMenuItem;
    private javax.swing.JMenuItem canvasColorMenuItem;
    private javax.swing.JPanel canvasPanel;
    private javax.swing.JMenu canvasPropertiesMenu;
    private javax.swing.JScrollPane canvasScrollPane;
    private javax.swing.JMenuItem canvasSizeMenuItem;
    private javax.swing.JMenuItem clearConsoleMenuItem;
    private javax.swing.JMenuItem clearRecentDocumentsQueueMenuItem;
    private javax.swing.JMenuItem closeMenuItem;
    private javax.swing.JTextArea consoleArea;
    private javax.swing.JMenu consoleMenu;
    private javax.swing.JScrollPane consoleScrollPane;
    private javax.swing.JMenuItem deleteMenuItem;
    private javax.swing.JMenuItem edgeColorMenuItem;
    private javax.swing.JMenuItem edgeFontColorMenuItem;
    private javax.swing.JMenuItem edgeFontSizeMenuItem;
    private javax.swing.JMenuItem edgeLineSizeMenuItem;
    private javax.swing.JMenu edgePropertiesMenu;
    private javax.swing.JMenuItem edgeSelectedColorMenuItem;
    private javax.swing.JMenuItem edgeSelectedFontColorMenuItem;
    private javax.swing.JMenu editMenu;
    private javax.swing.JToolBar editToolbar;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JToolBar fileToolbar;
    private javax.swing.JMenu graphMenu;
    private javax.swing.JButton helpButton;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JMenuItem helpMenuItem;
    private javax.swing.JToolBar helpToolbar;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator14;
    private javax.swing.JToolBar.Separator jSeparator15;
    private javax.swing.JSeparator jSeparator17;
    private javax.swing.JSeparator jSeparator18;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator21;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JMenuBar mainMenuBar;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JSplitPane mainSplitter;
    private javax.swing.JMenuItem maximumUndoCountMenuItem;
    private javax.swing.JButton newButton;
    private javax.swing.JMenuItem newMenuItem;
    private javax.swing.JButton nextStepButton;
    private javax.swing.JMenuItem nextStepMenuItem;
    private javax.swing.JButton openButton;
    private javax.swing.JMenuItem openMenuItem;
    private javax.swing.JMenu optionsMenu;
    private javax.swing.JMenu recentDocumentsMenu;
    private javax.swing.JButton redoButton;
    private javax.swing.JMenuItem redoMenuItem;
    private javax.swing.JButton runButton;
    private javax.swing.JMenu runMenu;
    private javax.swing.JMenuItem runMenuItem;
    private javax.swing.JButton runStepByStepButton;
    private javax.swing.JMenuItem runStepByStepMenuItem;
    private javax.swing.JToolBar runToolbar;
    private javax.swing.JButton saveAsButton;
    private javax.swing.JMenuItem saveAsMenuItem;
    private javax.swing.JButton saveButton;
    private javax.swing.JMenuItem saveConsoleAsMenuItem;
    private javax.swing.JMenuItem saveMenuItem;
    private javax.swing.JMenuItem selectAllMenuItem;
    private javax.swing.JPanel statusBar;
    private javax.swing.JLabel statusLabel;
    private javax.swing.JButton stopButton;
    private javax.swing.JMenuItem stopMenuItem;
    private javax.swing.JPanel toolbarPanel;
    private javax.swing.JButton undoButton;
    private javax.swing.JMenuItem undoMenuItem;
    private javax.swing.JCheckBoxMenuItem verboseMenuItem;
    private javax.swing.JMenuItem vertexBorderColorMenuItem;
    private javax.swing.JMenuItem vertexBorderSizeMenuItem;
    private javax.swing.JMenuItem vertexColorMenuItem;
    private javax.swing.JMenuItem vertexFontColorMenuItem;
    private javax.swing.JMenuItem vertexFontSizeMenuItem;
    private javax.swing.JMenuItem vertexNameCounterMenuItem;
    private javax.swing.JMenuItem vertexNameRootMenuItem;
    private javax.swing.JMenuItem vertexPaddingMenuItem;
    private javax.swing.JMenu vertexPropertiesMenu;
    private javax.swing.JMenuItem vertexSelectedBorderColorMenuItem;
    private javax.swing.JMenuItem vertexSelectedColorMenuItem;
    private javax.swing.JMenuItem vertexSelectedFontColorMenuItem;
    // End of variables declaration//GEN-END:variables

    private void refreshGUIforDocumentChange() {
        GraphDocument document = DocumentManager.getInstance().getDocument();
        boolean hasDocument = document != null;

        editMenu.setEnabled(hasDocument);
        consoleMenu.setEnabled(hasDocument);
        runMenu.setEnabled(hasDocument);
        algorithmMenu.setEnabled(hasDocument);

        canvasPropertiesMenu.setEnabled(hasDocument);
        vertexPropertiesMenu.setEnabled(hasDocument);
        edgePropertiesMenu.setEnabled(hasDocument);

        mainPanel.setVisible(hasDocument);

        refreshTitle();
    }

    private void refreshTitle() {
        GraphDocument document = DocumentManager.getInstance().getDocument();

        if (document == null) {
            setTitle(Application.TITLE);
            return;
        }

        File documentFile = document.getFile();
        String filePath;



        if (documentFile != null) {
            filePath = documentFile.getAbsolutePath();
        } else {
            filePath = "(untitled)";
        }

        String title = String.format("%s - %s", Application.TITLE, filePath);

        if (document.isModified()) {
            title += " *";
        }

        setTitle(title);
    }

    private void refreshGUIforRunState() {
        IRunController runController = DocumentManager.getInstance().getDocument().getAlgorithm().getRunController();

        canvasPanel.removeAll();


        if (!runController.isRunning()) {
            GraphCanvas inputCanvas = DocumentManager.getInstance().getDocument().getGraphCanvas();
            canvasPanel.add(inputCanvas);
            inputCanvas.requestFocusInWindow();
            inputCanvas.repaint();

        } else {
            GraphCanvas outputCanvas = runController.getOutputCanvas();
            canvasPanel.add(outputCanvas);
            outputCanvas.requestFocusInWindow();

            outputCanvas.repaint();
        }

        canvasPanel.repaint();
    }

    private void setStatusText(String text) {
        if (text.equals("")) {
            text = " ";
        }

        statusLabel.setText(text);
    }

    private void rebuildRecentMenu() {
        recentDocumentsMenu.removeAll();

        for (File file : RecentDocumentsQueue.getInstance()) {
            recentDocumentsMenu.add(new RecentDocumentAction(file));
        }


        recentDocumentsMenu.setEnabled(!RecentDocumentsQueue.getInstance().isEmpty());
    }

    private void bindNonProvidedActions() {
        final GraphCanvas canvas = DocumentManager.getInstance().getDocument().getGraphCanvas();


        //ALGORITHM MENU
        algorithmNameMenuItem.setAction(new AlgorithmAction("Show name") {

            @Override
            protected void perform(String actionTitle, IAlgorithm algorithm) {
                MessageProvider.getInstance().showInfoBox(algorithm.getAlgorithmName(), "Algorithm Name");
            }

            @Override
            protected KeyStroke getAccelerator() {
                return KeyStroke.getKeyStroke(KeyEvent.VK_D, InputEvent.CTRL_DOWN_MASK);
            }
        });


        algorithmHelpMenuItem.setAction(new AlgorithmAction("Show help") {

            @Override
            protected void perform(String actionTitle, IAlgorithm algorithm) {
                URL helpUrl = algorithm.getHelpUrl();
                if (helpUrl == null) {
                    MessageProvider.getInstance().showInfoBox("No help associated with this algorithm");
                } else {
                    HelpDialog algorithmHelpDialog = new HelpDialog(helpUrl, algorithm.getAlgorithmName());                    
                    algorithmHelpDialog.setVisible(true);                                                  
                    algorithmHelpDialog.dispose();
                }
            }

            @Override
            protected KeyStroke getAccelerator() {
                return KeyStroke.getKeyStroke(KeyEvent.VK_H, InputEvent.CTRL_DOWN_MASK);
            }
        });


        algorithmOptionsMenuItem.setAction(new AlgorithmAction("Show options...") {

            @Override
            protected void perform(String actionTitle, IAlgorithm algorithm) {
                if (algorithm.showOptionsDialog()) {
                    DocumentManager.getInstance().getDocument().setModified();
                }
            }

            @Override
            protected KeyStroke getAccelerator() {
                return KeyStroke.getKeyStroke(KeyEvent.VK_P, InputEvent.CTRL_DOWN_MASK);
            }
        });




        //CANVAS MENU ITEMS


        canvasColorMenuItem.setAction(new DocumentGraphCanvasPropertyAction<Color>("Color...", "BackgroundWithModification", Color.class) {

            @Override
            protected Color askUserForValue(String actionTitle, Color initialValue) {
                return MessageProvider.getInstance().askForColor(actionTitle, initialValue);
            }
        });


        canvasSizeMenuItem.setAction(new DocumentGraphCanvasPropertyAction<Dimension>("Size...", "SizeWithModification", Dimension.class) {

            @Override
            protected Dimension askUserForValue(String actionTitle, Dimension initialValue) {
                Dimension currentSize = canvas.getSizeWithModification();
                Integer newWidth = MessageProvider.getInstance().askForInteger("Please, input the new width:", actionTitle, currentSize.width, 0, null);

                if (newWidth == null) {
                    return null;
                }


                Integer newHeight = MessageProvider.getInstance().askForInteger("Please, input the new height:", actionTitle, currentSize.height, 0, null);

                if (newHeight == null) {
                    return null;
                }

                return new Dimension(newWidth, newHeight);
            }
        });


        vertexNameRootMenuItem.setAction(new DocumentGraphCanvasPropertyAction<String>("Vertex name root...", "VertexNameRoot", String.class) {

            @Override
            protected String askUserForValue(String actionTitle, String initialValue) {
                return MessageProvider.getInstance().askForString("Please, input the new vertex name root:", actionTitle, canvas.getVertexNameRoot());
            }

            @Override
            protected KeyStroke getAccelerator() {
                return KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_DOWN_MASK);
            }
        });


        vertexNameCounterMenuItem.setAction(new DocumentGraphCanvasPropertyAction<Integer>("Vertex name counter...", "VertexNameCounter", int.class) {

            @Override
            protected Integer askUserForValue(String actionTitle, Integer initialValue) {
                return MessageProvider.getInstance().askForInteger("Please, input the new vertex name counter:", actionTitle, initialValue, 0, null);
            }

            @Override
            protected KeyStroke getAccelerator() {
                return KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_DOWN_MASK);
            }
        });


        //VERTEX DRAWER MENU ITEMS

        vertexColorMenuItem.setAction(new VertexDrawersColorAction("Color...", canvas, "Color"));
        vertexBorderColorMenuItem.setAction(new VertexDrawersColorAction("Border color...", canvas, "BorderColor"));
        vertexBorderSizeMenuItem.setAction(new VertexDrawersIntegerAction("Border size...", canvas, "BorderSize", 0, null));
        vertexPaddingMenuItem.setAction(new VertexDrawersIntegerAction("Padding...", canvas, "Padding", 0, null));

        vertexFontSizeMenuItem.setAction(new VertexDrawersIntegerAction("Font size...", canvas, "FontSize", 0, null));
        vertexFontColorMenuItem.setAction(new VertexDrawersColorAction("Font color...", canvas, "FontColor"));
        vertexSelectedFontColorMenuItem.setAction(new VertexDrawersColorAction("Selected font color...", canvas, "SelectedFontColor"));
        vertexSelectedColorMenuItem.setAction(new VertexDrawersColorAction("Selected color...", canvas, "SelectedColor"));
        vertexSelectedBorderColorMenuItem.setAction(new VertexDrawersColorAction("Selected border color...", canvas, "SelectedBorderColor"));


        //EDGE DRAWER MENU ITEMS
        edgeColorMenuItem.setAction(new EdgeDrawersColorAction("Color...", canvas, "Color"));
        edgeLineSizeMenuItem.setAction(new EdgeDrawersIntegerAction("Line size...", canvas, "LineSize", 0, null));
        edgeFontColorMenuItem.setAction(new EdgeDrawersColorAction("Font color...", canvas, "FontColor"));
        edgeFontSizeMenuItem.setAction(new EdgeDrawersIntegerAction("Font size...", canvas, "FontSize", 0, null));
        edgeSelectedFontColorMenuItem.setAction(new EdgeDrawersColorAction("Selected font color...", canvas, "SelectedFontColor"));
        edgeSelectedColorMenuItem.setAction(new EdgeDrawersColorAction("Selected color...", canvas, "SelectedColor"));

    }
}
