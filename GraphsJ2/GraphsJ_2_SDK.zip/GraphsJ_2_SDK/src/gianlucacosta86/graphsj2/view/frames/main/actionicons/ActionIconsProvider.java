/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.frames.main.actionicons;

import javax.swing.ImageIcon;

/**
 *
 * @author Gianluca Costa
 */
public final class ActionIconsProvider {

    public static ImageIcon NEW_ICON = loadIcon("New.png");
    public static ImageIcon OPEN_ICON = loadIcon("Open.png");
    public static ImageIcon SAVE_ICON = loadIcon("Save.png");
    public static ImageIcon SAVE_AS_ICON = loadIcon("SaveAs.png");
    public static ImageIcon UNDO_ICON = loadIcon("Undo.png");
    public static ImageIcon REDO_ICON = loadIcon("Redo.png");
    public static ImageIcon SELECT_ALL_ICON = loadIcon("SelectAll.png");
    public static ImageIcon DELETE_ICON = loadIcon("Delete.png");
    public static ImageIcon RUN_ICON = loadIcon("Run.png");
    public static ImageIcon RUN_STEP_BY_STEP_ICON = loadIcon("RunStepByStep.png");
    public static ImageIcon NEXT_STEP_ICON = loadIcon("NextStep.png");
    public static ImageIcon STOP_ICON = loadIcon("Stop.png");
    public static ImageIcon HELP_ICON = loadIcon("Help.png");
    public static ImageIcon ABOUT_ICON = loadIcon("About.png");

    private static ImageIcon loadIcon(String name) {
        return new ImageIcon(ActionIconsProvider.class.getResource(name));
    }

    private ActionIconsProvider() {
    }
}
