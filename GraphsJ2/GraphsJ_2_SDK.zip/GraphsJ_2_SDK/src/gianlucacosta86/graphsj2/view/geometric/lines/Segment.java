/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.geometric.lines;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Line2D;
import gianlucacosta86.graphsj2.view.geometric.IDrawable2D;
import gianlucacosta86.graphsj2.view.geometric.RoundedStroke;
import gianlucacosta86.graphsj2.view.geometric.rectangles.PreciseRectangle;

/**
 *
 * @author Gianluca Costa
 */
public class Segment implements IDrawable2D {

    private static final long serialVersionUID = 1;
    private final Point sourcePoint;
    private final Point targetPoint;
    private final int lineSize;

    public Segment(Point sourcePoint, Point targetPoint, int lineSize) {
        this.sourcePoint = sourcePoint;
        this.targetPoint = targetPoint;
        this.lineSize = lineSize;
    }

    public Point getSourcePoint() {
        return sourcePoint;
    }

    public Point getTargetPoint() {
        return targetPoint;
    }

    public int getLineSize() {
        return lineSize;
    }

    public Line2D.Double toLine() {
        return new Line2D.Double(sourcePoint.x, sourcePoint.y, targetPoint.x, targetPoint.y);
    }

    public double getAngle() {
        return Math.atan2(targetPoint.y - sourcePoint.y, targetPoint.x - sourcePoint.x);
    }

    public Point getIntersection(Rectangle rect) {
        double centerX = rect.getCenterX();
        double centerY = rect.getCenterY();

        Point rectCenter = new Point((int) centerX, (int) centerY);
        Point freePoint;

        if (rectCenter.equals(sourcePoint)) {
            freePoint = targetPoint;
        } else if (rectCenter.equals(targetPoint)) {
            freePoint = sourcePoint;
        } else {
            throw new IllegalArgumentException("The specified rectangle must be centered on one of the 2 segment extremes");
        }


        if (rect.contains(freePoint)) {
            return null;
        }


        double rectHalfWidth = rect.width / 2.0;
        double rectHalfHeight = rect.height / 2.0;


        double deltaX = freePoint.x - centerX;
        double deltaY = freePoint.y - centerY;
        double deltaXAbs = Math.abs(deltaX);
        double deltaYAbs = Math.abs(deltaY);

        double lineSizeTerm = lineSize / 2.0;

        double tanAlpha;

        tanAlpha = deltaX / deltaYAbs;
        double dx = rectHalfHeight * tanAlpha;


        tanAlpha = deltaY / deltaXAbs;
        double dy = rectHalfWidth * tanAlpha;



        //If the intersection point falls on a vertical side...
        if (Math.abs(dx) > rectHalfWidth) {
            dx = rectHalfWidth * Math.signum(dx);
        } else if (Math.abs(dy) > rectHalfHeight) { //..else, if it falls on a horizontal side...
            dy = rectHalfHeight * Math.signum(dy);
        }


        if (Math.abs(dx) == rectHalfWidth) {
            dx += lineSizeTerm * Math.signum(dx);
        }

        if (Math.abs(dy) == rectHalfHeight) {
            dy += lineSizeTerm * Math.signum(dy);
        }

        return new Point((int) (centerX + dx), (int) (centerY + dy));
    }

    public boolean containsPoint(Point point) {
        double halfLineSize = lineSize / 2.0;

        if (getRect().contains(point)) {
            return toLine().ptLineDist(point) <= halfLineSize;
        }

        double sourceDistance = Point.distance(sourcePoint.x, sourcePoint.y, point.x, point.y);
        if (sourceDistance <= halfLineSize) {
            return true;
        }

        double targetDistance = Point.distance(targetPoint.x, targetPoint.y, point.x, point.y);
        if (targetDistance <= halfLineSize) {
            return true;
        }

        return false;
    }

    public PreciseRectangle getRect() {
        return new PreciseRectangle(sourcePoint, targetPoint);
    }

    @Override
    public void drawOn(Graphics2D g) {
        g.setStroke(new RoundedStroke(lineSize));
        g.drawLine(sourcePoint.x, sourcePoint.y, targetPoint.x, targetPoint.y);
    }

    public boolean intersects(Rectangle rect) {
        return toLine().intersects(rect);
    }
}
