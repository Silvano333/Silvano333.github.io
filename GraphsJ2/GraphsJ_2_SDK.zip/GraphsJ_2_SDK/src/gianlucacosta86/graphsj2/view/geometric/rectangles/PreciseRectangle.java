/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.geometric.rectangles;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import gianlucacosta86.graphsj2.view.geometric.IDrawable2D;

/**
 *
 * @author Gianluca Costa
 */
public class PreciseRectangle extends Rectangle implements IDrawable2D {

    private static final long serialVersionUID = 1;

    public PreciseRectangle(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public PreciseRectangle(Rectangle r) {
        super(r);
    }

    public PreciseRectangle(Point pointA, Point pointB) {
        int minX, minY;
        int maxX, maxY;

        if (pointA.x <= pointB.x) {
            minX = pointA.x;
            maxX = pointB.x;
        } else {
            minX = pointB.x;
            maxX = pointA.x;
        }

        if (pointA.y <= pointB.y) {
            minY = pointA.y;
            maxY = pointB.y;
        } else {
            minY = pointB.y;
            maxY = pointA.y;
        }

        setBounds(minX, minY, maxX - minX, maxY - minY);
    }

    @Override
    public void drawOn(Graphics2D g) {
        g.draw(this);
    }

    @Override
    public int outcode(Point2D p) {
        int result = super.outcode(p.getX(), p.getY());

        if (result != 0) {
            return result;
        }

        double centerX = getCenterX();
        double centerY = getCenterY();


        if (p.getY() <= centerY) {
            if (p.getX() <= centerX) {
                return Rectangle.OUT_TOP | Rectangle.OUT_LEFT;
            } else {
                return Rectangle.OUT_TOP | Rectangle.OUT_RIGHT;
            }
        } else {
            if (p.getX() <= centerX) {
                return Rectangle.OUT_BOTTOM | Rectangle.OUT_LEFT;
            } else {
                return Rectangle.OUT_BOTTOM | Rectangle.OUT_RIGHT;
            }
        }


    }
}
