/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.geometric;

import java.awt.Dimension;
import java.awt.Point;

/**
 *
 * @author Gianluca Costa
 */
public final class PointUtils {

    public static void moveByDelta(Point point, Point delta) {
        point.x += delta.x;
        point.y += delta.y;
    }

    public static Point getShiftedCopy(Point point, Point delta) {
        Point result = new Point(point);
        moveByDelta(result, delta);
        return result;
    }

    public static Point getHalfway(Point first, Point second) {
        Point result = new Point();

        result.x = (first.x + second.x) / 2;
        result.y = (first.y + second.y) / 2;

        return result;
    }

    public static void forceIntoDimension(Point point, Dimension dimension) {
        if (point.x < 0) {
            point.x = 0;
        } else if (point.x > dimension.width) {
            point.x = dimension.width;
        }

        if (point.y < 0) {
            point.y = 0;
        } else if (point.y > dimension.height) {
            point.y = dimension.height;
        }
    }

    private PointUtils() {
    }
}
