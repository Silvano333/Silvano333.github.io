/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.geometric.rectangles;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import gianlucacosta86.graphsj2.view.geometric.IDrawable2D;

/**
 *
 * @author Gianluca Costa
 */
public class BorderedBox implements IDrawable2D {

    private static final long serialVersionUID = 1;
    private final int borderSize;
    private final Rectangle internalRect;
    private final Rectangle externalRect;
    private Color borderColor = Color.BLACK;
    private Color internalColor = Color.WHITE;

    public BorderedBox(Point center, int internalWidth, int internalHeight, int borderSize) {
        this.borderSize = borderSize;

        int internalX = center.x - internalWidth / 2;
        int internalY = center.y - internalHeight / 2;

        internalRect = new Rectangle(internalX, internalY, internalWidth, internalHeight);

        externalRect = new Rectangle(
                internalX - borderSize,
                internalY - borderSize,
                internalWidth + 2 * borderSize,
                internalHeight + 2 * borderSize);

    }

    public Color getBorderColor() {
        return borderColor;
    }

    public void setBorderColor(Color borderColor) {
        this.borderColor = borderColor;
    }

    public Color getInternalColor() {
        return internalColor;
    }

    public void setInternalColor(Color internalColor) {
        this.internalColor = internalColor;
    }

    public PreciseRectangle getInternalRect() {
        return new PreciseRectangle(internalRect);
    }

    public PreciseRectangle getExternalRect() {
        return new PreciseRectangle(externalRect);
    }

    public boolean containsPoint(Point point) {
        return externalRect.contains(point);
    }

    public Dimension getSize() {
        return externalRect.getSize();
    }

    @Override
    public void drawOn(Graphics2D g) {
        g.setColor(internalColor);
        g.fill(externalRect);

        Object antiAliasPref = g.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g.setColor(borderColor);
        StrokeRectangle externalDrawingRect = new StrokeRectangle(externalRect, borderSize);
        externalDrawingRect.drawOn(g);

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, antiAliasPref);
    }
}
