/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.geometric.text;

import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import gianlucacosta86.graphsj2.view.geometric.IDrawable2D;

/**
 *
 * @author Gianluca Costa
 */
public class CenteredLabel implements IDrawable2D {

    private static final long serialVersionUID = 1;
    private final Point center;
    private final String text;

    public CenteredLabel(String text, Point center) {
        this.text = text;
        this.center = center;
    }

    public String getText() {
        return text;
    }

    public Point getCenter() {
        return center;
    }

    @Override
    public void drawOn(Graphics2D g) {
        FontMetrics metrics = g.getFontMetrics();

        int lineWidth = metrics.stringWidth(text);
        int lineHeight = metrics.getAscent();

        g.drawString(text, center.x - lineWidth / 2, center.y + lineHeight / 2);
    }
}
