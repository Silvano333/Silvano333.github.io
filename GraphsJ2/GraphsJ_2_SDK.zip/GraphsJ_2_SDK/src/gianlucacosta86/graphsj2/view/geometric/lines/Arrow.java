/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.geometric.lines;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

/**
 *
 * @author Gianluca Costa
 */
public class Arrow extends Segment {

    private static final long serialVersionUID = 1;
    private final double arrowsAngle;
    private final double arrowsAngleInDegrees;
    private final int barb;

    public Arrow(Point sourcePoint, Point targetPoint, int lineSize, double arrowsAngleInDegrees, int barb) {
        super(sourcePoint, targetPoint, lineSize);

        this.arrowsAngleInDegrees = arrowsAngleInDegrees;
        this.arrowsAngle = Math.toRadians(arrowsAngleInDegrees);
        this.barb = barb;
    }

    public Arrow(Point sourcePoint, Point targetPoint, int lineSize, double arrowsAngleInDegrees) {
        this(sourcePoint, targetPoint, lineSize, arrowsAngleInDegrees, 20);
    }

    public double getArrowsAngle() {
        return arrowsAngle;
    }

    public double getArrowsAngleInDegrees() {
        return arrowsAngleInDegrees;
    }

    @Override
    public void drawOn(Graphics2D g) {

        Point sourcePoint = getSourcePoint();
        Point targetPoint = getTargetPoint();


        GeneralPath path = new GeneralPath(new Line2D.Double(new Point2D.Double(sourcePoint.x, sourcePoint.y), new Point2D.Double(targetPoint.x, targetPoint.y)));


        double lineAngle = getAngle();


        double x;
        double y;


        x = targetPoint.x + barb * Math.cos(lineAngle + Math.PI - arrowsAngle);
        y = targetPoint.y + barb * Math.sin(lineAngle + Math.PI - arrowsAngle);


        path.moveTo(x, y);
        path.lineTo(targetPoint.x, targetPoint.y);



        x = targetPoint.x + barb * Math.cos(lineAngle + Math.PI + arrowsAngle);
        y = targetPoint.y + barb * Math.sin(lineAngle + Math.PI + arrowsAngle);
        path.lineTo(x, y);

        g.draw(path);
    }
}
