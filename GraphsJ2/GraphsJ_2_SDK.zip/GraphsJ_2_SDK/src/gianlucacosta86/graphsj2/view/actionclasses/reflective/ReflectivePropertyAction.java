/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.actionclasses.reflective;

import gianlucacosta86.graphsj2.model.utils.PropertyManager;
import gianlucacosta86.graphsj2.view.actionclasses.BasicGraphsJAction;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;
import java.awt.event.ActionEvent;
import java.lang.reflect.InvocationTargetException;
import javax.swing.Icon;

/**
 *
 * @author Gianluca Costa
 */
public abstract class ReflectivePropertyAction<T> extends BasicGraphsJAction {

    private final Object target;
    private final String propertyName;
    private final Class propertyClass;

    public ReflectivePropertyAction(String name, Icon icon, Object target, String propertyName, Class<T> propertyClass) {
        super(name, icon);
        this.target = target;
        this.propertyName = propertyName;
        this.propertyClass = propertyClass;
        verifyPropertyExistence();
    }

    public ReflectivePropertyAction(String name, Object target, String propertyName, Class<T> propertyClass) {
        super(name);
        this.target = target;
        this.propertyName = propertyName;
        this.propertyClass = propertyClass;
        verifyPropertyExistence();
    }

    private void verifyPropertyExistence() {
        PropertyManager.getInstance().assertPropertyExistence(target, propertyName, propertyClass);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        T propertyValue;
        try {
            propertyValue = (T) PropertyManager.getInstance().readProperty(target, propertyName);
        } catch (InvocationTargetException ex) {
            throw new IllegalArgumentException();
        }


        String actionTitle = getTitle();


        while (true) {
            T userResult = askUserForValue(actionTitle, propertyValue);

            if (userResult == null) {
                return;
            }


            try {
                PropertyManager.getInstance().setProperty(target, propertyName, propertyClass, userResult);
                return;
            } catch (InvocationTargetException ex) {
                MessageProvider.getInstance().showWarningBox(ex.getCause());
            }
        }
    }

    protected abstract T askUserForValue(String actionTitle, T initialValue);
}
