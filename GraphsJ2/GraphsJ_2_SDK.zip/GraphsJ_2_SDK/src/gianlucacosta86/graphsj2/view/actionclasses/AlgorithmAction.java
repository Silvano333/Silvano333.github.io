/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.actionclasses;

import gianlucacosta86.graphsj2.controller.graphdocument.DocumentManager;
import gianlucacosta86.graphsj2.model.algorithms.IAlgorithm;
import java.awt.event.ActionEvent;
import javax.swing.Icon;

/**
 *
 * @author Gianluca Costa
 */
public abstract class AlgorithmAction extends BasicGraphsJAction {

    public AlgorithmAction(String name, Icon icon) {
        super(name, icon);
    }

    public AlgorithmAction(String name) {
        super(name);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        IAlgorithm algorithm = DocumentManager.getInstance().getDocument().getAlgorithm();


        perform(getTitle(), algorithm);
    }

    protected abstract void perform(String actionTitle, IAlgorithm algorithm);
}
