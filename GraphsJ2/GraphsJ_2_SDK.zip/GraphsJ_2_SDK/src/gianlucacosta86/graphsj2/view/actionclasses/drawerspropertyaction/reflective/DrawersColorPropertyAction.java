/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.actionclasses.drawerspropertyaction.reflective;

import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.DrawerProperties;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;
import java.awt.Color;
import javax.swing.Icon;

/**
 *
 * @author Gianluca Costa
 */
public abstract class DrawersColorPropertyAction<TDrawerPropertiesType extends DrawerProperties> extends DrawersReflectivePropertyAction<TDrawerPropertiesType, Color> {

    public DrawersColorPropertyAction(String name, GraphCanvas canvas, String propertyName) {
        super(name, canvas, propertyName, Color.class);
    }

    public DrawersColorPropertyAction(String name, Icon icon, GraphCanvas canvas, String propertyName) {
        super(name, icon, canvas, propertyName, Color.class);
    }

    @Override
    protected Color interactivelyAskValue(String actionTitle, TDrawerPropertiesType properties) {
        Color defaultColor = getCurrentValue(properties);

        return MessageProvider.getInstance().askForColor(actionTitle, defaultColor);
    }
}
