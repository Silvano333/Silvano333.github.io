/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.actionclasses.drawerspropertyaction;

import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.Drawer;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.DrawerProperties;
import gianlucacosta86.graphsj2.view.actionclasses.BasicGraphsJAction;
import java.awt.event.ActionEvent;
import java.util.Collection;
import javax.swing.Icon;

/**
 *
 * @author Gianluca Costa
 */
public abstract class DrawersGeneralPropertyAction<TDrawerPropertiesType extends DrawerProperties, TValueType> extends BasicGraphsJAction {

    private final GraphCanvas canvas;

    public DrawersGeneralPropertyAction(String name, GraphCanvas canvas) {
        super(name);
        this.canvas = canvas;
    }

    public DrawersGeneralPropertyAction(String name, Icon icon, GraphCanvas canvas) {
        super(name, icon);
        this.canvas = canvas;

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        TDrawerPropertiesType defaultProperties = getDefaultProperties(canvas);

        while (true) {
            TValueType userValue = interactivelyAskValue(getTitle(), defaultProperties);

            if (userValue == null) {
                return;
            }


            if (!setNewValue(defaultProperties, userValue)) {
                continue;
            }

            boolean canBreakInfLoop = true;

            for (Drawer drawer : getDrawers(canvas)) {
                TDrawerPropertiesType properties = (TDrawerPropertiesType) drawer.getProperties();
                if (!setNewValue(properties, userValue)) {
                    canBreakInfLoop = false;
                    break;
                }
            }

            if (canBreakInfLoop) {
                break;
            }
        }

        canvas.markAsModified(false);
        canvas.fullRepaint();
    }

    protected abstract TDrawerPropertiesType getDefaultProperties(GraphCanvas canvas);

    protected abstract Collection<? extends Drawer> getDrawers(GraphCanvas canvas);

    protected abstract TValueType interactivelyAskValue(String actionTitle, TDrawerPropertiesType properties);

    protected abstract boolean setNewValue(TDrawerPropertiesType properties, TValueType value);
}
