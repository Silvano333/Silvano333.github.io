/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.actionclasses;

import gianlucacosta86.graphsj2.controller.graphdocument.DocumentManager;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmException;
import gianlucacosta86.graphsj2.model.algorithms.IRunController;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import javax.swing.Icon;

/**
 *
 * @author Gianluca Costa
 */
public abstract class StartRunAction extends RunControllerAction {

    public StartRunAction(String name, Icon icon) {
        super(name, icon);
    }

    public StartRunAction(String name) {
        super(name);
    }

    @Override
    protected void perform(String title, IRunController runController) throws AlgorithmException {
        GraphCanvas inputCanvas = DocumentManager.getInstance().getDocument().getGraphCanvas();
        GraphCanvas outputCanvas = inputCanvas.clone();

        outputCanvas.setEditable(false);

        startRun(runController, outputCanvas);
    }

    protected abstract void startRun(IRunController runController, GraphCanvas outputCanvas) throws AlgorithmException;
}
