/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.dialogs;

import gianlucacosta86.graphsj2.AppConstants;
import gianlucacosta86.graphsj2.Application;
import java.awt.Color;
import javax.swing.JColorChooser;
import javax.swing.JOptionPane;

/**
 * This class provides useful functions to simplify the interaction with the users.
 *
 * @author Gianluca Costa
 */
public final class MessageProvider {

    private static final MessageProvider instance = new MessageProvider();

    private MessageProvider() {
        //
    }

    public static MessageProvider getInstance() {
        return instance;
    }

    private String formatThrowable(Throwable throwable) {
        return String.format("%s (%s)", throwable.getClass().getSimpleName(), throwable.getLocalizedMessage());
    }

    public void showErrorBox(String message) {
        JOptionPane.showMessageDialog(null, message, Application.TITLE, JOptionPane.ERROR_MESSAGE);
    }

    public void showErrorBox(Throwable throwable) {
        while (throwable.getCause() != null) {
            throwable = throwable.getCause();
        }

        showErrorBox(formatThrowable(throwable));
    }

    public void showErrorBox(String message, Throwable throwable) {
        while (throwable.getCause() != null) {
            throwable = throwable.getCause();
        }

        showErrorBox(message + "\n\nCause:\n" + formatThrowable(throwable));
    }

    public void showWarningBox(String message) {
        JOptionPane.showMessageDialog(null, message, Application.TITLE, JOptionPane.WARNING_MESSAGE);
    }

    public void showWarningBox(Throwable throwable) {
        while (throwable.getCause() != null) {
            throwable = throwable.getCause();
        }

        showWarningBox(throwable.getLocalizedMessage());
    }

    public void showInfoBox(String message) {
        JOptionPane.showMessageDialog(null, message, Application.TITLE, JOptionPane.INFORMATION_MESSAGE);
    }

    public void showInfoBox(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public String askForString(String message, String title, String defaultValue) {
        return (String) JOptionPane.showInputDialog(null, message, title, JOptionPane.QUESTION_MESSAGE, null, null, defaultValue);
    }

    public Integer askForInteger(String message, String title, Integer defaultValue, Integer minValue, Integer maxValue, boolean isMinInf, boolean isMaxInf) {
        if (minValue == null) {
            minValue = Integer.MIN_VALUE;
        }

        if (maxValue == null) {
            maxValue = Integer.MAX_VALUE;
        }

        if (minValue > maxValue) {
            throw new IllegalArgumentException("It must be minValue <= maxValue");
        }

        while (true) {
            String inputString;


            if (defaultValue != null) {
                String initialString = null;

                if (isMaxInf && defaultValue.equals(maxValue)) {
                    initialString = AppConstants.PLUS_INF_STRING;
                } else if (isMinInf && defaultValue.equals(minValue)) {
                    initialString = AppConstants.MINUS_INF_STRING;
                } else {
                    initialString = defaultValue.toString();
                }

                inputString = askForString(message, title, initialString);
            } else {
                inputString = askForString(message, title, "");
            }

            if (inputString == null) {
                return null;
            }


            try {
                int inputInt = Integer.parseInt(inputString);

                if (inputInt < minValue || inputInt > maxValue) {
                    showWarningBox(String.format("The value you provide must be between %s and %s (included).", minValue, maxValue));
                    continue;
                }

                return inputInt;

            } catch (NumberFormatException ex) {

                if (isMaxInf && inputString.equalsIgnoreCase(AppConstants.GENERAL_INF_STRING) || inputString.equalsIgnoreCase(AppConstants.PLUS_INF_STRING)) {
                    return maxValue;
                }

                if (isMinInf && inputString.equalsIgnoreCase(AppConstants.MINUS_INF_STRING)) {
                    return minValue;
                }

                //Show a message, then continue the cycle
                showWarningBox("You must input a number!");
            }
        }
    }

    public Integer askForInteger(String message, String title, Integer defaultValue, Integer minValue, Integer maxValue) {
        boolean isMinInf = minValue == null || minValue.equals(Integer.MIN_VALUE);
        boolean isMaxInf = maxValue == null || maxValue.equals(Integer.MAX_VALUE);

        return askForInteger(message, title, defaultValue, minValue, maxValue, isMinInf, isMaxInf);
    }

    public Boolean askQuestion(String message, String title, boolean defaultYes, boolean showCancel) {
        Object[] options;
        if (showCancel) {
            options = new Object[]{"Yes", "No", "Cancel"};
        } else {
            options = new Object[]{"Yes", "No"};
        }

        Object defaultOption;
        if (defaultYes) {
            defaultOption = options[0];
        } else {
            defaultOption = options[1];
        }

        int messageResult = JOptionPane.showOptionDialog(null, message, title, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, defaultOption);


        switch (messageResult) {
            case JOptionPane.YES_OPTION:
                return true;
            case JOptionPane.NO_OPTION:
                return false;
            default:
                return null;
        }
    }

    public int showCustomButtons(String message, String title, int kindOption, Object[] buttonTitles, int defaultIndex) {
        int buttonsOption;

        switch (buttonTitles.length) {
            case 2:
                buttonsOption = JOptionPane.YES_NO_OPTION;
                break;

            case 3:
                buttonsOption = JOptionPane.YES_NO_CANCEL_OPTION;
                break;

            default:
                throw new IllegalArgumentException("You must provide only 2 or 3 button titles");
        }


        Object defaultButton = buttonTitles[defaultIndex];

        return JOptionPane.showOptionDialog(null, message, title, buttonsOption, kindOption, null, buttonTitles, defaultButton);
    }

    public Color askForColor(String title, Color defaultColor) {
        if (defaultColor == null) {
            throw new IllegalArgumentException("You must provide a default color");
        }
        return JColorChooser.showDialog(null, title, defaultColor);
    }
}
