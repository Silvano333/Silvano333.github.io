/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.dialogs.helpdialog;

import gianlucacosta86.graphsj2.view.dialogs.customdialog.CustomDialog;
import java.awt.Color;
import java.net.URL;

/**
 *
 * @author Gianluca Costa
 */
public class HelpDialog extends CustomDialog<HelpPanel> {

    private static final Color HELP_COLOR = new Color(204, 255, 204);

    public HelpDialog(URL helpUrl) {
        this(helpUrl, null);
    }

    public HelpDialog(URL helpUrl, String additionalTitle) {
        super("", false, new HelpPanel(helpUrl), false, 0);                

        String title = "Online Help";

        if (additionalTitle != null) {
            title += " - " + additionalTitle;
        }

        setTitle(title);

        getPanel().setBackground(HELP_COLOR);
        getButtonsPanel().setBackground(HELP_COLOR);                        
    }
}
