/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.dialogs.filechoicekeeper;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * This simple class manages the choice of jar files.
 * @author Gianluca Costa
 */
public class JarFileChoiceKeeper extends FileChoiceKeeper {

    public JarFileChoiceKeeper() {
        super("jar file", new EnhancedFileFilter("Jar file(*.jar)", ".jar"));
    }

    /**
     * Converts a jar file object to the corresponding well-formed Java jar url.
     * @param jarFile The jar file to convert.
     * @return The url in format "jar:file:(file)!/".
     */
    public static URL jarFileToUrl(File jarFile) {
        String urlString = String.format("jar:file:%s!/", jarFile.getAbsolutePath());

        try {
            return new URL(urlString);
        } catch (MalformedURLException ex) {
            throw new AssertionError();
        }
    }
}
