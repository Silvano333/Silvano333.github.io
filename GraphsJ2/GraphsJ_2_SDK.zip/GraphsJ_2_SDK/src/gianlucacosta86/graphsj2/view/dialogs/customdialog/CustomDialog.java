/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.view.dialogs.customdialog;

import gianlucacosta86.graphsj2.Application;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

/**
 *
 * @author Gianluca Costa
 */
public abstract class CustomDialog<T extends JPanel & IValidatablePanel> extends JDialog {

    private final T panel;
    private boolean confirmed;
    private JPanel buttonsPanel;

    public CustomDialog(String title, boolean showCancel, T panel) {
        this(title, showCancel, panel, false, 20);
    }

    public CustomDialog(String title, boolean showCancel, T panel, boolean resizable, int padding) {
        this.panel = panel;

        setModal(!resizable);
        setResizable(resizable);
        setTitle(title);

        addComponentListener(new ComponentAdapter() {

            @Override
            public void componentShown(ComponentEvent e) {
                super.componentShown(e);
                confirmed = false;
                CustomDialog.this.panel.onShow();
            }
        });


        buildButtonsPanel(showCancel);

        GridBagLayout layout = new GridBagLayout();
        setLayout(layout);
        GridBagConstraints constraints;

        constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(padding, padding, padding, padding);
        constraints.fill = GridBagConstraints.BOTH;
        constraints.weightx = 1;
        constraints.weighty = 1;
        add(panel, constraints);


        constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.fill = GridBagConstraints.BOTH;
        add(buttonsPanel, constraints);


        pack();


        setIconImage(Application.SMALL_ICON.getImage());
        setLocationRelativeTo(null);
    }

    private void buildButtonsPanel(boolean showCancel) {
        buttonsPanel = new JPanel();
        buttonsPanel.setBorder(new BevelBorder(BevelBorder.RAISED));

        GridBagLayout buttonsLayout = new GridBagLayout();
        buttonsPanel.setLayout(buttonsLayout);

        GridBagConstraints constraints;

        constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(10, 10, 10, 10);
        constraints.fill = GridBagConstraints.BOTH;
        constraints.weightx = 1;
        constraints.weighty = 1;

        buttonsPanel.add(buildOkButton(), constraints);

        if (showCancel) {
            constraints.gridx = 1;
            buttonsPanel.add(buildCancelButton(), constraints);
        }
    }

    private JButton buildOkButton() {
        JButton result = new JButton("OK");

        result.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (!panel.validateData()) {
                    return;
                }

                confirmed = true;
                
                setVisible(false);
            }
        });


        return result;
    }

    private JButton buildCancelButton() {
        JButton result = new JButton("Cancel");

        result.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        return result;
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    protected T getPanel() {
        return panel;
    }

    public JPanel getButtonsPanel() {
        return buttonsPanel;
    }
}
