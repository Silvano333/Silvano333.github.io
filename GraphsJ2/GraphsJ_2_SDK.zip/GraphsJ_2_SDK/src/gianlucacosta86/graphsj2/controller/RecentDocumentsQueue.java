/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.controller;

import gianlucacosta86.graphsj2.AppPreferences;
import gianlucacosta86.graphsj2.model.collections.general.CircularQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.Serializable;

/**
 *
 * @author Gianluca Costa
 */
public final class RecentDocumentsQueue extends CircularQueue<File> implements Serializable {

    private static final long serialVersionUID = 1;
    private static final int QUEUE_SIZE = 10;
    private static RecentDocumentsQueue instance;

    public static RecentDocumentsQueue getInstance() {
        if (instance == null) {
            RecentDocumentsQueue storedQueue = AppPreferences.getInstance().readRecentDocumentsQueue();

            if (storedQueue == null) {
                instance = new RecentDocumentsQueue();
            } else {
                instance = storedQueue;
            }


            instance.getOnModified().add(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    AppPreferences.getInstance().saveRecentDocumentQueue();
                }
            });
        }


        return instance;
    }

    private RecentDocumentsQueue() {
        super(true, QUEUE_SIZE);
    }

    @Override
    public boolean add(File element) {
        //This prevents duplicate items in the queue
        getInternalDeque().remove(element);

        return super.add(element);
    }
}
