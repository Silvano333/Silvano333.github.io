/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.controller.graphdocument;

import gianlucacosta86.graphsj2.model.utils.io.LoaderBasedInputStream;
import gianlucacosta86.graphsj2.model.utils.io.streamwrappers.InputStreamWrapper;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;

/**
 *
 * @author Gianluca Costa
 */
class DocumentInputStreamWrapper extends InputStreamWrapper<LoaderBasedInputStream> {

    private GraphDocument document;
    private final File file;

    public DocumentInputStreamWrapper(File file) {
        this.file = file;
    }

    @Override
    protected LoaderBasedInputStream buildStream() throws IOException {
        return new LoaderBasedInputStream(new GZIPInputStream(new FileInputStream(file)));
    }

    @Override
    protected void useStream(LoaderBasedInputStream stream) throws IOException {
        try {
            document = (GraphDocument) stream.readObject();
        } catch (ClassNotFoundException ex) {
            throw new IOException(ex);
        }
    }

    @Override
    protected void handleIOException(IOException ex) {
        MessageProvider.getInstance().showErrorBox("Cannot open the specified document", ex);
    }

    @Override
    protected void handleCloseException(IOException ex) {
        //Just do nothing
    }

    public GraphDocument getDocument() {
        return document;
    }
}
