/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.controller.graphdocument;

import gianlucacosta86.graphsj2.controller.graphdocument.exceptions.InvalidDocumentVersionException;
import gianlucacosta86.graphsj2.controller.graphdocument.exceptions.InvalidAlgorithmUrlException;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;
import gianlucacosta86.graphsj2.view.dialogs.filechoicekeeper.JarFileChoiceKeeper;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import javax.swing.JOptionPane;

/**
 *
 * @author Gianluca Costa
 */
class DocumentHeader implements Serializable {

    private static final long serialVersionUID = 1;
    private final int documentVersion;
    private URL algorithmUrl;

    public DocumentHeader(int documentVersion, URL algorithmUrl) {
        this.documentVersion = documentVersion;
        this.algorithmUrl = algorithmUrl;
    }

    public int getDocumentVersion() {
        return documentVersion;
    }

    public URL getAlgorithmUrl() {
        return algorithmUrl;
    }

    private void assertVersionValid() throws InvalidDocumentVersionException {
        if (documentVersion != GraphDocument.DOCUMENT_VERSION) {
            throw new InvalidDocumentVersionException("The specified file cannot be opened by this version by GraphsJ");
        }
    }

    private void assertUrlValid() throws InvalidAlgorithmUrlException {
        if (algorithmUrl != null) {

            while (true) {
                try {
                    URLConnection connection = algorithmUrl.openConnection();
                    connection.connect();

                    return;
                } catch (IOException ex) {
                    if (!askUserForCorrectUrl()) {
                        throw new InvalidAlgorithmUrlException("Cannot retrieve the jar file associated with the document");
                    }

                }
            }
        }
    }

    private boolean askUserForCorrectUrl() {
        JarFileChoiceKeeper jarChooser = new JarFileChoiceKeeper();

        String[] errorCaptions = new String[]{"Choose from local file", "Manually insert URL", "Cancel"};

        int emergencyResult = MessageProvider.getInstance().showCustomButtons(String.format("The following jar url:\n\n%s\n\ncannot be found.\n\nWhat would you like to do?", algorithmUrl), "Open error", JOptionPane.WARNING_MESSAGE, errorCaptions, 0);

        switch (emergencyResult) {
            case JOptionPane.YES_OPTION:
                File jarFile = jarChooser.askToOpen();

                if (jarFile == null) {
                    return false;
                }

                algorithmUrl = JarFileChoiceKeeper.jarFileToUrl(jarFile);
                return true;

            case JOptionPane.NO_OPTION:

                while (true) {
                    String newUrlString = MessageProvider.getInstance().askForString("Please, input the correct url (in Java format) to reference the jar file:", "Manually provide the jar file", algorithmUrl.toString());

                    if (newUrlString == null) {
                        return false;
                    }

                    try {
                        algorithmUrl = new URL(newUrlString);
                        return true;
                    } catch (MalformedURLException ex) {
                        MessageProvider.getInstance().showWarningBox("Malformed URL!");
                    }
                }


            default:
                return false;
        }
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        assertVersionValid();
        assertUrlValid();
    }
}
