/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.controller.graphdocument;

import gianlucacosta86.graphsj2.model.algorithms.IAlgorithm;
import gianlucacosta86.graphsj2.model.classloaders.ClassLoaderKeeper;
import gianlucacosta86.graphsj2.model.utils.events.CustomActionEvent;
import gianlucacosta86.graphsj2.model.utils.events.EventKey;
import gianlucacosta86.graphsj2.model.utils.io.streamwrappers.OutputStreamWrapper;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.zip.GZIPOutputStream;

/**
 *
 * @author Gianluca Costa
 */
public class GraphDocument implements Serializable {

    private static final long serialVersionUID = 1;
    public static final int DOCUMENT_VERSION = 7;
    public static final String FILE_EXT = ".grj2";
    private final EventKey EVENT_KEY = new EventKey();
    private final IAlgorithm algorithm;
    private final GraphCanvas graphCanvas;
    private transient File file;
    private transient boolean modified;
    //The header is transient since I store/load it separately, using a custom serialization protocol
    private transient DocumentHeader documentHeader = new DocumentHeader(DOCUMENT_VERSION, ClassLoaderKeeper.getInstance().getSourceUrl());
    private final CustomActionEvent onFileChanged = new CustomActionEvent(this, EVENT_KEY);
    private final CustomActionEvent onModifiedChanged = new CustomActionEvent(this, EVENT_KEY);

    GraphDocument(IAlgorithm algorithm) {
        this.algorithm = algorithm;
        this.graphCanvas = algorithm.buildGraphCanvas();
        initializeDocument();
    }

    private void initializeDocument() {
        modified = false;

        graphCanvas.getOnModifiedChanged().add(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (graphCanvas.isModified()) {
                    setModified();
                }
            }
        });

    }

    public IAlgorithm getAlgorithm() {
        return algorithm;
    }

    public GraphCanvas getGraphCanvas() {
        return graphCanvas;
    }

    static GraphDocument loadFrom(File file) {
        DocumentInputStreamWrapper wrapper = new DocumentInputStreamWrapper(file);

        if (!wrapper.perform()) {
            return null;
        }


        GraphDocument result = wrapper.getDocument();
        result.file = file;
        return result;

    }

    boolean saveTo(final File file) {
        OutputStreamWrapper<ObjectOutputStream> wrapper = new OutputStreamWrapper<ObjectOutputStream>() {

            @Override
            protected ObjectOutputStream buildStream() throws IOException {
                return new ObjectOutputStream(new GZIPOutputStream(new FileOutputStream(file)));
            }

            @Override
            protected void useStream(ObjectOutputStream stream) throws IOException {
                stream.writeObject(GraphDocument.this);
            }

            @Override
            protected void handleIOException(IOException ex) {
                file.delete();
                MessageProvider.getInstance().showErrorBox("Cannot save the document to the specified file", ex);
            }

            @Override
            protected void handleCloseException(IOException ex) {
                file.delete();
                MessageProvider.getInstance().showErrorBox("Cannot save the document to the specified file", ex);
            }
        };

        if (!wrapper.perform()) {
            return false;
        }

        setFile(file);
        setModified(false);
        return true;
    }

    public File getFile() {
        return file;
    }

    private void setFile(File file) {
        boolean changed = !file.equals(this.file);
        this.file = file;

        if (changed) {
            onFileChanged.fire(EVENT_KEY);
        }
    }

    public CustomActionEvent getOnFileChanged() {
        return onFileChanged;
    }

    public boolean isModified() {
        return modified;
    }

    public void setModified() {
        setModified(true);
    }

    private void setModified(boolean modified) {
        boolean changed = (modified != this.modified);

        this.modified = modified;

        if (changed) {
            onModifiedChanged.fire(EVENT_KEY);
        }
    }

    public CustomActionEvent getOnModifiedChanged() {
        return onModifiedChanged;
    }

    private void writeObject(ObjectOutputStream out) throws IOException {
        out.writeObject(documentHeader);
        out.defaultWriteObject();
        graphCanvas.setModified(false);
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        //This automatically performs checks on the header's validity
        documentHeader = (DocumentHeader) in.readObject();

        ClassLoaderKeeper.getInstance().setAlgorithmUrl(documentHeader.getAlgorithmUrl());

        in.defaultReadObject();
        initializeDocument();
    }
}
