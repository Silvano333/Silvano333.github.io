/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2.controller.graphdocument;

import gianlucacosta86.graphsj2.Application;
import gianlucacosta86.graphsj2.controller.RecentDocumentsQueue;
import gianlucacosta86.graphsj2.model.algorithms.IAlgorithm;
import gianlucacosta86.graphsj2.model.utils.events.CustomActionEvent;
import gianlucacosta86.graphsj2.model.utils.events.EventKey;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;
import gianlucacosta86.graphsj2.view.dialogs.algorithmdialog.AlgorithmDialog;
import gianlucacosta86.graphsj2.view.dialogs.filechoicekeeper.EnhancedFileFilter;
import gianlucacosta86.graphsj2.view.dialogs.filechoicekeeper.FileChoiceKeeper;
import java.io.File;

/**
 *
 * @author Gianluca Costa
 */
public final class DocumentManager {

    private static final DocumentManager instance = new DocumentManager();
    private final EventKey EVENT_KEY = new EventKey();
    private final CustomActionEvent onDocumentChanged = new CustomActionEvent(this, EVENT_KEY);
    private final EnhancedFileFilter graphFileFilter = new EnhancedFileFilter("Graph file", GraphDocument.FILE_EXT);
    private final FileChoiceKeeper fileChoiceKeeper = new FileChoiceKeeper("graph document", graphFileFilter);
    private final AlgorithmDialog algorithmDialog = new AlgorithmDialog();
    private GraphDocument document;

    public static DocumentManager getInstance() {
        return instance;
    }

    private DocumentManager() {
    }

    public void doNew() {
        if (!canClose()) {
            return;
        }

        algorithmDialog.setVisible(true);
        if (!algorithmDialog.isConfirmed()) {
            return;
        }

        IAlgorithm algorithm = algorithmDialog.getSelectedAlgorithm();

        setDocument(new GraphDocument(algorithm));
    }

    public void doOpen() {
        if (!canClose()) {
            return;
        }

        File chosenFile = fileChoiceKeeper.askToOpen();

        if (chosenFile == null) {
            return;
        } else {

            doClose(false);

            if (!openFromFile(chosenFile)) {
                return;
            }
        }
    }

    public boolean openFromFile(File file) {
        if (!canClose()) {
            return false;
        }

        GraphDocument loadedDocument = GraphDocument.loadFrom(file);

        if (loadedDocument == null) {
            return false;
        }

        RecentDocumentsQueue.getInstance().add(file);

        setDocument(loadedDocument);
        return true;
    }

    public boolean doSave() {
        if (document == null) {
            throw new IllegalStateException("Cannot save: no document!");
        }


        File currentFile = document.getFile();

        if (currentFile == null) {
            return doSaveAs();
        } else {
            return document.saveTo(currentFile);
        }

    }

    public boolean doSaveAs() {
        if (document == null) {
            throw new IllegalStateException("Cannot save: no document!");
        }


        File chosenFile = fileChoiceKeeper.askToSave();

        if (chosenFile == null) {
            return false;
        }


        boolean result = document.saveTo(chosenFile);
        if (result) {
            RecentDocumentsQueue.getInstance().add(chosenFile);
        }
        return result;
    }

    public boolean doClose() {
        return doClose(true);
    }

    private boolean doClose(boolean askCanClose) {

        if (askCanClose) {
            if (!canClose()) {
                return false;
            }
        }

        setDocument(null);
        return true;
    }

    private boolean canClose() {
        if (document == null || !document.isModified()) {
            return true;
        }

        Boolean messageResult = MessageProvider.getInstance().askQuestion("The current document has been modified.\nWould you like to save it?", Application.TITLE, true, true);

        if (messageResult == null) {
            return false;
        }

        if (messageResult) {
            return doSave();
        } else {
            return true;
        }
    }

    public GraphDocument getDocument() {
        return document;
    }

    private void setDocument(GraphDocument document) {
        boolean changed = (document != this.document);

        this.document = document;

        if (changed) {
            onDocumentChanged.fire(EVENT_KEY);
        }
    }

    public CustomActionEvent getOnDocumentChanged() {
        return onDocumentChanged;
    }
}
