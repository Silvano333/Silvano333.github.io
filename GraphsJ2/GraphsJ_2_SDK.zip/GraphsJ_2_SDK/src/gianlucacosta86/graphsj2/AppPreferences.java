/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ 2.
 *
 * GraphsJ 2 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2. If not, see <http://www.gnu.org/licenses/>.
 */
package gianlucacosta86.graphsj2;

import gianlucacosta86.graphsj2.controller.RecentDocumentsQueue;
import gianlucacosta86.graphsj2.model.utils.io.LoaderBasedInputStream;
import gianlucacosta86.graphsj2.view.dialogs.MessageProvider;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import java.util.prefs.Preferences;

/**
 *
 * @author Gianluca Costa
 */
public final class AppPreferences {

    private static final AppPreferences instance = new AppPreferences();
    private static final String MAX_UNDO_SIZE_KEY = "MaxUndoSize";
    private static final String RECENT_DOCUMENTS_QUEUE_KEY = "RecentDocuments";
    private final Preferences preferences;
    private int undoMaxSize;

    public static AppPreferences getInstance() {
        return instance;
    }

    private AppPreferences() {
        preferences = Preferences.userNodeForPackage(this.getClass());

        this.undoMaxSize = preferences.getInt(MAX_UNDO_SIZE_KEY, 30);
    }

    public int getUndoMaxSize() {
        return undoMaxSize;
    }

    public void setUndoMaxSize(int undoMaxSize) {
        this.undoMaxSize = undoMaxSize;
        preferences.putInt(MAX_UNDO_SIZE_KEY, undoMaxSize);
    }

    public RecentDocumentsQueue readRecentDocumentsQueue() {

        byte[] recentDocumentsBytes = preferences.getByteArray(RECENT_DOCUMENTS_QUEUE_KEY, null);

        if (recentDocumentsBytes == null) {
            return null;
        } else {

            try {
                LoaderBasedInputStream queueStream = null;
                try {
                    queueStream = new LoaderBasedInputStream(new ByteArrayInputStream(recentDocumentsBytes));
                    return (RecentDocumentsQueue) queueStream.readObject();
                } finally {
                    queueStream.close();
                }
            } catch (ClassNotFoundException ex) {
                preferences.remove(RECENT_DOCUMENTS_QUEUE_KEY);
            } catch (IOException ex) {
                preferences.remove(RECENT_DOCUMENTS_QUEUE_KEY);
            }

            return null;
        }
    }

    public void clearRecentDocumentQueueSettings() {
        preferences.remove(RECENT_DOCUMENTS_QUEUE_KEY);
    }

    public void saveRecentDocumentQueue() {
        try {
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            ObjectOutputStream objectStream = new ObjectOutputStream(byteStream);
            objectStream.writeObject(RecentDocumentsQueue.getInstance());
            objectStream.close();

            preferences.putByteArray(RECENT_DOCUMENTS_QUEUE_KEY, byteStream.toByteArray());
            byteStream.reset();
        } catch (IOException ex) {
            MessageProvider.getInstance().showErrorBox("Could not save the Recent Documents list", ex);
        }

    }
}
