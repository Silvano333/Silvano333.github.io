/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms;

import com.paolotagliapietra.graphsj2.algorithms.tsp.heuristic.twoapprox.TwoApproxEdge;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.NonNegativeIntegerWeightedEdge;

/**
 *
 * @author Paolo Tagliapietra
 */
public class IntegerWeightChangeInformation {

    private IntegerWeightQuantity oldWeight, newWeight;
    private NonNegativeIntegerWeightedEdge edge;

    public NonNegativeIntegerWeightedEdge getEdge() {
        return edge;
    }

    public void setEdge(TwoApproxEdge edge) {
        this.edge = edge;
    }

    public IntegerWeightQuantity getNewWeight() {
        return newWeight;
    }

    public void setNewWeight(IntegerWeightQuantity newWeight) {
        this.newWeight = newWeight;
    }

    public IntegerWeightQuantity getOldWeight() {
        return oldWeight;
    }

    public void setOldWeight(IntegerWeightQuantity oldWeight) {
        this.oldWeight = oldWeight;
    }

    public IntegerWeightChangeInformation(IntegerWeightQuantity oldWeight, IntegerWeightQuantity newWeight, NonNegativeIntegerWeightedEdge edge) {
        this.oldWeight = oldWeight;
        this.newWeight = newWeight;
        this.edge = edge;
    }

    @Override
    public String toString() {
        return "Changed weight of " + edge.getBounds() + " from " + getOldWeight() + " to " + getNewWeight();
    }
}
