/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms;

import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.InvalidWeightException;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.NonNegativeIntegerWeightedEdge;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeMap;

/**
 *
 * @author Paolo Tagliapietra
 */
public class TriangularityHelper<V extends Vertex, E extends NonNegativeIntegerWeightedEdge> {

    public List<IntegerWeightChangeInformation> imposeTriangularityCondition(IntegerWeightedGraph<V, E> graph) {
        List<IntegerWeightChangeInformation> result = new ArrayList<IntegerWeightChangeInformation>();
        VertexList<V> fullVList = graph.getVertexList(true);

        for (int i = 0; i < fullVList.size(); i++) {
            V vi = fullVList.get(i);
            for (int j = 0; j < fullVList.size(); j++) {
                V vj = fullVList.get(j);
                E ij = graph.getEdge(vi, vj);
                if (ij == null) {
                    continue;
                }

                for (int k = 0; k < fullVList.size(); k++) {
                    V vk = fullVList.get(k);

                    E jk = graph.getEdge(vj, vk);
                    if (jk == null) {
                        continue;
                    }

                    E ik = graph.getEdge(vi, vk);
                    if (ik == null) {
                        continue;
                    }

                    if (ij.getWeight().sum(jk.getWeight()).getValue() < ik.getWeight().getValue()) {
                        try {
                            IntegerWeightQuantity oldWeight = ik.getWeight();
                            ik.setWeight(IntegerWeightQuantity.PLUS_INF);
                            IntegerWeightQuantity newWeight = singleTargetDijkstra(graph, vi, vk);
                            ik.setWeight(newWeight);
                            result.add(new IntegerWeightChangeInformation(oldWeight, newWeight, ik));
                        } catch (InvalidWeightException ex) {
                            // Can't occur
                        }
                    }
                }
            }
        }

        return result;
    }

    public IntegerWeightQuantity singleTargetDijkstra(IntegerWeightedGraph<V, E> graph, V source, V target) {
        VertexList<V> fullVList = graph.getVertexList(true);
        final TreeMap<V, DijkstraData> dijkstraDataMap = new TreeMap<V, DijkstraData>();

        for (V v : fullVList) {
            DijkstraData vData = new DijkstraData();
            dijkstraDataMap.put(v, vData);
            vData.setDist(IntegerWeightQuantity.PLUS_INF);
            vData.setPrevious(null);
        }

        dijkstraDataMap.get(source).setDist(IntegerWeightQuantity.ZERO);

        List<V> q = new ArrayList<V>();
        Comparator dijkstraComp = new Comparator<V>() {

            @Override
            public int compare(V o1, V o2) {
                return dijkstraDataMap.get(o1).getDist().compareTo(dijkstraDataMap.get(o2).getDist());
            }
        };

        for (V v : fullVList) {
            q.add(v);
        }
        Collections.sort(q, dijkstraComp);

        while (!q.isEmpty()) {
            IntegerWeightQuantity minDist = IntegerWeightQuantity.PLUS_INF;
            V u = null; // Vertex with smallest dist
            for (V v : q) {
                DijkstraData vData = dijkstraDataMap.get(v);
                if (vData.getDist().getValue() < minDist.getValue()) {
                    minDist = vData.getDist();
                    u = v;
                }
            }

            if (u == target) {
                return dijkstraDataMap.get(u).getDist();
            }

            q.remove(u);
            for (Vertex v : u.getLinkedVertexes()) { // Neighbors of u
                V cv = (V) v;
                IntegerWeightQuantity alt = dijkstraDataMap.get(u).getDist().sum(graph.getEdge(u, cv).getWeight());
                DijkstraData cvData = dijkstraDataMap.get(cv);
                if (alt.getValue() < cvData.getDist().getValue()) {
                    cvData.setDist(alt);
                    cvData.setPrevious(u);
                    Collections.sort(q, dijkstraComp);
                }
            }
        }

        return IntegerWeightQuantity.PLUS_INF;
    }
}