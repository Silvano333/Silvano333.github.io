/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms;

import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmEdge;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmVertex;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.standard.StandardAlgorithm;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.Graph;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.edgedrawer.EdgeDrawerProperties;

/**
 *
 * @author Paolo Tagliapietra
 */

/*
 * This sad class is sadly necessary to override the useless printing of
 * all the vertex labels..
 */
public abstract class NotTooVerboseStandardAlgorithm<V extends Vertex & IAlgorithmVertex, E extends Edge & IAlgorithmEdge, G extends Graph<V, E>> extends StandardAlgorithm<V, E, G> {

    @Override
    protected void runStep(GraphCanvas canvas, G graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        canvas.resetEdgeProperties();

        standardRunStep(canvas, graph, console, verboseRun, currentStep);


        Iterable<E> stepSolutionEdges = getStepSolutionEdges(currentStep);


        if (stepSolutionEdges != null) {

            for (E edge : stepSolutionEdges) {
                EdgeDrawerProperties properties = canvas.getPropertiesFor(edge);
                properties.setLineSize(properties.getLineSize() + ENHANCED_EDGE_WIDTH_ADDEND);
                properties.setColor(getStepSolutionEdgeColor());
            }

        }
    }
}
