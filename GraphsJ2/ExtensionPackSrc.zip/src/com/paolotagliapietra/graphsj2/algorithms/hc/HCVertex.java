/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.hc;

import gianlucacosta86.graphsj2.model.algorithms.standard.StandardVertex;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Paolo Tagliapietra
 */
public class HCVertex extends StandardVertex {

    private static final long serialVersionUID = 1L;
    private List<HCVertex> visitedVertexes;

    public HCVertex(String name) throws InvalidNameException {
        super(name);
        this.visitedVertexes = new ArrayList<HCVertex>();
    }

    @Override
    protected String getRunningLabel() {
        if (visitedVertexes.isEmpty()) {
            return this.getName();
        } else {
            StringBuilder builder = new StringBuilder(getName());
            builder.append(" [");
            for (HCVertex v : visitedVertexes) {
                builder.append(" ").append(v.getName()).append(",");
            }
            builder.deleteCharAt(builder.lastIndexOf(","));
            builder.append(" ]");

            return builder.toString();
        }
    }

    public void addVisitedVertex(HCVertex vertex) {
        visitedVertexes.add(vertex);
    }

    public boolean hasVisitedVertex(HCVertex vertex) {
        return visitedVertexes.contains(vertex);
    }

    public void clearVisitedVertexes() {
        visitedVertexes.clear();
    }
}
