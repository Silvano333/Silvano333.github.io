/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.hc;

import com.paolotagliapietra.graphsj2.algorithms.NotTooVerboseStandardAlgorithm;
import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.Graph;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.exceptions.DuplicateEdgeException;
import gianlucacosta86.graphsj2.model.graph.exceptions.EmptyGraphException;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.VertexChooser;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 *
 * @author Paolo Tagliapietra
 */
public class HCAccel extends NotTooVerboseStandardAlgorithm<HCVertex, HCEdge, Graph<HCVertex, HCEdge>> {

    private EdgeList<HCEdge> currentPath;
    private VertexList<HCVertex> vList;
    private VertexList<HCVertex> wList;
    private HCVertex vBar; // the vertex on which we're working in the current step
    private HCVertex startingVertex;
    private HCVertex rule1Target;
    private int treeHeight;
    private boolean failure;
    private Map<HCVertex, EdgeList<HCEdge>> removedEdgesMap;
    private boolean useRules;
    private boolean lastStep;

    @Override
    protected void postInitializeRun(GraphCanvas canvas, Graph<HCVertex, HCEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        lastStep = false;
        vList = graph.getVertexList(true);
        wList = new VertexList<HCVertex>(false);
        currentPath = new EdgeList<HCEdge>(false);

        int result = JOptionPane.showOptionDialog(null, "Use acceleration rules ?", this.getAlgorithmName(),
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
        useRules = result == 0;

        HCVertex v1;
        try {
            v1 = new VertexChooser<HCVertex, HCEdge>(graph).askForVertex("Choose the initial vertex:", this.toString());
            if (v1 == null) {
                throw new AlgorithmInterruptedException();
            }
        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException(ex);
        }

        // Initialization
        wList.add(v1);
        vList.remove(v1);
        vBar = v1;
        startingVertex = v1;
        treeHeight = 0;
        failure = false;
        removedEdgesMap = new HashMap<HCVertex, EdgeList<HCEdge>>();

        if (verboseRun) {
            console.writeHeader("Legend");
            console.writeLine();
            console.writeLine("V", "The graph vertexes");
            console.writeLine("S", "Vertexes belonging to the path in the current step");
            console.writeLine("As", "Arcs belonging to the path in the current step");
            console.writeLine("Vbar", "Vertex added to the tree in the current step");
            console.writeLine();

            console.writeHeader("Before step 1" + (useRules ? ", using acceleration rules" : ""));

            console.writeLine("S", wList.getNamesList());
            console.writeLine("V\\S", vList.getNamesList());
            console.writeLine("As", currentPath.getBoundsList());
        }
    }

    @Override
    protected void standardRunStep(GraphCanvas canvas, Graph<HCVertex, HCEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        if (verboseRun) {
            console.writeHeader("Step " + currentStep);
            console.writeLine();
        }

        if (lastStep) {
            HCEdge last = graph.getEdge(vBar, startingVertex);
            if (last != null) {
                // Success !
                currentPath.add(last);
                throw new AlgorithmEndedException();
            } else {
                // Backtracking due to lack of last arc
                if (verboseRun) {
                    console.writeLine("There is no arc from " + vBar + " to " + startingVertex + ", backtracking..");
                    console.writeLine();
                }

                backtrack(graph);
                lastStep = false;
            }
        } else {
            int rule1or2 = useRules ? rule1or2(graph) : -1;
            if (useRules && rule1or2 == 2) {
                if (verboseRun) {
                    console.writeLine("Rule 2 satisfied, backtracking..");
                    console.writeLine();
                }

                if (treeHeight == 0) {
                    // Failure: there does not exist any hamiltonian circuit
                    failure = true;
                } else {
                    // Backtrack because of Rule 2
                    backtrack(graph);
                }
            } else if (useRules && rule1or2 == 1 && !vBar.hasVisitedVertex(rule1Target)) {
                if (verboseRun) {
                    console.writeLine("Rule 1 satisfied with (" + vBar + ", " + rule1Target + ").");
                    console.writeLine();
                }

                // Direct forward step because of Rule 1
                forwardStep(rule1Target, graph);
            } else {
                // Normal procedure: look for an unvisited neighbor not belonging to wList (not in solution)
                VertexList<HCVertex> neighbors = vBar.getExitingVertexes();
                neighbors.sort();
                boolean neighborFound = false;
                for (HCVertex neighbor : neighbors) {
                    if (!vBar.hasVisitedVertex(neighbor) && !wList.contains(neighbor)) {
                        if (!useRules || !rule3(graph, neighbor)) {
                            // Not using rules or Rule 3 not satisfied
                            neighborFound = true;
                            if (verboseRun) {
                                console.writeLine("Adding (" + vBar + ", " + neighbor + ")");
                                console.writeLine();
                            }

                            forwardStep(neighbor, graph);
                            break;
                        } else { // useRules && Rule 3 satisfied
                            if (verboseRun) {
                                console.writeLine("Not adding (" + vBar + ", " + neighbor + ") due to Rule 3.");
                                console.writeLine();
                            }
                        }
                    }
                }

                if (!neighborFound && vList.size() != 0) {
                    // No neighbor found, and more than 1 vertex not in solution
                    if (treeHeight == 0) {
                        // Failure: there does not exist any hamiltonian circuit
                        failure = true;
                    } else {
                        // Normal backtracking
                        if (verboseRun) {
                            console.writeLine("No suitable neighbors found, backtracking..");
                            console.writeLine();
                        }

                        backtrack(graph);
                    }
                }
            }

            if (verboseRun) {
                console.writeHeader("At the end of the step" + (useRules ? ", using acceleration rules" : ""));
                console.writeLine();
                console.writeLine("Vbar", vBar);
                console.writeLine("S", wList.getNamesList());
                console.writeLine("V \\ S", vList.getNamesList());
                console.writeLine("E", currentPath.getBoundsList());
                console.writeLine();
                console.writeLine();
            }

            if (failure) {
                throw new AlgorithmEndedException();
            }

            if (vList.size() == 0) { // No more vertexes left to add
                lastStep = true;
            }
        }
    }

    private void forwardStep(HCVertex neighbor, Graph<HCVertex, HCEdge> graph) {
        // Forward Step:
        // Create a new branch in the decisional tree
        vBar.addVisitedVertex(neighbor);
        neighbor.clearVisitedVertexes();
        treeHeight++;

        // Update the lists
        wList.add(neighbor);
        vList.remove(neighbor);
        currentPath.add(graph.getEdge(vBar, neighbor));

        // Remove and save vBar's exiting edges and neighbor's entering edges
        removedEdgesMap.put(vBar, new EdgeList<HCEdge>());
        for (Vertex vi : vBar.getExitingVertexes()) {
            if (vi != neighbor) {
                HCEdge toRemove = graph.getEdge(vBar, (HCVertex) vi);
                removedEdgesMap.get(vBar).add(toRemove);
                graph.removeEdge(toRemove);
            }
        }
        for (Vertex vj : neighbor.getEnteringVertexes()) {
            if (vj != vBar) {
                HCEdge toRemove = graph.getEdge((HCVertex) vj, neighbor);
                removedEdgesMap.get(vBar).add(toRemove);
                graph.removeEdge(toRemove);
            }
        }

        // The next vBar will be the selected neighbor
        vBar = neighbor;
    }

    private void backtrack(Graph<HCVertex, HCEdge> graph) {
        // Temporary failure: this branch doesn't lead to HC
        // --> Backtrack

        // Update the lists, step back in the decisional tree and step back to the precedent vBar
        wList.remove(vBar);
        vList.add(vBar);
        HCVertex formerVBar = wList.get(treeHeight - 1);
        currentPath.remove(graph.getEdge(formerVBar, vBar));
        vBar = formerVBar;
        treeHeight--;

        // Restore the edges removed when current vBar was added to the solution (was "neighbor")
        EdgeList<HCEdge> removedEdges = removedEdgesMap.get(formerVBar);
        for (int i = 0; i < removedEdges.size(); i++) {
            HCEdge removedEdge = removedEdges.get(i);
            try {
                graph.addEdge(removedEdge);
            } catch (DuplicateEdgeException ex) {
                // Can't occur
            }
            removedEdges.remove(removedEdge);
            i--;
        }
    }

    private int rule1or2(Graph<HCVertex, HCEdge> graph) {
        // Considering S = { startingVertex, ..., Vl } (wList)

        // if Exists an arc (Vl,Vi) with Vi not belonging to S (being in vList) such that Vi has only 
        // one entering arc then only the branch corresponding to the arc (Vl,Vi) must be generated.
        // if Exists (Vl,Vj),(Vl,Vk) satisfying the same conditions, then backtrack.
        int result = 0;

        HCVertex vl = vBar;
        for (HCVertex vi : vList) {
            if (vi.getInDegree() == 1 && graph.getEdge(vl, vi) != null) {
                result++;
                rule1Target = vi;
            }
            if (result >= 2) {
                break;
            }
        }
        return result; // Returns 1 if Rule1 ok, or 2 if Rule2 ok
    }

    private boolean rule3(Graph<HCVertex, HCEdge> graph, HCVertex vi) {
        // Considering S = { startingVertex, ..., Vl } (wList)

        // if Exists (Vl,Vi) (Vk,Vi) with Vi and Vk not belonging to S (being in vList) 
        // such that Vk has only one exiting arc, then the branch corresponding to 
        // the arc (Vl,Vi) must NOT be generated

        for (HCVertex vk : vList) {
            if (vk.getOutDegree() == 1 && graph.getEdge(vk, vi) != null) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void standardOnEndRun(GraphCanvas canvas, Graph<HCVertex, HCEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        if (!failure) {
            console.writeLine("There exists an Hamiltonian Circuit.");
            console.writeLine();
            console.writeLine("Its edges are: " + currentPath.getBoundsList());
        } else {
            console.writeLine("All possible branches have been explored: there doesn't exist any Hamiltonian Circuit in the given Graph.");
        }
    }

    @Override
    protected Iterable<HCEdge> getSolutionEdges() {
        return currentPath;
    }

    @Override
    protected Iterable<HCEdge> getStepSolutionEdges(int currentStep) {
        return currentPath;
    }

    @Override
    protected IGraphFactory buildGraphFactory() {
        return new HCFactory();
    }

    @Override
    public String getAlgorithmName() {
        return "Enumerative Algorithm for the Hamiltonian Circuit (HC), with optional Acceleration Rules";
    }

    @Override
    protected void onInterruptedRun(GraphCanvas canvas, Graph<HCVertex, HCEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
    }
}
