/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.localsearch.twoopt;

import com.paolotagliapietra.graphsj2.algorithms.tsp.ITSPAlgorithmWrapper;
import com.paolotagliapietra.graphsj2.algorithms.tsp.ITSPVertex;
import com.paolotagliapietra.graphsj2.algorithms.tsp.greedy.multifragment.Multifragment;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import java.util.List;

/**
 *
 * @author Paolo Tagliapietra
 */
public class MultifragmentWrapper extends Multifragment implements ITSPAlgorithmWrapper {

    @Override
    public Iterable<Edge> getSolution() {
        EdgeList<Edge> solution = new EdgeList<Edge>();
        if (super.getSolutionEdges() == null) {
            return null;
        }

        for (Edge e : super.getSolutionEdges()) {
            solution.add((Edge) e);
        }
        return solution;
    }

    @Override
    public IntegerWeightQuantity getCircuitCost(ITSPVertex startingVertex) {
        return super.computeCircuitCost(startingVertex);
    }

    @Override
    public String getCircuitString(ITSPVertex startingVertex) {
        return super.circuitString(startingVertex);
    }

    @Override
    public VertexList getCircuitVertexes(ITSPVertex startingVertex) {
        return super.getCircuitVertexes(startingVertex);
    }

    @Override
    public VertexList getPartialCircuitVertexes(ITSPVertex start, ITSPVertex end) {
        return super.getPartialCircuitVertexes(start, end);
    }

    @Override
    public List<IntegerWeightQuantity> getCircuitCosts(ITSPVertex start) {
        return super.getCircuitCosts(start);
    }

    @Override
    public List<IntegerWeightQuantity> getPartialCircuitCosts(ITSPVertex start, ITSPVertex end) {
        return super.getPartialCircuitCosts(start, end);
    }
}
