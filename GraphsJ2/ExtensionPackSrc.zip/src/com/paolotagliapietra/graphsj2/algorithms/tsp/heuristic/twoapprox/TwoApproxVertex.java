/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.heuristic.twoapprox;

import com.paolotagliapietra.graphsj2.algorithms.tsp.ITSPVertex;
import gianlucacosta86.graphsj2.model.algorithms.concrete.prim.PrimVertex;
import gianlucacosta86.graphsj2.model.graph.GraphObject;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author Paolo Tagliapietra
 */
public class TwoApproxVertex extends PrimVertex implements ITSPVertex {

    private boolean visited;
    private boolean defaultStatus;
    private IntegerWeightQuantity nextCost;
    private TwoApproxVertex finalNextStop;
    private Map<TwoApproxVertex, TwoApproxEdge> neighbors;
    private TwoApproxVertex previousStop;
    private IntegerWeightQuantity previousDistance;

    public TwoApproxVertex(String name) throws InvalidNameException {
        super(name);
        defaultStatus = false;
        neighbors = new TreeMap<TwoApproxVertex, TwoApproxEdge>(); // Maintains neighbors in alphabetical order
        previousDistance = IntegerWeightQuantity.ZERO;
    }

    @Override
    protected String getRunningLabel() {
        return defaultStatus
                ? this.getName() + (visited ? " [@] " : "")
                : super.getRunningLabel();
    }

    public void imposeDefaultStatus() {
        this.defaultStatus = true;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    @Override
    public ITSPVertex getNextStop() {
        return finalNextStop;
    }

    @Override
    public IntegerWeightQuantity getNextCost() {
        return nextCost;
    }

    @Override
    public void setNextStop(ITSPVertex nextStop) {
        this.finalNextStop = (TwoApproxVertex) nextStop;
    }

    @Override
    public void setNextCost(IntegerWeightQuantity cost) {
        this.nextCost = cost;
    }

    @Override
    protected GraphObject clone() {
        return super.clone();
    }

    @Override
    public TwoApproxVertex getBestVertex() {
        return (TwoApproxVertex) super.getBestVertex();
    }

    @Override
    public IntegerWeightQuantity getWeightFromBestVertex() {
        return super.getWeightFromBestVertex();
    }

    public void addNeighbor(TwoApproxVertex neighbor, TwoApproxEdge way) {
        neighbors.put(neighbor, way);
    }

    public TwoApproxEdge getWayToNeighbor(TwoApproxVertex neighbor) {
        return neighbors.get(neighbor);
    }

    public Set<TwoApproxVertex> getNeighbors() {
        return neighbors.keySet();
    }

    public TwoApproxVertex getPreviousStop() {
        return previousStop;
    }

    public void setPreviousStop(TwoApproxVertex previousStop) {
        this.previousStop = previousStop;
    }

    public IntegerWeightQuantity getPreviousDistance() {
        return previousDistance;
    }

    public void setPreviousDistance(IntegerWeightQuantity previousDistance) {
        this.previousDistance = previousDistance;
    }
}
