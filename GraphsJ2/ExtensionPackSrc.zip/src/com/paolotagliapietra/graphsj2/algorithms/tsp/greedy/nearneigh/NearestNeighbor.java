/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.greedy.nearneigh;

import com.paolotagliapietra.graphsj2.algorithms.IntegerWeightChangeInformation;
import com.paolotagliapietra.graphsj2.algorithms.TriangularityHelper;
import com.paolotagliapietra.graphsj2.algorithms.tsp.TSPAlgorithm;
import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.sets.VertexSet;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.exceptions.EmptyGraphException;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.dialogs.VertexChooser;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Paolo Tagliapietra
 */
public class NearestNeighbor extends TSPAlgorithm<NNVertex, NNEdge, IntegerWeightedGraph<NNVertex, NNEdge>> {

    private NNVertex vNn, currentVertex, startingVertex;
    private VertexList<NNVertex> vList;
    private VertexList<NNVertex> wList;
    private EdgeList<NNEdge> path;
    private boolean failure;

    @Override
    protected void postInitializeRun(GraphCanvas canvas, IntegerWeightedGraph<NNVertex, NNEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        int result = JOptionPane.showOptionDialog(null, "Impose Triangularity Condition?", this.getAlgorithmName(),
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
        if (result == 0) {
            List<IntegerWeightChangeInformation> changes = new TriangularityHelper<NNVertex, NNEdge>().imposeTriangularityCondition(graph);
            if (changes.size() > 0 && verboseRun) {
                console.writeHeader("Changes made to impose the Triangularity Condition");
                console.writeLine();
                for (IntegerWeightChangeInformation inf : changes) {
                    console.writeLine(inf.toString());
                }
                console.writeLine();
            }
        } else {
            JOptionPane.showMessageDialog(null, "In this case, the algorithm might terminate with no solution", "Warning", JOptionPane.WARNING_MESSAGE);
        }

        vList = graph.getVertexList(false);
        wList = new VertexList<NNVertex>(false);

        NNVertex v1;
        try {
            v1 = new VertexChooser<NNVertex, NNEdge>(graph).askForVertex("Choose the initial vertex:", this.toString());
            if (v1 == null) {
                throw new AlgorithmInterruptedException();
            }
        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException(ex);
        }

        v1.setVisited(true);

        wList.add(v1);
        vList.remove(v1);

        path = new EdgeList<NNEdge>(false);
        currentVertex = v1;
        startingVertex = v1;
        failure = false;

        if (verboseRun) {
            console.writeHeader("Legend");
            console.writeLine();
            console.writeLine("V", "The graph vertexes");
            console.writeLine("W", "Vertexes belonging to the path in the current step");
            console.writeLine("E", "Edges belonging to the path in the current step");
            console.writeLine("Vnn", "Vertex added to the solution in the current step");
            console.writeLine();

            console.writeHeader("Before step 1");

            console.writeLine("W", wList.getNamesList());
            console.writeLine("V\\W", vList.getNamesList());
            console.writeLine("E", path.getBoundsList());
        }
    }

    /*
     * This algorithm is so simple that it can be considered self-documented
     */
    @Override
    protected void standardRunStep(GraphCanvas canvas, IntegerWeightedGraph<NNVertex, NNEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        if (verboseRun) {
            console.writeHeader("Step " + currentStep);
            console.writeLine();
        }


        if (vList.isEmpty()) {
            NNEdge endingEdge = graph.getEdge(currentVertex, startingVertex);
            if (endingEdge != null) {
                path.add(endingEdge);
                currentVertex.setNextStop(startingVertex);
                currentVertex.setNextCost(endingEdge.getWeight());
            } else {
                failure = true;
            }
            throw new AlgorithmEndedException();
        }

        VertexSet<NNVertex> neighbors = currentVertex.getLinkedVertexes();
        IntegerWeightQuantity nearestNeighborDistance = IntegerWeightQuantity.PLUS_INF;
        for (NNVertex neighbor : neighbors) {
            if (neighbor.isVisited()) {
                continue;
            }

            IntegerWeightQuantity distanceFromCurrentNode = graph.getDistanceBetween(currentVertex, neighbor);

            if (distanceFromCurrentNode.getValue() <= nearestNeighborDistance.getValue()) {
                vNn = neighbor;
                nearestNeighborDistance = distanceFromCurrentNode;
            }
        }

        currentVertex.setNextStop(vNn);
        currentVertex.setNextCost(nearestNeighborDistance);
        wList.add(vNn);
        vList.remove(vNn);

        NNEdge chosenEdge = graph.getEdge(currentVertex, vNn);
        if (chosenEdge == null) {
            failure = true;
            throw new AlgorithmEndedException();
        }

        path.add(chosenEdge);

        vNn.setVisited(true);
        currentVertex = vNn;

        if (verboseRun) {
            console.writeLine("At the end of the step:");
            console.writeLine();
            console.writeLine("vNn", vNn);
            console.writeLine("W", wList.getNamesList());
            console.writeLine("V \\ W", vList.getNamesList());
            console.writeLine("E", path.getBoundsList());
            console.writeLine();
            console.writeLine();
        }
    }

    @Override
    protected void standardOnEndRun(GraphCanvas canvas, IntegerWeightedGraph<NNVertex, NNEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        if (failure) {
            console.writeLine("The edges belonging to the partial path are: " + path.getBoundsList());
            console.writeLine();
            console.writeLine("There are no edges or paths connecting the current vertex to the "
                    + "starting vertex: therefore, the total weight of the path is: "
                    + IntegerWeightQuantity.PLUS_INF);
        } else {
            //Now, I find out the total weight of the path

            int totalWeight = computeCircuitCost(startingVertex).getValue();
            console.writeLine("The edges belonging to the path are: " + path.getBoundsList());
            console.writeLine();
            console.writeLine("Therefore, the circuit is: " + circuitString(startingVertex));
            console.writeLine("And its cost is: " + totalWeight);
        }
    }

    @Override
    public String getAlgorithmName() {
        return "Nearest Neighbor (NN) - Greedy Algorithm for Travelling Salesman Problem (TSP)";
    }

    @Override
    protected void onInterruptedRun(GraphCanvas gc, IntegerWeightedGraph<NNVertex, NNEdge> g, AlgorithmConsole ac, boolean bln, int i) throws AlgorithmRunException {
        // Do nothing 
    }

    @Override
    protected Iterable<NNEdge> getSolutionEdges() {
        return path;
    }

    @Override
    protected IGraphFactory buildGraphFactory() {
        return new NNFactory();
    }

    @Override
    protected Iterable<NNEdge> getStepSolutionEdges(int currentStep) {
        return path;
    }
}