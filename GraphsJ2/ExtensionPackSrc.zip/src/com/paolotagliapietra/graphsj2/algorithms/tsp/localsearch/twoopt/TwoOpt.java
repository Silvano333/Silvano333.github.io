/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.localsearch.twoopt;

import com.paolotagliapietra.graphsj2.algorithms.tsp.ITSPAlgorithmWrapper;
import com.paolotagliapietra.graphsj2.algorithms.NotTooVerboseStandardAlgorithm;
import com.paolotagliapietra.graphsj2.algorithms.tsp.ITSPVertex;
import gianlucacosta86.graphsj2.controller.graphfactory.GraphFactory;
import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.IRunController;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.IAlgorithmConsoleWriter;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmEdge;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmVertex;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.algorithms.standard.StandardAlgorithm;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.InvalidWeightException;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightedEdge;
import gianlucacosta86.graphsj2.model.graph.exceptions.DuplicateEdgeException;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.edgedrawer.EdgeDrawerProperties;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Paolo Tagliapietra
 */
public class TwoOpt<V extends Vertex & IAlgorithmVertex & ITwoOptVertex, E extends IntegerWeightedEdge & IAlgorithmEdge & ITwoOptEdge>
        extends NotTooVerboseStandardAlgorithm<V, E, IntegerWeightedGraph<V, E>> {

    public final static Color DEFAULT_REMOVED_EDGE_COLOR = Color.decode("0xCCCCCC");
    public final static Color DEFAULT_ADDED_EDGE_COLOR = StandardAlgorithm.DEFAULT_STEP_SOLUTION_EDGE_COLOR.darker();
    private ITSPAlgorithmWrapper initialAlgorithm;
    private EdgeList<E> currentSolution;
    private EdgeList<E> nonSolutionEdges;
    private IRunController rc;
    private VertexList<V> vList;
    private GraphFactory factory;
    private IntegerWeightQuantity currentCircuitCost;
    private String currentCircuitString;
    private int selectedOption = -1;
    private EdgeList<E> lastAddedEdges;
    private Color removedEdgeColor = DEFAULT_REMOVED_EDGE_COLOR;
    private Color addedEdgeColor = DEFAULT_ADDED_EDGE_COLOR;
    private Object[] options = new Object[]{"Nearest Neighbor", "Multifragment"};

    @Override
    protected IGraphFactory buildGraphFactory() {
        selectedOption = askSelectedOption(options);
        buildInitialAlgorithm();
        buildInitialFactory();
        return factory;
    }

    private void addToSolution(E ejk, GraphCanvas canvas) {
        lastAddedEdges.add(ejk);
        setAddedEdgeColor(canvas, ejk);
        currentSolution.add(ejk);
    }

    private void buildInitialAlgorithm() {
        switch (selectedOption) {
            case 0:
                initialAlgorithm = new NearestNeighborWrapper();
                break;
            case 1:
                initialAlgorithm = new MultifragmentWrapper();
                break;
        }
    }

    private void buildInitialFactory() throws RuntimeException {
        if (initialAlgorithm instanceof NearestNeighborWrapper) {
            factory = new NNTwoOptFactory();
        } else if (initialAlgorithm instanceof MultifragmentWrapper) {
            factory = new MFTwoOptFactory();
        } else {
            throw new RuntimeException("Unsupported initial algorithm");
        }
    }

    private int askSelectedOption(Object[] options) {
        return JOptionPane.showOptionDialog(null, "Choose an Algorithm to find a starting solution:",
                "Approximate Algorithm chooser", 0, JOptionPane.QUESTION_MESSAGE,
                null, options, null);
    }

    private void completeGraph(IntegerWeightedGraph<V, E> graph) throws AlgorithmRunException {
        for (int i = 0; i < vList.size(); i++) {
            V vi = vList.get(i);
            for (int j = i + 1; j < vList.size(); j++) {
                V vj = vList.get(j);
                if (graph.getEdge(vi, vj) == null) {
                    E e = (E) factory.createEdge(vi, vj);
                    try {
                        e.setWeight(IntegerWeightQuantity.PLUS_INF);
                        graph.addEdge(e);
                    } catch (InvalidWeightException ex) {
                        // Can't occur
                        throw new AlgorithmRunException(ex);
                    } catch (DuplicateEdgeException ex) {
                        // Can't occur
                        throw new AlgorithmRunException(ex);
                    }
                }
            }
        }
    }

    private void inferSelectedOption(IntegerWeightedGraph<V, E> graph) {
        vList = graph.getVertexList(false);
        if (vList.isEmpty()) {
            askSelectedOption(options);
        } else if (vList.get(0) instanceof MFTwoOptVertex) {
            selectedOption = 1;
        } else if (vList.get(0) instanceof NNTwoOptVertex) {
            selectedOption = 0;
        } else {
            throw new RuntimeException("Unsupported initial algorithm");
        }
    }

    @Override
    protected void postInitializeRun(GraphCanvas canvas, IntegerWeightedGraph<V, E> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        if (selectedOption == -1) {
            inferSelectedOption(graph);
            buildInitialAlgorithm();
            buildInitialFactory();
        }

        if (initialAlgorithm instanceof NearestNeighborWrapper) {
            initialAlgorithm = new NearestNeighborWrapper();
        } else if (initialAlgorithm instanceof MultifragmentWrapper) {
            initialAlgorithm = new MultifragmentWrapper();
        }

        vList = graph.getVertexList(false);
        completeGraph(graph);

        rc = initialAlgorithm.getRunController();
        final AlgorithmConsole thisConsole = console;
        rc.getConsole().addWriter(new IAlgorithmConsoleWriter() {

            @Override
            public void write(String text) {
                thisConsole.write("|\t" + text);
            }

            @Override
            public void writeLine(String text) {
                thisConsole.writeLine("|\t" + text);
            }
        });

        if (rc.isRunning()) {
            rc.stopRun();
        }

        rc.fullRun(canvas, verboseRun);
        if (initialAlgorithm.getSolution() == null) {
            console.writeLine("|\tExecution interrupted");
            throw new AlgorithmInterruptedException();
        }

        currentSolution = new EdgeList<E>(true);
        for (Edge e : initialAlgorithm.getSolution()) {
            currentSolution.add((E) e);
        }
        nonSolutionEdges = graph.getEdgeList(true);
        currentCircuitCost = IntegerWeightQuantity.ZERO;
        for (E e : currentSolution) {
            nonSolutionEdges.remove(e);
            if (currentCircuitCost != IntegerWeightQuantity.PLUS_INF) {
                currentCircuitCost = currentCircuitCost.sum(e.getWeight());
            } else {
                currentCircuitCost = IntegerWeightQuantity.PLUS_INF;
            }
        }
        currentCircuitString = initialAlgorithm.getCircuitString((V) currentSolution.get(0).getSource());
        vList = initialAlgorithm.getCircuitVertexes((V) currentSolution.get(0).getSource());
        lastAddedEdges = new EdgeList<E>();

        if (verboseRun) {
            console.writeHeader("Legend");
            console.writeLine();
            console.writeLine("E", "The graph edges");
            console.writeLine("Er", "Edges removed from the current Circuit");
            console.writeLine("Ea", "Edges added to the current Circuit");
            console.writeLine("C", "The current Circuit");
            console.writeLine("W", "Cost of the current Solution");
            console.writeLine();

            console.writeHeader("Before step 1");

            console.writeLine("Er", "-");
            console.writeLine("Ea", currentSolution.getBoundsList());
            console.writeLine("Es", currentSolution.getBoundsList());
            console.writeLine("E\\C", nonSolutionEdges.getBoundsList());
            console.writeLine("C", currentCircuitString);
            console.writeLine("W", currentCircuitCost);
        }
    }

    @Override
    protected void standardRunStep(GraphCanvas canvas, IntegerWeightedGraph<V, E> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        if (currentStep == 1) {
            for (V v : graph.getVertexList(false)) {
                ((ITwoOptVertex) v).imposeTwoOptVertexStatus();
            }
        }

        if (verboseRun) {
            console.writeHeader("Step " + currentStep);
            console.writeLine();
        }

        lastAddedEdges.clear();

        String eaString = "-";
        String erString = "-";

        boolean bothDirectionsScanned = false;
        boolean improvementFound = false;
        int i;
        do {
            vList = initialAlgorithm.getCircuitVertexes(vList.get(0));
            vList.add(vList.get(0));
            for (i = 0; i < vList.size() && !improvementFound; i++) {
                ITSPVertex vi = vList.get(i);
                for (int j = i + 1; j < vList.size() & !improvementFound; j++) {
                    ITSPVertex vj = vList.get(j);

                    E eij = null;
                    for (E e : currentSolution) {
                        if (e.getSource() == vi && e.getTarget() == vj
                                || e.getSource() == vj && e.getTarget() == vi) {
                            eij = e;
                            break;
                        }
                    }
                    if (eij == null) {
                        continue;
                    }

                    for (int l = j + 1; l < vList.size() & !improvementFound; l++) {
                        ITSPVertex vl = vList.get(l);
                        for (int k = l + 1; k < vList.size() & !improvementFound; k++) {
                            ITSPVertex vk = vList.get(k);

                            E elk = null;
                            for (E e : currentSolution) {
                                if (e.getSource() == vl && e.getTarget() == vk
                                        || e.getSource() == vk && e.getTarget() == vl) {
                                    elk = e;
                                    break;
                                }
                            }
                            if (elk == null) {
                                continue;
                            }

                            E eil = null, ejk = null;
                            for (E e : nonSolutionEdges) {
                                if (eil == null) {
                                    if (e.getSource() == vi && e.getTarget() == vl
                                            || e.getSource() == vl && e.getTarget() == vi) {
                                        eil = e;
                                    }
                                }
                                if (ejk == null) {
                                    if (e.getSource() == vj && e.getTarget() == vk
                                            || e.getSource() == vk && e.getTarget() == vj) {
                                        ejk = e;
                                    }
                                }
                                if (ejk != null && eil != null) {
                                    break;
                                }
                            }
                            if (ejk == null || eil == null) {
                                continue;
                            }

                            if (!(eil.getWeight().isPlusInf())
                                    && !(ejk.getWeight().isPlusInf()) && ((ejk.getWeight().getValue() + eil.getWeight().getValue() < eij.getWeight().getValue() + elk.getWeight().getValue())
                                    || (eil.getWeight().isPlusInf() || elk.getWeight().isPlusInf()))) {

                                removeFromSolution(canvas, elk);
                                removeFromSolution(canvas, eij);
                                addToSolution(eil, canvas);
                                addToSolution(ejk, canvas);

                                invertPartialCircuit(vj, vl);

                                vi.setNextStop(vl);
                                vi.setNextCost(eil.getWeight());
                                vj.setNextStop(vk);
                                vj.setNextCost(ejk.getWeight());

                                if (currentCircuitCost == IntegerWeightQuantity.PLUS_INF) {
                                    currentCircuitCost = IntegerWeightQuantity.ZERO;
                                    for (E e : currentSolution) {
                                        if (currentCircuitCost != IntegerWeightQuantity.PLUS_INF) {
                                            currentCircuitCost = currentCircuitCost.sum(e.getWeight());
                                        }
                                        if (e.getWeight() == IntegerWeightQuantity.PLUS_INF) {
                                            currentCircuitCost = IntegerWeightQuantity.PLUS_INF;
                                            break;
                                        }
                                    }
                                } else {
                                    currentCircuitCost = currentCircuitCost.sum(eil.getWeight());
                                    currentCircuitCost = currentCircuitCost.sum(ejk.getWeight());
                                    currentCircuitCost = currentCircuitCost.subtract(eij.getWeight());
                                    currentCircuitCost = currentCircuitCost.subtract(elk.getWeight());
                                }

                                nonSolutionEdges.remove(eil);
                                nonSolutionEdges.remove(ejk);
                                nonSolutionEdges.add(eij);
                                nonSolutionEdges.add(elk);

                                currentCircuitString = initialAlgorithm.getCircuitString(vi);
                                erString = "[" + elk.getBounds() + "," + eij.getBounds() + "]";
                                eaString = "[" + eil.getBounds() + "," + ejk.getBounds() + "]";
                                improvementFound = true;
                            }
                        }
                    }
                }
            }

            if (!bothDirectionsScanned && !improvementFound) {
                invertCircuit((ITSPVertex) vList.get(0));
                bothDirectionsScanned = true;
            } else {
                break;
            }
        } while (true);

        if (verboseRun) {
            console.writeLine("At the end of the step:");
            console.writeLine();
            console.writeLine("Er", erString);
            console.writeLine("Ea", eaString);
            console.writeLine("Es", currentSolution.getBoundsList());
            console.writeLine("E\\C", nonSolutionEdges.getBoundsList());
            console.writeLine("C", currentCircuitString);
            console.writeLine("W", currentCircuitCost);
            console.writeLine();
            console.writeLine();
        }

        if (i >= currentSolution.size()) {
            throw new AlgorithmEndedException();
        }
    }

    private void removeFromSolution(GraphCanvas canvas, E elk) {
        setRemovedEdgeColor(canvas, elk);
        currentSolution.remove(elk);
    }

    private void setAddedEdgeColor(GraphCanvas canvas, E edge) {
        EdgeDrawerProperties properties = canvas.getPropertiesFor(edge);
        properties.setLineSize(properties.getLineSize() + ENHANCED_EDGE_WIDTH_ADDEND);
        if (properties != null) {
            properties.setColor(addedEdgeColor);
        }
    }

    private void setRemovedEdgeColor(GraphCanvas canvas, E edge) {
        EdgeDrawerProperties properties = canvas.getPropertiesFor(edge);
        if (properties != null) {
            properties.setColor(removedEdgeColor);
        }
    }

    @Override
    protected void standardOnEndRun(GraphCanvas canvas, IntegerWeightedGraph<V, E> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        console.writeLine("No further improvement possible.");
        currentCircuitString = initialAlgorithm.getCircuitString(vList.get(0));
        console.writeLine("The Local Optimum Circuit found is: " + currentCircuitString);
        console.writeLine("And its cost is: " + currentCircuitCost);
    }

    @Override
    protected Iterable<E> getSolutionEdges() {
        return currentSolution;
    }

    @Override
    protected Iterable<E> getStepSolutionEdges(int currentStep) {
        List<E> result = new ArrayList<E>();
        result.addAll(currentSolution);
        result.removeAll(lastAddedEdges);
        return result;
    }

    @Override
    public String getAlgorithmName() {
        return "Two-Opt (2O) - Local Search Algorithm for Travelling Salesman Problem (TSP)";
    }

    @Override
    protected void onInterruptedRun(GraphCanvas canvas, IntegerWeightedGraph<V, E> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        if (rc.isRunning()) {
            rc.stopRun();
        }
    }

    private void invertCircuit(ITSPVertex start) {
        VertexList<V> pList = initialAlgorithm.getCircuitVertexes(start);
        List<IntegerWeightQuantity> cList = initialAlgorithm.getCircuitCosts(start);
        for (int i = pList.size() - 1; i > 0; i--) {
            pList.get(i).setNextStop(pList.get(i - 1));
            pList.get(i).setNextCost(cList.get(i - 1));
        }

        start.setNextStop(pList.get(pList.size() - 1));
        start.setNextCost(cList.get(pList.size() - 1));
    }

    private void invertPartialCircuit(ITSPVertex vj, ITSPVertex vl) {
        if (vj == vl) {
            return;
        }

        VertexList<V> pList = initialAlgorithm.getPartialCircuitVertexes(vj, vl);
        List<IntegerWeightQuantity> cList = initialAlgorithm.getPartialCircuitCosts(vj, vl);
        for (int i = pList.size() - 1; i > 0; i--) {
            pList.get(i).setNextStop(pList.get(i - 1));
            pList.get(i).setNextCost(cList.get(i - 1));
        }
    }

    public Color getRemovedEdgeColor() {
        return removedEdgeColor;
    }

    public void setRemovedEdgeColor(Color removedEdgeColor) {
        this.removedEdgeColor = removedEdgeColor;
    }

    public Color getAddedEdgeColor() {
        return addedEdgeColor;
    }

    public void setAddedEdgeColor(Color addedEdgeColor) {
        this.addedEdgeColor = addedEdgeColor;
    }
}
