/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.greedy.multifragment;

import com.paolotagliapietra.graphsj2.algorithms.tsp.ITSPVertex;
import gianlucacosta86.graphsj2.model.algorithms.standard.StandardVertex;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Paolo Tagliapietra
 */
public class MFVertex extends StandardVertex implements ITSPVertex {

    private List<MFEdge> mfEdges = new ArrayList<MFEdge>();
    private int mfDegree;
    private ITSPVertex nextStop;
    private IntegerWeightQuantity nextCost;

    public MFVertex(String name) throws InvalidNameException {
        super(name);
    }

    @Override
    protected String getRunningLabel() {
        return getName() + "[" + mfDegree + "]";
    }

    public int getMFDegree() {
        return mfDegree;
    }

    public void addMFEdge(MFEdge edge) {
        if (mfDegree < 2) {
            mfEdges.add(edge);
            mfDegree++;
        }
    }

    public MFEdge getOtherMFEdge(MFEdge edge) {
        if (mfEdges.get(0) == edge) {
            return mfEdges.size() == 2 ? mfEdges.get(1) : null;
        } else if (mfEdges.size() == 1 || (mfEdges.size() == 2 && mfEdges.get(1) == edge)) {
            return mfEdges.get(0);
        } else {
            return null;
        }
    }

    @Override
    public ITSPVertex getNextStop() {
        return nextStop;
    }

    @Override
    public IntegerWeightQuantity getNextCost() {
        return nextCost;
    }

    @Override
    public void setNextStop(ITSPVertex nextStop) {
        this.nextStop = nextStop;
    }

    @Override
    public void setNextCost(IntegerWeightQuantity cost) {
        this.nextCost = cost;
    }
}
