/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.greedy.multifragment;

import com.paolotagliapietra.graphsj2.algorithms.IntegerWeightChangeInformation;
import com.paolotagliapietra.graphsj2.algorithms.TriangularityHelper;
import com.paolotagliapietra.graphsj2.algorithms.tsp.TSPAlgorithm;
import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Paolo Tagliapietra
 */
public class Multifragment extends TSPAlgorithm<MFVertex, MFEdge, IntegerWeightedGraph<MFVertex, MFEdge>> {

    private Iterator<MFEdge> weightSortedEdges;
    private EdgeList<MFEdge> graphEdges; // All the graph edges
    private EdgeList<MFEdge> remainingGraphEdges; // The edges not belonging to the solution
    private EdgeList<MFEdge> currentSolution; // The edges belonging to the solution
    private int n;

    @Override
    protected void postInitializeRun(GraphCanvas canvas, IntegerWeightedGraph<MFVertex, MFEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        int result = JOptionPane.showOptionDialog(null, "Impose Triangularity Condition?", this.getAlgorithmName(),
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
        if (result == 0) {
            List<IntegerWeightChangeInformation> changes = new TriangularityHelper<MFVertex, MFEdge>().imposeTriangularityCondition(graph);
            if (changes.size() > 0 && verboseRun) {
                console.writeHeader("Changes made to impose the Triangularity Condition");
                console.writeLine();
                for (IntegerWeightChangeInformation inf : changes) {
                    console.writeLine(inf.toString());
                }
                console.writeLine();
            }
        } else {
            JOptionPane.showMessageDialog(null, "In this case, the algorithm might terminate with no solution", "Warning", JOptionPane.WARNING_MESSAGE);
        }

        currentSolution = new EdgeList<MFEdge>();

        ArrayList<MFEdge> edgeList = new ArrayList<MFEdge>(graph.getEdgeSet());
        Collections.sort(edgeList);
        weightSortedEdges = edgeList.iterator();

        graphEdges = graph.getEdgeList(false);
        remainingGraphEdges = graph.getEdgeList(false);
        n = graph.getVertexList(false).size();

        if (verboseRun) {
            console.writeHeader("Legend");
            console.writeLine();
            console.writeLine("E", "The graph edges");
            console.writeLine("S", "Edges belonging to the solution in the current step");
            console.writeLine();

            console.writeHeader("Before step 1");

            console.writeLine("E", graphEdges.getBoundsList());
            console.writeLine("E\\S", remainingGraphEdges.getBoundsList());
            console.writeLine("S", currentSolution.getBoundsList());
        }
    }

    @Override
    protected void standardRunStep(GraphCanvas canvas, IntegerWeightedGraph<MFVertex, MFEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        if (verboseRun) {
            console.writeHeader("Step " + currentStep);
            console.writeLine();
        }

        MFEdge currentEdge;
        while (weightSortedEdges.hasNext()) {
            currentEdge = weightSortedEdges.next();
            MFVertex vi = (MFVertex) currentEdge.getSource();
            MFVertex vj = (MFVertex) currentEdge.getTarget();

            if (vi.getMFDegree() < 2 && vj.getMFDegree() < 2) {
                /* 
                 * both vertex and source of the current edge must have degree 
                 * (considering only edges belonging to the solution) lesser than 2
                 */

                if (vi.getMFDegree() == 0 || vj.getMFDegree() == 0) {
                    /*
                     * if source or vertex has degree 0 (i.e. is not touched by
                     * any edge belonging to the solution), then the current edge
                     * can be added
                     */

                    addToSolution(vi, currentEdge, vj);
                    break;
                } else { // Both source and target of the current edge have degree greater than 0
                    if (findCircuit(vi, currentEdge, vj) == null) {
                        // If adding the current edge doesn't form circuits..
                        addToSolution(vi, currentEdge, vj);
                        break;
                    }
                }
            }
        }

        if (verboseRun) {
            console.writeLine("At the end of the step:");
            console.writeLine();
            console.writeLine("E", graphEdges.getBoundsList());
            console.writeLine("E\\S", remainingGraphEdges.getBoundsList());
            console.writeLine("S", currentSolution.getBoundsList());
            console.writeLine();
            console.writeLine();
        }

        if (!weightSortedEdges.hasNext() || currentStep == n) {
            throw new AlgorithmEndedException();
        }
    }

    private void addToSolution(MFVertex vi, MFEdge edge, MFVertex vj) {
        vi.addMFEdge(edge);
        vj.addMFEdge(edge);
        currentSolution.add(edge);
        remainingGraphEdges.remove(edge);
    }

    @Override
    protected void standardOnEndRun(GraphCanvas canvas, IntegerWeightedGraph<MFVertex, MFEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        /*
         * First, I add the (unique) edge that closes the circuit by finding
         * the only two vertexes with degree = 1 (considering only solution edges)
         */
        MFVertex last1 = null, last2 = null;
        for (MFVertex vertex : graph.getVertexSet()) {
            if (vertex.getMFDegree() == 1) {
                if (last1 == null) {
                    last1 = vertex;
                    continue;
                }
                last2 = vertex;
                break;
            }
        }

        MFEdge lastEdge = graph.getEdge(last1, last2);
        if (lastEdge == null) {
            // If the last edge does not exist, report an infinite cost
            console.writeLine("The edges belonging to the solution are: " + currentSolution.getBoundsList());
            console.writeLine();
            console.writeLine("There are no edges which close the current circuit: "
                    + "therefore, the total cost of the path is: "
                    + IntegerWeightQuantity.PLUS_INF);
            return;
        }


        //Now, If the last edge has been found, I find out the total cost of the solution
        addToSolution(last1, lastEdge, last2);
        setNexts(null, lastEdge, last2); // Not mandatory, but needed to respect TSPAlgorithm abstract class methods
        int totalCost = super.computeCircuitCost((MFVertex) (lastEdge.getSource())).getValue();

        if (verboseRun) {
            console.writeLine("At the end of the algorithm:");
            console.writeLine();
            console.writeLine("E", graphEdges.getBoundsList());
            console.writeLine("E\\S", remainingGraphEdges.getBoundsList());
            console.writeLine("S", currentSolution.getBoundsList());
            console.writeLine();
            console.writeLine();
        }

        console.writeLine("The edges belonging to the path are: " + currentSolution.getBoundsList());
        console.writeLine();
        console.writeLine("Therefore, the circuit is: " + super.circuitString(last2));
        console.writeLine("The total weight of the path is: " + totalCost);
    }

    @Override
    public String getAlgorithmName() {
        return "Multifragment (MF) - Greedy Algorithm for Travelling Salesman Problem (TSP)";
    }

    @Override
    protected void onInterruptedRun(GraphCanvas canvas, IntegerWeightedGraph<MFVertex, MFEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        // Do nothing
    }

    @Override
    protected Iterable<MFEdge> getSolutionEdges() {
        return currentSolution;
    }

    @Override
    protected IGraphFactory buildGraphFactory() {
        return new MFFactory();
    }

    @Override
    protected Iterable<MFEdge> getStepSolutionEdges(int currentStep) {
        return currentSolution;
    }

    private EdgeList<MFEdge> findCircuit(MFVertex vi, MFEdge edge, MFVertex vj) {
        EdgeList<MFEdge> circuit = new EdgeList<MFEdge>();
        if (findCircuitRec(vi, edge, vj, circuit)) {
            return circuit;
        } else {
            return null;
        }
    }

    private boolean findCircuitRec(MFVertex vi, MFEdge edge, MFVertex vj, EdgeList<MFEdge> circuit) {
        if (vi == vj) {
            return true;
        } else {
            if (vj == null) {
                return false;
            }

            MFEdge nextEdge = vj.getOtherMFEdge(edge);
            if (nextEdge != null) {
                circuit.add(nextEdge);
                return findCircuitRec(vi, nextEdge, nextEdge.getOtherMFVertex(vj), circuit);
            } else {
                return false;
            }
        }
    }

    // This method builds a circuit suitable for the methods of the TSPAlgorithm abstract class
    private void setNexts(MFVertex startingVertex, MFEdge edge, MFVertex vj) {
        if (startingVertex == null) {
            startingVertex = vj;
            startingVertex.setNextStop(vj);
            startingVertex.setNextCost(edge.getWeight());
        }

        MFEdge nextEdge = vj.getOtherMFEdge(edge);
        MFVertex nextVertex = nextEdge.getOtherMFVertex(vj);
        vj.setNextStop(nextVertex);
        vj.setNextCost(nextEdge.getWeight());

        if (nextVertex == startingVertex) {
            return;
        } else {
            setNexts(startingVertex, nextEdge, nextEdge.getOtherMFVertex(vj));
        }
    }
}