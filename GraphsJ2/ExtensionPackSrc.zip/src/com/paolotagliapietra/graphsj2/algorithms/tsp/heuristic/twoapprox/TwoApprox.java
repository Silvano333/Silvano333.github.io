/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.heuristic.twoapprox;

import com.paolotagliapietra.graphsj2.algorithms.IntegerWeightChangeInformation;
import com.paolotagliapietra.graphsj2.algorithms.TriangularityHelper;
import com.paolotagliapietra.graphsj2.algorithms.tsp.TSPAlgorithm;
import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.algorithms.IRunController;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.AlgorithmConsole;
import gianlucacosta86.graphsj2.model.algorithms.algorithmconsole.IAlgorithmConsoleWriter;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmEndedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmInterruptedException;
import gianlucacosta86.graphsj2.model.algorithms.exceptions.AlgorithmRunException;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.InvalidWeightException;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.exceptions.DuplicateEdgeException;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

/**
 *
 * @author Paolo Tagliapietra
 */
public class TwoApprox extends TSPAlgorithm<TwoApproxVertex, TwoApproxEdge, IntegerWeightedGraph<TwoApproxVertex, TwoApproxEdge>> {

    private Stack<TwoApproxVertex> passedForks;
    private VertexList<TwoApproxVertex> leaves;
    private VertexList<TwoApproxVertex> fullVList;
    private VertexList<TwoApproxVertex> vList;
    private VertexList<TwoApproxVertex> wList;
    private TwoApproxVertex startingVertex;
    private TwoApproxVertex currentVertex;
    private EdgeList<TwoApproxEdge> currentSolution;
    private TwoApproxFactory factory;
    int n;

    @Override
    public void initializeRun(GraphCanvas canvas, IntegerWeightedGraph<TwoApproxVertex, TwoApproxEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(canvas, graph, console, verboseRun);

        fullVList = graph.getVertexList(true);
        wList = new VertexList<TwoApproxVertex>(true);
        buildGraphFactory(); // Due to a serialization issue, the factory may be null.

        List<IntegerWeightChangeInformation> changes = new TriangularityHelper<TwoApproxVertex, TwoApproxEdge>().imposeTriangularityCondition(graph);
        if (changes.size() > 0 && verboseRun) {
            console.writeHeader("Changes made to impose the Triangularity Condition");
            console.writeLine();
            for (IntegerWeightChangeInformation inf : changes) {
                console.writeLine(inf.toString());
            }
            console.writeLine();
        }

        PrimSSTWrapper primAlg = new PrimSSTWrapper();
        IRunController rc = primAlg.getRunController();
        final AlgorithmConsole thisConsole = console;
        rc.getConsole().addWriter(new IAlgorithmConsoleWriter() {

            @Override
            public void write(String text) {
                thisConsole.write("|\t" + text);
            }

            @Override
            public void writeLine(String text) {
                thisConsole.writeLine("|\t" + text);
            }
        });
        if (rc.isRunning()) {
            rc.stopRun();
        }
        rc.fullRun(canvas, verboseRun);
        if (primAlg.getSolution() == null) {
            console.writeLine("|\tExecution interrupted");
            throw new AlgorithmInterruptedException();
        }

        EdgeList<TwoApproxEdge> sst = new EdgeList<TwoApproxEdge>(false);
        Map<TwoApproxVertex, Integer> visitsNumber = new HashMap<TwoApproxVertex, Integer>();
        leaves = new VertexList<TwoApproxVertex>();
        for (TwoApproxVertex v : fullVList) {
            visitsNumber.put(v, 0);
        }

        startingVertex = null;
        for (Edge e : primAlg.getSolution()) {
            sst.add((TwoApproxEdge) e);

            TwoApproxVertex s = (TwoApproxVertex) e.getSource();
            TwoApproxVertex t = (TwoApproxVertex) e.getTarget();

            s.addNeighbor(t, (TwoApproxEdge) e);
            t.addNeighbor(s, (TwoApproxEdge) e);

            if (startingVertex == null) {
                // Assign the SST root as starting vertex
                if (s.getBestVertex() == s) {
                    startingVertex = s;
                } else if (t.getBestVertex() == t) {
                    startingVertex = t;
                }
            }

            visitsNumber.put(s, visitsNumber.get(s) + 1);
            visitsNumber.put(t, visitsNumber.get(t) + 1);

            ((TwoApproxEdge) e).setPartOfSst(true);
        }
        for (TwoApproxVertex v : fullVList) {
            if (visitsNumber.get(v) == 1) {
                leaves.add(v);
            }
        }
        n = sst.size();

        vList = new VertexList<TwoApproxVertex>(fullVList, true);
        startingVertex.setVisited(true);
        leaves.remove(0);
        wList.add(startingVertex);
        vList.remove(startingVertex);

        currentVertex = startingVertex;
        currentSolution = new EdgeList<TwoApproxEdge>();
        passedForks = new Stack<TwoApproxVertex>();
        passedForks.push(startingVertex); // The SST root IS a fork

        if (verboseRun) {
            console.writeHeader("Legend");
            console.writeLine();
            console.writeLine("V", "The graph vertexes");
            console.writeLine("W", "Vertexes belonging to the path in the current step");
            console.writeLine("E", "Edges belonging to the path in the current step");
            console.writeLine("Vc", "Vertex added to the solution in the current step");
            console.writeLine();

            console.writeHeader("Before step 1");

            console.writeLine("W", wList.getNamesList());
            console.writeLine("V\\W", vList.getNamesList());
            console.writeLine("E", currentSolution.getBoundsList());
        }
    }

    @Override
    public GraphCanvas buildGraphCanvas() {
        return new FixedGraphCanvas(buildGraphFactory());
    }

    @Override
    protected void postInitializeRun(GraphCanvas canvas, IntegerWeightedGraph<TwoApproxVertex, TwoApproxEdge> graph, AlgorithmConsole console, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
    }

    @Override
    protected void standardRunStep(GraphCanvas canvas, IntegerWeightedGraph<TwoApproxVertex, TwoApproxEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        if (currentStep == 1) {
            for (TwoApproxVertex v : graph.getVertexSet()) {
                v.imposeDefaultStatus();
            }
        }

        if (verboseRun) {
            console.writeHeader("Step " + currentStep);
            console.writeLine();
        }

        if (currentSolution.size() == n) {
            TwoApproxEdge toAdd = (TwoApproxEdge) graph.getEdge(currentVertex, startingVertex);
            if (toAdd == null) {
                toAdd = factory.createEdge(currentVertex, startingVertex);
                try {
                    toAdd.setWeight(new TriangularityHelper<TwoApproxVertex, TwoApproxEdge>().singleTargetDijkstra(graph, startingVertex, currentVertex));
                } catch (InvalidWeightException ex) {
                    // Can't occur
                }
                try {
                    graph.addEdge(toAdd);
                } catch (DuplicateEdgeException ex) {
                    // Can't occur
                }

                if (verboseRun) {
                    console.writeLine("Added edge " + toAdd.getBounds() + " based on the shortest"
                            + " path between " + startingVertex.getName() + " and " + currentVertex.getName());
                    console.writeLine();
                }
            }
            currentSolution.add(toAdd);
            currentVertex.setNextStop(startingVertex);
            currentVertex.setNextCost(toAdd.getWeight());
            throw new AlgorithmEndedException();
        }

        TwoApproxVertex nextVertex = null;
        if (currentVertex.getNeighbors().size() == 1 && currentVertex != startingVertex) {
            // Leaf vertex
            do {
                TwoApproxVertex lastFork = passedForks.pop();
                int i = 0;
                for (TwoApproxVertex v : lastFork.getNeighbors()) {
                    if (!v.isVisited()) {
                        v.setVisited(true);
                        v.setPreviousStop(currentVertex);
                        TwoApproxEdge toAdd = graph.getEdge(currentVertex, v);
                        if (toAdd == null) {
                            IntegerWeightQuantity cost = new TriangularityHelper<TwoApproxVertex, TwoApproxEdge>().singleTargetDijkstra(graph, currentVertex, v);

                            if (cost.getValue() < 0) {
                                cost = IntegerWeightQuantity.ZERO;
                            }
                            toAdd = factory.createEdge(currentVertex, v);

                            try {
                                toAdd.setWeight(cost);
                            } catch (InvalidWeightException ex) {
                                // Can't occur
                            }
                            try {
                                graph.addEdge(toAdd);
                            } catch (DuplicateEdgeException ex) {
                                // Can't occur
                            }

                            if (verboseRun) {
                                console.writeLine("Added edge " + toAdd.getBounds() + " based on the shortest"
                                        + " path between " + currentVertex.getName() + " and " + v.getName());
                                console.writeLine();
                            }
                        }
                        currentSolution.add(toAdd);
                        currentVertex.setNextStop(v);
                        currentVertex.setNextCost(toAdd.getWeight());
                        nextVertex = v;
                        wList.add(v);
                        vList.remove(v);
                        break;
                    }
                    i++;
                }
            } while (nextVertex == null && !passedForks.isEmpty());
        } else {
            for (TwoApproxVertex v : currentVertex.getNeighbors()) {
                if (!v.isVisited()) {
                    v.setVisited(true);
                    currentVertex.setNextStop(v);
                    currentVertex.setNextCost(currentVertex.getWayToNeighbor(v).getWeight());
                    currentSolution.add(currentVertex.getWayToNeighbor(v));
                    wList.add(v);
                    vList.remove(v);
                    nextVertex = v;
                    break;
                }
            }

            if (currentVertex.getNeighbors().size() > 2) {
                passedForks.push(currentVertex);
            }
        }

        if (verboseRun) {
            console.writeLine("At the end of the step:");
            console.writeLine();
            console.writeLine("Vc", currentVertex);
            console.writeLine("W", wList.getNamesList());
            console.writeLine("V \\ W", vList.getNamesList());
            console.writeLine("E", currentSolution.getBoundsList());
            console.writeLine();
            console.writeLine();
        }

        currentVertex = nextVertex;
    }

    @Override
    protected void standardOnEndRun(GraphCanvas canvas, IntegerWeightedGraph<TwoApproxVertex, TwoApproxEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        int totalWeight = computeCircuitCost(startingVertex).getValue();
        console.writeLine("The edges belonging to the path are: " + currentSolution.getBoundsList());
        console.writeLine();
        console.writeLine("Therefore, the circuit is: " + circuitString(startingVertex));
        console.writeLine("And its cost is: " + totalWeight);
    }

    @Override
    protected Iterable<TwoApproxEdge> getSolutionEdges() {
        return currentSolution;
    }

    @Override
    protected Iterable<TwoApproxEdge> getStepSolutionEdges(int currentStep) {
        return currentSolution;
    }

    @Override
    protected IGraphFactory buildGraphFactory() {
        if (factory == null) {
            factory = new TwoApproxFactory();
        }

        return factory;
    }

    @Override
    public String getAlgorithmName() {
        return "2Approx - Heuristic Algorithm for Travelling Salesman Problem (TSP)";
    }

    @Override
    protected void onInterruptedRun(GraphCanvas canvas, IntegerWeightedGraph<TwoApproxVertex, TwoApproxEdge> graph, AlgorithmConsole console, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //
    }
}
