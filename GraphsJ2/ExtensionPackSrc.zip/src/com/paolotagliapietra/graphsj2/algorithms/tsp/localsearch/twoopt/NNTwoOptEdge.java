/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.localsearch.twoopt;

import com.paolotagliapietra.graphsj2.algorithms.tsp.greedy.nearneigh.NNEdge;
import gianlucacosta86.graphsj2.model.graph.Vertex;

/**
 *
 * @author Paolo Tagliapietra
 */
public class NNTwoOptEdge extends NNEdge implements ITwoOptEdge {

    public NNTwoOptEdge(Vertex source, Vertex target) {
        super(source, target);
    }
}