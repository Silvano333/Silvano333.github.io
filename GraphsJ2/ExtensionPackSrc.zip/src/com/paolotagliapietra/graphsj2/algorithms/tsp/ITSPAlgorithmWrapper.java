/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp;

import com.paolotagliapietra.graphsj2.algorithms.IAlgorithmWrapper;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import java.util.List;

/**
 *
 * @author Paolo Tagliapietra
 */

/*
 * This interface provides methods specific of TSP Algorithms:
 * i.e. all methods related to circuits and circuit costs
 */
public interface ITSPAlgorithmWrapper extends IAlgorithmWrapper {

    public IntegerWeightQuantity getCircuitCost(ITSPVertex startingVertex);

    public String getCircuitString(ITSPVertex startingVertex);

    public VertexList getCircuitVertexes(ITSPVertex startingVertex);

    public VertexList getPartialCircuitVertexes(ITSPVertex start, ITSPVertex end);

    public List<IntegerWeightQuantity> getCircuitCosts(ITSPVertex start);

    public List<IntegerWeightQuantity> getPartialCircuitCosts(ITSPVertex start, ITSPVertex end);
}
