/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp;

import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmEdge;
import gianlucacosta86.graphsj2.model.algorithms.algorithmobjects.IAlgorithmVertex;
import gianlucacosta86.graphsj2.model.algorithms.standard.StandardAlgorithm;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.VertexList;
import gianlucacosta86.graphsj2.model.graph.Graph;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightedEdge;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Paolo Tagliapietra
 */

/*
 * 
 */
public abstract class TSPAlgorithm<V extends Vertex & ITSPVertex & IAlgorithmVertex, E extends IntegerWeightedEdge & IAlgorithmEdge, G extends Graph<V, E>> extends StandardAlgorithm<V, E, G> {

    public IntegerWeightQuantity computeCircuitCost(ITSPVertex start) {
        return recursiveComputeCircuitCost(null, start);
    }

    public IntegerWeightQuantity computePartialCircuitCost(ITSPVertex start, ITSPVertex end) {
        return recursiveComputeCircuitCost(end, start);
    }

    private IntegerWeightQuantity recursiveComputeCircuitCost(ITSPVertex start, ITSPVertex next) {
        if (start == next) {
            return IntegerWeightQuantity.ZERO;
        } else {
            if (start == null) {
                start = next;
            }

            return next.getNextCost().sum(recursiveComputeCircuitCost(start, next.getNextStop()));
        }
    }

    public String circuitString(ITSPVertex start) {
        return "( " + recursiveCircuitString(null, start) + " -> " + start.getName() + " )";
    }

    private String recursiveCircuitString(ITSPVertex start, ITSPVertex next) {
        if (start == next) {
            return "";
        } else {
            if (start == null) {
                start = next;
            }

            String nextString = recursiveCircuitString(start, next.getNextStop());
            return next.getName() + (nextString.equals("") ? "" : " -> " + nextString);
        }
    }

    public VertexList<V> getCircuitVertexes(ITSPVertex start) {
        VertexList<V> vList = new VertexList<V>();
        recursiveGetCircuitVertexes(null, start, vList);
        return vList;
    }

    public VertexList<V> getPartialCircuitVertexes(ITSPVertex start, ITSPVertex end) {
        VertexList<V> vList = new VertexList<V>();
        recursiveGetCircuitVertexes(end, start, vList);
        vList.add((V) end);
        return vList;
    }

    private void recursiveGetCircuitVertexes(ITSPVertex start, ITSPVertex next, VertexList<V> vList) {
        if (start == next) {
            return;
        } else {
            if (start == null) {
                start = next;
            }

            vList.add((V) next);
            recursiveGetCircuitVertexes(start, next.getNextStop(), vList);
        }
    }

    public List<IntegerWeightQuantity> getPartialCircuitCosts(ITSPVertex start, ITSPVertex end) {
        List<IntegerWeightQuantity> cList = new ArrayList<IntegerWeightQuantity>();
        recursiveGetCircuitCosts(end, start, cList);
        return cList;
    }

    public List<IntegerWeightQuantity> getCircuitCosts(ITSPVertex start) {
        List<IntegerWeightQuantity> cList = new ArrayList<IntegerWeightQuantity>();
        recursiveGetCircuitCosts(null, start, cList);
        return cList;
    }

    private void recursiveGetCircuitCosts(ITSPVertex start, ITSPVertex next, List<IntegerWeightQuantity> cList) {
        if (start == next) {
            return;
        } else {
            if (start == null) {
                start = next;
            }

            cList.add(next.getNextCost());
            recursiveGetCircuitCosts(start, next.getNextStop(), cList);
        }
    }
}
