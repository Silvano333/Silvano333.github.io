/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.heuristic.twoapprox;

import gianlucacosta86.graphsj2.controller.graphfactory.IGraphFactory;
import gianlucacosta86.graphsj2.model.graph.Edge;
import gianlucacosta86.graphsj2.view.components.graphcanvas.GraphCanvas;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.edgedrawer.EdgeDrawer;
import gianlucacosta86.graphsj2.view.components.graphcanvas.drawers.vertexdrawer.VertexDrawer;

/**
 *
 * @author Paolo Tagliapietra
 */
public class FixedGraphCanvas extends GraphCanvas {

    public FixedGraphCanvas(IGraphFactory graphFactory) {
        super(graphFactory);
    }

    @Override
    protected EdgeDrawer buildEdgeDrawer(VertexDrawer sourceVertexDrawer, VertexDrawer targetVertexDrawer, Edge edge) {
        return new EdgeDrawer(sourceVertexDrawer, targetVertexDrawer, edge, getDefaultEdgeDrawerProperties().clone());
    }
}
