/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.greedy.nearneigh;

import gianlucacosta86.graphsj2.controller.graphfactory.GraphFactory;
import gianlucacosta86.graphsj2.model.graph.Graph;
import gianlucacosta86.graphsj2.model.graph.Vertex;
import gianlucacosta86.graphsj2.model.graph.weighted.IntegerWeightedGraph;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;

/**
 *
 * @author Paolo Tagliapietra
 */
public class NNFactory extends GraphFactory<NNVertex, NNEdge> {

    @Override
    public Graph<NNVertex, NNEdge> createGraph() {
        return new IntegerWeightedGraph<NNVertex, NNEdge>(false);
    }

    @Override
    public NNVertex createVertex(String name) throws InvalidNameException {
        return new NNVertex(name);
    }

    @Override
    public NNEdge createEdge(Vertex sourceVertex, Vertex targetVertex) {
        return new NNEdge(sourceVertex, targetVertex);
    }
}
