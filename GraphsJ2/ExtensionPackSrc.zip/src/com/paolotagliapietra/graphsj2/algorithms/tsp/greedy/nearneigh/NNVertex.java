/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.greedy.nearneigh;

import com.paolotagliapietra.graphsj2.algorithms.tsp.ITSPVertex;
import gianlucacosta86.graphsj2.model.algorithms.standard.StandardVertex;
import gianlucacosta86.graphsj2.model.graph.edges.weighted.integer.IntegerWeightQuantity;
import gianlucacosta86.graphsj2.model.utils.namevalidator.InvalidNameException;

/**
 *
 * @author Paolo Tagliapietra
 */
public class NNVertex extends StandardVertex implements ITSPVertex {

    private IntegerWeightQuantity nextCost;
    private ITSPVertex nextStop;

    public NNVertex(String name) throws InvalidNameException {
        super(name);
    }
    private boolean visited;

    protected boolean isVisited() {
        return visited;
    }

    protected void setVisited(boolean visited) {
        this.visited = visited;
    }

    @Override
    protected String getRunningLabel() {
        return getName().concat(visited
                ? getAlgorithm().getRunController().isVerboseRun() ? " [@]"
                : "" : "");
    }

    @Override
    public ITSPVertex getNextStop() {
        return nextStop;
    }

    @Override
    public IntegerWeightQuantity getNextCost() {
        return nextCost;
    }

    @Override
    public void setNextStop(ITSPVertex nextStop) {
        this.nextStop = nextStop;
    }

    @Override
    public void setNextCost(IntegerWeightQuantity cost) {
        this.nextCost = cost;
    }
}
