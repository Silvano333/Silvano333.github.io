/*
 * author: Paolo Tagliapietra
 * application: GraphsJ 2 Extension Pack
 * e-mail: paolo@paolotagliapietra.com
 */

/*
 * Copyright © 2011 Paolo Tagliapietra
 * 
 * This file is part of GraphsJ 2 Extension Pack.
 *
 * GraphsJ 2 Extension Pack is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ 2 Extension Pack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ 2 Extension Pack. If not, see <http://www.gnu.org/licenses/>.
 */
package com.paolotagliapietra.graphsj2.algorithms.tsp.heuristic.twoapprox;

import com.paolotagliapietra.graphsj2.algorithms.IAlgorithmWrapper;
import gianlucacosta86.graphsj2.model.algorithms.concrete.prim.PrimSST;
import gianlucacosta86.graphsj2.model.collections.graphoriented.lists.EdgeList;
import gianlucacosta86.graphsj2.model.graph.Edge;

/**
 *
 * @author Paolo Tagliapietra
 */
public class PrimSSTWrapper extends PrimSST implements IAlgorithmWrapper {

    @Override
    public Iterable<Edge> getSolution() {
        EdgeList<Edge> solution = new EdgeList<Edge>();
        if (super.getSolutionEdges() == null) {
            return null;
        }

        for (Edge e : super.getSolutionEdges()) {
            solution.add((Edge) e);
        }
        return solution;
    }
}
