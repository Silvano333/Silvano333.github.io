/*
 * Copyright © 2009 Gianluca Costa
 * 
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj;

import graphsj.gui.windows.main.MainFrame;
import javax.swing.ImageIcon;
import javax.swing.UIManager;

/**
 * This class contains the program's entry point and some global application data.
 * 
 * @author Gianluca Costa
 */
public final class Application {

    public static final String NAME = "GraphsJ";
    public static final String VERSION = "1.0";
    public static final String TITLE = NAME + " " + VERSION;
    public static final ImageIcon SMALL_ICON = new ImageIcon(Application.class.getResource("SmallIcon.png"));
    public static final ImageIcon BIG_ICON = new ImageIcon(Application.class.getResource("BigIcon.png"));
    public static final ImageIcon HUGE_ICON = new ImageIcon(Application.class.getResource("HugeIcon.png"));

    /**
     * The program's entry point.
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            //Just do nothing
        }


        //Now I can show the main frame
        new MainFrame().setVisible(true);
    }

    private Application() {
    }
}
