/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.components;

import graphsj.model.graphkeeper.BasicEdge;
import graphsj.model.graphkeeper.BasicVertex;
import graphsj.model.graphkeeper.BasicGraphObject;
import graphsj.gui.utils.MessageProvider;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.lang.reflect.Constructor;
import java.util.Map;
import graphsj.model.graphkeeper.exceptions.GraphException;
import graphsj.model.graphkeeper.exceptions.DuplicateVertexException;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.exceptions.DuplicateEdgeException;
import graphsj.model.graphkeeper.utils.InvalidNameException;
import graphsj.model.graphkeeper.utils.NameValidator;
import java.awt.Point;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseListener;
import org.jgraph.JGraph;
import org.jgraph.event.GraphSelectionEvent;
import org.jgraph.event.GraphSelectionListener;
import org.jgraph.graph.DefaultCellViewFactory;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.GraphConstants;
import org.jgraph.graph.GraphLayoutCache;

/**
 * This canvas graphically shows its underlying adapter, and enables the user to easily modify it.
 * @author Gianluca Costa
 * @param <V> The vertex class.
 * @param <E> The edge class.
 */
public class GraphCanvas<V extends BasicVertex, E extends BasicEdge> extends JGraph {

    private SafeAdapter<V, E> adapter;
    private static final int EDGE_KEY = KeyEvent.VK_L;
    private boolean creatingEdge;
    private Object edgeSourceCell;
    private String vertexBaseName = "V";
    private int vertexNameCounter = 0;
    /**
     * This listener keeps track of the user's key presses.
     */
    private final KeyListener keyListener = new KeyAdapter() {

        @Override
        public void keyPressed(KeyEvent e) {
            super.keyPressed(e);

            if (!editable) {
                return;
            }

            switch (e.getKeyCode()) {
                case KeyEvent.VK_DELETE:
                    removeSelectedCells();
                    break;

                case EDGE_KEY:
                    creatingEdge = true;
                    break;
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
            super.keyReleased(e);

            switch (e.getKeyCode()) {
                case EDGE_KEY:
                    creatingEdge = false;
                    break;
            }
        }
    };
    /**
     * This listener keeps track of the user's mouse movements
     */
    private final MouseListener graphMouseListener = new MouseAdapter() {

        @Override
        public void mouseClicked(MouseEvent e) {
            super.mouseClicked(e);

            if (!editable) {
                return;
            }

            int button = e.getButton();

            if (button == MouseEvent.BUTTON1) {
                int clickCount = e.getClickCount();

                if (clickCount == 1) {
                    if (isInBlankSpace(new Point(e.getX(), e.getY()))) {
                        createVertex(e.getX(), e.getY());
                    }
                } else if (clickCount == 2) {
                    editSelectedItemIfPossible();
                }

            } else if (button == MouseEvent.BUTTON3) {
                removeSelectedCells();
            }
        }
    };
    /**
     * This listener keeps track of the changes in the canvas selection.
     */
    private final GraphSelectionListener selectionListener = new GraphSelectionListener() {

        @Override
        public void valueChanged(GraphSelectionEvent e) {
            if (!editable) {
                return;
            }


            Object newEdgeSourceCell = null;


            try {

                Object selectedVertexCell = getSelectedVertexCell();

                if (selectedVertexCell == null) {
                    return;
                }

                if (selectedVertexCell.getClass() != DefaultGraphCell.class) {
                    return;
                }

                if (creatingEdge) {

                    if (edgeSourceCell != null) {
                        if (edgeSourceCell != selectedVertexCell) {
                            createEdge(edgeSourceCell, selectedVertexCell);
                            newEdgeSourceCell = edgeSourceCell;
                            setSelectionCell(edgeSourceCell);

                        }
                    } else {
                        newEdgeSourceCell = selectedVertexCell;
                    }

                } else {
                    newEdgeSourceCell = selectedVertexCell;
                }
            } finally {
                edgeSourceCell = newEdgeSourceCell;
            }

        }
    };

    /**
     * Creates the canvas.
     */
    public GraphCanvas() {
        addMouseListener(graphMouseListener);
        addKeyListener(keyListener);
        addGraphSelectionListener(selectionListener);
    }

    /**
     *
     * @return The vertex base name, used as the root of the name of new vertexes.
     */
    public String getVertexBaseName() {
        return vertexBaseName;
    }

    /**
     * Sets the vertex base name, used as the root of the name of new vertexes.
     * @param vertexBaseName The new base name. It must be a valid name.
     * @throws graphsj.model.graphkeeper.utils.InvalidNameException Thrown if the new base name is invalid.
     */
    public void setVertexBaseName(String vertexBaseName) throws InvalidNameException {
        NameValidator.getInstance().validateName(vertexBaseName);
        this.vertexBaseName = vertexBaseName;
    }

    /**
     *
     * @return The vertex name counter, used as the suffix of the name of new vertexes.
     */
    public int getVertexNameCounter() {
        return vertexNameCounter;
    }

    /**
     * Sets the vertex name counter, used as the suffix of the name of new vertexes.
     * @param vertexNameCounter The new counter. It is only a hint, since the canvas will assign to new vertexes a name with the FIRST suffix, starting from the counter, that creates a unique vertex name in the graph.
     */
    public void setVertexNameCounter(int vertexNameCounter) {
        this.vertexNameCounter = vertexNameCounter;
    }

    /**
     *
     * @return The underlying adapter.
     */
    public SafeAdapter<V, E> getAdapter() {
        return adapter;
    }

    /**
     * Sets the underlying adapter.
     * @param adapter The new adapter. It will be immediately shown in the canvas.
     */
    public void setAdapter(SafeAdapter adapter) {
        setGraphLayoutCache(new GraphLayoutCache(adapter, new DefaultCellViewFactory()));
        this.adapter = adapter;
    }

    /**
     *
     * @return The adapter's graph keeper.
     */
    private GraphKeeper<V, E> getGraphKeeper() {
        return adapter.getGraphKeeper();
    }

    /**
     * Creates a vertex at the specified point. The name of the new vertex is determined by the properties "VertexBaseName" and "VertexNameCounter".
     * @param x The x coordinate of the vertex center.
     * @param y The y coordinate of the vertex center.
     */
    public void createVertex(int x, int y) {
        if (!editable) {
            throw new IllegalStateException("Cannot create vertexes when the graph is not editable");
        }

        V newVertex = null;

        while (true) {
            try {
                String newVertexString = vertexBaseName + (vertexNameCounter++);
                Constructor<V> vertexConstructor = (Constructor<V>) getGraphKeeper().getVertexClass().getConstructor(String.class);
                newVertex = vertexConstructor.newInstance(newVertexString);

                newVertex.attach(getGraphKeeper());
                break;
            } catch (DuplicateVertexException ex) {
                continue;
            } catch (IllegalAccessException ex) {
                throw new IllegalStateException("Cannot access a public vertex constructor whose signature is Constructor(String)");
            } catch (Exception ex) {
                MessageProvider.getInstance().showErrorBox(ex);
                return;
            }
        }


        DefaultGraphCell cell = getAdapter().getVertexCell(newVertex);
        Map vertexAttributes = cell.getAttributes();

        Rectangle2D vertexBounds = GraphConstants.getBounds(vertexAttributes);

        int newX = (int) (x - vertexBounds.getWidth() / 2);
        int newY = (int) (y - vertexBounds.getHeight() / 2);

        GraphConstants.setBounds(vertexAttributes, new Rectangle(newX, newY, 0, 0));

        getAdapter().cellChanged(cell);
    }

    /**
     * Creates an edge between the 2 specified GRAPHIC cells, which must be different.
     * @param sourceCell The source cell.
     * @param targetCell The target cell.
     */
    private void createEdge(Object sourceCell, Object targetCell) {
        if (!editable) {
            throw new IllegalStateException("Cannot create edges when the graph is not editable");
        }


        if (sourceCell == null) {
            throw new IllegalArgumentException("The source cell must NOT be null");
        }

        if (targetCell == null) {
            throw new IllegalArgumentException("The target cell must NOT be null");
        }

        if (sourceCell == targetCell) {
            throw new IllegalArgumentException("The source cell and the target cell cannot be the same instance");
        }

        E newEdge = null;

        try {
            Constructor<E> edgeConstructor = getGraphKeeper().getEdgeClass().getConstructor();
            newEdge = edgeConstructor.newInstance();
            V sourceVertex = (V) getAdapter().getValue(sourceCell);
            V targetVertex = (V) getAdapter().getValue(targetCell);

            newEdge.attach(getGraphKeeper(), sourceVertex, targetVertex);
        } catch (DuplicateEdgeException ex) {
            MessageProvider.getInstance().showWarningBox("Cannot duplicate the edge!");
        } catch (Exception ex) {
            MessageProvider.getInstance().showErrorBox(ex);
            return;
        }
    }

    /**
     * If there is just one item selected, starts its interactive editing and, if successful, refreshes the canvas.
     */
    public void editSelectedItemIfPossible() {
        if (!editable) {
            throw new IllegalStateException("Cannot edit objects when the graph is not editable");
        }


        if (getSelectionCount() == 1) {
            BasicGraphObject basicObject = (BasicGraphObject) getAdapter().getValue(getSelectionCell());

            try {
                if (basicObject.edit(this)) {
                    //It is far better to refresh the whole adapter, otherwise strange glitches can appear.
                    getAdapter().cellsChanged();
                }
            } catch (GraphException ex) {
                MessageProvider.getInstance().showWarningBox(ex);
            }
        }
    }

    /**
     * Removes the selected cells.
     */
    public void removeSelectedCells() {
        if (!editable) {
            throw new IllegalStateException("Cannot remove cells when the graph is not editable");
        }

        Object[] selectedCells = getSelectionCells();
        if (selectedCells.length > 0) {

            for (Object currentSelectedCell : selectedCells) {

                if (currentSelectedCell == edgeSourceCell) {
                    edgeSourceCell = null;
                }

                BasicGraphObject graphObject = (BasicGraphObject) getAdapter().getValue(currentSelectedCell);
                graphObject.detach();
            }
        }
    }

    /**
     *
     * @param point The point to test.
     * @return The vertex cell, if any, owning the specified point.
     */
    public DefaultGraphCell vertexCellAtPoint(Point point) {
        for (BasicVertex vertex : getGraphKeeper().vertexSet()) {
            DefaultGraphCell cell = getAdapter().getVertexCell(vertex);
            if (hitsCell(cell, point)) {
                return cell;
            }
        }

        return null;
    }

    /**
     *
     * @param point The specified point
     * @return True if the point belongs to the blank space, false otherwise.
     */
    public boolean isInBlankSpace(Point point) {
        //This branch handles edge selection and multi-cell square selections
        if (getSelectionCount() > 0) {
            return false;
        } else {
            return vertexCellAtPoint(point) == null;
        }

    }

    /**
     *
     * @return The selected cell if there is just one cell selected in the canvas, and it is a vertex cell, false otherwise.
     */
    private Object getSelectedVertexCell() {
        if (getSelectionCount() != 1) {
            return null;
        }

        Object selectedCell = getSelectionCell();
        if (selectedCell.getClass() != DefaultGraphCell.class) {
            return null;
        }

        return selectedCell;
    }

    /**
     * Checks if the specified point belongs to the specified cell.
     * @param cell The cell
     * @param point The point
     * @return True if the specified point belongs to the specified cell.
     */
    private boolean hitsCell(DefaultGraphCell cell, Point point) {
        Rectangle2D cellBounds = GraphConstants.getBounds(cell.getAttributes());

        return cellBounds.contains(point);
    }
}
