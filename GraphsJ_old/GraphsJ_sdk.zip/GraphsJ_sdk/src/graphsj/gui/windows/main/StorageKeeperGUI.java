/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.windows.main;

import graphsj.model.graphkeeper.BasicEdge;
import graphsj.model.graphkeeper.BasicVertex;
import graphsj.model.graphkeeper.SafeAdapter;

/**
 * This interface should be implemented by a GUI (for example a frame) supporting the StorageKeeper
 * @author Gianluca Costa
 */
interface StorageKeeperGUI {

    /**
     *
     * @return The adapter containing the user input, on which the StorageKeeper must work.
     */
    public SafeAdapter<? extends BasicVertex, ? extends BasicEdge> getInputAdapter();

    /**
     * Allows the StorageKeeper to change the input adapter in the GUI.
     * @param adapter The new adapter provided by the StorageKeeper.
     */
    public void setInputAdapter(SafeAdapter<? extends BasicVertex, ? extends BasicEdge> adapter);
}
