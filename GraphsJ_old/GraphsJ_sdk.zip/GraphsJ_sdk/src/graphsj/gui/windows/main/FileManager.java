/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.windows.main;

import graphsj.Application;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

/**
 * This class keeps track of the currently open file and its state, and provides functions to interact with the user to create/open/save/close files.
 *
 * @author Gianluca Costa
 */
class FileManager extends FileManagerBase {

    private File lastDir = null;
    private final StorageKeeper storageKeeper;
    private final FileFilter graphFileFilter = new javax.swing.filechooser.FileFilter() {

        @Override
        public boolean accept(File f) {
            return f.isDirectory() || f.getName().endsWith(GRAPH_FILE_EXT);
        }

        @Override
        public String getDescription() {
            return String.format("Graph file (*%s)", GRAPH_FILE_EXT);
        }
    };

    /**
     * Creates the file manager.
     * @param storageKeeper The storage keeper to use.
     */
    public FileManager(StorageKeeper storageKeeper) {
        this.storageKeeper = storageKeeper;
    }

    /**
     * Determines if the current document can be closed.
     * @return If no document is open, or it is not modified, it returns true immediately. Otherwise, it asks the user if the document can be closed (and maybe saved).
     */
    public boolean canClose() {
        if (isEmpty() || !isModified()) {
            return true;
        }

        int messageResult = JOptionPane.showConfirmDialog(null, "The current graph has been modified.\nWould you like to save it?", Application.TITLE, JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        switch (messageResult) {
            case JOptionPane.YES_OPTION:
                return doSave();
            case JOptionPane.NO_OPTION:
                return true;
            default:
                return false;
        }
    }

    /**
     * Asks the user for a file path. If the user is saving and chooses the default filter, the default document extension is automatically added if not provided by the user.
     * @param dialogMode. Tells the dialog how to appear and behave. It can only be either JFileChooser.OPEN_DIALOG or JFileChooser.SAVE_DIALOG.
     * @return The file chosen by the user, or null if the user cancelled the dialog.
     */
    private File askForFile(int dialogMode) {
        JFileChooser chooser = new JFileChooser();
        chooser.addChoosableFileFilter(graphFileFilter);


        if (lastDir != null) {
            chooser.setCurrentDirectory(lastDir);
        }

        int dialogResult;

        switch (dialogMode) {
            case JFileChooser.OPEN_DIALOG:
                chooser.setDialogTitle("Open graph document...");
                dialogResult = chooser.showOpenDialog(null);
                break;


            case JFileChooser.SAVE_DIALOG:
                chooser.setDialogTitle("Save graph document...");
                dialogResult = chooser.showSaveDialog(null);
                break;

            default:
                throw new IllegalArgumentException("Invalid dialog mode for the JFileChooser!");
        }


        if (dialogResult == JFileChooser.APPROVE_OPTION) {
            File chosenFile = chooser.getSelectedFile();
            lastDir = chosenFile.getParentFile();

            if (dialogMode == JFileChooser.OPEN_DIALOG) {
                return chosenFile;
            }

            if (chooser.getFileFilter() == graphFileFilter && !chosenFile.getName().endsWith(GRAPH_FILE_EXT)) {
                return new File(chosenFile.getAbsolutePath() + GRAPH_FILE_EXT);
            } else {
                return chosenFile;
            }

        }

        return null;
    }

    /**
     * Tries to create a new file.
     * @return True if the new document was successfully created.
     */
    public boolean doNew() {
        if (!canClose()) {
            return false;
        }

        boolean result = storageKeeper.doNew();
        if (!result) {
            return false;
        }

        setState(false, null, false);
        return true;
    }

    /**
     * Tries to open an existing document.
     * @return True if the document was successfully loaded.
     */
    public boolean doOpen() {
        if (!canClose()) {
            return false;
        }

        File chosenFile = askForFile(JFileChooser.OPEN_DIALOG);

        if (chosenFile == null) {
            return false;
        } else {

            if (!storageKeeper.loadData(chosenFile)) {
                return false;
            }

            setState(false, chosenFile, false);
            return true;
        }
    }

    /**
     * Tries to save the current document.
     * @return True if the document was successfully saved.
     */
    public boolean doSave() {
        if (isEmpty()) {
            throw new IllegalStateException("Cannot save an empty document!");
        }


        File currentFile = getCurrentFile();

        if (currentFile == null) {
            return doSaveAs();
        } else {
            if (!storageKeeper.saveData(currentFile)) {
                return false;
            }
            setState(false, currentFile, false);
            return true;
        }
    }

    /**
     * Tries to save the current document with a different name.
     * @return True if the document was successfully saved with a different name.
     */
    public boolean doSaveAs() {
        if (isEmpty()) {
            throw new IllegalStateException("Cannot save an empty document!");
        }


        File chosenFile = askForFile(JFileChooser.SAVE_DIALOG);

        if (chosenFile != null && storageKeeper.saveData(chosenFile)) {
            setState(false, chosenFile, false);
            return true;
        }

        return false;
    }

    /**
     * Tries to close the current document.
     * @return True if it was successfully closed.
     */
    public boolean doClose() {
        if (!canClose()) {
            return false;
        }

        if (!storageKeeper.doClose()) {
            return false;
        }

        setState(true, null, false);

        return true;

    }
}
