/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.windows;

import graphsj.Application;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeListener;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

/**
 * A dialog with common useful functions, in particular:
 * <ul>
 *  <li>It is centered on the screen</li>
 *  <li>Is provides an "OK" and a "Cancel" button. The latter can be shown or hidden when constructing the dialog</li>
 *  <li>When the user clicks the OK button, a validation method is called: if it does not return successfully, the dialog is not closed</li>
 *  <li>Shortcuts are supported for both the "OK" (via Enter) and "Cancel" (via Esc) button.
 *  <li>When closed, it is just hidden, so it allows you to determine whether it was confirmed or cancelled</li>
 *  <li>The program icon</li>
 * </ul>
 *
 * <b>NOTE: </b>If you are using NetBeans, and inherit from this class, you should delete the call to "initializeComponents()" in the subclass's constructor, and make it the only instruction in the implementation of "initDescendantComponents()".
 *
 * @author Gianluca Costa
 */
public abstract class CommonDialog extends javax.swing.JDialog {

    private boolean confirmed;

    /** Creates new CommonDialog.
     * @param parent The parent.
     * @param modal True if it must be modal.
     * @param showCancelButton True if the "Cancel" button must be shown.
     */
    public CommonDialog(java.awt.Frame parent, boolean modal, boolean showCancelButton) {
        super(parent, modal);
        initGUI();

        cancelButton.setVisible(showCancelButton);

        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);


        getRootPane().setDefaultButton(okButton);


        //Now, I bind the "esc" key and the CancelButton listener
        InputMap inputMap = rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);

        KeyStroke escStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0);
        final Object escToken = new Object();
        inputMap.put(escStroke, escToken);
        rootPane.getActionMap().put(escToken, new Action() {

            @Override
            public Object getValue(String key) {
                return escToken;
            }

            @Override
            public void putValue(String key, Object value) {
            }

            @Override
            public void setEnabled(boolean b) {
            }

            @Override
            public boolean isEnabled() {
                return true;
            }

            @Override
            public void addPropertyChangeListener(PropertyChangeListener listener) {
            }

            @Override
            public void removePropertyChangeListener(PropertyChangeListener listener) {
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                cancelButtonActionPerformed(null);
            }
        });


        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(getMainPanel(), BorderLayout.CENTER);
        getContentPane().add(buttonsPanel, BorderLayout.SOUTH);

        setIconImage(Application.SMALL_ICON.getImage());
        setLocationRelativeTo(null);
    }

    /**
     * Initializes the GUI, by creating the GUI components both in this class and the inheriting class.
     * It is due to the lack of inheritance flexibility in NetBeans.
     */
    private void initGUI() {
        initComponents();
        initDescendantComponents();
    }

    /**
     * In this method, initialize the components of your descendant class.
     * If you are using NetBeans, just insert a call to the private "initComponents()" method.
     */
    protected abstract void initDescendantComponents();

    /**
     *
     * @return The main panel of the dialog, the one which will be inserted in the center area of the dialog's BorderLayout.
     */
    protected abstract JPanel getMainPanel();

    /**
     *
     * @return True if the user closed the dialog by clicking OK.
     */
    public final boolean isConfirmed() {
        return confirmed;
    }

    /**
     * Use this method to perform all the checks required when the user clicks the OK button.
     * It's up to you to show warning/error messages in case of errors.
     * @return True if the validation succeeded, and the dialog can be closed.
     */
    protected boolean validateOnOk() {
        return true;
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        buttonsPanel = new javax.swing.JPanel();
        okButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();

        buttonsPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        buttonsPanel.setLayout(new java.awt.GridBagLayout());

        okButton.setText("OK");
        okButton.setPreferredSize(new java.awt.Dimension(47, 28));
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(7, 0, 7, 0);
        buttonsPanel.add(okButton, gridBagConstraints);

        cancelButton.setText("Cancel");
        cancelButton.setPreferredSize(new java.awt.Dimension(65, 28));
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(7, 0, 7, 0);
        buttonsPanel.add(cancelButton, gridBagConstraints);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            confirmed = false;
        }
        super.setVisible(visible);
    }

    /**
     * Sets the color of the buttons panel.
     * @param color The new color.
     */
    public void setButtonsPanelColor(Color color) {
        buttonsPanel.setBackground(color);
    }

    private void okButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButtonActionPerformed
        if (!validateOnOk()) {
            return;
        }

        confirmed = true;
        setVisible(false);
}//GEN-LAST:event_okButtonActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        setVisible(false);
}//GEN-LAST:event_cancelButtonActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel buttonsPanel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JButton okButton;
    // End of variables declaration//GEN-END:variables
}
