/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.model.graphkeeper.exceptions.DuplicateVertexException;
import graphsj.model.graphkeeper.exceptions.DuplicateEdgeException;
import graphsj.model.graphkeeper.utils.VertexPair;
import graphsj.model.graphkeeper.edges.WeightedEdge;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.jgrapht.graph.DefaultListenableGraph;

/**
 * This class wraps a JGraphT graph to grant many features and advanced type checking.
 * It is the only object used to represent a graph in this library.
 * 
 * @author Gianluca Costa
 */
public abstract class GraphKeeper<V extends BasicVertex, E extends BasicEdge> implements Externalizable {

    private transient DefaultListenableGraph<BasicVertex, BasicEdge> graph;

    /**
     * Creates the graph keeper.
     */
    public GraphKeeper() {
        this.graph = (DefaultListenableGraph<BasicVertex, BasicEdge>) createGraph();
    }

    /**
     *
     * @return The edge class used by the keeper.
     */
    public abstract Class<E> getEdgeClass();

    /**
     *
     * @return The vertex class used by the keeper.
     */
    public abstract Class<V> getVertexClass();

    /**
     *
     * @return The graph underlying the keeper.
     */
    public abstract DefaultListenableGraph<V, E> createGraph();

    /**
     *
     * @return A copy of the vertex set. The vertexes in the new set are the original ones, NOT cloned.
     */
    public Set<V> vertexSetCopy() {
        Set<V> originalSet = vertexSet();
        return new HashSet<V>(originalSet);
    }

    /**
     *
     * @return An ordered list of the vertexes. The vertexes in the list are the original ones, NOT cloned.
     */
    public List<V> orderedVertexList() {
        List<V> result = new ArrayList(vertexSet());
        Collections.sort(result);
        return result;
    }

    /**
     *
     * @return An ordered list of the edges. The edges in the list are the original ones, NOT cloned.
     */
    public List<E> orderedEdgeList() {
        List<E> result = new ArrayList(edgeSet());
        Collections.sort(result);
        return result;
    }

    /**
     *
     * @return The underlying graph
     */
    DefaultListenableGraph<V, E> getGraph() {
        return (DefaultListenableGraph<V, E>) graph;
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {

        Set<BasicVertex> vertexes = new HashSet<BasicVertex>(graph.vertexSet());
        out.writeObject(vertexes);


        Map<BasicEdge, VertexPair> edgeMap = new HashMap<BasicEdge, VertexPair>();

        for (BasicEdge edge : graph.edgeSet()) {
            VertexPair edgePair = new VertexPair(graph.getEdgeSource(edge), graph.getEdgeTarget(edge));
            edgeMap.put(edge, edgePair);
        }

        out.writeObject(edgeMap);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        graph = (DefaultListenableGraph<BasicVertex, BasicEdge>) createGraph();
        Set<BasicVertex> vertexes = (Set<BasicVertex>) in.readObject();
        Map<BasicEdge, VertexPair> edgeMap = (Map<BasicEdge, VertexPair>) in.readObject();


        for (BasicVertex vertex : vertexes) {
            try {
                vertex.attach(this);
            } catch (DuplicateVertexException ex) {
                throw new RuntimeException(ex);
            }
        }


        for (Entry<BasicEdge, VertexPair> entry : edgeMap.entrySet()) {
            BasicEdge edge = entry.getKey();

            VertexPair pair = entry.getValue();
            try {
                edge.attach(this, pair.getSource(), pair.getTarget());
            } catch (DuplicateEdgeException ex) {
                throw new RuntimeException(ex);
            }
        }

    }

    /**
     * Searches in the underlying graph for vertexes conflicting with the specified vertex.
     * Two vertexes are conflicting if they are equal AND at different memory addresses.
     * @param vertex The vertex.
     * @return
     */
    boolean hasConflictingVertex(V vertex) {
        for (BasicVertex currentVertex : graph.vertexSet()) {
            if ((currentVertex != vertex) && currentVertex.equals(vertex)) {
                return true;
            }
        }

        return false;
    }


    //----------------
    //DELEGATE METHODS
    //----------------
    /**
     *
     * @return The vertex set, from the original graph.
     */
    public Set<V> vertexSet() {
        return (Set<V>) graph.vertexSet();
    }

    /**
     *
     * @return The edge set, from the original graph.
     */
    public Set<E> edgeSet() {
        return (Set<E>) graph.edgeSet();
    }

    /**
     * Gets the edge between two vertexes
     * @param sourceVertex The source vertex
     * @param targetVertex The target vertex
     * @return The edge
     */
    public E getEdge(BasicVertex sourceVertex, BasicVertex targetVertex) {
        return (E) graph.getEdge(sourceVertex, targetVertex);
    }

    /**
     * Returns the distance between 2 vertexes, if the underlying edge class is or subclasses WeightedEdge.
     * @param startVertex The start vertex
     * @param stopVertex The target vertex
     * @return The weight of the edge between the 2 vertexes, or an infinite value if there is no edge between them.
     */
    public int getDistanceBetween(V startVertex, V stopVertex) {
        if (!WeightedEdge.class.isAssignableFrom(getEdgeClass())) {
            throw new RuntimeException("Cannot compute vertex distance if the graph does not support weights!");
        }

        WeightedEdge edge = (WeightedEdge) graph.getEdge(startVertex, stopVertex);

        if (edge == null) {
            return WeightedEdge.INF_WEIGHT;
        } else {
            return edge.getWeight();
        }
    }
}
