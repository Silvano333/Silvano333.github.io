/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.edges;

import graphsj.gui.components.GraphCanvas;
import graphsj.model.graphkeeper.exceptions.GraphException;
import graphsj.model.graphkeeper.BasicEdge;
import graphsj.gui.utils.MessageProvider;
import java.util.Locale;

/**
 * This edge supports an integer weight.
 * Infinite weights are represented by +/-INF_WEIGHT.
 * @author Gianluca Costa
 */
public class WeightedEdge extends BasicEdge {

    /**
     * The maximum weight allowed for an edge.
     */
    public static int INF_WEIGHT = Integer.MAX_VALUE;
    private int weight;

    /**
     * Parses a string to retrieve a weight quantity. It does not perform ANY range check on the parsed number.
     * @param weightString The string to parse. It can be numeric, or "INF" or "-INF" (case insensitive).
     * @return The parsed integer.
     * @throws java.lang.NumberFormatException Thrown if a conversion error occurred.
     */
    public static Integer parseWeightString(String weightString) throws NumberFormatException {
        weightString = weightString.toUpperCase(Locale.getDefault());

        if (weightString.equals("INF")) {
            return INF_WEIGHT;
        } else if (weightString.equals("-INF")) {
            return -INF_WEIGHT;
        }


        return Integer.parseInt(weightString);
    }

    /**
     * Asks the user for a "weight quantity" (in particular, the weight itself, but it could also be a capacity or something else).
     * This function performs no range check on the integer value provided by the user, it just checks the value is between -INF_VALUE and +INF_VALUE (included).
     * The user can also insert string representations of infinite quantities.
     * @param message The dialog prompt.
     * @param title The dialog title
     * @param defaultValue The default value
     * @return The provided integer value, or null if the user cancelled the dialog.
     */
    public static Integer askForWeightQuantity(String message, String title, int defaultValue) {
        String weightString = MessageProvider.getInstance().askForString(message, title, edgeQuantityToString(defaultValue));

        if (weightString == null) {
            return null;
        }

        int newWeight;

        while (true) {
            try {
                newWeight = parseWeightString(weightString);
                break;
            } catch (NumberFormatException ex) {
                MessageProvider.getInstance().showWarningBox("You must input a number!");
            }
        }

        return newWeight;
    }

    @Override
    public boolean edit(GraphCanvas canvas) throws GraphException {
        Integer newWeight = askForWeightQuantity("Edge weight:", "Edit edge weight...", weight);

        if (newWeight == null) {
            return false;
        }


        setWeight(newWeight);
        return true;
    }

    /**
     *
     * @return The edge weight
     */
    public int getWeight() {
        return weight;
    }

    /**
     * Sets the edge weight.
     * @param weight The new weight. In the default implementation, every value is accepted.
     * @throws graphsj.model.graphkeeper.edges.InvalidWeightException Thrown if the weight value is invalid for this instance.
     */
    public void setWeight(int weight) throws InvalidWeightException {
        if (weight < -INF_WEIGHT || weight > INF_WEIGHT) {
            throw new InvalidWeightException("Weight out of bounds");
        }

        this.weight = weight;
    }

    /**
     *
     * @return The edge weight, converted to a meaningful string. Infinite weights are shown as "inf" or "-inf".
     */
    @Override
    public String toString() {
        return edgeQuantityToString(weight);
    }

    /**
     * Formats in a nice way the specified weight quantity.
     * @param quantity The quantity to format.
     * @return <ul>
     * <li>"inf" if quantity == INF_WEIGHT</li>
     * <li>"-inf" if quantity == -INF_WEIGHT</li>
     * <li>The string representation of the quantity otherwise</li>
     * </ul>
     */
    public static String edgeQuantityToString(int quantity) {
        if (quantity == INF_WEIGHT) {
            return "inf";
        } else if (quantity == -INF_WEIGHT) {
            return "-inf";
        } else {
            return "" + quantity;
        }
    }

    /**
     * Sums 2 weights, avoiding overflow over INF_WEIGHT and -INF_WEIGHT, as well as the sum of opposite infinites.
     * @param weight1 The first quantity
     * @param weight2 The second quantity
     * @return The sum of the 2 quantities, in the valid weight range.
     */
    public static int sumWeights(int weight1, int weight2) {
        if (weight1 == INF_WEIGHT) {
            if (weight2 == -INF_WEIGHT) {
                throw new IllegalArgumentException("Cannot sum opposite infinite weights");
            } else {
                return INF_WEIGHT;
            }
        }

        if (weight2 == INF_WEIGHT) {
            if (weight1 == -INF_WEIGHT) {
                throw new IllegalArgumentException("Cannot sum opposite infinite weights");
            } else {
                return INF_WEIGHT;
            }
        }


        if (weight1 == -INF_WEIGHT) {
            if (weight2 == INF_WEIGHT) {
                throw new IllegalArgumentException("Cannot sum opposite infinite weights");
            } else {
                return -INF_WEIGHT;
            }
        }


        if (weight2 == -INF_WEIGHT) {
            if (weight1 == INF_WEIGHT) {
                throw new IllegalArgumentException("Cannot sum opposite infinite weights");
            } else {
                return -INF_WEIGHT;
            }
        }


        return weight1 + weight2;
    }
}
