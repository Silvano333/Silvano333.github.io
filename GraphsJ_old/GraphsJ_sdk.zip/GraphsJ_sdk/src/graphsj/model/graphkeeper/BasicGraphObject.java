/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.gui.components.GraphCanvas;
import graphsj.model.graphkeeper.exceptions.GraphException;
import java.io.Serializable;

/**
 * The generic graph element. It can be assigned to a GraphKeeper.
 * @author Gianluca Costa
 */
public abstract class BasicGraphObject implements Serializable {

    //The parent keeper MUST be transient. The GraphKeeper itself will save its objects and will reattach them when deserializing.
    private transient GraphKeeper<? extends BasicVertex, ? extends BasicEdge> parentKeeper;

    /**
     *
     * @param <V> The vertex class
     * @param <E> The edge class
     * @return The parent keeper.
     */
    protected <V extends BasicVertex, E extends BasicEdge> GraphKeeper<V, E> getParentKeeper() {
        return (GraphKeeper<V, E>) parentKeeper;
    }

    /**
     * Assigns the parent keeper. If the object is already assigned to a keeper, you have to detach it before assigning it to a different keeper.
     * @param parentKeeper The new parent keeper     
     */
    protected void setParentKeeper(GraphKeeper<? extends BasicVertex, ? extends BasicEdge> parentKeeper) {
        if (parentKeeper != null && this.parentKeeper != null) {
            throw new IllegalStateException("You have to detach the object from its keeper before assigning it to another keeper");
        }
        this.parentKeeper = parentKeeper;
    }

    /**
     * Clones the object.
     * @return The clone of the object, detached from any keeper
     */
    @Override
    protected Object clone() {
        try {
            BasicGraphObject result = (BasicGraphObject) super.clone();
            result.parentKeeper = null;
            return result;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * This method interactively asks the user to edit the object properties.
     * @param canvas The GraphCanvas object used to draw the current object
     * @return True if the GraphCanvas used to show the object should be refreshed.
     * @throws graphsj.model.graphkeeper.exceptions.GraphException
     */
    public abstract boolean edit(GraphCanvas canvas) throws GraphException;

    /**
     * Detaches the object from the current keeper.
     */
    public abstract void detach();

    /**
     * Throws an exception if the parent keeper is null
     */
    protected void verifyParentKeeperNotNull() {
        if (parentKeeper == null) {
            throw new IllegalStateException("The graph object's parent keeper must not be null");
        }
    }
}
