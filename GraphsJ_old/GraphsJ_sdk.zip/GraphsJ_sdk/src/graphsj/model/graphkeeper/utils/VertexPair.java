/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.utils;

import graphsj.model.graphkeeper.BasicVertex;
import java.io.Serializable;

/**
 * An ordered pair of vertexes.
 *
 * @author Gianluca Costa
 */
public class VertexPair implements Serializable {

    private final BasicVertex source;
    private final BasicVertex target;

    /**
     * Creates the vertex pair.
     * @param source The source vertex.
     * @param target The target vertex.
     */
    public VertexPair(BasicVertex source, BasicVertex target) {
        this.source = source;
        this.target = target;
    }

    /**
     *
     * @return The source vertex.
     */
    public BasicVertex getSource() {
        return source;
    }

    /**
     *
     * @return The target vertex.
     */
    public BasicVertex getTarget() {
        return target;
    }
}
