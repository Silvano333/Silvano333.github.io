/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.spp;

import graphsj.gui.utils.VertexChooser;
import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.standard.StandardAlgorithm;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.exceptions.EmptyGraphException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Dijkstra's SPP algorithm.
 * @author Gianluca Costa
 */
public class Spp extends StandardAlgorithm<SppVertex, SppEdge> {

    private transient Set<SppVertex> vSet;
    private transient List<SppVertex> pathVertexes;
    private transient List<SppEdge> pathEdges;
    private transient SppVertex vBar;

    @Override
    protected Iterable<SppEdge> getSolutionEdges() {
        return pathEdges;
    }

    @Override
    public String getAlgorithmName() {
        return "Dijkstra's Shortest Path Problem (SPP)";
    }

    @Override
    public GraphKeeper createGraphKeeper() {
        return new SppKeeper();
    }

    @Override
    public void initializeRun(SafeAdapter<SppVertex, SppEdge> adapter, GraphKeeper<SppVertex, SppEdge> graphKeeper, AlgorithmOutput<SppVertex, SppEdge> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(adapter, graphKeeper, output, verboseRun);

        vSet = graphKeeper.vertexSetCopy();
        pathVertexes = new ArrayList<SppVertex>();


        SppVertex startVertex;
        try {
            startVertex = new VertexChooser<SppVertex>(graphKeeper).askForVertex("Choose start vertex:", getAlgorithmName());
            if (startVertex == null) {
                throw new AlgorithmInterruptedException();
            }
        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException(ex);
        }

        pathVertexes.add(startVertex);
        vSet.remove(startVertex);

        pathEdges = new ArrayList<SppEdge>();


        //I initialize the vertex labels
        startVertex.setPreviousVertex(null);
        startVertex.setPathLength(0);


        for (SppVertex vertex : vSet) {
            vertex.setPreviousVertex(startVertex);
            vertex.setPathLength(graphKeeper.getDistanceBetween(startVertex, vertex));
        }

        if (verboseRun) {
            output.printHeader("Legend");
            output.printLine();
            output.printLine("Vbar", "Vertex added to the shortest path in the current step");
            output.printLine();
            output.printHeader("Before step 1");
            output.printLine();
            output.printLine("Path vertexes", SppVertex.collectionToSortedNameString(pathVertexes));
            output.printLine("Path edges", SppEdge.collectionToVertexString(pathEdges));
            output.printLine();
        }
    }

    @Override
    protected void runStep(SafeAdapter<SppVertex, SppEdge> adapter, GraphKeeper<SppVertex, SppEdge> graphKeeper, AlgorithmOutput<SppVertex, SppEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        if (verboseRun) {
            output.printHeader("Step " + currentStep);
        }


        //I update the vertex labels starting from step 2, since the vBar vertex is not available at step 1
        if (currentStep > 1) {

            for (SppVertex vertex : vSet) {
                int vertexPathLenFromStart = SppEdge.sumWeights(vBar.getPathLength(), graphKeeper.getDistanceBetween(vBar, vertex));

                if (vertexPathLenFromStart < vertex.getPathLength()) {
                    vertex.setPathLength(vertexPathLenFromStart);
                    vertex.setPreviousVertex(vBar);
                }
            }
        }


        int minPathLength = SppEdge.INF_WEIGHT;

        //I find out the "vBar" vertex
        for (SppVertex vertex : vSet) {
            if (vertex.getPathLength() < minPathLength) {
                vBar = vertex;
                minPathLength = vertex.getPathLength();
            }
        }

        if (vBar == null) {
            throw new AlgorithmRunException("Cannot determine Vbar. Algorithm Error");
        }

        //I update the sets
        pathVertexes.add(vBar);
        vSet.remove(vBar);

        pathEdges.add(graphKeeper.getEdge(vBar.getPreviousVertex(), vBar));


        if (verboseRun) {
            output.printLine();
            output.printLine("At the end of the step:");
            output.printLine();
            output.printLine("Vbar", vBar);
            output.printLine("Path vertexes", SppVertex.collectionToSortedNameString(pathVertexes));
            output.printLine("Path edges", SppEdge.collectionToVertexString(pathEdges));
            output.printLine();
        }

        if (vSet.isEmpty()) {
            throw new AlgorithmEndedException();
        }


        super.runStep(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    protected void onInterruptedRun(SafeAdapter<SppVertex, SppEdge> adapter, GraphKeeper<SppVertex, SppEdge> graphKeeper, AlgorithmOutput<SppVertex, SppEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    protected void onEndRun(SafeAdapter<SppVertex, SppEdge> adapter, GraphKeeper<SppVertex, SppEdge> graphKeeper, AlgorithmOutput<SppVertex, SppEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        output.printLine("The edges used by the shortest paths are: " + SppEdge.collectionToVertexString(pathEdges));
        super.onEndRun(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    public String getAlgorithmHelp() {
        return "<vertex name> [<previous vertex>, <total length of the shortest path to reach this vertex> ]";
    }

    @Override
    protected Iterable<SppEdge> getStepSolutionEdges(int currentStep) {
        return pathEdges;
    }
}
