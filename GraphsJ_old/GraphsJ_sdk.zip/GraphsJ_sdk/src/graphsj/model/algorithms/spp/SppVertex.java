/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.spp;

import graphsj.model.algorithms.standard.StandardVertex;
import graphsj.model.graphkeeper.exceptions.DuplicateObjectException;

/**
 * The vertex class used by SPP.
 * @author Gianluca Costa
 */
public class SppVertex extends StandardVertex {

    private transient SppVertex previousVertex;
    private transient int pathLength;

    public SppVertex(String name) throws DuplicateObjectException {
        super(name);
    }

    protected int getPathLength() {
        return pathLength;
    }

    protected void setPathLength(int pathLength) {
        this.pathLength = pathLength;
    }

    protected SppVertex getPreviousVertex() {
        return previousVertex;
    }

    protected void setPreviousVertex(SppVertex previousVertex) {
        this.previousVertex = previousVertex;
    }

    @Override
    protected String getRunningLabel() {
        String previousString = "(null)";

        if (previousVertex != null) {
            previousString = previousVertex.getName();
        }

        return String.format("%s [%s, %s]", getName(), previousString, SppEdge.edgeQuantityToString(pathLength));

    }
}
