/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms;

import graphsj.model.graphkeeper.BasicEdge;
import graphsj.model.graphkeeper.BasicVertex;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * The execution of an algorithm is not managed by the algorithm itself, but by this class,
 * which keeps track of the state of the algorithm execution and allows you to control it.
 * Remember that step numbers start from 1, but a special value of 0 is assigned to the currentStep during the
 * initialization of the algorithm execution, i.e. while the initializeRun() and postInitializeRun() methods of the
 * algorithm are being called).
 *
 * @param V The vertex class
 * @param E The edge class
 *
 * @author Gianluca Costa
 */
public class RunController<V extends BasicVertex, E extends BasicEdge> {

    private final Algorithm<V, E> algorithm;
    private RunStateEnum runState = RunStateEnum.NOT_RUNNING;
    private AlgorithmOutput<V, E> output;
    private boolean verboseRun;
    private int currentStep;
    private int completedStep;
    private final List<ActionListener> runStateChangedListeners = new ArrayList<ActionListener>();
    private final List<ActionListener> stepCompletedListeners = new ArrayList<ActionListener>();

    /**
     * Creates the controller.
     * @param algorithm The algorithm associated with the controller.
     */
    protected RunController(Algorithm<V, E> algorithm) {
        this.algorithm = algorithm;
    }

    /**
     *
     * @return The AlgorithmOutput object used during the algorithm execution.
     */
    public AlgorithmOutput<V, E> getOutput() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }
        return output;
    }

    /**
     *
     * @return The output adapter used during the algorithm execution.
     */
    public SafeAdapter<V, E> getOutputAdapter() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }
        return output.getOutputAdapter();
    }

    /**
     *
     * @return The graph keeper used during the algorithm execution.
     */
    public GraphKeeper<V, E> getOutputKeeper() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }
        return output.getOutputAdapter().getGraphKeeper();
    }

    /**
     *
     * @return True if the algorithm must run or is running in verbose mode.
     */
    public boolean isVerboseRun() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }

        return verboseRun;
    }

    /**
     *
     * @return The step currently executing. Step numbers are from 1.
     */
    public int getCurrentStep() {
        if (!isRunning()) {
            throw new IllegalStateException("Cannot get the current step if the algorithm is not running");
        }
        return currentStep;
    }

    /**
     *
     * @return The step just completed. Step numbers are from 1.
     */
    public int getCompletedStep() {
        if (!isRunning()) {
            throw new IllegalStateException("Cannot get the completed step if the algorithm is not running");
        }
        return completedStep;
    }

    /**
     * Initializes both the algorithm and the controller when starting an algorithm execution.
     * @param output The algorithm output.
     * @param verboseRun True if the algorithm execution must provide verbose details.
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     * @throws graphsj.model.algorithms.AlgorithmInterruptedException Thrown by the algorithm if the algorithm execution was interrupted by the user.
     * @throws graphsj.model.algorithms.AlgorithmEndedException Thrown by the algorithm if it reached a solution and its execution consequently ended.
     */
    private void prepareForRun(AlgorithmOutput<V, E> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        this.output = output;
        this.verboseRun = verboseRun;

        currentStep = 0;
        completedStep = -1;
        SafeAdapter<V, E> outputAdapter = output.getOutputAdapter();
        algorithm.initializeRun(outputAdapter, outputAdapter.getGraphKeeper(), output, verboseRun);
        algorithm.postInitializeRun(outputAdapter, outputAdapter.getGraphKeeper(), output, verboseRun);
        outputAdapter.cellsChanged();
        completedStep = 0;
    }

    /**
     * Runs the algorithm in full mode - with no user interaction needed to perform the algorithm steps.
     * You must not call this method when the controller is already running the algorithm.
     * @param output The output on which the algorithm should operate.
     * @param verboseRun True if the algorithm execution must provide verbose details.
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     */
    public void fullRun(AlgorithmOutput<V, E> output, boolean verboseRun) throws AlgorithmRunException {
        if (runState != RunStateEnum.NOT_RUNNING) {
            throw new RuntimeException("Cannot perform a full run on a controller which is already running");
        }


        setRunState(RunStateEnum.FULL_RUNNING);

        try {
            prepareForRun(output, verboseRun);
        } catch (AlgorithmRunException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
            throw ex;
        } catch (AlgorithmInterruptedException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
            return;
        } catch (AlgorithmEndedException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
            return;
        }



        while (runState == RunStateEnum.FULL_RUNNING) {
            nextStep();
        }
    }

    /**
     * Begins a step-by-step execution of the algorithm.
     * You must not call this method when the controller is already running the algorithm.
     * @param output The output on which the algorithm should operate.
     * @param verboseRun True if the algorithm execution must provide verbose details.
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     */
    public void enterStepByStepRun(AlgorithmOutput<V, E> output, boolean verboseRun) throws AlgorithmRunException {
        if (runState != RunStateEnum.NOT_RUNNING) {
            throw new RuntimeException("Cannot perform a step-by-step run on a controller which is already running");
        }


        setRunState(RunStateEnum.STEP_RUNNING);

        try {
            prepareForRun(output, verboseRun);
        } catch (AlgorithmRunException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
            throw ex;
        } catch (AlgorithmInterruptedException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
            return;
        } catch (AlgorithmEndedException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
            return;
        }


    }

    /**
     * Increases the completed step number and fires the "step completed" event.
     */
    private void increaseCompletedStepAndNotify() {
        completedStep++;

        ActionEvent event = new ActionEvent(this, 0, null);

        for (ActionListener listener : stepCompletedListeners) {
            listener.actionPerformed(event);
        }
    }

    /**
     * Executes the next step of an algorithm execution when it is already in full run or in step-by-step run.
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     */
    public void nextStep() throws AlgorithmRunException {
        if (runState != RunStateEnum.FULL_RUNNING && runState != RunStateEnum.STEP_RUNNING) {
            throw new RuntimeException("Cannot perform a step if the controller is not running");
        }

        SafeAdapter<V, E> outputAdapter = output.getOutputAdapter();

        try {
            currentStep++;
            algorithm.runStep(outputAdapter, outputAdapter.getGraphKeeper(), output, verboseRun, currentStep);
            increaseCompletedStepAndNotify();
        } catch (AlgorithmRunException ex) {
            setRunState(RunStateEnum.NOT_RUNNING);
            throw ex;
        } catch (AlgorithmInterruptedException ex) {
            algorithm.onInterruptedRun(outputAdapter, outputAdapter.getGraphKeeper(), output, verboseRun, currentStep);
            setRunState(RunStateEnum.NOT_RUNNING);
        } catch (AlgorithmEndedException ex) {
            algorithm.onEndRun(outputAdapter, outputAdapter.getGraphKeeper(), output, verboseRun, currentStep);

            increaseCompletedStepAndNotify();
            setRunState(RunStateEnum.ENDED_RUNNING);
        }

        outputAdapter.cellsChanged();
    }

    /**
     * Stops the execution of an algorithm.
     * If used when the algorithm is executing (in a step-by-step run, for example), it calls the onInterruptedRun() method of the algorithm.
     * Otherwise, if the running state is ENDED_RUNNING, the execution just stops and is not considered interrupted.
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     */
    public void stopRun() throws AlgorithmRunException {
        if (runState == RunStateEnum.NOT_RUNNING) {
            throw new RuntimeException("Cannot stop running, since the RunController is not running");
        }

        SafeAdapter<V, E> outputAdapter = output.getOutputAdapter();
        try {
            if (runState != RunStateEnum.ENDED_RUNNING) {
                algorithm.onInterruptedRun(outputAdapter, outputAdapter.getGraphKeeper(), output, verboseRun, currentStep);
            }
        } finally {
            setRunState(RunStateEnum.NOT_RUNNING);
        }
    }

    /**
     * Stops the algorithm if running (just like a call to stop()), does nothing if not running.
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     */
    public void safeStop() throws AlgorithmRunException {
        switch (runState) {
            case FULL_RUNNING:
            case STEP_RUNNING:
            case ENDED_RUNNING:
                stopRun();
                break;
        }

    }

    /**
     * Adds a listener called when the run state changed.
     * @param listener The listener
     */
    public void addRunStateChangedListener(ActionListener listener) {
        runStateChangedListeners.add(listener);
    }

    /**
     * Removes a listener called when the run state changed.
     * @param listener The listener
     */
    public void removeRunStateChangedListener(ActionListener listener) {
        runStateChangedListeners.remove(listener);
    }

    /**
     * Adds a listener called when a step was just completed.
     * The last step of the algorithm (the one raising AlgorithmEndedException) fires this event, too.
     * @param listener The listener
     */
    public void addStepCompletedListener(ActionListener listener) {
        stepCompletedListeners.add(listener);
    }

    /**
     * Removes a listener called when a step was just completed.
     * @param listener The listener
     */
    public void removeStepCompletedListener(ActionListener listener) {
        stepCompletedListeners.remove(listener);
    }

    /**
     * @return The state of the algorithm execution.
     */
    public RunStateEnum getRunState() {
        return runState;
    }

    /**
     * Sets the state of the algorithm execution.
     * @param runState The new state
     */
    private void setRunState(RunStateEnum runState) {
        boolean runStateChanged = (runState != this.runState);

        this.runState = runState;

        if (runStateChanged) {
            ActionEvent event = new ActionEvent(this, 0, null);

            for (ActionListener listener : runStateChangedListeners) {
                listener.actionPerformed(event);
            }
        }
    }

    /**
     *
     * @return True if the algorithm is running. This means that it can be in full run mode, in step-by-step mode,
     * and in "ended" mode (in which it is waiting for the user to read the solution and stop the execution).
     */
    public boolean isRunning() {
        return runState != RunStateEnum.NOT_RUNNING;
    }

    /**
     *
     * @return The textual description of the execution step just completed, or null if there are no descriptions.
     */
    public String getCompletedStepDescription() {
        if (!isRunning()) {
            throw new IllegalStateException("The algorithm is not running!");
        }

        return algorithm.getCompletedStepDescription(getCompletedStep());
    }
}