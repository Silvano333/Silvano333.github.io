/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.fordfulkerson;

import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.startstop.StartStopAlgorithm;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.edges.InvalidWeightException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Ford-Fulkerson's flow algorithm.
 * @author Gianluca Costa
 */
public class FordFulkerson extends StartStopAlgorithm<FordFulkersonVertex, FordFulkersonEdge> {

    private transient FordFulkersonVertex startVertex;
    private transient FordFulkersonVertex stopVertex;
    private transient List<FordFulkersonEdge> incChain;

    @Override
    public void initializeRun(SafeAdapter<FordFulkersonVertex, FordFulkersonEdge> adapter, GraphKeeper<FordFulkersonVertex, FordFulkersonEdge> graphKeeper, AlgorithmOutput<FordFulkersonVertex, FordFulkersonEdge> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(adapter, graphKeeper, output, verboseRun);
        startVertex = getStartVertex();
        stopVertex = getStopVertex();
        incChain = null;
    }

    @Override
    protected Iterable<FordFulkersonEdge> getStepSolutionEdges(int currentStep) {
        return incChain;
    }

    @Override
    protected Iterable<FordFulkersonEdge> getSolutionEdges() {
        return incChain;
    }

    @Override
    protected void runStep(SafeAdapter<FordFulkersonVertex, FordFulkersonEdge> adapter, GraphKeeper<FordFulkersonVertex, FordFulkersonEdge> graphKeeper, AlgorithmOutput<FordFulkersonVertex, FordFulkersonEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        if (verboseRun) {
            output.printLine();
            output.printHeader("Step " + currentStep);
            output.printLine();
        }


        int currentStepInSeries = currentStep % 3;

        if (currentStepInSeries == 1) {


            incChain = null;

            for (FordFulkersonVertex vertex : graphKeeper.vertexSet()) {
                vertex.setLabeled(false);
                vertex.setExplored(false);
            }

            startVertex.setLabeled(true);
            startVertex.setPlusVk(true);
            startVertex.setVk(null);
            startVertex.setDelta(FordFulkersonEdge.INF_WEIGHT);
            startVertex.setExplored(false);



            //The internal iterations begin here
            for (int intraIndex = 1; intraIndex <= graphKeeper.vertexSet().size(); intraIndex++) {

                FordFulkersonVertex vi = null;

                //Here, I get the first vertex available, and set it as "Vi"
                for (FordFulkersonVertex vertex : graphKeeper.orderedVertexList()) {

                    if (vertex.isLabeled() && !vertex.isExplored()) {
                        vi = vertex;
                        break;
                    }
                }

                if (vi == null) {
                    break;
                }


                vi.setExplored(true);


                //Here, I set the label for the vertexes belonging to the "gamma+" of Vi
                for (FordFulkersonVertex vj : vi.<FordFulkersonVertex>getOutgoingVertexes()) {

                    if (vj.isLabeled()) {
                        continue;
                    }

                    FordFulkersonEdge edgeIJ = graphKeeper.getEdge(vi, vj);

                    if (edgeIJ.getWeight() < edgeIJ.getCapacity()) {
                        vj.setLabeled(true);
                        vj.setPlusVk(true);
                        vj.setVk(vi);
                        vj.setDelta(Math.min(vi.getDelta(), FordFulkersonEdge.sumWeights(edgeIJ.getCapacity(), -edgeIJ.getWeight())));
                    }
                }

                //Here, I set the label for the vertexes belonging to the "gamma-" of Vi
                for (FordFulkersonVertex vj : vi.<FordFulkersonVertex>getIncomingVertexes()) {
                    if (vj.isLabeled()) {
                        continue;
                    }

                    FordFulkersonEdge linkJI = graphKeeper.getEdge(vj, vi);
                    if (linkJI.getWeight() > 0) {
                        vj.setLabeled(true);
                        vj.setPlusVk(false);
                        vj.setVk(vi);
                        vj.setDelta(Math.min(vi.getDelta(), linkJI.getWeight()));
                    }
                }



                if (stopVertex.isLabeled()) {
                    break;
                }

            }


            //The internal iteration has just ended: I can show the resulting edge weights now, as well as the labels
            if (verboseRun) {
                output.printLine("Edges at the end of the step: ");

                for (FordFulkersonEdge edge : graphKeeper.edgeSet()) {
                    output.printLine(String.format("%s -- %s", edge.toVertexString(), edge.toString()));
                }

                output.printLine();
                output.printLine();
            }


            if (!stopVertex.isLabeled()) {
                throw new AlgorithmEndedException();
            }

        } else if (currentStepInSeries == 2) {
            //Now I set up the increasing chain
            incChain = new ArrayList<FordFulkersonEdge>();

            FordFulkersonVertex x = stopVertex;
            FordFulkersonVertex y;

            //I update link flows now, by using the "delta*"
            while (x != startVertex) {
                y = x.getVk();
                FordFulkersonEdge augEdge = null;


                if (x.isPlusVk()) {
                    augEdge = graphKeeper.getEdge(y, x);
                } else {
                    augEdge = graphKeeper.getEdge(x, y);
                }


                x = y;
                incChain.add(augEdge);
            }

            if (verboseRun) {
                Collections.reverse(incChain);
                output.printLine("Increasing chain", incChain);
                output.printLine();
            }
        } else { //The last step in a step sequence

            //Here, I get the "delta*" variable for this iteration
            int deltaStar = stopVertex.getDelta();

            FordFulkersonVertex x = stopVertex;
            FordFulkersonVertex y;


            if (verboseRun) {
                output.printLine("Delta*", deltaStar);
            }

            //I update link flows now, by using the "delta*"
            while (x != startVertex) {
                y = x.getVk();
                FordFulkersonEdge augEdge = null;

                try {
                    if (x.isPlusVk()) {
                        augEdge = graphKeeper.getEdge(y, x);
                        augEdge.setWeight(FordFulkersonEdge.sumWeights(augEdge.getWeight(), deltaStar));
                    } else {
                        augEdge = graphKeeper.getEdge(x, y);
                        augEdge.setWeight(FordFulkersonEdge.sumWeights(augEdge.getWeight(), -deltaStar));
                    }
                } catch (InvalidWeightException ex) {
                    throw new AlgorithmRunException(ex);
                }

                x = y;
            }

        }

        super.runStep(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    protected void onEndRun(SafeAdapter<FordFulkersonVertex, FordFulkersonEdge> adapter, GraphKeeper<FordFulkersonVertex, FordFulkersonEdge> graphKeeper, AlgorithmOutput<FordFulkersonVertex, FordFulkersonEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //I can get the resulting sets of vertexes
        List<FordFulkersonVertex> V1 = new ArrayList<FordFulkersonVertex>();
        List<FordFulkersonVertex> V2 = new ArrayList<FordFulkersonVertex>();


        for (FordFulkersonVertex vertex : graphKeeper.orderedVertexList()) {
            if (vertex.isLabeled()) {
                V1.add(vertex);
            } else {
                V2.add(vertex);
            }
        }



        //Now, I also get the maximum flow value
        int maxFlow = 0;

        incChain = new ArrayList<FordFulkersonEdge>();
        for (FordFulkersonEdge edge : graphKeeper.edgeSet()) {

            if (V1.contains(edge.getSource()) && V2.contains(edge.getTarget())) {
                maxFlow = FordFulkersonEdge.sumWeights(maxFlow, edge.getCapacity());
                incChain.add(edge);
            }
        }

        //I print out the results
        output.printLine("V1", V1);
        output.printLine("V2", V2);

        output.printLine();

        output.printLine(String.format("Maximum flow from '%s' to '%s'", startVertex.getName(), stopVertex.getName()), maxFlow);

        output.printLine("\nThe highlighted edges show the min cut.");

        super.onEndRun(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    public String getAlgorithmName() {
        return "Ford-Fulkerson's flow algorithm";
    }

    @Override
    public GraphKeeper createGraphKeeper() {
        return new FordFulkersonKeeper();
    }

    @Override
    protected void onInterruptedRun(SafeAdapter<FordFulkersonVertex, FordFulkersonEdge> adapter, GraphKeeper<FordFulkersonVertex, FordFulkersonEdge> graphKeeper, AlgorithmOutput<FordFulkersonVertex, FordFulkersonEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    public String getAlgorithmHelp() {
        return "FOR VERTEXES:\n" +
                "<vertex name>\n" +
                "--OR--\n" +
                "<vertex name> [<+|-> <vk>, <delta>, <'@' if the vertex has been explored in the current iteration step>]\n" +
                "\n" +
                "FOR EDGES:\n" +
                "(<edge flow>, <edge capacity>)";

    }
}
