/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.prim;

import graphsj.gui.utils.VertexChooser;
import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.standard.StandardAlgorithm;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.exceptions.EmptyGraphException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

/**
 * Prim's SST algorithm.
 * 
 * @author Gianluca Costa.
 */
public class PrimSST extends StandardAlgorithm<PrimVertex, PrimEdge> {

    private transient Collection<PrimVertex> vSet;
    private transient Collection<PrimVertex> wSet;
    private transient List<PrimEdge> treeEdges;
    private transient PrimVertex vBar;

    @Override
    public void initializeRun(SafeAdapter<PrimVertex, PrimEdge> adapter, GraphKeeper<PrimVertex, PrimEdge> graphKeeper, AlgorithmOutput<PrimVertex, PrimEdge> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(adapter, graphKeeper, output, verboseRun);

        vSet = graphKeeper.vertexSetCopy();


        wSet = new HashSet<PrimVertex>();
        PrimVertex v1;
        try {
            v1 = new VertexChooser<PrimVertex>(graphKeeper).askForVertex("Choose the initial vertex:", this.toString());
            if (v1 == null) {
                throw new AlgorithmInterruptedException();
            }
        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException(ex);
        }
        v1.setBestVertex(v1);
        v1.setWeightFromBestVertex(0);
        wSet.add(v1);
        vSet.remove(v1);

        treeEdges = new ArrayList<PrimEdge>();

        for (PrimVertex vertex : vSet) {
            vertex.setBestVertex(v1);
            vertex.setWeightFromBestVertex(graphKeeper.getDistanceBetween(v1, vertex));
        }


        if (verboseRun) {
            output.printHeader("Legend");
            output.printLine();
            output.printLine("V", "The graph vertexes");
            output.printLine("W", "Vertexes belonging to the tree in the current step");
            output.printLine("E", "Edges belonging to the tree in the current step");
            output.printLine("Vbar", "Vertex added to the tree in the current step");
            output.printLine();

            output.printHeader("Before step 1");

            output.printLine("W", PrimVertex.collectionToSortedNameString(wSet));
            output.printLine("V\\W", PrimVertex.collectionToSortedNameString(vSet));
            output.printLine("E", PrimEdge.collectionToVertexString(treeEdges));
        }
    }

    @Override
    protected void runStep(SafeAdapter<PrimVertex, PrimEdge> adapter, GraphKeeper<PrimVertex, PrimEdge> graphKeeper, AlgorithmOutput<PrimVertex, PrimEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        if (verboseRun) {
            output.printHeader("Step " + currentStep);
            output.printLine();
        }


        for (PrimVertex vertex : vSet) {
            int distanceFromVBar = graphKeeper.getDistanceBetween(vBar, vertex);

            if (distanceFromVBar < vertex.getWeightFromBestVertex()) {
                vertex.setBestVertex(vBar);
                vertex.setWeightFromBestVertex(distanceFromVBar);
            }
        }


        //Now, I determine the "vBar" vertex        
        int minBest = PrimEdge.INF_WEIGHT;
        vBar = null;

        for (PrimVertex vertex : vSet) {
            if (vertex.getWeightFromBestVertex() < minBest) {
                vBar = vertex;
                minBest = vertex.getWeightFromBestVertex();
            }
        }

        if (vBar == null) {
            throw new AlgorithmRunException("Could not determine vBar! Error in the algorithm!");
        }


        //I add vBar to the "W" set, and remove it from the "V" set
        wSet.add(vBar);
        vSet.remove(vBar);

        //I also add the corresponding link to E
        PrimEdge chosenEdge = graphKeeper.getEdge(vBar, vBar.getBestVertex());
        treeEdges.add(chosenEdge);

        if (verboseRun) {
            output.printLine("At the end of the step:");
            output.printLine();
            output.printLine("Vbar", vBar);
            output.printLine("W", PrimVertex.collectionToSortedNameString(wSet));
            output.printLine("V \\ W", PrimVertex.collectionToSortedNameString(vSet));
            output.printLine("E", PrimEdge.collectionToVertexString(treeEdges));
            output.printLine();
            output.printLine();
        }

        if (vSet.isEmpty()) {
            throw new AlgorithmEndedException();
        }

        super.runStep(adapter, graphKeeper, output, verboseRun, currentStep);

    }

    @Override
    protected void onEndRun(SafeAdapter<PrimVertex, PrimEdge> adapter, GraphKeeper<PrimVertex, PrimEdge> graphKeeper, AlgorithmOutput<PrimVertex, PrimEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Now, I find out the total weight of the spanning tree
        int totalWeight = 0;
        for (PrimEdge edge : treeEdges) {
            totalWeight += edge.getWeight();
        }


        output.printLine("The branches of the spanning tree are: " + PrimEdge.collectionToVertexString(treeEdges));
        output.printLine("The total weight of the spanning tree is: " + totalWeight);

        super.onEndRun(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    public String getAlgorithmName() {
        return "Prim's Short Spanning Tree (SST)";
    }

    @Override
    protected void onInterruptedRun(SafeAdapter<PrimVertex, PrimEdge> adapter, GraphKeeper<PrimVertex, PrimEdge> graphKeeper, AlgorithmOutput<PrimVertex, PrimEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    protected Iterable<PrimEdge> getSolutionEdges() {
        return treeEdges;
    }

    @Override
    public GraphKeeper createGraphKeeper() {
        return new PrimKeeper();
    }

    @Override
    public String getAlgorithmHelp() {
        return "IF VERBOSE IS ON:\n\n<vertex name> [<previous ('best') vertex>, <distance from previous vertex>]\n\nELSE:\n\n<vertex name> [<previous ('best') vertex>]";
    }

    @Override
    protected Iterable<PrimEdge> getStepSolutionEdges(int currentStep) {
        return treeEdges;
    }
}