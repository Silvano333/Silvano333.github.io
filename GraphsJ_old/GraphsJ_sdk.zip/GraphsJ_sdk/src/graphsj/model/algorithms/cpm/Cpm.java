/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.cpm;

import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.startstop.StartStopAlgorithm;
import graphsj.model.graphkeeper.BasicVertex;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * CPM algorithm.
 * @author Gianluca Costa
 */
public class Cpm extends StartStopAlgorithm<CpmVertex, CpmEdge> {

    private transient CpmVertex startVertex;
    private transient CpmVertex stopVertex;
    private transient int numVertexes;
    private transient List<CpmVertex> indexedVertexList;
    private transient List<CpmEdge> criticalActivities;

    @Override
    protected Iterable<CpmEdge> getStepSolutionEdges(int currentStep) {
        return null;
    }

    @Override
    protected Iterable<CpmEdge> getSolutionEdges() {
        return criticalActivities;
    }

    @Override
    public String getAlgorithmName() {
        return "Task management (CPM)";
    }

    @Override
    public GraphKeeper createGraphKeeper() {
        return new CpmKeeper();
    }

    @Override
    public void initializeRun(SafeAdapter<CpmVertex, CpmEdge> adapter, GraphKeeper<CpmVertex, CpmEdge> graphKeeper, AlgorithmOutput<CpmVertex, CpmEdge> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(adapter, graphKeeper, output, verboseRun);

        startVertex = getStartVertex();
        stopVertex = getStopVertex();

        List<CpmVertex> vList = graphKeeper.orderedVertexList();
        numVertexes = vList.size();
        indexedVertexList = new ArrayList<CpmVertex>();

        startVertex.setIndex(0);
        indexedVertexList.add(startVertex);
        vList.remove(startVertex);


        stopVertex.setIndex(numVertexes - 1);
        vList.remove(stopVertex);

        //Enumerating vertexes
        for (int counter = 1; counter <= numVertexes - 2; counter++) {
            CpmVertex indexedVertex = null;

            for (CpmVertex vertex : vList) {
                boolean vertexHasGammaMinus = false;

                for (BasicVertex gammaMinusVertex : vertex.getIncomingVertexes()) {
                    if (vList.contains(gammaMinusVertex)) {
                        vertexHasGammaMinus = true;
                        break;
                    }
                }

                if (!vertexHasGammaMinus) {
                    vertex.setIndex(counter);
                    indexedVertex = vertex;
                    indexedVertexList.add(vertex);
                    break;
                }
            }

            if (indexedVertex == null) {
                throw new RuntimeException("Could not index vertexes. Algorithm Error");
            }
            vList.remove(indexedVertex);
        }


        indexedVertexList.add(stopVertex);

    }

    @Override
    protected void runStep(SafeAdapter<CpmVertex, CpmEdge> adapter, GraphKeeper<CpmVertex, CpmEdge> graphKeeper, AlgorithmOutput<CpmVertex, CpmEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        if (verboseRun) {
            output.printHeader("Step " + currentStep);
        }


        if (currentStep == 1) {


            startVertex.setTmin(0);

            for (int k = 1; k <= numVertexes - 1; k++) {
                CpmVertex currentVertex = indexedVertexList.get(k);

                int tMin = 0;

                for (CpmEdge edge : currentVertex.<CpmEdge>getIncomingEdges()) {
                    int val = CpmEdge.sumWeights(edge.<CpmVertex>getSource().getTmin(), edge.getWeight());
                    if (val > tMin) {
                        tMin = val;
                    }
                }

                currentVertex.setTmin(tMin);
            }
        } else if (currentStep == 2) {
            stopVertex.setTmax(stopVertex.getTmin());

            for (int k = numVertexes - 2; k >= 0; k--) {
                CpmVertex currentVertex = indexedVertexList.get(k);
                int tMax = CpmEdge.INF_WEIGHT;

                for (CpmEdge edge : currentVertex.<CpmEdge>getOutgoingEdges()) {
                    int val = CpmEdge.sumWeights(edge.<CpmVertex>getTarget().getTmax(), -edge.getWeight());
                    if (val < tMax) {
                        tMax = val;
                    }
                }

                currentVertex.setTmax(tMax);
            }
        } else {
            throw new AlgorithmEndedException();
        }

        super.runStep(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    protected void onEndRun(SafeAdapter<CpmVertex, CpmEdge> adapter, GraphKeeper<CpmVertex, CpmEdge> graphKeeper, AlgorithmOutput<CpmVertex, CpmEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        criticalActivities = new ArrayList<CpmEdge>();

        for (CpmEdge edge : graphKeeper.edgeSet()) {
            if (edge.getActivityName().equals("")) {
                continue;
            }
            CpmVertex edgeSource = edge.getSource();
            CpmVertex edgeTarget = edge.getTarget();

            if (edgeSource.getTmin() == edgeSource.getTmax() && edgeTarget.getTmin() == edgeTarget.getTmax()) {
                criticalActivities.add(edge);
            }
        }

        Collections.sort(criticalActivities);


        output.printHeader("Activity Table");
        output.printLine(String.format("%30s\t%15s\t%15s\t%15s\t%15s", "Activity", "Length", "EST", "LST", "S"));
        for (CpmEdge edge : graphKeeper.orderedEdgeList()) {
            if (edge.getActivityName().equals("")) {
                continue;
            }
            int est = edge.<CpmVertex>getSource().getTmin();
            int lst = CpmEdge.sumWeights(edge.<CpmVertex>getTarget().getTmax(), -edge.getWeight());
            int s = CpmEdge.sumWeights(lst, -est);
            output.printLine(String.format("%30s\t%15d\t%15d\t%15d\t%15d", edge.getActivityName(), edge.getWeight(), est, lst, s));
        }
        output.printLine();
        output.printHeader("Critical activities");
        for (CpmEdge edge : criticalActivities) {
            output.printLine(edge.toString());
        }



        super.onEndRun(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    protected void onInterruptedRun(SafeAdapter<CpmVertex, CpmEdge> adapter, GraphKeeper<CpmVertex, CpmEdge> graphKeeper, AlgorithmOutput<CpmVertex, CpmEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    public String getAlgorithmHelp() {
        return "<vertex name> [<vertex index>, <minimum time>, <maximum time>]";
    }

    @Override
    protected String getCompletedStepDescription(int completedStepNumber) {
        switch (completedStepNumber) {
            case 1:
                return "Minimum times set";
            case 2:
                return "Maximum times set";
            case 3:
                return "Critical activities determined";
            default:
                return null;
        }
    }
}
