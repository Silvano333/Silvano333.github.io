/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.utils;

import graphsj.Application;
import graphsj.model.graphkeeper.edges.WeightQuantity;
import javax.swing.JOptionPane;

/**
 * This class provides useful functions to simplify the interaction with the users.
 *
 * @author Gianluca Costa
 */
public class MessageProvider {

    private static MessageProvider instance = new MessageProvider();

    protected MessageProvider() {
        //
    }

    /**
     *
     * @return The Singleton instance of the class
     */
    public static MessageProvider getInstance() {
        return instance;
    }

    /**
     * Formats the specified throwable in a custom way.
     * @param throwable The throwable to format.
     * @return The formatted string.
     */
    private String formatThrowable(Throwable throwable) {
        return String.format("%s (%s)", throwable.getClass().getSimpleName(), throwable.getLocalizedMessage());
    }

    /**
     * Shows an error dialog with the specified prompt.
     * @param message The dialog prompt
     */
    public void showErrorBox(String message) {
        JOptionPane.showMessageDialog(null, message, Application.TITLE, JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Shows an error box for the specified Throwable.
     * In particular, it recursively follows the chain of throwable causes, and shows just the one with a "null" cause,
     * which is shown as a formatted string.
     * @param throwable The throwable to format.
     */
    public void showErrorBox(Throwable throwable) {
        while (throwable.getCause() != null) {
            throwable = throwable.getCause();
        }

        showErrorBox(formatThrowable(throwable));
    }

    /**
     *  Shows an error box that reports the message prompt followed by the formatted version of the specified Throwable.
     * @param message The message prompt
     * @param throwable The trowable to format.
     */
    public void showErrorBox(String message, Throwable throwable) {
        while (throwable.getCause() != null) {
            throwable = throwable.getCause();
        }

        showErrorBox(message + "\n\nCause:\n" + formatThrowable(throwable));
    }

    /**
     * Shows a warning box with the specified prompt.
     * @param message The dialog prompt.
     */
    public void showWarningBox(String message) {
        JOptionPane.showMessageDialog(null, message, Application.TITLE, JOptionPane.WARNING_MESSAGE);
    }

    /**
     * Shows a warning box for the specified Throwable.
     * In particular, it recursively follows the chain of throwable causes, and shows just the one with a "null" cause.
     * In the case of this function, just the localized message of the throwable is shown, not its type,
     * in order to make the dialog user-friendly.
     * @param throwable The throwable to format.
     */
    public void showWarningBox(Throwable throwable) {
        while (throwable.getCause() != null) {
            throwable = throwable.getCause();
        }

        showWarningBox(throwable.getLocalizedMessage());
    }

    /**
     * Shows an information box with the specified prompt.
     * @param message The dialog prompt.
     */
    public void showInfoBox(String message) {
        JOptionPane.showMessageDialog(null, message, Application.TITLE, JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Shows an information box with the specified prompt and title.
     * @param message The dialog prompt.
     * @param title The dialog title.
     */
    public void showInfoBox(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Asks the user for a string.
     * @param message The dialog prompt.
     * @param title The dialog title
     * @param defaultValue The default value
     * @return The user string, or null if the dialog was cancelled.
     */
    public String askForString(String message, String title, String defaultValue) {
        return (String) JOptionPane.showInputDialog(null, message, title, JOptionPane.QUESTION_MESSAGE, null, null, defaultValue);
    }

    /**
     * Asks the user for a valid integer value, showing warning dialogs and asking again if errors occur.
     * @param message The dialog prompt.
     * @param title The dialog title.
     * @param defaultValue The default value. If null, the dialog will show no default value; otherwise, it must be between minValue and maxValue (included).
     * @param minValue The minimum acceptable value (included). If null, Integer.MIN_VALUE will be used.
     * @param maxValue The maximum acceptable value (included). If null, Integer.MAX_VALUE will be used.
     * @return The integer value provided by the user, or null if the dialog was cancelled.
     */
    public Integer askForNumber(String message, String title, Integer defaultValue, Integer minValue, Integer maxValue) {
        if (minValue == null) {
            minValue = Integer.MIN_VALUE;
        }

        if (maxValue == null) {
            maxValue = Integer.MAX_VALUE;
        }

        if (minValue > maxValue) {
            throw new IllegalArgumentException("It must be minValue <= maxValue");
        }

        if ((defaultValue != null) && (defaultValue < minValue || defaultValue > maxValue)) {
            throw new IllegalArgumentException("It must be minValue <= defaultValue <= maxValue");
        }

        while (true) {
            String inputString;

            if (defaultValue != null) {
                inputString = askForString(message, title, defaultValue.toString());
            } else {
                inputString = askForString(message, title, "");
            }

            if (inputString == null) {
                return null;
            }

            try {
                int inputInt = Integer.parseInt(inputString);

                if (inputInt < minValue || inputInt > maxValue) {
                    showWarningBox(String.format("The value you provide must be between %s and %s (included).", minValue, maxValue));
                    continue;
                }

                return inputInt;

            } catch (NumberFormatException ex) {
                //Show a message, then continue the cycle
                showWarningBox("You must input a number!");
            }
        }
    }

    /**
     * A handy shortcut to the function, which allows any integer value to be input by the user.
     * @param message The dialog prompt.
     * @param title The dialog title.
     * @param defaultValue The default value. If null, no default value will be shown in the dialog.
     * @return The input integer, or null if the user cancelled the dialog.
     */
    public Integer askForNumber(String message, String title, Integer defaultValue) {
        return askForNumber(message, title, defaultValue, null, null);
    }

    /**
     * Asks the user for a weight quantity, which could be a weight, a capacity or something else.     
     * The user can also insert string representations of infinite quantities.
     * @param message The dialog prompt.
     * @param title The dialog title.
     * @param defaultQuantity The default value. It must NOT be null.
     * @param minQuantity The minimum acceptable value (included). If null, WeightQuantity.MINUS_INF will be used.
     * @param maxQuantity The maximum acceptable value (included). If null, WeightQuantity.PLUS_INF will be used.
     * @return The provided weight quantity, or null if the user cancelled the dialog.
     */
    public WeightQuantity askForWeightQuantity(String message, String title, WeightQuantity defaultQuantity, WeightQuantity minQuantity, WeightQuantity maxQuantity) {
        if (defaultQuantity == null) {
            throw new IllegalArgumentException("defaultValue cannot be null");
        }

        if (minQuantity == null) {
            minQuantity = WeightQuantity.MINUS_INF;
        }

        if (maxQuantity == null) {
            maxQuantity = WeightQuantity.PLUS_INF;
        }
      

        while(true) {
            String weightString = askForString(message, title, defaultQuantity.toString());

            if (weightString == null) {
                return null;
            }


            try {
                WeightQuantity result = WeightQuantity.parseWeightString(weightString);

                if (result.getValue() < minQuantity.getValue() || result.getValue() > maxQuantity.getValue()) {
                    showWarningBox(String.format("You must insert a quantity in the range [%s; %s]", minQuantity, maxQuantity));
                    continue;
                }

                return result;
            } catch (NumberFormatException ex) {
                showWarningBox(String.format("You must insert a quantity in the range [%s; %s]", minQuantity, maxQuantity));
            }

        }        
    }
}
