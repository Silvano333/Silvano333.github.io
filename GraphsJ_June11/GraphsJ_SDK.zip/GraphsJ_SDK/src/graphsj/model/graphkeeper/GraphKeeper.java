/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.extension.GraphInputStream;
import graphsj.extension.GraphOutputStream;
import graphsj.model.graphkeeper.collections.edges.EdgeSet;
import graphsj.model.graphkeeper.collections.vertexes.VertexSet;
import graphsj.model.graphkeeper.exceptions.DuplicateVertexException;
import graphsj.model.graphkeeper.exceptions.DuplicateEdgeException;
import graphsj.model.graphkeeper.utils.VertexPair;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.jgrapht.graph.DefaultListenableGraph;

/**
 * This class wraps a JGraphT graph to grant many features and advanced type checking.
 * It is the only object used to represent a graph in this library.
 * 
 * @param <V> The vertex class
 * @param <E> The edge class
 * 
 * @author Gianluca Costa
 */
public abstract class GraphKeeper<V extends Vertex<V, E>, E extends Edge<V, E>> implements Externalizable {

    private DefaultListenableGraph<V, E> graph;

    /**
     * Creates the graph keeper.
     */
    public GraphKeeper() {
        this.graph = createGraph();
    }

    /**
     *
     * @return The edge class used by the keeper.
     */
    public abstract Class<E> getEdgeClass();

    /**
     *
     * @return The vertex class used by the keeper.
     */
    public abstract Class<V> getVertexClass();

    /**
     * This method must create the graph underlying the keeper.
     * @return The graph underlying the keeper.
     */
    public abstract DefaultListenableGraph<V, E> createGraph();

    /**     
     * @return A copy of the internal vertex set. The vertexes in the new set are the original ones, NOT cloned.
     */
    public VertexSet<V> vertexSet() {
        return new VertexSet<V>(graph.vertexSet());
    }

    /**
     * @return A copy of the internal edge set. The edges in the new set are the original ones, NOT cloned.
     */
    public EdgeSet<V, E> edgeSet() {
        return new EdgeSet<V, E>(graph.edgeSet());
    }

    /**
     *
     * @return The underlying graph
     */
    protected DefaultListenableGraph<V, E> getGraph() {
        return graph;
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {

        if (!(out instanceof GraphOutputStream)) {
            throw new IllegalArgumentException("GraphKeeper instances must be serialized via a GraphOutputStream");
        }

        VertexSet<V> vertexes = new VertexSet<V>(graph.vertexSet());
        out.writeObject(vertexes);


        Map<E, VertexPair<V>> edgeBoundsMap = new HashMap<E, VertexPair<V>>();

        for (E edge : graph.edgeSet()) {
            VertexPair<V> edgeBounds = edge.getBounds();
            edgeBoundsMap.put(edge, edgeBounds);
        }

        out.writeObject(edgeBoundsMap);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {

        if (!(in instanceof GraphInputStream)) {
            throw new IllegalArgumentException("GraphKeeper instances must be deserialized via a GraphInputStream");
        }

        graph = createGraph();
        
        VertexSet<V> vertexes = (VertexSet<V>) in.readObject();

        for (V vertex : vertexes) {
            try {
                vertex.attach(this);
            } catch (DuplicateVertexException ex) {
                throw new RuntimeException(ex);
            }
        }
        

        Map<E, VertexPair<V>> edgeBoundsMap = (Map<E, VertexPair<V>>) in.readObject();
        for (Entry<E, VertexPair<V>> entry : edgeBoundsMap.entrySet()) {
            E edge = entry.getKey();

            VertexPair<V> edgeBounds = entry.getValue();
            try {
                edge.attach(this, edgeBounds.getSource(), edgeBounds.getTarget());
            } catch (DuplicateEdgeException ex) {
                throw new RuntimeException(ex);
            }
        }

    }

    /**
     * Searches in the underlying graph for vertexes conflicting with the specified vertex.
     * By default, two vertexes are conflicting if they have the same name and do not refer to the same instance.
     * You can override this method as you wish, and call it whenever you have changed a vertex field which should be unique throughout the graph.
     * @param vertex The vertex which should be unique.
     * @return True if a vertex conflicting with the specified one was found.
     */
    public boolean hasConflictingVertex(V vertex) {
        for (V currentVertex : graph.vertexSet()) {
            if ((currentVertex != vertex) && currentVertex.getName().equals(vertex.getName())) {
                return true;
            }
        }

        return false;
    }

    /**
     * Searches in the underlying graph for edges conflicting with the specified edge.
     * By default, two edges never conflict with each other.
     * You can override this method as you wish, and call it whenever you have changed an edge field which should be unique throughout the graph.
     * @param edge The edge which should be unique.
     * @return True if an edge conflicting with the specified one was found.
     */
    public boolean hasConflictingEdge(E edge) {
        return false;
    }

    /**
     * Gets the edge between two vertexes.
     * @param sourceVertex The source vertex.
     * @param targetVertex The target vertex.
     * @return The edge between them, or null if no edge connects them. If the graph is undirected, the order of the vertexes is irrelevant.
     */
    public E getEdge(V sourceVertex, V targetVertex) {
        return graph.getEdge(sourceVertex, targetVertex);
    }    
}
