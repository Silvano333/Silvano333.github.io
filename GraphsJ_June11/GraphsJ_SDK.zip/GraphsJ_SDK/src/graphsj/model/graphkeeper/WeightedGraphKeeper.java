/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.model.graphkeeper.edges.WeightQuantity;
import graphsj.model.graphkeeper.edges.WeightedEdge;

/**
 * A graph keeper specialized in weighted edges.
 *
 * @param <V> The vertex class
 * @param <E> The edge class
 * 
 * @author Gianluca Costa
 */
public abstract class WeightedGraphKeeper<V extends Vertex<V, E>, E extends WeightedEdge<V, E>> extends GraphKeeper<V, E> {
    /**
     * Returns the distance between 2 vertexes.
     *
     * @param startVertex The start vertex.
     * @param stopVertex The target vertex.
     *
     * @return The weight of the edge between the 2 vertexes, or the "+infinite" quantity if there is no edge between them.
     */
    public WeightQuantity getDistanceBetween(V startVertex, V stopVertex) {
        E edge = getGraph().getEdge(startVertex, stopVertex);

        if (edge == null) {
            return WeightQuantity.PLUS_INF;
        } else {
            return edge.getWeight();
        }
    }
}
