/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.collections.edges;

import graphsj.model.graphkeeper.*;
import graphsj.model.graphkeeper.utils.VertexPair;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

/**
 * A set of edges.
 * 
 * @param <V> The vertex class
 * @param <E> The edge class
 * 
 * @author Gianluca Costa
 */
public class EdgeSet<V extends Vertex<V, E>, E extends Edge<V, E>> extends HashSet<E> {

    private static final long serialVersionUID = 1L;
    
    /**
     * Creates an empty edge set
     */
    public EdgeSet() {
        super();
    }

    /**
     * Create an edge set with the same edge instances contained in the collection argument.
     * @param edgeCollection The source collection.
     */
    public EdgeSet(Collection<E> edgeCollection) {
        super(edgeCollection);
    }

    /**
     * @return A list of the sorted edges.
     * The edges in the list are exactly the instances contained in this collection.
     * The returned list is not kept sorted.
     */
    public EdgeList<V, E> getSortedList() {
        EdgeList<V, E> sortedEdges = new EdgeList<V, E>(this, false);
        sortedEdges.sort();
        return sortedEdges;
    }

    /**
     * @param keepSorted True if the returned list must be kept sorted when using its overridden insertion methods.
     * @return A list of the sorted edges.
     * The edges in the list are exactly the instances contained in this collection.
     */
    public EdgeList<V, E> getSortedList(boolean keepSorted) {
        EdgeList<V, E> sortedEdges = new EdgeList<V, E>(this, keepSorted);
        if (!keepSorted) {
            sortedEdges.sort();
        }
        return sortedEdges;
    }

    /**
     * @return A list of the bounds for all the edges
     */
    public List<VertexPair<V>> getBoundsList() {
        List<VertexPair<V>> result = new ArrayList<VertexPair<V>>();

        for (Edge<V, E> edge : this) {
            result.add(edge.getBounds());
        }

        return result;
    }
}
