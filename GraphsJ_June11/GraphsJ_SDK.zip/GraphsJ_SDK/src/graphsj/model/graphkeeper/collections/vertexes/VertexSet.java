/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.collections.vertexes;

import graphsj.model.graphkeeper.*;
import java.util.Collection;
import java.util.HashSet;

/**
 * A set of vertexes.
 *
 * @param <V> The vertex class.
 * 
 * @author Gianluca Costa
 */
public class VertexSet<V extends Vertex<V, ?>> extends HashSet<V> {

    private static final long serialVersionUID = 1L;
    
    /**
     * Creates an empty vertex set
     */
    public VertexSet() {
        super();
    }

    /**
     * Create a vertex set with the vertex instances contained in the collection argument.
     * @param vertexCollection The source collection.
     */
    public VertexSet(Collection<V> vertexCollection) {
        super(vertexCollection);
    }

    /**
     * @return A list of the sorted vertexes. 
     * The vertexes in the list are exactly the instances contained in this collection.
     * The returned list is NOT kept sorted.
     */
    public VertexList<V> getSortedList() {
        VertexList<V> sortedVertexes = new VertexList<V>(this, false);
        sortedVertexes.sort();
        return sortedVertexes;
    }

    /**
     * @param keepSorted True if the returned list must be kept sorted when using its overridden insertion methods.
     * @return A list of the sorted vertexes.
     * The vertexes in the list are exactly the instances contained in this collection.
     */
    public VertexList<V> getSortedList(boolean keepSorted) {
        VertexList<V> sortedVertexes = new VertexList<V>(this, keepSorted);

        if (!keepSorted) {
            sortedVertexes.sort();
        }

        return sortedVertexes;
    }
}
