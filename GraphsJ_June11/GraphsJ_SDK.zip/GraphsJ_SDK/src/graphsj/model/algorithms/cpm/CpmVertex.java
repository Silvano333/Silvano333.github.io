/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.cpm;

import graphsj.model.algorithms.standard.StandardVertex;
import graphsj.model.graphkeeper.edges.WeightQuantity;

/**
 * The vertex class used by CPM.
 *
 * @author Gianluca Costa
 */
public class CpmVertex extends StandardVertex<CpmVertex, CpmEdge> {

    private static final long serialVersionUID = 1L;

    
    private int index;
    private WeightQuantity tmin;
    private WeightQuantity tmax;

    protected int getIndex() {
        return index;
    }

    protected void setIndex(int index) {
        this.index = index;
    }

    protected WeightQuantity getTmax() {
        return tmax;
    }

    protected void setTmax(WeightQuantity tmax) {
        this.tmax = tmax;
    }

    protected WeightQuantity getTmin() {
        return tmin;
    }

    protected void setTmin(WeightQuantity tmin) {
        this.tmin = tmin;
    }

    /**
     * Two CPM vertexes are compared according to (in order):
     * <ol>
     *  <li>Their CPM index, IF the algorithm is running and has already assigned vertex indexes</li>
     *  <li>The default vertex ordering scheme otherwise</li>
     * </ol>
     * @param o The other vertex
     * @return A proper integer value.
     */
    @Override
    public int compareTo(CpmVertex o) {
        CpmVertex other = o;

        int comparisonResult = new Integer(index).compareTo(other.index);

        if (comparisonResult == 0) {
            return super.compareTo(o);
        }

        return comparisonResult;
    }

    @Override
    protected String getRunningLabel() {
        switch (getAlgorithm().getRunController().getCompletedStep()) {
            case 0:
                return String.format("%s {%d}", getName(), index);

            case 1:
                return String.format("%s {%d, %s}", getName(), index, tmin.toString());

            default:
                return String.format("%s {%d, %s, %s}", getName(), index, tmin.toString(), tmax.toString());
        }
    }
}
