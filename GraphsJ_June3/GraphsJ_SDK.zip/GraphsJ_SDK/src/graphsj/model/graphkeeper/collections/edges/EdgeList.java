/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.collections.edges;

import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.collections.GraphObjectList;
import graphsj.model.graphkeeper.utils.VertexPair;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * A list of edges.
 *
 * @param <V> The vertex class
 * @param <E> The edge class
 *
 * @author Gianluca Costa
 */
public class EdgeList<V extends Vertex<V, E>, E extends Edge<V, E>> extends GraphObjectList<E> {

    /**
     * Creates a new edge list, which is NOT kept sorted.
     */
    public EdgeList() {
        super();
    }

    /**
     * Creates a new edge list.
     * @param keepSorted If true, calls to the overridden insertion methods will cause the list to be automatically sorted.
     */
    public EdgeList(boolean keepSorted) {
        super(keepSorted);
    }

    /**
     * Creates a new edge list with the elements of another collection. The list is NOT kept sorted.
     * @param sourceCollection The source collection.
     */
    public EdgeList(Collection<E> sourceCollection) {
        super(sourceCollection);
    }

    /**
     * Creates a new edge list with the elements of another collection.
     * @param sourceCollection The source collection.
     * @param keepSorted If true, calls to the overridden insertion methods will cause the list to be automatically sorted.
     */
    public EdgeList(Collection<E> sourceCollection, boolean keepSorted) {
        super(sourceCollection, keepSorted);
    }

    /**
     * @return A list of the bounds for all the edges
     */
    public List<VertexPair<V>> getBoundsList() {
        List<VertexPair<V>> result = new ArrayList<VertexPair<V>>();

        for (Edge<V, E> edge : this) {
            result.add(edge.getBounds());
        }

        return result;
    }
}
