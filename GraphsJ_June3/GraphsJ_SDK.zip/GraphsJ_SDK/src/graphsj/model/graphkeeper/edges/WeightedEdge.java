/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.edges;

import graphsj.gui.components.GraphCanvas;
import graphsj.model.graphkeeper.GraphObject;
import graphsj.model.graphkeeper.exceptions.GraphException;
import graphsj.model.graphkeeper.Edge;
import graphsj.gui.utils.MessageProvider;
import graphsj.model.graphkeeper.Vertex;

/**
 * This edge supports an integer weight.
 * Infinite weights are represented by +/-INF_WEIGHT.
 *
 * @param <V> The vertex class
 * @param <E> The edge class
 * 
 * @author Gianluca Costa
 */
public class WeightedEdge<V extends Vertex<V, E>, E extends WeightedEdge<V, E>> extends Edge<V, E> {    
    private WeightQuantity weight = WeightQuantity.ZERO;

    /**
     *
     * @return The edge weight
     */
    public WeightQuantity getWeight() {
        return weight;
    }

    /**
     * Sets the edge weight.
     * @param weight The new weight. In the default implementation, every value is accepted.
     * @throws graphsj.model.graphkeeper.edges.InvalidWeightException Thrown if the weight value is invalid for this instance.
     */
    public void setWeight(WeightQuantity weight) throws InvalidWeightException {        
        this.weight = weight;
    }

    /**
     *
     * @return The edge weight, converted to a meaningful string. Infinite weights are shown as "inf" or "-inf".
     */
    @Override
    public String toString() {
        return weight.toString();
    }

    @Override
    protected void restoreFromObject(GraphObject<V, E> obj) {
        WeightedEdge<V, E> other = (WeightedEdge<V, E>) obj;

        weight = other.weight;
    }

    @Override
    protected boolean askUserForEditData(GraphCanvas<V, E> canvas) throws GraphException {
        WeightQuantity newWeight = MessageProvider.getInstance().askForWeightQuantity("Edge weight:", "Edit edge weight...", weight);

        if (newWeight == null) {
            return false;
        }


        setWeight(newWeight);
        return true;
    }
}
