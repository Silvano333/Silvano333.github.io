/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */

package graphsj.model.graphkeeper.edges;

import java.io.Serializable;
import java.util.Locale;

/**
 * A "weight quantity", that is an integer quantity which behaves like an edge weight.
 * Weight quantities are immutable objects.
 *
 * @author Gianluca Costa
 */
public class WeightQuantity implements Comparable<WeightQuantity>, Serializable, Cloneable {

    /**
     * The positive infinity. It can be input by the user via "inf" or "+inf".
     */
    public static final WeightQuantity PLUS_INF = new WeightQuantity(Integer.MAX_VALUE);

    /**
     * Zero is a very useful constant for algorithm execution and for field initialization.
     */
    public static final WeightQuantity ZERO = new WeightQuantity(0);

    /**
     * The negative infinity. It can be input by the user via "-inf".
     */
    public static final WeightQuantity MINUS_INF = new WeightQuantity(Integer.MIN_VALUE);

    private final int value;


    /**
     * Creates the weight quantity.
     * @param value Its underlying integer value.
     */
    public WeightQuantity(int value) {
        assert PLUS_INF.value == Integer.MAX_VALUE;
        assert MINUS_INF.value == Integer.MIN_VALUE;
        
        this.value = value;
    }

    /**     
     * @return The underlying integer value.
     */
    public int getValue() {
        return value;
    }

    /**
     * Weight quantities are compared according to their underlying integer value.
     * @param other The other quantity.
     * @return The comparison integer value.
     */
    @Override
    public int compareTo(WeightQuantity other) {
        return new Integer(value).compareTo(other.value);
    }


    /**
     * Two weight quantities are equal if their underlying integer value is equal.
     * @param obj The other weight quantity.
     * @return True if the two weight quantities are equal.
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof WeightQuantity)) {
            return false;
        }

        WeightQuantity other = (WeightQuantity) obj;

        return value == other.value;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
    


    @Override
    public String toString() {
        if (value == PLUS_INF.value) {
            return "inf";
        } else if (value == MINUS_INF.value) {
            return "-inf";
        } else {
            return "" + value;
        }
    }


    /**
     * Sums two weight quantities. If one of them is an infinite quantity, an infinite quantity is returned or,
     * if the terms are opposite infinite quantities, and exception is thrown.
     * @param a
     * @param b
     * @return The sum of the two weight quantities (a + b)
     */
    public static WeightQuantity sum(WeightQuantity a, WeightQuantity b) {
        int aValue = a.value;
        int bValue = b.value;
        
        
        if (aValue == PLUS_INF.value) {
            if (bValue == MINUS_INF.value) {
                throw new IllegalArgumentException("Cannot sum opposite infinite weights");
            } else {
                return PLUS_INF;
            }
        }

        if (bValue == PLUS_INF.value) {
            if (aValue == MINUS_INF.value) {
                throw new IllegalArgumentException("Cannot sum opposite infinite weights");
            } else {
                return PLUS_INF;
            }
        }


        if (aValue == MINUS_INF.value) {
            if (bValue == PLUS_INF.value) {
                throw new IllegalArgumentException("Cannot sum opposite infinite weights");
            } else {
                return MINUS_INF;
            }
        } else

            if (bValue == MINUS_INF.value) {
            if (aValue == PLUS_INF.value) {
                throw new IllegalArgumentException("Cannot sum opposite infinite weights");
            } else {
                return MINUS_INF;
            }
        }


        return new WeightQuantity(aValue + bValue);
    }


    /**
     * Parses a string to retrieve a weight quantity. It does not perform ANY range check on the parsed number.
     * @param weightString The string to parse. It can be numeric, or "INF", "+INF" or "-INF" (case insensitive).
     * @return The parsed quantity.
     * @throws java.lang.NumberFormatException Thrown if a conversion error occurred.
     */
    public static WeightQuantity parseWeightString(String weightString) throws NumberFormatException {
        weightString = weightString.toUpperCase(Locale.getDefault());

        if (weightString.equals("INF") || weightString.equals("+INF")) {
            return PLUS_INF;
        } else if (weightString.equals("-INF")) {
            return MINUS_INF;
        }


        return new WeightQuantity(Integer.parseInt(weightString));
    }


    /**     
     * @return The opposite of this weight quantity (-this)
     */
    public WeightQuantity negate() {
        return new WeightQuantity(-value);
    }


    /**
     * Subtracts a weight quantity from another.
     * @param a The first quantity
     * @param b The quantity to remove
     * @return The difference (a- b)
     */
    public static WeightQuantity subtract(WeightQuantity a, WeightQuantity b) {
        return sum(a, b.negate());
    }


    /**     
     * @param a The first quantity
     * @param b The second quantity
     * @return The smallest of the two quantities
     */
    public static WeightQuantity min(WeightQuantity a, WeightQuantity b) {
        if (a.value <= b.value) {
            return a;
        } else {
            return b;
        }
    }


    /**
     * @param a The first quantity
     * @param b The second quantity
     * @return The biggest of the two quantities
     */
    public static WeightQuantity max(WeightQuantity a, WeightQuantity b) {
        if (a.value >= b.value) {
            return a;
        } else {
            return b;
        }
    }
}
