/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.extension.GraphInputStream;
import graphsj.extension.GraphOutputStream;
import java.awt.Color;
import java.awt.Font;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.List;
import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.GraphConstants;
import org.jgrapht.ext.JGraphModelAdapter;

/**
 * Enables a GraphKeeper to be shown on a GraphCanvas, and adds some useful graphical features.
 * In order to serialize/deserialize an adapter, you must use the specific methods provided by GraphInputStream and GraphOutputStream, NOT
 * the default writeObject()/readObject() methods.
 * 
 * @param <V> The vertex class
 * @param <E> The edge class
 * 
 * @author Gianluca Costa
 */
public class SafeAdapter<V extends Vertex<V, E>, E extends Edge<V, E>> extends JGraphModelAdapter<V, E> implements Cloneable, Externalizable {

    private final GraphKeeper<V, E> graphKeeper;

    /**
     * Creates the adapter, and sets some default values for both vertex cells and edge cells.
     * @param graphKeeper The GraphKeeper to show via this adapter.
     */
    public SafeAdapter(GraphKeeper<V, E> graphKeeper) {
        super(graphKeeper.getGraph());
        this.graphKeeper = graphKeeper;

        AttributeMap defaultVertexAttributes = getDefaultVertexAttributes();
        GraphConstants.setFont(defaultVertexAttributes, new Font("Arial", Font.BOLD, 15));
        GraphConstants.setAutoSize(defaultVertexAttributes, true);
        GraphConstants.setEditable(defaultVertexAttributes, false);
        GraphConstants.setInset(defaultVertexAttributes, 5);

        
        AttributeMap defaultEdgeAttributes = getDefaultEdgeAttributes();
        GraphConstants.setEditable(defaultEdgeAttributes, false);
        GraphConstants.setConnectable(defaultEdgeAttributes, false);
        GraphConstants.setDisconnectable(defaultEdgeAttributes, false);
        GraphConstants.setMoveable(defaultEdgeAttributes, false);
        GraphConstants.setFont(defaultEdgeAttributes, new Font("Arial", Font.BOLD, 16));       
    }
    

    /**
     *
     * @return The underlying graph keeper.
     */
    public GraphKeeper<V, E> getGraphKeeper() {
        return graphKeeper;
    }

    /**
     * Resets the style of every edge in the graph to the default values, except a few elements such as the edge points.
     */
    public void resetEdgesToDefaultStyle() {
        AttributeMap defaultEdgeAttributes = getDefaultEdgeAttributes();


        for (E edge : graphKeeper.edgeSet()) {
            DefaultEdge edgeCell = getEdgeCell(edge);

            AttributeMap oldEdgeAttributes = edgeCell.getAttributes();
            AttributeMap newEdgeAttributes = (AttributeMap) defaultEdgeAttributes.clone();


            List<?> edgePoints = GraphConstants.getPoints(oldEdgeAttributes);
            if (edgePoints != null) {
                GraphConstants.setPoints(newEdgeAttributes, edgePoints);
            }
            edgeCell.setAttributes(newEdgeAttributes);
        }

        cellsChanged();

    }

    /**
     * Clones the adapter, <b>but NOT its listeners</b>.
     * @return A clone of the adapter, WITHOUT the original listeners.
     */
    @Override
    public SafeAdapter<V, E> clone() {
        try {
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            GraphOutputStream<V, E> outputStream = new GraphOutputStream<V, E>(byteStream);
            outputStream.writeAdapter(this);

            GraphInputStream inputStream = new GraphInputStream(new ByteArrayInputStream(byteStream.toByteArray()));
            return inputStream.readAdapter();

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Refreshes the specified cell (it can be a vertex cell or an edge cell).
     * @param cell The cell (of a vertex or an edge) to refresh.
     */
    public void cellChanged(DefaultGraphCell cell) {
        cellsChanged(new Object[]{cell});
    }

    /**
     * Refreshes all the cells (both of vertexes and edges) of the adapter.
     */
    public void cellsChanged() {
        cellsChanged(getRoots().toArray());
    }

    /**
     * Sets the width and the color of the specified edge
     * @param edge The edge IN THE MODEL to make up.
     * @param width The requested width.
     * @param color The requested color.
     */
    public void makeUpEdge(E edge, int width, Color color) {

        DefaultEdge edgeCell = getEdgeCell(edge);

        AttributeMap edgeAttributes = (AttributeMap) edgeCell.getAttributes().clone();
        GraphConstants.setLineWidth(edgeAttributes, width);
        GraphConstants.setLineColor(edgeAttributes, color);
        edgeCell.setAttributes(edgeAttributes);

        cellChanged(edgeCell);
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        throw new UnsupportedOperationException("You must serialize your adapter by using the writeAdapter() method of a GraphOutputStream");
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        throw new UnsupportedOperationException("You must deserialize your adapter by using the readAdapter() method of a GraphInputStream.");
    }


    /**
     * @return The default font size used to render vertex labels.
     */
    public int getVertexFontSize() {
        AttributeMap defaultVertexAttributes = getDefaultVertexAttributes();

        Font defaultFont = GraphConstants.getFont(defaultVertexAttributes);

        return defaultFont.getSize();
    }


    /**
     * Sets the font size for all the existing vertex cells AND for the default vertex attributes.
     * @param size The new font size.
     */
    public void setVertexFontSize(int size) {
        AttributeMap defaultVertexAttributes = getDefaultVertexAttributes();

        Font oldFont = GraphConstants.getFont(defaultVertexAttributes);
        Font newFont = oldFont.deriveFont((float)size);

        GraphConstants.setFont(defaultVertexAttributes, newFont);

        for (V vertex : graphKeeper.vertexSet()) {
            DefaultGraphCell vertexCell = getVertexCell(vertex);
            AttributeMap vertexAttributes = vertexCell.getAttributes();

            GraphConstants.setFont(vertexAttributes, newFont);
        }

        cellsChanged();
    }


    /**
     * @return The default font color used to render vertex labels.
     */
    public Color getVertexFontColor() {
        AttributeMap defaultVertexAttributes = getDefaultVertexAttributes();

        return GraphConstants.getForeground(defaultVertexAttributes);
    }


    /**
     * Sets the font color for all the existing vertex cells AND for the default vertex attributes.
     * @param color The new font color.
     */
    public void setVertexFontColor(Color color) {
        AttributeMap defaultVertexAttributes = getDefaultVertexAttributes();


        GraphConstants.setForeground(defaultVertexAttributes, color);

        for (V vertex : graphKeeper.vertexSet()) {
            DefaultGraphCell vertexCell = getVertexCell(vertex);
            AttributeMap vertexAttributes = vertexCell.getAttributes();

            GraphConstants.setForeground(vertexAttributes, color);
        }

        cellsChanged();
    }



     /**
     * @return The default font size used to render edge labels.
     */
    public int getEdgeFontSize() {
        AttributeMap defaultEdgeAttributes = getDefaultEdgeAttributes();

        Font defaultFont = GraphConstants.getFont(defaultEdgeAttributes);

        return defaultFont.getSize();
    }


    /**
     * Sets the font size for all the existing edge cells AND for the default edge attributes.
     * @param size The new font size.
     */
    public void setEdgeFontSize(int size) {
        AttributeMap defaultEdgeAttributes = getDefaultEdgeAttributes();

        Font oldFont = GraphConstants.getFont(defaultEdgeAttributes);
        Font newFont = oldFont.deriveFont((float)size);

        GraphConstants.setFont(defaultEdgeAttributes, newFont);

        for (E edge : graphKeeper.edgeSet()) {
            DefaultEdge edgeCell = getEdgeCell(edge);
            AttributeMap edgeAttributes = edgeCell.getAttributes();

            GraphConstants.setFont(edgeAttributes, newFont);
        }

        cellsChanged();
    }


    /**
     * @return The default font color used to render edge labels.
     */
    public Color getEdgeFontColor() {
        AttributeMap defaultEdgeAttributes = getDefaultEdgeAttributes();

        return GraphConstants.getForeground(defaultEdgeAttributes);
    }


    /**
     * Sets the font color for all the existing edge cells AND for the default edge attributes.
     * @param color The new font color.
     */
    public void setEdgeFontColor(Color color) {
        AttributeMap defaultEdgeAttributes = getDefaultEdgeAttributes();

        GraphConstants.setForeground(defaultEdgeAttributes, color);

        for (E edge : graphKeeper.edgeSet()) {
            DefaultEdge edgeCell = getEdgeCell(edge);
            AttributeMap edgeAttributes = edgeCell.getAttributes();

            GraphConstants.setForeground(edgeAttributes, color);
        }

        cellsChanged();
    }
}
