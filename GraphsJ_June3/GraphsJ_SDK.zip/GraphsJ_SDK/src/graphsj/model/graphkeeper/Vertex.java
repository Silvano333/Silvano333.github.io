/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.gui.components.GraphCanvas;
import graphsj.gui.utils.MessageProvider;
import graphsj.model.graphkeeper.collections.edges.EdgeSet;
import graphsj.model.graphkeeper.collections.vertexes.VertexSet;
import graphsj.model.graphkeeper.exceptions.DuplicateVertexException;
import graphsj.model.graphkeeper.exceptions.GraphException;
import graphsj.model.graphkeeper.utils.InvalidNameException;
import graphsj.model.graphkeeper.utils.NameValidator;
import java.util.Set;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.graph.DefaultListenableGraph;

/**
 * The generic graph vertex.
 * 
 * @param <V> The vertex class
 * @param <E> The edge class
 *
 * @author Gianluca Costa
 */
public abstract class Vertex<V extends Vertex<V, E>, E extends Edge<V, E>> extends GraphObject<V, E> implements Comparable<V> {

    private String name;

    /**
     * Creates the vertex.
     * @param name The vertex name. It should uniquely identify the vertex in a graph.
     */
    public Vertex(String name) {
        this.name = name;
    }

    /**
     *
     * @return The vertex name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the vertex name.
     * @param name The vertex name.
     * @throws graphsj.model.graphkeeper.exceptions.DuplicateVertexException Thrown if the vertex is attached to a graph keeper containing a vertex with the same name.
     * @throws InvalidNameException Thrown if the new vertex name is not valid.
     */
    public void setName(String name) throws DuplicateVertexException, InvalidNameException {
        GraphKeeper<V, E> parentKeeper = getParentKeeper();

        NameValidator.getInstance().validateName(name);

        this.name = name;

        if (parentKeeper != null && parentKeeper.hasConflictingVertex((V) this)) {
            throw new DuplicateVertexException(String.format("Vertex '%s' already exists!", name));
        }
        
    }

    /**
     * Attaches the vertex to a graph keeper.
     * @param graphKeeper The GraphKeeper object to attach the vertex to.
     * @throws graphsj.model.graphkeeper.exceptions.DuplicateVertexException Thrown if a vertex conflicting with this one already belongs to the graph.
     */
    public void attach(GraphKeeper<V, E> graphKeeper) throws DuplicateVertexException {
        if (graphKeeper.getVertexClass() != getClass()) {
            throw new IllegalArgumentException("The vertex class of the GraphKeeper does not match");
        }


        if (getParentKeeper() != null) {
            throw new RuntimeException(String.format("Could not attach vertex '%s', since it's already attached to a graph", name));
        }


        if (graphKeeper.hasConflictingVertex((V)this)) {
            throw new DuplicateVertexException(String.format("Vertex '%s' already belongs to the graph.", name));
        }


        if (!graphKeeper.getGraph().addVertex((V)this)) {
            throw new DuplicateVertexException(String.format("Cannot add vertex '%s' to the internal graph", name));
        }


        setParentKeeper(graphKeeper);

    }

    /**
     * Detaches the vertex from the GraphKeeper it is currently attached to.
     */
    @Override
    public void detach() {
        GraphKeeper<V, E> parentKeeper = getParentKeeper();

        if (parentKeeper == null) {
            throw new RuntimeException(String.format("Vertex '%s' is already detached", name));
        }

        if (!parentKeeper.getGraph().removeVertex((V)this)) {
            throw new RuntimeException("Could not detach the vertex from the graph");
        }


        setParentKeeper(null);
    }    

    /**
     *
     * @return The vertex name
     */
    @Override
    public String toString() {
        return name;
    }

    /**
     * By default, vertexes are sorted according to their names.
     * @param o The other vertex
     * @return The suitable integer value.
     */
    @Override
    public int compareTo(V o) {
        return name.compareTo(o.name);
    }

    

    /**
     *
     * @return A set containing the source vertex of each incoming edge
     */
    public VertexSet<V> getIncomingVertexes() {
        VertexSet<V> result = new VertexSet<V>();

        Set<E> incomingEdges = getParentKeeper().getGraph().incomingEdgesOf((V)this);

        for (E edge : incomingEdges) {
            result.add(getParentKeeper().getGraph().getEdgeSource(edge));
        }

        return result;
    }

    /**
     *
     * @return A set containing the target vertex of each outcoming edge
     */
    public VertexSet<V> getOutgoingVertexes() {
        VertexSet<V> result = new VertexSet<V>();
        Set<E> outgoingEdges = getParentKeeper().getGraph().outgoingEdgesOf((V)this);

        for (E edge : outgoingEdges) {
            result.add(getParentKeeper().getGraph().getEdgeTarget(edge));
        }

        return result;
    }

    /**
     *
     * @return The set of all the outgoing edges
     */
    public EdgeSet<V, E> getOutgoingEdges() {
        return new EdgeSet<V, E>(getParentKeeper().getGraph().outgoingEdgesOf((V)this));
    }

    /**
     * @return The number of outgoing edges
     */
    public int getOutDegree() {
        return getParentKeeper().getGraph().outDegreeOf((V)this);
    }

    /**
     *
     * @return The set of incoming edges
     */
    public EdgeSet<V, E> getIncomingEdges() {
        return new EdgeSet<V, E>(getParentKeeper().getGraph().incomingEdgesOf((V) this));
    }

    /**
     *
     * @return The set of the incoming and outgoing edges
     */
    public EdgeSet<V, E> getEdges() {
        return new EdgeSet<V, E>(getParentKeeper().getGraph().edgesOf((V)this));
    }

    /**
     *
     * @return The number of incoming edges
     */
    public int getInDegree() {
        return getParentKeeper().getGraph().inDegreeOf((V)this);
    }

    /**
     *
     * @return The number of incoming edges plus the number of outgoing edges
     */
    public int getDegree() {
        DefaultListenableGraph<V, E> graph = getParentKeeper().getGraph();
        if (graph instanceof UndirectedGraph) {
            return graph.degreeOf((V)this);
        } else {
            return graph.inDegreeOf((V)this) + graph.outDegreeOf((V)this);
        }

    }

    

    @Override
    protected void restoreFromObject(GraphObject<V, E> obj) {
        V other = (V) obj;

        this.name = other.name;
    }

    @Override
    protected boolean askUserForEditData(GraphCanvas<V, E> canvas) throws GraphException {
        String newVertexName = MessageProvider.getInstance().askForString("Vertex name:", "Edit vertex name...", name);

        if (newVertexName == null) {
            return false;
        }
       
        setName(newVertexName);
        return true;
    }    
}
