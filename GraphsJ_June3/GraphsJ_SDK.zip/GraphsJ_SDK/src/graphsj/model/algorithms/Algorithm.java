/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms;

import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import java.io.Serializable;

/**
 * The basic definition of a graph algorithm. You will probably want to inherit from more specific subclasses (e.g. StandardAlgorithm) which provide more useful features.
 * You should consider keeping "transient" as many execution-related fields as you can,
 * since the algorithm framework assumes that algorithm initialization is not run by the constructor,
 * but at the beginning of every algorithm execution; such initialization happens in the initializeRun() and postInitializeRun() methods.
 * Of course, fields containing user-defined options should NOT be declared transient.
 * These serialization warnings applies also to classes used by your algorithm, in particular custom Vertex/Edge/GraphKeeper subclasses.
 *
 * If you provide a file called "Help.html" into your algorithm's package, it will automatically be read and displayed by the GUI framework whenever
 * the user asks for the algorithm help.
 *
 * @param <V> The vertex class
 * @param <E> The edge class
 * 
 * @author Gianluca Costa
 */
public abstract class Algorithm<V extends Vertex<V, E>, E extends Edge<V, E>> implements Serializable {

    private transient RunController<V, E> runController;

    /**
     *
     * @return The RunController associated with the algorithm. Every algorithm instance can have just one associated RunController to manage its execution.
     */
    public RunController<V, E> getRunController() {
        if (runController == null) {
            runController = new RunController<V, E>(this);
        }
        return runController;
    }

    /**
     * Creates the algorithm
     */
    public Algorithm() {
        super();
    }

    /**
     * @return By default, the algorithm name is returned.
     */
    @Override
    public String toString() {
        return getAlgorithmName();
    }

    /**
     *
     * @return The algorithm name (called by the GUI framework)
     */
    public abstract String getAlgorithmName();

    /**
     *
     * @return A GraphKeeper instance. It will be internally stored and used during the algorithm execution.
     */
    public abstract GraphKeeper<V, E> createGraphKeeper();

    /**
     * Initializes the algorithm. It is the first algorithm method called by the RunController when starting the algorithm execution.
     * When overriding this method, the FIRST operation in the method should be a call to the super implementation.
     * @param adapter The adapter provided by the associated RunController.
     * @param graphKeeper The graph keeper provided by the associated RunController.
     * @param output The AlgorithmOutput provided by the associated RunController.
     * @param verboseRun True if the user wants a verbose execution (it's up to your algorithm to decide what this means).
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     * @throws graphsj.model.algorithms.AlgorithmInterruptedException Thrown by the algorithm if the algorithm execution was interrupted by the user.
     * @throws graphsj.model.algorithms.AlgorithmEndedException Thrown by the algorithm if it reached a solution and its execution consequently ended.
     */
    public abstract void initializeRun(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException;

    /**
     * Called by the RunController just after initializeRun(), at the end of the algorithm initialization.
     * When overriding this method, the FIRST operation in the method should be a call to the super implementation.
     * @param adapter The adapter provided by the associated RunController.
     * @param graphKeeper The graph keeper provided by the associated RunController.
     * @param output The AlgorithmOutput provided by the associated RunController.
     * @param verboseRun True if the user wants a verbose execution (it's up to your algorithm to decide what this means).
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     * @throws graphsj.model.algorithms.AlgorithmInterruptedException Thrown by the algorithm if the algorithm execution was interrupted by the user.
     * @throws graphsj.model.algorithms.AlgorithmEndedException Thrown by the algorithm if it reached a solution and its execution consequently ended.
     */
    protected abstract void postInitializeRun(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException;

    /**
     * Called by the RunController whenever an algorithm step must be performed.
     * When overriding this method, the LAST operation in the method should be a call to the super implementation.
     * @param adapter The adapter provided by the associated RunController.
     * @param graphKeeper The graph keeper provided by the associated RunController.
     * @param output The AlgorithmOutput provided by the associated RunController.
     * @param verboseRun True if the user wants a verbose execution (it's up to your algorithm to decide what this means).
     * @param currentStep The step currently executed. Steps are numbered from 1 (step number 0 is reserved to the initialization pseudo-step).
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     * @throws graphsj.model.algorithms.AlgorithmInterruptedException Thrown by the algorithm if the algorithm execution was interrupted by the user.
     * @throws graphsj.model.algorithms.AlgorithmEndedException Thrown by the algorithm if it reached a solution and its execution consequently ended.
     */
    protected abstract void runStep(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException;

    /**
     * Called by the RunController when the user interrupts the algorithm execution, that is when the algorithm raises AlgorithmInterruptedException or when the algorithm execution is interrupted via the RunController.
     * It is not called when the user stops the algorithm execution when it has already ended and has shown the solution to the user.
     * When overriding this method, the LAST operation in the method should be a call to the super implementation.
     * @param adapter The adapter provided by the associated RunController.
     * @param graphKeeper The graph keeper provided by the associated RunController.
     * @param output The AlgorithmOutput provided by the associated RunController.
     * @param verboseRun True if the user wants a verbose execution (it's up to your algorithm to decide what this means).
     * @param currentStep The step currently executed. Steps are numbered from 1 (step number 0 is reserved to the initialization pseudo-step).
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     */
    protected abstract void onInterruptedRun(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun, int currentStep) throws AlgorithmRunException;

    /**
     * Called when an algorithm method raises an AlgorithmEndedException. This method should probably sum up the algorithm results and clearly show them to the user.
     * When overriding this method, the LAST operation in the method should be a call to the super implementation.
     * @param adapter The adapter provided by the associated RunController.
     * @param graphKeeper The graph keeper provided by the associated RunController.
     * @param output The AlgorithmOutput provided by the associated RunController.
     * @param verboseRun True if the user wants a verbose execution (it's up to your algorithm to decide what this means).
     * @param currentStep The step currently executed. Steps are numbered from 1 (step number 0 is reserved to the initialization pseudo-step).
     * @throws graphsj.model.algorithms.AlgorithmRunException Thrown by the algorithm if the user made some mistakes, or an impredictable error occured during the algorithm execution.
     */
    protected abstract void onEndRun(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun, int currentStep) throws AlgorithmRunException;

    /**
     * Shows the algorithm's options dialog. It is called by the GUI framework.
     * @return True if the dialog was confirmed.
     */
    public abstract boolean showOptionsDialog();    

    /**
     *
     * @param completedStepNumber The number of the step just completed by the RunController. Steps are numbered from 1 (step number 0 is reserved to the initialization pseudo-step).
     * @return A string describing the completed step, or null, if no description must be shown for that step.
     */
    protected abstract String getCompletedStepDescription(int completedStepNumber);

    /**
     *
     * @return The graphic adapter to be used with this algorithm. It defaults to a SafeAdapter.
     */
    public Class<? extends SafeAdapter> getAdapterClass() {
        return (Class<? extends SafeAdapter>) SafeAdapter.class;
    }
}
