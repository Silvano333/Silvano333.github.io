/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.startstop;

import graphsj.gui.utils.VertexChooser;
import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.standard.StandardAlgorithm;
import graphsj.model.algorithms.standard.StandardEdge;
import graphsj.model.algorithms.standard.StandardVertex;
import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.exceptions.EmptyGraphException;

/**
 * This standard algorithm asks the user for a "start vertex" and a "stop vertex", whose meaning depends on the algorithm you are implementing.
 * It checks that:
 * <ul>
 *  <li>The start vertex has no incoming edges</li>
 *  <li>The stop vertex has no outgoing edges</li>
 * </ul>
 * 
 * @param <V> The vertex class.
 * @param <E> The edge class.
 * 
 * @author Gianluca Costa
 */
public abstract class StartStopAlgorithm<V extends StandardVertex<V, E>, E extends Edge<V, E> & StandardEdge<V, E>> extends StandardAlgorithm<V, E> {

    private transient V startVertex = null;
    private transient V stopVertex = null;

    @Override
    public void initializeRun(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(adapter, graphKeeper, output, verboseRun);

        VertexChooser<V, E> vertexChooser = new VertexChooser<V, E>(graphKeeper);
        try {
            startVertex = vertexChooser.askForVertex("Choose the source ('start') vertex:", getAlgorithmName());
            if (startVertex == null) {
                throw new AlgorithmInterruptedException();
            }

            if (startVertex.getInDegree() > 0) {
                throw new AlgorithmRunException("The start vertex cannot have incoming edges");
            }


            stopVertex = vertexChooser.askForVertex("Choose the sink ('stop') vertex:", getAlgorithmName());
            if (stopVertex == null) {
                throw new AlgorithmInterruptedException();
            }


            if (stopVertex.getOutDegree() > 0) {
                throw new AlgorithmRunException("The stop vertex cannot have outgoing edges");
            }

        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException("No vertexes in this graph!");
        }


        if (startVertex == stopVertex) {
            throw new AlgorithmRunException("The start vertex and the stop vertex cannot be the same!");
        }
    }

    /**
     *
     * @return The start vertex provided by the user.
     */
    protected V getStartVertex() {
        return startVertex;
    }

    /**
     *
     * @return The stop vertex provided by the user.
     */
    protected V getStopVertex() {
        return stopVertex;
    }
}
