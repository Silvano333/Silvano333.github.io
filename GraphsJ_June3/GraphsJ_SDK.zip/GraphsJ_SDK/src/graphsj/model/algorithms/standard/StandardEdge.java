/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.standard;

import graphsj.model.graphkeeper.Edge;

/**
 * Make this interface implemented by your edge class if you create algorithm classes inheriting from StandardAlgorithm.
 * Whenever an instance of StandardAlgorithm terminates its initialization step, it calls this method for every edge in the graph.
 * Therefore, you can save a reference to the currently running algorithm via this method (for example, by setting a private field).
 * Of course, if you don't need to store this reference, you can just leave the method body empty.
 *
 * Since you'll probably need to save the reference to StandardAlgorithm as a private field,
 * remember that you can (and should) declare it as a transient field, because it will be re-initialized every time
 * the algorithm runs.
 * 
 * @param <V> The vertex class
 * @param <E> The edge class
 * 
 * @author Gianluca Costa
 */
public interface StandardEdge<V extends StandardVertex<V, E>, E extends Edge<V, E> & StandardEdge<V, E>> {

    /**
     * Sets the standard algorithm used by the edge at the end of the algorithm initialization. It is automatically called by StandardAlgorithm.
     * @param algorithm The standard algorithm that is going to run and that will call this method.
     */
    void setAlgorithm(StandardAlgorithm<V, E> algorithm);
}
