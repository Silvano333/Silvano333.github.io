/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.fordfulkerson;

import graphsj.model.algorithms.standard.StandardVertex;
import graphsj.model.graphkeeper.edges.WeightQuantity;
import graphsj.model.graphkeeper.exceptions.DuplicateObjectException;

/**
 * The vertex class used by Ford-Fulkerson's algorithm.
 *
 * @author Gianluca Costa
 */
public class FordFulkersonVertex extends StandardVertex<FordFulkersonVertex, FordFulkersonEdge> {

    private transient boolean labeled;
    private transient boolean plusVk;
    private transient FordFulkersonVertex vk;
    private transient WeightQuantity delta;
    private transient boolean explored;

    public FordFulkersonVertex(String name) throws DuplicateObjectException {
        super(name);
    }

    protected boolean isLabeled() {
        return labeled;
    }

    protected void setLabeled(boolean labeled) {
        this.labeled = labeled;
    }

    protected WeightQuantity getDelta() {
        return delta;
    }

    protected void setDelta(WeightQuantity delta) {
        this.delta = delta;
    }

    protected boolean isExplored() {
        return explored;
    }

    protected void setExplored(boolean explored) {
        this.explored = explored;
    }

    protected boolean isPlusVk() {
        return plusVk;
    }

    protected void setPlusVk(boolean plusVk) {
        this.plusVk = plusVk;
    }

    protected FordFulkersonVertex getVk() {
        return vk;
    }

    protected void setVk(FordFulkersonVertex vk) {
        this.vk = vk;
    }

    @Override
    protected String getRunningLabel() {
        if (!labeled) {
            return getName();
        } else {
            return String.format("%s {%s%s, %s}%s",
                    getName(),
                    plusVk ? "+" : "-",
                    vk != null ? vk.getName() : "(null)",
                    delta.toString(),
                    explored ? " @" : "");
        }
    }
}
