/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.windows.main;

import graphsj.extension.GraphInputStream;
import graphsj.extension.GraphOutputStream;
import graphsj.gui.utils.MessageProvider;
import graphsj.gui.windows.AlgorithmDialog;
import graphsj.model.algorithms.Algorithm;
import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.Vertex;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * This class manages the document data used by the application.
 * 
 * @param <V> The vertex class
 * @param <E> The edge class
 *
 * @author Gianluca Costa
 */
class StorageKeeper<V extends Vertex<V, E>, E extends Edge<V, E>> {

    private final AlgorithmDialog algorithmDialog = new AlgorithmDialog();
    private final StorageKeeperGUI<V, E> gui;
    private Algorithm<V, E> algorithm;

    /**
     * Creates the keeper.
     * @param gui The GUI object connected with the keeper.
     */
    public StorageKeeper(StorageKeeperGUI<V, E> gui) {
        this.gui = gui;
    }

    /**
     * Tries to create a new document.
     * @return True if it was created successfully.
     */
    protected boolean doNew() {
        algorithmDialog.setVisible(true);

        Algorithm<V, E> selectedAlgorithm = (Algorithm<V, E>) algorithmDialog.getSelectedAlgorithm();
        if (selectedAlgorithm == null) {
            return false;
        }
        algorithm = selectedAlgorithm;


        Class<? extends SafeAdapter> adapterClass = algorithm.getAdapterClass();
        SafeAdapter<V, E> adapter;
        try {
            Constructor<? extends SafeAdapter> adapterConstructor = (Constructor<? extends SafeAdapter>) adapterClass.getConstructor(GraphKeeper.class);
            adapter = adapterConstructor.newInstance(algorithm.createGraphKeeper());
            gui.setInputAdapter(adapter);
            return true;
        } catch (NoSuchMethodException ex) {
            MessageProvider.getInstance().showErrorBox(ex);
        } catch (SecurityException ex) {
            MessageProvider.getInstance().showErrorBox(ex);
        } catch (IllegalAccessException ex) {
            MessageProvider.getInstance().showErrorBox(ex);
        } catch (IllegalArgumentException ex) {
            MessageProvider.getInstance().showErrorBox(ex);
        } catch (InstantiationException ex) {
            MessageProvider.getInstance().showErrorBox(ex);
        } catch (InvocationTargetException ex) {
            MessageProvider.getInstance().showErrorBox(ex);
        }

        return false;
    }

    /**
     * Tries to load a document from the specified file.
     * @param chosenFile The document file.
     * @return True if the document was loaded correctly.
     */
    protected boolean loadData(File chosenFile) {
        GraphInputStream stream = null;

        try {
            stream = new GraphInputStream(new GZIPInputStream(new FileInputStream(chosenFile)));

            try {
                algorithm = (Algorithm<V, E>) stream.readObject();                
                SafeAdapter<V, E> adapter = stream.readAdapter();
                gui.setInputAdapter(adapter);

                return true;
            } finally {
                stream.close();
            }
        } catch (ClassNotFoundException ex) {
            MessageProvider.getInstance().showErrorBox("Could not open the file.", ex);
        } catch (IOException ex) {
            MessageProvider.getInstance().showErrorBox("Could not open the file.", ex);
        }

        return false;
    }

    /**
     * Saves the current document to a file.
     * @param chosenFile The target file.
     * @return True if the document was successfully saved.
     */
    protected boolean saveData(File chosenFile) {
        GraphOutputStream<V, E> stream = null;

        try {
            stream = new GraphOutputStream<V, E>(new GZIPOutputStream(new FileOutputStream(chosenFile)));

            try {
                stream.writeObject(algorithm);                
                stream.writeAdapter(gui.getInputAdapter());
            } finally {
                stream.close();
            }


            return true;
        } catch (IOException ex) {
            MessageProvider.getInstance().showErrorBox("Could not save the graph.", ex);
        }

        return false;
    }

    /**
     * Tries to close the document.
     * @return True if the document was closed successfully.
     */
    protected boolean doClose() {
        algorithm = null;
        return true;
    }

    /**
     * @return The current algorithm, created via the dialog or loaded from a file.
     */
    public Algorithm<V, E> getAlgorithm() {
        return algorithm;
    }
}
