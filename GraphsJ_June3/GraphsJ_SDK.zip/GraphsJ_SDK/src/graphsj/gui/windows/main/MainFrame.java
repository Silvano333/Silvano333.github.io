/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.windows.main;

import graphsj.gui.windows.*;
import graphsj.Application;
import graphsj.gui.utils.MessageProvider;
import graphsj.model.algorithms.Algorithm;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.RunController;
import graphsj.model.algorithms.RunStateEnum;
import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.utils.InvalidNameException;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import org.jgraph.event.GraphModelEvent;
import org.jgraph.event.GraphModelListener;

/**
 * The application's main frame.
 *
 * @param <V> The vertex class
 * @param <E> The edge class
 *
 * @author Gianluca Costa
 */
public class MainFrame<V extends Vertex<V, E>, E extends Edge<V, E>> extends javax.swing.JFrame implements StorageKeeperGUI<V, E> {

    private SafeAdapter<V, E> undoAdapter;
    private SafeAdapter<V, E> redoAdapter;
    private HelpDialog algorithmHelpDialog;
    private final StorageKeeper<V, E> storageKeeper = new StorageKeeper<V, E>(this);
    private final FileManager<V, E> fileManager = new FileManager<V, E>(storageKeeper);
    private final HelpDialog mainHelpDialog = new HelpDialog(String.format("%s - Online Help", Application.TITLE), Application.class.getResource("Help.html"));
    private final AboutDialog aboutDialog = new AboutDialog();

    private final AlgorithmOutput<V, E> mainOutput = new AlgorithmOutput<V, E>() {

        @Override
        public void printLine(String line) {
            outputArea.setText(outputArea.getText() + line + "\n");
        }

        @Override
        public SafeAdapter<V, E> getOutputAdapter() {
            return outputGraphCanvas.getAdapter();
        }
    };
    private final ActionListener fileManagerStateListener = new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {

            //First of all, I must interrupt a running algorithm when changing the file state.
            if (getRunController() != null) {
                try {
                    getRunController().safeStop();
                } catch (AlgorithmRunException ex) {
                    MessageProvider.getInstance().showWarningBox(ex);
                }
            }

            //Now, I can update the GUI
            updateTitle();

            boolean hasDocument = !fileManager.isEmpty();

            actionPanel.setVisible(hasDocument);

            saveItem.setEnabled(hasDocument);
            saveAsItem.setEnabled(hasDocument);
            closeItem.setEnabled(hasDocument);

            editMenu.setEnabled(hasDocument);
            optionsMenu.setEnabled(hasDocument);
            outputMenu.setEnabled(hasDocument);
            runMenu.setEnabled(hasDocument);

            algorithmHelpItem.setEnabled(hasDocument);

            if (!hasDocument) {
                setStatusText("");
            }
        }
    };
    private final ActionListener runStateListener = new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
            boolean running = getRunController().isRunning();
            RunStateEnum runState = getRunController().getRunState();

            runItem.setEnabled(!running);
            runStepByStepItem.setEnabled(!running);
            nextStepItem.setEnabled(runState == RunStateEnum.STEP_RUNNING);
            stopItem.setEnabled(runState == RunStateEnum.STEP_RUNNING || runState == RunStateEnum.ENDED_RUNNING);
            verboseItem.setEnabled(!running);

            editMenu.setEnabled(!running);


            //I disable here some options
            vertexAutoNamingMenu.setEnabled(!running);
            algorithmOptionsItem.setEnabled(!running);
            fontsAndColorsMenu.setEnabled(!running);

            if (!running) {
                actionSplitter.setTopComponent(inputGraphScrollPane);
            } else {
                actionSplitter.setTopComponent(outputGraphScrollPane);
            }
        }
    };
    private final ActionListener runStepCompletedListener = new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
            StringBuilder statusBuilder = new StringBuilder(String.format("Step %d completed", storageKeeper.getAlgorithm().getRunController().getCompletedStep()));

            String completedStepDescription = getRunController().getCompletedStepDescription();
            if (completedStepDescription != null) {
                statusBuilder.append(" - ");
                statusBuilder.append(completedStepDescription);
            }

            setStatusText(statusBuilder.toString());
        }
    };
    private final FileFilter outputTextFileFilter = new FileFilter() {

        @Override
        public boolean accept(File f) {
            return f.isDirectory() || f.getName().endsWith(".txt");
        }

        @Override
        public String getDescription() {
            return "Text file (*.txt)";
        }
    };
    private final GraphModelListener graphChangeListener = new GraphModelListener() {

        @Override
        public void graphChanged(GraphModelEvent e) {
            fileManager.makeModified();
        }
    };

    /** Creates an instance of the frame */
    public MainFrame() {
        initComponents();

        //This refreshes the GUI
        fileManagerStateListener.actionPerformed(null);

        //The file manager remains fixed in the class, so I can register here its listeners
        fileManager.addStateChangeListener(fileManagerStateListener);

        outputFileChooser.addChoosableFileFilter(outputTextFileFilter);

        //This updates the size of the outputGraphCanvas.
        outputGraphCanvas.setPreferredSize(inputGraphCanvas.getPreferredSize());

        setStatusText("Choose Graph->New... to solve a new graph problem");

        setIconImage(Application.SMALL_ICON.getImage());
        setLocationRelativeTo(null);
    }

    /**
     * Registers run listeners on the run controller.
     * It is called when creating a new document or opening an existing one (so the handlers are registered just once).
     * It also refreshes the GUI by simulating the emission of a "state changed" event by the run controller.
     */
    private void registerRunControllerListeners() {
        RunController<V, E> runController = getRunController();

        runController.addRunStateChangedListener(runStateListener);
        runController.addStepCompletedListener(runStepCompletedListener);
        runStateListener.actionPerformed(null);
    }

    /**
     *
     * @return The run controller used by the frame
     */
    private RunController<V, E> getRunController() {
        if (storageKeeper.getAlgorithm() == null) {
            return null;
        }
        return storageKeeper.getAlgorithm().getRunController();
    }

    /**
     * Updates the frame title, according to the application and document state.
     */
    private void updateTitle() {
        StringBuilder titleBuilder = new StringBuilder(Application.TITLE);

        if (!fileManager.isEmpty()) {
            titleBuilder.append(" - ");

            File currentFile = fileManager.getCurrentFile();

            if (currentFile != null) {
                titleBuilder.append(currentFile.getName());
            } else {
                titleBuilder.append("[untitled]");
            }

            if (fileManager.isModified()) {
                titleBuilder.append(" *");
            }
        }

        setTitle(titleBuilder.toString());
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        inputGraphScrollPane = new javax.swing.JScrollPane();
        inputGraphCanvas = new graphsj.gui.components.GraphCanvas();
        outputFileChooser = new javax.swing.JFileChooser();
        outputGraphScrollPane = new javax.swing.JScrollPane();
        outputGraphCanvas = new graphsj.gui.components.GraphCanvas();
        statusBar = new javax.swing.JPanel();
        statusLabel = new javax.swing.JLabel();
        actionPanel = new javax.swing.JPanel();
        actionSplitter = new javax.swing.JSplitPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        outputArea = new javax.swing.JTextArea();
        menuBar = new javax.swing.JMenuBar();
        graphMenu = new javax.swing.JMenu();
        newItem = new javax.swing.JMenuItem();
        openItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        saveItem = new javax.swing.JMenuItem();
        saveAsItem = new javax.swing.JMenuItem();
        closeItem = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JSeparator();
        exitItem = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        undoItem = new javax.swing.JMenuItem();
        redoItem = new javax.swing.JMenuItem();
        outputMenu = new javax.swing.JMenu();
        clearOutputMenu = new javax.swing.JMenuItem();
        saveOutputItem = new javax.swing.JMenuItem();
        runMenu = new javax.swing.JMenu();
        runItem = new javax.swing.JMenuItem();
        runStepByStepItem = new javax.swing.JMenuItem();
        nextStepItem = new javax.swing.JMenuItem();
        stopItem = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JSeparator();
        verboseItem = new javax.swing.JCheckBoxMenuItem();
        optionsMenu = new javax.swing.JMenu();
        vertexAutoNamingMenu = new javax.swing.JMenu();
        vertexBaseNameItem = new javax.swing.JMenuItem();
        vertexBaseCounterItem = new javax.swing.JMenuItem();
        fontsAndColorsMenu = new javax.swing.JMenu();
        vertexFontSizeItem = new javax.swing.JMenuItem();
        vertexFontColorItem = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JSeparator();
        edgeFontSizeItem = new javax.swing.JMenuItem();
        edgeFontColorItem = new javax.swing.JMenuItem();
        algorithmNameItem = new javax.swing.JMenuItem();
        algorithmOptionsItem = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        helpItem = new javax.swing.JMenuItem();
        algorithmHelpItem = new javax.swing.JMenuItem();
        aboutItem = new javax.swing.JMenuItem();

        inputGraphCanvas.setPreferredSize(new java.awt.Dimension(1500, 1500));
        inputGraphCanvas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                inputGraphCanvasMousePressed(evt);
            }
        });
        inputGraphCanvas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                inputGraphCanvasKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inputGraphCanvasKeyTyped(evt);
            }
        });
        inputGraphScrollPane.setViewportView(inputGraphCanvas);

        outputFileChooser.setDialogTitle("Save output as...");
        outputFileChooser.setDialogType(javax.swing.JFileChooser.SAVE_DIALOG);

        outputGraphCanvas.setEditable(false);
        outputGraphCanvas.setPreferredSize(new java.awt.Dimension(530, 310));
        outputGraphScrollPane.setViewportView(outputGraphCanvas);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle(Application.TITLE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        statusBar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        statusBar.setLayout(new java.awt.BorderLayout());

        statusLabel.setText(" ");
        statusBar.add(statusLabel, java.awt.BorderLayout.LINE_START);

        getContentPane().add(statusBar, java.awt.BorderLayout.PAGE_END);

        actionPanel.setPreferredSize(new java.awt.Dimension(640, 480));
        actionPanel.setLayout(new java.awt.BorderLayout());

        actionSplitter.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        actionSplitter.setResizeWeight(0.75);

        jScrollPane1.setPreferredSize(new java.awt.Dimension(640, 190));

        outputArea.setColumns(20);
        outputArea.setEditable(false);
        outputArea.setLineWrap(true);
        outputArea.setRows(5);
        jScrollPane1.setViewportView(outputArea);

        actionSplitter.setRightComponent(jScrollPane1);

        actionPanel.add(actionSplitter, java.awt.BorderLayout.CENTER);

        getContentPane().add(actionPanel, java.awt.BorderLayout.CENTER);

        graphMenu.setMnemonic('G');
        graphMenu.setText("Graph");

        newItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        newItem.setMnemonic('N');
        newItem.setText("New...");
        newItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newItemActionPerformed(evt);
            }
        });
        graphMenu.add(newItem);

        openItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        openItem.setMnemonic('O');
        openItem.setText("Open...");
        openItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openItemActionPerformed(evt);
            }
        });
        graphMenu.add(openItem);
        graphMenu.add(jSeparator1);

        saveItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        saveItem.setMnemonic('S');
        saveItem.setText("Save");
        saveItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveItemActionPerformed(evt);
            }
        });
        graphMenu.add(saveItem);

        saveAsItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        saveAsItem.setMnemonic('A');
        saveAsItem.setText("Save as...");
        saveAsItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveAsItemActionPerformed(evt);
            }
        });
        graphMenu.add(saveAsItem);

        closeItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        closeItem.setMnemonic('C');
        closeItem.setText("Close");
        closeItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeItemActionPerformed(evt);
            }
        });
        graphMenu.add(closeItem);
        graphMenu.add(jSeparator2);

        exitItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        exitItem.setMnemonic('E');
        exitItem.setText("Exit");
        exitItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitItemActionPerformed(evt);
            }
        });
        graphMenu.add(exitItem);

        menuBar.add(graphMenu);

        editMenu.setMnemonic('E');
        editMenu.setText("Edit");

        undoItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.CTRL_MASK));
        undoItem.setText("Undo");
        undoItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                undoItemActionPerformed(evt);
            }
        });
        editMenu.add(undoItem);

        redoItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Y, java.awt.event.InputEvent.CTRL_MASK));
        redoItem.setText("Redo");
        redoItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoItemActionPerformed(evt);
            }
        });
        editMenu.add(redoItem);

        menuBar.add(editMenu);

        outputMenu.setMnemonic('P');
        outputMenu.setText("Output");

        clearOutputMenu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        clearOutputMenu.setMnemonic('C');
        clearOutputMenu.setText("Clear");
        clearOutputMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearOutputMenuActionPerformed(evt);
            }
        });
        outputMenu.add(clearOutputMenu);

        saveOutputItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        saveOutputItem.setMnemonic('S');
        saveOutputItem.setText("Save output as..");
        saveOutputItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveOutputItemActionPerformed(evt);
            }
        });
        outputMenu.add(saveOutputItem);

        menuBar.add(outputMenu);

        runMenu.setMnemonic('R');
        runMenu.setText("Run");

        runItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F5, 0));
        runItem.setMnemonic('R');
        runItem.setText("Run");
        runItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runItemActionPerformed(evt);
            }
        });
        runMenu.add(runItem);

        runStepByStepItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F7, 0));
        runStepByStepItem.setMnemonic('S');
        runStepByStepItem.setText("Run step by step");
        runStepByStepItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runStepByStepItemActionPerformed(evt);
            }
        });
        runMenu.add(runStepByStepItem);

        nextStepItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F9, 0));
        nextStepItem.setMnemonic('N');
        nextStepItem.setText("Next step");
        nextStepItem.setEnabled(false);
        nextStepItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextStepItemActionPerformed(evt);
            }
        });
        runMenu.add(nextStepItem);

        stopItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F11, 0));
        stopItem.setMnemonic('T');
        stopItem.setText("Stop");
        stopItem.setEnabled(false);
        stopItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopItemActionPerformed(evt);
            }
        });
        runMenu.add(stopItem);
        runMenu.add(jSeparator3);

        verboseItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        verboseItem.setMnemonic('V');
        verboseItem.setSelected(true);
        verboseItem.setText("Verbose");
        runMenu.add(verboseItem);

        menuBar.add(runMenu);

        optionsMenu.setMnemonic('O');
        optionsMenu.setText("Options");

        vertexAutoNamingMenu.setMnemonic('A');
        vertexAutoNamingMenu.setText("Automatic vertex naming");

        vertexBaseNameItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        vertexBaseNameItem.setMnemonic('N');
        vertexBaseNameItem.setText("Set base name...");
        vertexBaseNameItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vertexBaseNameItemActionPerformed(evt);
            }
        });
        vertexAutoNamingMenu.add(vertexBaseNameItem);

        vertexBaseCounterItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        vertexBaseCounterItem.setMnemonic('C');
        vertexBaseCounterItem.setText("Set base counter...");
        vertexBaseCounterItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vertexBaseCounterItemActionPerformed(evt);
            }
        });
        vertexAutoNamingMenu.add(vertexBaseCounterItem);

        optionsMenu.add(vertexAutoNamingMenu);

        fontsAndColorsMenu.setMnemonic('F');
        fontsAndColorsMenu.setText("Fonts and colors");

        vertexFontSizeItem.setText("Edit vertex font size...");
        vertexFontSizeItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vertexFontSizeItemActionPerformed(evt);
            }
        });
        fontsAndColorsMenu.add(vertexFontSizeItem);

        vertexFontColorItem.setText("Edit vertex font color...");
        vertexFontColorItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vertexFontColorItemActionPerformed(evt);
            }
        });
        fontsAndColorsMenu.add(vertexFontColorItem);
        fontsAndColorsMenu.add(jSeparator4);

        edgeFontSizeItem.setText("Edit edge font size...");
        edgeFontSizeItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edgeFontSizeItemActionPerformed(evt);
            }
        });
        fontsAndColorsMenu.add(edgeFontSizeItem);

        edgeFontColorItem.setText("Edit edge font color...");
        edgeFontColorItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edgeFontColorItemActionPerformed(evt);
            }
        });
        fontsAndColorsMenu.add(edgeFontColorItem);

        optionsMenu.add(fontsAndColorsMenu);

        algorithmNameItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        algorithmNameItem.setMnemonic('N');
        algorithmNameItem.setText("Show algorithm name");
        algorithmNameItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                algorithmNameItemActionPerformed(evt);
            }
        });
        optionsMenu.add(algorithmNameItem);

        algorithmOptionsItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.CTRL_MASK));
        algorithmOptionsItem.setMnemonic('O');
        algorithmOptionsItem.setText("Algorithm options...");
        algorithmOptionsItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                algorithmOptionsItemActionPerformed(evt);
            }
        });
        optionsMenu.add(algorithmOptionsItem);

        menuBar.add(optionsMenu);

        helpMenu.setMnemonic('H');
        helpMenu.setText("Help");

        helpItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, 0));
        helpItem.setMnemonic('H');
        helpItem.setText("Help");
        helpItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpItemActionPerformed(evt);
            }
        });
        helpMenu.add(helpItem);

        algorithmHelpItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_H, java.awt.event.InputEvent.CTRL_MASK));
        algorithmHelpItem.setText("Algorithm help");
        algorithmHelpItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                algorithmHelpItemActionPerformed(evt);
            }
        });
        helpMenu.add(algorithmHelpItem);

        aboutItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F12, 0));
        aboutItem.setMnemonic('A');
        aboutItem.setText("About...");
        aboutItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutItemActionPerformed(evt);
            }
        });
        helpMenu.add(aboutItem);

        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitItemActionPerformed
        if (fileManager.canClose()) {
            System.exit(0);
        }
    }//GEN-LAST:event_exitItemActionPerformed

    @Override
    public SafeAdapter<V, E> getInputAdapter() {
        return inputGraphCanvas.getAdapter();
    }

    @Override
    public void setInputAdapter(SafeAdapter<V, E> adapter) {
        inputGraphCanvas.setAdapter(adapter);
        adapter.addGraphModelListener(graphChangeListener);
    }

    /**
     * Takes an "undo" snapshot of the current input adapter
     */
    private void takeUndoSnapshot() {
        setUndoAdapter(inputGraphCanvas.getAdapter());
        setRedoAdapter(null);
    }

    /**
     * Sets the adapter that will be used when invoking the "Undo" edit operation.
     * @param undoAdapter An adapter that is a "snapshot" of the user input, or null to disable this feature.
     */
    private void setUndoAdapter(SafeAdapter<V, E> undoAdapter) {

        if (undoAdapter != null) {
            this.undoAdapter = undoAdapter.clone();
        } else {
            this.undoAdapter = null;
        }
        undoItem.setEnabled(undoAdapter != null);
    }

    /**
     * Sets the adapter that will be used when invoking the "Redo" edit operation.
     * @param redoAdapter An adapter that is a "snapshot" of the user input, or null to disable this feature.
     */
    private void setRedoAdapter(SafeAdapter<V, E> redoAdapter) {

        if (redoAdapter != null) {
            this.redoAdapter = redoAdapter.clone();
        } else {
            this.redoAdapter = null;
        }
        redoItem.setEnabled(redoAdapter != null);
    }

    /**
     * Sets the text in the status bar.
     * @param text The status text. If it is null or an empty string, the status bar is anyway shown.
     */
    private void setStatusText(String text) {
        //This is to keep the status bar always visible
        if (text == null || text.equals("")) {
            text = " ";
        }

        statusLabel.setText(text);
    }

    /**
     * Called whenever a new file is created or an existing file is opened
     */
    private void performFileChangedOperations() {
        registerRunControllerListeners();
        setStatusText("Left-click in the empty space to create a new vertex. Press F1 for more help");

        setUndoAdapter(null);
        setRedoAdapter(null);

        Algorithm<V, E> algorithm = storageKeeper.getAlgorithm();
        URL algorithmHelpUrl = algorithm.getClass().getResource("Help.html");        

        if (algorithmHelpUrl == null) {
            algorithmHelpDialog = null;
        } else {
            algorithmHelpDialog = new HelpDialog(String.format("%s - Online Help", algorithm.getAlgorithmName()), algorithmHelpUrl);
        }
    }

    private void newItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newItemActionPerformed
        if (fileManager.doNew()) {

            performFileChangedOperations();
            inputGraphCanvas.setVertexNameCounter(0);
        }
    }//GEN-LAST:event_newItemActionPerformed

    private void openItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openItemActionPerformed
        if (fileManager.doOpen()) {
            performFileChangedOperations();

            inputGraphCanvas.setVertexNameCounter(inputGraphCanvas.getAdapter().getGraphKeeper().vertexSet().size());
        }
    }//GEN-LAST:event_openItemActionPerformed

    private void saveItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveItemActionPerformed
        fileManager.doSave();
    }//GEN-LAST:event_saveItemActionPerformed

    private void saveAsItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveAsItemActionPerformed
        fileManager.doSaveAs();
    }//GEN-LAST:event_saveAsItemActionPerformed

    private void runItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runItemActionPerformed
        SafeAdapter<V, E> outputAdapter = inputGraphCanvas.getAdapter().clone();
        outputGraphCanvas.setAdapter(outputAdapter);

        try {
            getRunController().fullRun(mainOutput, verboseItem.isSelected());
        } catch (AlgorithmRunException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
        }
    }//GEN-LAST:event_runItemActionPerformed

    private void clearOutputMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearOutputMenuActionPerformed
        outputArea.setText("");
    }//GEN-LAST:event_clearOutputMenuActionPerformed

    private void runStepByStepItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runStepByStepItemActionPerformed
        SafeAdapter<V, E> outputAdapter = inputGraphCanvas.getAdapter().clone();
        outputGraphCanvas.setAdapter(outputAdapter);

        try {
            getRunController().enterStepByStepRun(mainOutput, verboseItem.isSelected());
        } catch (AlgorithmRunException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
        }

    }//GEN-LAST:event_runStepByStepItemActionPerformed

    private void nextStepItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextStepItemActionPerformed
        try {
            getRunController().nextStep();
        } catch (AlgorithmRunException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
        }
    }//GEN-LAST:event_nextStepItemActionPerformed

    private void stopItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopItemActionPerformed
        try {
            getRunController().stopRun();
        } catch (AlgorithmRunException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
        }

        setStatusText("");
    }//GEN-LAST:event_stopItemActionPerformed

    private void closeItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeItemActionPerformed
        fileManager.doClose();
    }//GEN-LAST:event_closeItemActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        exitItemActionPerformed(null);
    }//GEN-LAST:event_formWindowClosing

    private void algorithmNameItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_algorithmNameItemActionPerformed
        MessageProvider.getInstance().showInfoBox(storageKeeper.getAlgorithm().getAlgorithmName());
    }//GEN-LAST:event_algorithmNameItemActionPerformed

    private void saveOutputItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveOutputItemActionPerformed
        outputFileChooser.setSelectedFile(null);
        outputFileChooser.setCurrentDirectory(fileManager.getCurrentFile().getParentFile());

        if (outputFileChooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File chosenFile = outputFileChooser.getSelectedFile();

        if (outputFileChooser.getFileFilter() == outputTextFileFilter) {
            if (!chosenFile.getName().endsWith(".txt")) {
                chosenFile = new File(chosenFile.getAbsolutePath() + ".txt");
            }
        }


        try {
            FileWriter writer = new FileWriter(chosenFile);

            try {
                writer.write(outputArea.getText());
            } finally {
                writer.close();
            }
        } catch (IOException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
        }
    }//GEN-LAST:event_saveOutputItemActionPerformed

    private void aboutItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutItemActionPerformed
        aboutDialog.setVisible(true);
    }//GEN-LAST:event_aboutItemActionPerformed

    private void algorithmOptionsItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_algorithmOptionsItemActionPerformed
        storageKeeper.getAlgorithm().showOptionsDialog();
    }//GEN-LAST:event_algorithmOptionsItemActionPerformed

    private void vertexBaseCounterItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vertexBaseCounterItemActionPerformed
        Integer newCounter = MessageProvider.getInstance().askForNumber("New vertexes will be created with a suffix starting from the following index:", Application.TITLE, inputGraphCanvas.getVertexNameCounter());
        if (newCounter == null) {
            return;
        }

        inputGraphCanvas.setVertexNameCounter(newCounter);
    }//GEN-LAST:event_vertexBaseCounterItemActionPerformed

    private void vertexBaseNameItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vertexBaseNameItemActionPerformed
        String newBaseName = MessageProvider.getInstance().askForString("New vertexes will be created with the following common name root:", Application.TITLE, inputGraphCanvas.getVertexBaseName());

        if (newBaseName == null) {
            return;
        }
        try {
            inputGraphCanvas.setVertexBaseName(newBaseName);
        } catch (InvalidNameException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
        }
    }//GEN-LAST:event_vertexBaseNameItemActionPerformed

    private void helpItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpItemActionPerformed
        mainHelpDialog.setVisible(true);
    }//GEN-LAST:event_helpItemActionPerformed

    private void algorithmHelpItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_algorithmHelpItemActionPerformed
        if (algorithmHelpDialog == null) {
            MessageProvider.getInstance().showInfoBox(String.format("No help is available for '%s'", storageKeeper.getAlgorithm().getAlgorithmName()));
        } else {
            algorithmHelpDialog.setVisible(true);
        }
}//GEN-LAST:event_algorithmHelpItemActionPerformed

    private void undoItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_undoItemActionPerformed
        setRedoAdapter(inputGraphCanvas.getAdapter());

        setInputAdapter(undoAdapter);

        setUndoAdapter(null);
    }//GEN-LAST:event_undoItemActionPerformed

    private void redoItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoItemActionPerformed
        setUndoAdapter(inputGraphCanvas.getAdapter());

        setInputAdapter(redoAdapter);

        setRedoAdapter(null);
    }//GEN-LAST:event_redoItemActionPerformed

    private void inputGraphCanvasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inputGraphCanvasMousePressed
        takeUndoSnapshot();
    }//GEN-LAST:event_inputGraphCanvasMousePressed

    private void inputGraphCanvasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inputGraphCanvasKeyPressed
    }//GEN-LAST:event_inputGraphCanvasKeyPressed

    private void inputGraphCanvasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inputGraphCanvasKeyTyped
        takeUndoSnapshot();
    }//GEN-LAST:event_inputGraphCanvasKeyTyped

    private void vertexFontSizeItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vertexFontSizeItemActionPerformed
        Integer newSize = MessageProvider.getInstance().askForNumber("New font size:", vertexFontSizeItem.getText() , inputGraphCanvas.getAdapter().getVertexFontSize(), 1, null);

        if (newSize == null) {
            return;
        }

        inputGraphCanvas.getAdapter().setVertexFontSize(newSize);
    }//GEN-LAST:event_vertexFontSizeItemActionPerformed

    private void vertexFontColorItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vertexFontColorItemActionPerformed
        Color newColor = JColorChooser.showDialog(null, vertexFontColorItem.getText(), inputGraphCanvas.getAdapter().getVertexFontColor());

        if (newColor == null) {
            return;
        }

        inputGraphCanvas.getAdapter().setVertexFontColor(newColor);
    }//GEN-LAST:event_vertexFontColorItemActionPerformed

    private void edgeFontSizeItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edgeFontSizeItemActionPerformed
        Integer newSize = MessageProvider.getInstance().askForNumber("New font size:", edgeFontSizeItem.getText() , inputGraphCanvas.getAdapter().getEdgeFontSize(), 1, null);

        if (newSize == null) {
            return;
        }

        inputGraphCanvas.getAdapter().setEdgeFontSize(newSize);
    }//GEN-LAST:event_edgeFontSizeItemActionPerformed

    private void edgeFontColorItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edgeFontColorItemActionPerformed
        Color newColor = JColorChooser.showDialog(null, edgeFontColorItem.getText(), inputGraphCanvas.getAdapter().getEdgeFontColor());

        if (newColor == null) {
            return;
        }

        inputGraphCanvas.getAdapter().setEdgeFontColor(newColor);
    }//GEN-LAST:event_edgeFontColorItemActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutItem;
    private javax.swing.JPanel actionPanel;
    private javax.swing.JSplitPane actionSplitter;
    private javax.swing.JMenuItem algorithmHelpItem;
    private javax.swing.JMenuItem algorithmNameItem;
    private javax.swing.JMenuItem algorithmOptionsItem;
    private javax.swing.JMenuItem clearOutputMenu;
    private javax.swing.JMenuItem closeItem;
    private javax.swing.JMenuItem edgeFontColorItem;
    private javax.swing.JMenuItem edgeFontSizeItem;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitItem;
    private javax.swing.JMenu fontsAndColorsMenu;
    private javax.swing.JMenu graphMenu;
    private javax.swing.JMenuItem helpItem;
    private javax.swing.JMenu helpMenu;
    private graphsj.gui.components.GraphCanvas inputGraphCanvas;
    private javax.swing.JScrollPane inputGraphScrollPane;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem newItem;
    private javax.swing.JMenuItem nextStepItem;
    private javax.swing.JMenuItem openItem;
    private javax.swing.JMenu optionsMenu;
    private javax.swing.JTextArea outputArea;
    private javax.swing.JFileChooser outputFileChooser;
    private graphsj.gui.components.GraphCanvas outputGraphCanvas;
    private javax.swing.JScrollPane outputGraphScrollPane;
    private javax.swing.JMenu outputMenu;
    private javax.swing.JMenuItem redoItem;
    private javax.swing.JMenuItem runItem;
    private javax.swing.JMenu runMenu;
    private javax.swing.JMenuItem runStepByStepItem;
    private javax.swing.JMenuItem saveAsItem;
    private javax.swing.JMenuItem saveItem;
    private javax.swing.JMenuItem saveOutputItem;
    private javax.swing.JPanel statusBar;
    private javax.swing.JLabel statusLabel;
    private javax.swing.JMenuItem stopItem;
    private javax.swing.JMenuItem undoItem;
    private javax.swing.JCheckBoxMenuItem verboseItem;
    private javax.swing.JMenu vertexAutoNamingMenu;
    private javax.swing.JMenuItem vertexBaseCounterItem;
    private javax.swing.JMenuItem vertexBaseNameItem;
    private javax.swing.JMenuItem vertexFontColorItem;
    private javax.swing.JMenuItem vertexFontSizeItem;
    // End of variables declaration//GEN-END:variables
}
