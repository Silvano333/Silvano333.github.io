/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.spp;

import graphsj.gui.utils.VertexChooser;
import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.standard.StandardAlgorithm;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.collections.edges.EdgeList;
import graphsj.model.graphkeeper.collections.vertexes.VertexList;
import graphsj.model.graphkeeper.edges.WeightQuantity;
import graphsj.model.graphkeeper.exceptions.EmptyGraphException;

/**
 * Dijkstra's SPP algorithm.
 *
 * @author Gianluca Costa
 */
public class Spp extends StandardAlgorithm<SppVertex, SppEdge> {

    private static final long serialVersionUID = 1L;

    private VertexList<SppVertex> vList;
    private VertexList<SppVertex> pathVertexes;
    private EdgeList<SppVertex, SppEdge> pathEdges;
    private SppVertex vBar;    

    @Override
    protected Iterable<SppEdge> getSolutionEdges() {
        return pathEdges;
    }

    @Override
    public String getAlgorithmName() {
        return "Dijkstra's Shortest Path Problem (SPP)";
    }

    @Override
    public SppKeeper createGraphKeeper() {
        return new SppKeeper();
    }

    @Override
    public void initializeRun(SafeAdapter<SppVertex, SppEdge> adapter, GraphKeeper<SppVertex, SppEdge> graphKeeper, AlgorithmOutput<SppVertex, SppEdge> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(adapter, graphKeeper, output, verboseRun);

        SppKeeper sppKeeper = (SppKeeper) graphKeeper;

        vList = graphKeeper.vertexSet().getSortedList();
        pathVertexes = new VertexList<SppVertex>(true);


        SppVertex startVertex;
        try {
            startVertex = new VertexChooser<SppVertex, SppEdge>(graphKeeper).askForVertex("Choose start vertex:", getAlgorithmName());
            if (startVertex == null) {
                throw new AlgorithmInterruptedException();
            }
        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException(ex);
        }

        pathVertexes.add(startVertex);
        vList.remove(startVertex);

        pathEdges = new EdgeList<SppVertex, SppEdge>();


        //I initialize the vertex labels
        startVertex.setPreviousVertex(null);
        startVertex.setPathLength(WeightQuantity.ZERO);


        for (SppVertex vertex : vList) {
            vertex.setPreviousVertex(startVertex);
            vertex.setPathLength(sppKeeper.getDistanceBetween(startVertex, vertex));
        }

        if (verboseRun) {
            output.printHeader("Legend");
            output.printLine();
            output.printLine("Vbar", "Vertex added to the shortest path in the current step");
            output.printLine();
            output.printHeader("Before step 1");
            output.printLine();
            output.printLine("Path vertexes", pathVertexes.getNamesList() );
            output.printLine("Path edges", pathEdges.getBoundsList());
            output.printLine();
        }
    }

    @Override
    protected void runStep(SafeAdapter<SppVertex, SppEdge> adapter, GraphKeeper<SppVertex, SppEdge> graphKeeper, AlgorithmOutput<SppVertex, SppEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        SppKeeper sppKeeper = (SppKeeper) graphKeeper;

        
        if (verboseRun) {
            output.printHeader("Step " + currentStep);
        }


        //I update the vertex labels starting from step 2, because the vBar vertex is not available at step 1
        if (currentStep > 1) {

            for (SppVertex vertex : vList) {
                WeightQuantity vertexPathLenFromStart = WeightQuantity.sum(vBar.getPathLength(), sppKeeper.getDistanceBetween(vBar, vertex));

                if (vertexPathLenFromStart.getValue() < vertex.getPathLength().getValue()) {
                    vertex.setPathLength(vertexPathLenFromStart);
                    vertex.setPreviousVertex(vBar);
                }
            }
        }


        WeightQuantity minPathLength = WeightQuantity.PLUS_INF;

        //I find out the "vBar" vertex
        for (SppVertex vertex : vList) {
            if (vertex.getPathLength().getValue() < minPathLength.getValue()) {
                vBar = vertex;
                minPathLength = vertex.getPathLength();
            }
        }

        if (vBar == null) {
            throw new AlgorithmRunException("Cannot determine Vbar. Algorithm Error");
        }

        //I update the sets
        pathVertexes.add(vBar);
        vList.remove(vBar);

        pathEdges.add(graphKeeper.getEdge(vBar.getPreviousVertex(), vBar));


        if (verboseRun) {
            output.printLine();
            output.printLine("At the end of the step:");
            output.printLine();
            output.printLine("Vbar", vBar);
            output.printLine("Path vertexes", pathVertexes.getNamesList());
            output.printLine("Path edges", pathEdges.getBoundsList());
            output.printLine();
        }

        if (vList.isEmpty()) {
            throw new AlgorithmEndedException();
        }


        super.runStep(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    protected void onInterruptedRun(SafeAdapter<SppVertex, SppEdge> adapter, GraphKeeper<SppVertex, SppEdge> graphKeeper, AlgorithmOutput<SppVertex, SppEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    protected void onEndRun(SafeAdapter<SppVertex, SppEdge> adapter, GraphKeeper<SppVertex, SppEdge> graphKeeper, AlgorithmOutput<SppVertex, SppEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        output.printLine("The edges used by the shortest paths are: " + pathEdges.getBoundsList());
        super.onEndRun(adapter, graphKeeper, output, verboseRun, currentStep);
    }


    @Override
    protected Iterable<SppEdge> getStepSolutionEdges(int currentStep) {
        return pathEdges;
    }
}
