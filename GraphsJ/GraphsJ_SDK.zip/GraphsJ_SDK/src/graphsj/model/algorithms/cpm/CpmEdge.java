/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.cpm;

import graphsj.gui.components.GraphCanvas;
import graphsj.gui.utils.MessageProvider;
import graphsj.model.algorithms.standard.StandardAlgorithm;
import graphsj.model.algorithms.standard.StandardEdge;
import graphsj.model.graphkeeper.GraphObject;
import graphsj.model.graphkeeper.edges.InvalidWeightException;
import graphsj.model.graphkeeper.edges.NonNegativeWeightedEdge;
import graphsj.model.graphkeeper.edges.WeightQuantity;
import graphsj.model.graphkeeper.exceptions.GraphException;
import graphsj.model.graphkeeper.utils.InvalidNameException;
import graphsj.model.graphkeeper.utils.NameValidator;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The edge class used by CPM.
 *
 * @author Gianluca Costa
 */
public class CpmEdge extends NonNegativeWeightedEdge<CpmVertex, CpmEdge> implements StandardEdge<CpmVertex, CpmEdge> {

    private static final long serialVersionUID = 1L;

    
    private String activityName = "";
    private Cpm algorithm;

    
    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        super.writeExternal(out);
        out.writeUTF(activityName);
    }

    
    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        super.readExternal(in);
        activityName = in.readUTF();
    }




    protected String getActivityName() {
        return activityName;
    }

    
    protected void setActivityName(String activityName) throws InvalidNameException, DuplicateActivityException {
        if (activityName.equals("")) {
            this.activityName = activityName;

            try {
                setWeight(WeightQuantity.ZERO);
            } catch (InvalidWeightException ex) {
                throw new RuntimeException("This exception should NOT occur for a CPM nameless edge", ex);
            }
        }

        
        NameValidator.getInstance().validateName(activityName);
        
        this.activityName = activityName;

        if (getParentKeeper() != null && getParentKeeper().hasConflictingEdge(this)) {
            throw new DuplicateActivityException(String.format("Activity '%s' already exists!", activityName));
        }
    }



    /**
     * @return If the activity name is an empty string, returns an empty string. Otherwise, both the activity name and its duration (the edge weight) are returned in a formatted string.
     */
    @Override
    public String toString() {
        if (activityName.equals("")) {
            return "";
        } else {
            return String.format("%s, %s", activityName, getWeight().toString());
        }
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return The EST for this activity.
     */
    public WeightQuantity getEST() {
        if (algorithm == null) {
            throw new IllegalStateException("No algorithm is running now!");
        }

        if (algorithm.getRunController().getCompletedStep() < Cpm.MAX_LABELING_STEP) {
            throw new IllegalStateException("You cannot call this method during this algorithm step!");
        }
        CpmVertex source = getSource();
        return source.getTmin();
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return The LST for this activity.
     */
    public WeightQuantity getLST() {
        if (algorithm == null) {
            throw new IllegalStateException("No algorithm is running now!");
        }

        if (algorithm.getRunController().getCompletedStep() < Cpm.MAX_LABELING_STEP) {
            throw new IllegalStateException("You cannot call this method during this algorithm step!");
        }


        CpmVertex target = getTarget();
        return WeightQuantity.subtract(target.getTmax(), getWeight());
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return The S for this activity.
     */
    public WeightQuantity getS() {
        return WeightQuantity.subtract(getLST(), getEST());
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return True if the activity is critical.
     */
    public boolean isCritical() {
        return getS().getValue() == 0;
    }

    /**
     * Two CPM edges are compared according to the string order of their activity name.
     * @param other The other edge.
     * @return A proper integer value.
     */
    @Override
    public int compareTo(CpmEdge other) {

        int result = activityName.compareTo(other.activityName);

        if (result != 0) {
            return result;
        }

        return super.compareTo(other);
    }

    @Override
    public void setAlgorithm(StandardAlgorithm<CpmVertex, CpmEdge> algorithm) {
        this.algorithm = (Cpm) algorithm;
    }

    @Override
    protected boolean askUserForEditData(GraphCanvas<CpmVertex, CpmEdge> canvas) throws GraphException {
        String newActivityName = MessageProvider.getInstance().askForString("Activity name:", "Edit edge...", activityName);

        if (newActivityName == null) {
            return false;
        }

        setActivityName(newActivityName);        

        return super.askUserForEditData(canvas);
    }

    @Override
    protected void restoreFromObject(GraphObject<CpmVertex, CpmEdge> obj) {
        CpmEdge other = (CpmEdge) obj;
        activityName = other.activityName;
        
        super.restoreFromObject(obj);
    }


    
}
