/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms;

/**
 * This enum describes the possible states of the algorithm execution.
 *
 * @author Gianluca Costa
 */
public enum RunStateEnum {

    /**
     * The algorithm is not running.
     */
    NOT_RUNNING,
    /**
     * The algorithm is running in full mode: the steps are automatically executed by the program, and the user input is frozen until a solution is reached.
     */
    FULL_RUNNING,
    /**
     * The algorithm is running in step-by-step mode, and the every step is manually requested by the user.
     */
    STEP_RUNNING,
    /**
     * The algorithm execution has ended, and the solution is shown to the user, who must terminate the algorithm.
     */
    ENDED_RUNNING;
}
