/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.fordfulkerson;

import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.startstop.StartStopAlgorithm;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.collections.edges.EdgeList;
import graphsj.model.graphkeeper.collections.vertexes.VertexList;
import graphsj.model.graphkeeper.edges.InvalidWeightException;
import graphsj.model.graphkeeper.edges.WeightQuantity;
import java.util.Collections;

/**
 * Ford-Fulkerson's flow algorithm.
 *
 * @author Gianluca Costa
 */
public class FordFulkerson extends StartStopAlgorithm<FordFulkersonVertex, FordFulkersonEdge> {

    private static final long serialVersionUID = 1L;

    
    private FordFulkersonVertex startVertex;
    private FordFulkersonVertex stopVertex;
    private EdgeList<FordFulkersonVertex, FordFulkersonEdge> incChain;

    @Override
    public void initializeRun(SafeAdapter<FordFulkersonVertex, FordFulkersonEdge> adapter, GraphKeeper<FordFulkersonVertex, FordFulkersonEdge> graphKeeper, AlgorithmOutput<FordFulkersonVertex, FordFulkersonEdge> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(adapter, graphKeeper, output, verboseRun);
        startVertex = getStartVertex();
        stopVertex = getStopVertex();
        incChain = null;
    }

    @Override
    protected Iterable<FordFulkersonEdge> getStepSolutionEdges(int currentStep) {
        return incChain;
    }

    @Override
    protected Iterable<FordFulkersonEdge> getSolutionEdges() {
        return incChain;
    }

    @Override
    protected void runStep(SafeAdapter<FordFulkersonVertex, FordFulkersonEdge> adapter, GraphKeeper<FordFulkersonVertex, FordFulkersonEdge> graphKeeper, AlgorithmOutput<FordFulkersonVertex, FordFulkersonEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        if (verboseRun) {
            output.printLine();
            output.printHeader("Step " + currentStep);
            output.printLine();
        }


        int currentStepInSeries = currentStep % 3;

        if (currentStepInSeries == 1) {


            incChain = null;

            for (FordFulkersonVertex vertex : graphKeeper.vertexSet()) {
                vertex.setLabeled(false);
                vertex.setExplored(false);
            }

            startVertex.setLabeled(true);
            startVertex.setPlusVk(true);
            startVertex.setVk(null);
            startVertex.setDelta(WeightQuantity.PLUS_INF);
            startVertex.setExplored(false);



            //The internal iterations begin here
            for (int intraIndex = 1; intraIndex <= graphKeeper.vertexSet().size(); intraIndex++) {

                FordFulkersonVertex vi = null;

                //Here, I get the first vertex available, and set it as "Vi"
                for (FordFulkersonVertex vertex : graphKeeper.vertexSet().getSortedList()) {

                    if (vertex.isLabeled() && !vertex.isExplored()) {
                        vi = vertex;
                        break;
                    }
                }

                if (vi == null) {
                    break;
                }


                vi.setExplored(true);


                //Here, I set the label for the vertexes belonging to the "gamma+" of Vi
                for (FordFulkersonVertex vj : vi.getOutgoingVertexes()) {

                    if (vj.isLabeled()) {
                        continue;
                    }

                    FordFulkersonEdge edgeIJ = graphKeeper.getEdge(vi, vj);

                    if (edgeIJ.getWeight().getValue() < edgeIJ.getCapacity().getValue()) {
                        vj.setLabeled(true);
                        vj.setPlusVk(true);
                        vj.setVk(vi);
                        vj.setDelta(WeightQuantity.min(vi.getDelta(),  WeightQuantity.subtract(edgeIJ.getCapacity(), edgeIJ.getWeight())));
                    }
                }

                //Here, I set the label for the vertexes belonging to the "gamma-" of Vi
                for (FordFulkersonVertex vj : vi.getIncomingVertexes()) {
                    if (vj.isLabeled()) {
                        continue;
                    }

                    FordFulkersonEdge linkJI = graphKeeper.getEdge(vj, vi);
                    if (linkJI.getWeight().getValue() > 0) {
                        vj.setLabeled(true);
                        vj.setPlusVk(false);
                        vj.setVk(vi);
                        vj.setDelta(WeightQuantity.min(vi.getDelta(), linkJI.getWeight()));
                    }
                }



                if (stopVertex.isLabeled()) {
                    break;
                }

            }


            //The internal iteration has just ended: I can show the resulting edge weights now, as well as the labels
            if (verboseRun) {
                output.printLine("Edges at the end of the step: ");

                for (FordFulkersonEdge edge : graphKeeper.edgeSet()) {
                    output.printLine(String.format("%s -- %s", edge.toVertexString(), edge.toString()));
                }

                output.printLine();
                output.printLine();
            }


            if (!stopVertex.isLabeled()) {
                throw new AlgorithmEndedException();
            }

        } else if (currentStepInSeries == 2) {
            //Now I set up the increasing chain
            incChain = new EdgeList<FordFulkersonVertex, FordFulkersonEdge>();

            FordFulkersonVertex x = stopVertex;
            FordFulkersonVertex y;

            //I update link flows now, by using the "delta*"
            while (x != startVertex) {
                y = x.getVk();
                FordFulkersonEdge augEdge = null;


                if (x.isPlusVk()) {
                    augEdge = graphKeeper.getEdge(y, x);
                } else {
                    augEdge = graphKeeper.getEdge(x, y);
                }


                x = y;
                incChain.add(augEdge);
            }

            if (verboseRun) {
                Collections.reverse(incChain);
                output.printLine("Increasing chain", incChain);
                output.printLine();
            }
        } else { //The last step in a step sequence

            //Here, I get the "delta*" variable for this iteration
            WeightQuantity deltaStar = stopVertex.getDelta();

            FordFulkersonVertex x = stopVertex;
            FordFulkersonVertex y;


            if (verboseRun) {
                output.printLine("Delta*", deltaStar);
            }

            //I update link flows now, by using the "delta*"
            while (x != startVertex) {
                y = x.getVk();
                FordFulkersonEdge augEdge = null;

                try {
                    if (x.isPlusVk()) {
                        augEdge = graphKeeper.getEdge(y, x);
                        augEdge.setWeight(WeightQuantity.sum(augEdge.getWeight(), deltaStar));
                    } else {
                        augEdge = graphKeeper.getEdge(x, y);
                        augEdge.setWeight(WeightQuantity.subtract(augEdge.getWeight(), deltaStar));
                    }
                } catch (InvalidWeightException ex) {
                    throw new AlgorithmRunException(ex);
                }

                x = y;
            }

        }

        super.runStep(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    protected void onEndRun(SafeAdapter<FordFulkersonVertex, FordFulkersonEdge> adapter, GraphKeeper<FordFulkersonVertex, FordFulkersonEdge> graphKeeper, AlgorithmOutput<FordFulkersonVertex, FordFulkersonEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //I can get the resulting sets of vertexes
        VertexList<FordFulkersonVertex> V1 = new VertexList<FordFulkersonVertex>();
        VertexList<FordFulkersonVertex> V2 = new VertexList<FordFulkersonVertex>();


        for (FordFulkersonVertex vertex : graphKeeper.vertexSet().getSortedList()) {
            if (vertex.isLabeled()) {
                V1.add(vertex);
            } else {
                V2.add(vertex);
            }
        }

        V1.sort();
        V2.sort();



        //Now, I also get the maximum flow value
        WeightQuantity maxFlow = WeightQuantity.ZERO;

        incChain = new EdgeList<FordFulkersonVertex, FordFulkersonEdge>();
        for (FordFulkersonEdge edge : graphKeeper.edgeSet()) {

            if (V1.contains(edge.getSource()) && V2.contains(edge.getTarget())) {
                maxFlow = WeightQuantity.sum(maxFlow, edge.getCapacity());
                incChain.add(edge);
            }
        }

        //I print out the results
        output.printLine("V1", V1.getNamesList());
        output.printLine("V2", V2.getNamesList());

        output.printLine();

        output.printLine(String.format("Maximum flow from '%s' to '%s'", startVertex.getName(), stopVertex.getName()), maxFlow);

        output.printLine("\nThe highlighted edges show the min cut.");

        super.onEndRun(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    public String getAlgorithmName() {
        return "Ford-Fulkerson's flow algorithm";
    }

    @Override
    public FordFulkersonKeeper createGraphKeeper() {
        return new FordFulkersonKeeper();
    }

    @Override
    protected void onInterruptedRun(SafeAdapter<FordFulkersonVertex, FordFulkersonEdge> adapter, GraphKeeper<FordFulkersonVertex, FordFulkersonEdge> graphKeeper, AlgorithmOutput<FordFulkersonVertex, FordFulkersonEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }    
}
