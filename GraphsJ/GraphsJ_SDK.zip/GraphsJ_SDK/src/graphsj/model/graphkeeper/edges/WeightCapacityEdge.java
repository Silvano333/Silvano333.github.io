/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.edges;

import graphsj.gui.components.GraphCanvas;
import graphsj.gui.utils.MessageProvider;
import graphsj.model.graphkeeper.GraphObject;
import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.exceptions.GraphException;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * Edge having a weight and a capacity. It always has 0 <= weight <= capacity.
 *
 * @param <V> The vertex class
 * @param <E> The edge class
 * 
 * @author Gianluca Costa
 */
public class WeightCapacityEdge<V extends Vertex<V, E>, E extends WeightCapacityEdge<V, E>> extends NonNegativeWeightedEdge<V, E> {

    private static final long serialVersionUID = 1L;
    
    private WeightQuantity capacity = WeightQuantity.ZERO;

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        super.writeExternal(out);
        out.writeObject(capacity);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        super.readExternal(in);
        capacity = (WeightQuantity) in.readObject();
    }



    /**
     * Sets both the weight and the capacity, in one action.
     * @param newWeight The new value for the weight.
     * @param newCapacity The new value for the capacity.
     * @throws graphsj.model.graphkeeper.edges.InvalidWeightException Thrown if an invalid weight was specified
     * @throws graphsj.model.graphkeeper.edges.InvalidCapacityException Thrown if an invalid capacity was specified, or the relation between weight and capacity was not respected.
     */
    protected void setWeightAndCapacity(WeightQuantity newWeight, WeightQuantity newCapacity) throws InvalidWeightException, InvalidCapacityException {
        if (newWeight.getValue() > newCapacity.getValue()) {
            throw new InvalidCapacityException("You must set Weight <= Capacity");
        }

        super.setWeight(newWeight);

        //Capacity is therefore always >= 0
        capacity = newCapacity;
    }
    

    /**
     * Sets the edge weight.
     * @param weight The new weight. It must be 0 <= weight <= capacity.
     * @throws graphsj.model.graphkeeper.edges.InvalidWeightException Thrown if the new weight is invalid.
     */
    @Override
    public void setWeight(WeightQuantity weight) throws InvalidWeightException {
        try {
            setWeightAndCapacity(weight, capacity);
        } catch (InvalidCapacityException ex) {
            throw new RuntimeException("The current capacity shoud NOT cause an InvalidCapacityException!", ex);
        }
    }

    /**
     *
     * @return The edge capacity.
     */
    public WeightQuantity getCapacity() {
        return capacity;
    }

    /**
     * Sets the edge capacity.
     * @param capacity The new capacity. It must be 0 <= weight <= capacity.
     * @throws graphsj.model.graphkeeper.edges.InvalidCapacityException Thrown if the new capacity is invalid.
     */
    public void setCapacity(WeightQuantity capacity) throws InvalidCapacityException {
        try {
            setWeightAndCapacity(getWeight(), capacity);
        } catch (InvalidWeightException ex) {
            throw new RuntimeException("The current weight shoud NOT cause an InvalidWeightException!", ex);
        }
    }


    

    @Override
    protected boolean askUserForEditData(GraphCanvas<V, E> canvas) throws GraphException {
        WeightQuantity newWeight = MessageProvider.getInstance().askForWeightQuantity("Weight:", "Edit edge...", getWeight(), WeightQuantity.ZERO, null);

        if (newWeight == null) {
            return false;
        }

        
        while (true) {
            WeightQuantity newCapacity = MessageProvider.getInstance().askForWeightQuantity("Capacity:", "Edit edge...", newWeight, WeightQuantity.ZERO, null);

            if (newCapacity == null) {
                return false;
            }

            try {
                setWeightAndCapacity(newWeight, newCapacity);
                return true;

            } catch (InvalidCapacityException ex) {
                MessageProvider.getInstance().showWarningBox(ex);
                
            }
            
        }        
    }

    
    @Override
    protected void restoreFromObject(GraphObject<V, E> obj) {
        WeightCapacityEdge<V, E> other = (WeightCapacityEdge<V, E>) obj;
        capacity = other.capacity;
        
        super.restoreFromObject(obj);                
    }


    /**
     *
     * @return A string containing, in order, the edge weight and the edge capacity.
     */
    @Override
    public String toString() {
        return String.format("(%s, %s)", getWeight().toString(), capacity.toString());
    }
}
