/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.extension;

import java.net.URL;

/**
 * This class manages the class loader to use to load classes at runtime, compatibly with the extension mechanism.
 *
 * @author Gianluca Costa
 */
public final class ClassLoaderKeeper {

    private static ClassLoader loader = ClassLoaderKeeper.class.getClassLoader();

    
    private ClassLoaderKeeper() {
    }
    

    /**
     *
     * @return The class loader to use to dynamically load classes
     */
    public static synchronized ClassLoader getDynamicLoader() {
        return loader;
    }

    /**
     * Sets the class loader to use in order to load classes first from the specified URL (for example, a jar file), then from the default loader.
     * @param sourceURL The URL containing the extension classes.
     */
    public static synchronized void setAlgorithmURL(URL sourceURL) {
        if (sourceURL == null) {
            loader = ClassLoaderKeeper.class.getClassLoader();            
        } else {
            loader = new GraphClassLoader(sourceURL);
        }
    }
}
