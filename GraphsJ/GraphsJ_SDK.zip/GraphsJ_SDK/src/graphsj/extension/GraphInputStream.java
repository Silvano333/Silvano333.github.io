/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.extension;

import graphsj.gui.utils.JarFileChoiceKeeper;
import graphsj.gui.utils.MessageProvider;
import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.net.URL;
import java.util.Map;
import javax.swing.JOptionPane;
import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphCell;

/**
 * Special ObjectInputStream which should be used to deserialize every object in the program.
 * @author Gianluca Costa
 */
public class GraphInputStream extends ObjectInputStream {

    private final JarFileChoiceKeeper jarChooser = new JarFileChoiceKeeper();

    
    public GraphInputStream(InputStream in) throws IOException {
        super(in);

        String urlString = readUTF();



        if (!urlString.equals("")) {
            
            
            URL url = new URL(urlString);
            
            boolean stopLoop = false;

            while(!stopLoop) {

                try {
                    url.getContent();
                    break;
                } catch (IOException ex) {
                    
                    
                    String[] errorCaptions = new String[] {"Choose from local file", "Manually insert URL", "Cancel"};
                    int emergencyResult = MessageProvider.getInstance().showCustomButtons(String.format("The following jar url:\n\n%s\n\ncannot be found.\n\nWhat would you like to do?", url), "Open error", JOptionPane.WARNING_MESSAGE, errorCaptions, 0);

                    switch (emergencyResult) {
                        case JOptionPane.YES_OPTION:                            
                            File jarFile = jarChooser.askToOpen();

                            if (jarFile == null) {
                                stopLoop = true;
                                break;
                            }

                            url = JarFileChoiceKeeper.jarFileToUrl(jarFile);
                            break;

                        case JOptionPane.NO_OPTION:
                            String newUrlString = MessageProvider.getInstance().askForString("Please, input the correct url (in Java format) to reference the jar file:", "Manually provide the jar file", url.toString());

                            if (newUrlString == null) {
                                stopLoop = true;
                                break;
                            }


                            url = new URL(newUrlString);
                            break;

                        case JOptionPane.CANCEL_OPTION:
                            stopLoop = true;
                            break;
                    }
                    
                }                
            }

            ClassLoaderKeeper.setAlgorithmURL(url);
        }
    }

    /**
     * Reads a SafeAdapter from the stream.
     * @param <V> The vertex class
     * @param <E> The edge class
     * @return The adapter read from the stream.
     * @throws java.io.IOException
     * @throws java.lang.ClassNotFoundException
     */
    public <V extends Vertex<V, E>, E extends Edge<V, E>> SafeAdapter<V, E> readAdapter() throws IOException, ClassNotFoundException {

        GraphKeeper<V, E> destGraphKeeper = (GraphKeeper<V, E>) readObject();
        SafeAdapter<V, E> result = new SafeAdapter<V, E>(destGraphKeeper);

        AttributeMap defaultVertexAttributes = (AttributeMap) readObject();
        result.setDefaultVertexAttributes(defaultVertexAttributes);

        AttributeMap defaultEdgeAttributes = (AttributeMap) readObject();
        result.setDefaultEdgeAttributes(defaultEdgeAttributes);
        

        Map<V, AttributeMap> vertexToAttributesMap = (Map<V, AttributeMap>) readObject();

        for (V vertex : destGraphKeeper.vertexSet()) {
            DefaultGraphCell vertexCell = result.getVertexCell(vertex);
            AttributeMap cellAttributes = vertexToAttributesMap.get(vertex);
            vertexCell.setAttributes(cellAttributes);
        }


        Map<E, AttributeMap> edgeToAttributesMap = (Map<E, AttributeMap>) readObject();

        for (E edge : destGraphKeeper.edgeSet()) {
            DefaultEdge edgeCell = result.getEdgeCell(edge);
            AttributeMap cellAttributes = edgeToAttributesMap.get(edge);
            edgeCell.setAttributes(cellAttributes);
        }


        result.cellsChanged();

        return result;
    }

    @Override
    protected Class<?> resolveClass(ObjectStreamClass desc) throws IOException, ClassNotFoundException {
        return ClassLoaderKeeper.getDynamicLoader().loadClass(desc.getName());
    }
}
