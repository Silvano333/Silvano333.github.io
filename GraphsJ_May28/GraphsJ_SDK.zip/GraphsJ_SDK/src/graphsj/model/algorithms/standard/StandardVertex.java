/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.standard;

import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.exceptions.DuplicateObjectException;

/**
 * The vertex class used by the StandardAlgorithm.
 * It shows a custom label during the algorithm execution.
 * @author Gianluca Costa
 */
public abstract class StandardVertex extends Vertex {

    private transient StandardAlgorithm<? extends StandardVertex, ? extends Edge> algorithm;

    public StandardVertex(String name) throws DuplicateObjectException {
        super(name);
    }

    /**
     * Associates the vertex to the specified standard algorithm.
     * This is very useful since the vertex will be able, during the algorithm execution,
     *
     * to retrieve algorithm information such as the RunController and its data.
     * @param algorithm
     */
    void setAlgorithm(StandardAlgorithm algorithm) {
        this.algorithm = algorithm;
    }

    /**
     *
     * @return The string representation of the vertex.
     */
    @Override
    public String toString() {
        if (algorithm != null) {
            return getRunningLabel();
        } else {
            return super.toString();
        }
    }

    /**
     *
     * @return The vertex label to show during the algorithm execution.
     */
    protected abstract String getRunningLabel();

    /**
     *
     * @return The algorithm with which the vertex is associated.
     * It is set by the StandardAlgorithm when the algorithm execution begins.
     */
    protected StandardAlgorithm getAlgorithm() {
        return algorithm;
    }
}
