/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.cpm;

import graphsj.gui.components.GraphCanvas;
import graphsj.gui.utils.MessageProvider;
import graphsj.model.algorithms.standard.StandardAlgorithm;
import graphsj.model.algorithms.standard.StandardEdge;
import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.edges.NonNegativeWeightedEdge;
import graphsj.model.graphkeeper.edges.WeightQuantity;
import graphsj.model.graphkeeper.exceptions.GraphException;
import graphsj.model.graphkeeper.utils.InvalidNameException;
import graphsj.model.graphkeeper.utils.NameValidator;

/**
 * The edge class used by CPM.
 * @author Gianluca Costa
 */
public class CpmEdge extends NonNegativeWeightedEdge implements StandardEdge {

    
    private String activityName = "";
    private transient Cpm algorithm;


    protected String getActivityName() {
        return activityName;
    }

    /**
     * Two CPM edges are equal if they have the same activity name. However, if the activity name is the empty string for both, they are considered different.
     * @param obj The other edge.
     * @return True if the edges are equal.
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof CpmEdge)) {
            return false;
        }

        CpmEdge other = (CpmEdge) obj;

        boolean areNameEqual = activityName.equals(other.activityName);

        if (!areNameEqual) {
            return false;
        }

        return !activityName.equals("");
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean edit(GraphCanvas canvas) throws GraphException {
        String newActivityName = MessageProvider.getInstance().askForString("Activity name:", "Edit edge...", activityName);

        if (newActivityName == null) {
            return false;
        }

        if (newActivityName.equals("")) {
            activityName = newActivityName;
            setWeight(WeightQuantity.ZERO);
            return true;
        }



        try {
            NameValidator.getInstance().validateName(newActivityName);
        } catch (InvalidNameException ex) {
            MessageProvider.getInstance().showWarningBox(ex);
            return false;
        }


        GraphKeeper<CpmVertex, CpmEdge> parentKeeper = getParentKeeper();
        for (CpmEdge edge : parentKeeper.edgeSet()) {
            if (edge == this) {
                continue;
            }

            if (this.equals(edge)) {
                throw new DuplicateActivityException(String.format("Activity '%s' already exists", newActivityName));
            }
        }

        boolean defaultEditResult = super.edit(canvas);

        if (defaultEditResult) {
            activityName = newActivityName;
        }


        return defaultEditResult;
    }

    /**
     * @return If the activity name is an empty string, returns an empty string. Otherwise, both the activity name and its duration (the edge weight) are returned in a formatted string.
     */
    @Override
    public String toString() {
        if (activityName.equals("")) {
            return "";
        } else {
            return String.format("%s, %s", activityName, getWeight().toString());
        }
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return The EST for this activity.
     */
    public WeightQuantity getEST() {
        if (algorithm == null) {
            throw new IllegalStateException("No algorithm is running now!");
        }

        if (algorithm.getRunController().getCompletedStep() < Cpm.MAX_LABELING_STEP) {
            throw new IllegalStateException("You cannot call this method during this algorithm step!");
        }
        CpmVertex source = getSource();
        return source.getTmin();
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return The LST for this activity.
     */
    public WeightQuantity getLST() {
        if (algorithm == null) {
            throw new IllegalStateException("No algorithm is running now!");
        }

        if (algorithm.getRunController().getCompletedStep() < Cpm.MAX_LABELING_STEP) {
            throw new IllegalStateException("You cannot call this method during this algorithm step!");
        }

        
        CpmVertex target = getTarget();
        return WeightQuantity.subtract(target.getTmax(), getWeight());
    }

    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return The S for this activity.
     */
    public WeightQuantity getS() {
        return WeightQuantity.subtract(getLST(), getEST());
    }


    /**
     * You can call this method only after the algorithm has labelled every vertex with the tmax.
     * @return True if the activity is critical.
     */
    public boolean isCritical() {
        return getS().getValue() == 0;
    }

    /**
     * Two CPM edges are compared according to the string order of their activity name.
     * @param o The other edge.
     * @return A proper integer value.
     */
    @Override
    public int compareTo(Edge o) {
        CpmEdge other = (CpmEdge) o;
        return activityName.compareTo(other.activityName);
    }

    @Override
    public void setAlgorithm(StandardAlgorithm algorithm) {
        this.algorithm = (Cpm) algorithm;
    }
}
