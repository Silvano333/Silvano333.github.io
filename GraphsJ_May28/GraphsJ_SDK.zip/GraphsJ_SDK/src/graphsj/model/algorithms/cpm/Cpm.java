/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.cpm;

import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.startstop.StartStopAlgorithm;
import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.collections.edges.EdgeList;
import graphsj.model.graphkeeper.collections.vertexes.VertexList;
import graphsj.model.graphkeeper.edges.WeightQuantity;

/**
 * CPM algorithm.
 * @author Gianluca Costa
 */
public class Cpm extends StartStopAlgorithm<CpmVertex, CpmEdge> {  
    public static final int MIN_LABELING_STEP = 1;
    public static final int MAX_LABELING_STEP = 2;
    
    private transient CpmVertex startVertex;
    private transient CpmVertex stopVertex;
    private transient int numVertexes;
    private transient VertexList<CpmVertex> indexedVertexList;
    private transient EdgeList<CpmEdge> criticalActivities;

    @Override
    protected Iterable<CpmEdge> getStepSolutionEdges(int currentStep) {
        return null;
    }

    @Override
    protected Iterable<CpmEdge> getSolutionEdges() {
        return criticalActivities;
    }

    @Override
    public String getAlgorithmName() {
        return "Task management (CPM)";
    }

    @Override
    public GraphKeeper createGraphKeeper() {
        return new CpmKeeper();
    }

    @Override
    public void initializeRun(SafeAdapter<CpmVertex, CpmEdge> adapter, GraphKeeper<CpmVertex, CpmEdge> graphKeeper, AlgorithmOutput<CpmVertex, CpmEdge> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(adapter, graphKeeper, output, verboseRun);

        startVertex = getStartVertex();
        stopVertex = getStopVertex();

        VertexList<CpmVertex> vList = graphKeeper.vertexSet().getSortedList();
        numVertexes = vList.size();
        indexedVertexList = new VertexList<CpmVertex>();

        startVertex.setIndex(0);
        indexedVertexList.add(startVertex);
        vList.remove(startVertex);


        stopVertex.setIndex(numVertexes - 1);
        vList.remove(stopVertex);

        //Enumerating vertexes
        for (int counter = 1; counter <= numVertexes - 2; counter++) {
            CpmVertex indexedVertex = null;

            for (CpmVertex vertex : vList) {
                boolean vertexHasGammaMinus = false;

                for (Vertex gammaMinusVertex : vertex.getIncomingVertexes()) {
                    if (vList.contains(gammaMinusVertex)) {
                        vertexHasGammaMinus = true;
                        break;
                    }
                }

                if (!vertexHasGammaMinus) {
                    vertex.setIndex(counter);
                    indexedVertex = vertex;
                    indexedVertexList.add(vertex);
                    break;
                }
            }

            if (indexedVertex == null) {
                throw new RuntimeException("Could not index vertexes. Algorithm Error");
            }
            vList.remove(indexedVertex);
        }


        indexedVertexList.add(stopVertex);

    }

    @Override
    protected void runStep(SafeAdapter<CpmVertex, CpmEdge> adapter, GraphKeeper<CpmVertex, CpmEdge> graphKeeper, AlgorithmOutput<CpmVertex, CpmEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        if (verboseRun) {
            output.printHeader("Step " + currentStep);
        }


        if (currentStep == 1) {


            startVertex.setTmin(WeightQuantity.ZERO);

            for (int k = 1; k <= numVertexes - 1; k++) {
                CpmVertex currentVertex = indexedVertexList.get(k);

                WeightQuantity tMin = WeightQuantity.ZERO;

                for (CpmEdge edge : currentVertex.<CpmEdge>getIncomingEdges()) {
                    WeightQuantity val = WeightQuantity.sum(edge.<CpmVertex>getSource().getTmin(), edge.getWeight());
                    if (val.getValue() > tMin.getValue()) {
                        tMin = val;
                    }
                }

                currentVertex.setTmin(tMin);
            }
        } else if (currentStep == 2) {
            stopVertex.setTmax(stopVertex.getTmin());

            for (int k = numVertexes - 2; k >= 0; k--) {
                CpmVertex currentVertex = indexedVertexList.get(k);
                WeightQuantity tMax = WeightQuantity.PLUS_INF;

                for (CpmEdge edge : currentVertex.<CpmEdge>getOutgoingEdges()) {
                    WeightQuantity val =  WeightQuantity.subtract(edge.<CpmVertex>getTarget().getTmax(), edge.getWeight());
                    if (val.getValue() < tMax.getValue()) {
                        tMax = val;
                    }
                }

                currentVertex.setTmax(tMax);
            }
        } else {
            throw new AlgorithmEndedException();
        }

        super.runStep(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    protected void onEndRun(SafeAdapter<CpmVertex, CpmEdge> adapter, GraphKeeper<CpmVertex, CpmEdge> graphKeeper, AlgorithmOutput<CpmVertex, CpmEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        criticalActivities = new EdgeList<CpmEdge>();

        for (CpmEdge edge : graphKeeper.edgeSet()) {
            if (edge.getActivityName().equals("")) {
                continue;
            }
            
            if (edge.isCritical()) {
                criticalActivities.add(edge);
            }
        }

        criticalActivities.sort();


        output.printHeader("Activity Table");
        output.printLine(String.format("%30s\t%15s\t%15s\t%15s\t%15s", "Activity", "Length", "EST", "LST", "S"));
        for (CpmEdge edge : graphKeeper.edgeSet().getSortedList()) {
            if (edge.getActivityName().equals("")) {
                continue;
            }
            
            output.printLine(String.format("%30s\t%15s\t%15s\t%15s\t%15s", edge.getActivityName(), edge.getWeight(), edge.getEST(), edge.getLST(), edge.getS()));
        }
        output.printLine();
        output.printHeader("Critical activities");
        for (CpmEdge edge : criticalActivities) {
            output.printLine(edge.toString());
        }



        super.onEndRun(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    protected void onInterruptedRun(SafeAdapter<CpmVertex, CpmEdge> adapter, GraphKeeper<CpmVertex, CpmEdge> graphKeeper, AlgorithmOutput<CpmVertex, CpmEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }


    @Override
    protected String getCompletedStepDescription(int completedStepNumber) {
        switch (completedStepNumber) {
            case 1:
                return "Minimum times set";
            case 2:
                return "Maximum times set";
            case 3:
                return "Critical activities determined";
            default:
                return null;
        }
    }
}
