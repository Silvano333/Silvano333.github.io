/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.prim;

import graphsj.gui.utils.VertexChooser;
import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.algorithms.standard.StandardAlgorithm;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import graphsj.model.graphkeeper.collections.edges.EdgeList;
import graphsj.model.graphkeeper.collections.vertexes.VertexList;
import graphsj.model.graphkeeper.edges.WeightQuantity;
import graphsj.model.graphkeeper.exceptions.EmptyGraphException;

/**
 * Prim's SST algorithm.
 * 
 * @author Gianluca Costa.
 */
public class PrimSST extends StandardAlgorithm<PrimVertex, PrimEdge> {

    private transient VertexList<PrimVertex> vList;
    private transient VertexList<PrimVertex> wList;
    private transient EdgeList<PrimEdge> treeEdges;
    private transient PrimVertex vBar;

    @Override
    public void initializeRun(SafeAdapter<PrimVertex, PrimEdge> adapter, GraphKeeper<PrimVertex, PrimEdge> graphKeeper, AlgorithmOutput<PrimVertex, PrimEdge> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        super.initializeRun(adapter, graphKeeper, output, verboseRun);

        vList = graphKeeper.vertexSet().getSortedList();


        wList = new VertexList<PrimVertex>(true);
        PrimVertex v1;
        try {
            v1 = new VertexChooser<PrimVertex>(graphKeeper).askForVertex("Choose the initial vertex:", this.toString());
            if (v1 == null) {
                throw new AlgorithmInterruptedException();
            }
        } catch (EmptyGraphException ex) {
            throw new AlgorithmRunException(ex);
        }
        v1.setBestVertex(v1);
        v1.setWeightFromBestVertex(WeightQuantity.ZERO);
        wList.add(v1);
        vList.remove(v1);

        treeEdges = new EdgeList<PrimEdge>(false);

        for (PrimVertex vertex : vList) {
            vertex.setBestVertex(v1);
            vertex.setWeightFromBestVertex(graphKeeper.getDistanceBetween(v1, vertex));
        }


        if (verboseRun) {
            output.printHeader("Legend");
            output.printLine();
            output.printLine("V", "The graph vertexes");
            output.printLine("W", "Vertexes belonging to the tree in the current step");
            output.printLine("E", "Edges belonging to the tree in the current step");
            output.printLine("Vbar", "Vertex added to the tree in the current step");
            output.printLine();

            output.printHeader("Before step 1");

            output.printLine("W", wList.toNamesString());
            output.printLine("V\\W", vList.toNamesString());
            output.printLine("E", treeEdges.toVertexString());
        }
    }

    @Override
    protected void runStep(SafeAdapter<PrimVertex, PrimEdge> adapter, GraphKeeper<PrimVertex, PrimEdge> graphKeeper, AlgorithmOutput<PrimVertex, PrimEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        if (verboseRun) {
            output.printHeader("Step " + currentStep);
            output.printLine();
        }


        for (PrimVertex vertex : vList) {
            WeightQuantity distanceFromVBar = graphKeeper.getDistanceBetween(vBar, vertex);

            if (distanceFromVBar.getValue() < vertex.getWeightFromBestVertex().getValue()) {
                vertex.setBestVertex(vBar);
                vertex.setWeightFromBestVertex(distanceFromVBar);
            }
        }


        //Now, I determine the "vBar" vertex        
        WeightQuantity minBest = WeightQuantity.PLUS_INF;
        vBar = null;

        for (PrimVertex vertex : vList) {
            if (vertex.getWeightFromBestVertex().getValue() < minBest.getValue()) {
                vBar = vertex;
                minBest = vertex.getWeightFromBestVertex();
            }
        }

        if (vBar == null) {
            throw new AlgorithmRunException("Could not determine vBar! Error in the algorithm!");
        }


        //I add vBar to the "W" set, and remove it from the "V" set
        wList.add(vBar);
        vList.remove(vBar);

        //I also add the corresponding link to E
        PrimEdge chosenEdge = graphKeeper.getEdge(vBar, vBar.getBestVertex());
        treeEdges.add(chosenEdge);

        if (verboseRun) {
            output.printLine("At the end of the step:");
            output.printLine();
            output.printLine("Vbar", vBar);
            output.printLine("W", wList.toNamesString());
            output.printLine("V \\ W", vList.toNamesString());
            output.printLine("E", treeEdges.toVertexString());
            output.printLine();
            output.printLine();
        }

        if (vList.isEmpty()) {
            throw new AlgorithmEndedException();
        }

        super.runStep(adapter, graphKeeper, output, verboseRun, currentStep);

    }

    @Override
    protected void onEndRun(SafeAdapter<PrimVertex, PrimEdge> adapter, GraphKeeper<PrimVertex, PrimEdge> graphKeeper, AlgorithmOutput<PrimVertex, PrimEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Now, I find out the total weight of the spanning tree
        int totalWeight = 0;
        for (PrimEdge edge : treeEdges) {
            totalWeight += edge.getWeight().getValue();
        }


        output.printLine("The branches of the spanning tree are: " + treeEdges.toVertexString());
        output.printLine("The total weight of the spanning tree is: " + totalWeight);

        super.onEndRun(adapter, graphKeeper, output, verboseRun, currentStep);
    }

    @Override
    public String getAlgorithmName() {
        return "Prim's Short Spanning Tree (SST)";
    }

    @Override
    protected void onInterruptedRun(SafeAdapter<PrimVertex, PrimEdge> adapter, GraphKeeper<PrimVertex, PrimEdge> graphKeeper, AlgorithmOutput<PrimVertex, PrimEdge> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        //Just do nothing
    }

    @Override
    protected Iterable<PrimEdge> getSolutionEdges() {
        return treeEdges;
    }

    @Override
    public GraphKeeper createGraphKeeper() {
        return new PrimKeeper();
    }


    @Override
    protected Iterable<PrimEdge> getStepSolutionEdges(int currentStep) {
        return treeEdges;
    }
}