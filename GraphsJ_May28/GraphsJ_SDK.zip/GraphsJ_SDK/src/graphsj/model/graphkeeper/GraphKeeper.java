/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.model.graphkeeper.collections.edges.EdgeSet;
import graphsj.model.graphkeeper.collections.vertexes.VertexSet;
import graphsj.model.graphkeeper.edges.WeightQuantity;
import graphsj.model.graphkeeper.exceptions.DuplicateVertexException;
import graphsj.model.graphkeeper.exceptions.DuplicateEdgeException;
import graphsj.model.graphkeeper.utils.VertexPair;
import graphsj.model.graphkeeper.edges.WeightedEdge;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.jgrapht.graph.DefaultListenableGraph;

/**
 * This class wraps a JGraphT graph to grant many features and advanced type checking.
 * It is the only object used to represent a graph in this library.
 * 
 * @param <V> The vertex class
 * @param <E> The edge class
 * @author Gianluca Costa
 */
public abstract class GraphKeeper<V extends Vertex, E extends Edge> implements Externalizable {

    private transient DefaultListenableGraph<Vertex, Edge> graph;

    /**
     * Creates the graph keeper.
     */
    public GraphKeeper() {
        this.graph = (DefaultListenableGraph<Vertex, Edge>) createGraph();
    }

    /**
     *
     * @return The edge class used by the keeper.
     */
    public abstract Class<E> getEdgeClass();

    /**
     *
     * @return The vertex class used by the keeper.
     */
    public abstract Class<V> getVertexClass();

    /**
     *
     * @return The graph underlying the keeper.
     */
    public abstract DefaultListenableGraph<V, E> createGraph();

    /**     
     * @return A copy of the internal vertex set. The vertexes in the new set are the original ones, NOT cloned.
     */
    public VertexSet<V> vertexSet() {        
        return new VertexSet<V>((Set<V>)graph.vertexSet());
    }


    /**
     * @return A copy of the internal edge set. The edges in the new set are the original ones, NOT cloned.
     */
    public EdgeSet<E> edgeSet() {
        return new EdgeSet<E>((Set<E>)graph.edgeSet());
    }

    /**
     *
     * @return The underlying graph
     */
    DefaultListenableGraph<V, E> getGraph() {
        return (DefaultListenableGraph<V, E>) graph;
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {

        Set<Vertex> vertexes = new HashSet<Vertex>(graph.vertexSet());
        out.writeObject(vertexes);


        Map<Edge, VertexPair> edgeMap = new HashMap<Edge, VertexPair>();

        for (Edge edge : graph.edgeSet()) {
            VertexPair edgePair = new VertexPair(graph.getEdgeSource(edge), graph.getEdgeTarget(edge));
            edgeMap.put(edge, edgePair);
        }

        out.writeObject(edgeMap);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        graph = (DefaultListenableGraph<Vertex, Edge>) createGraph();
        Set<Vertex> vertexes = (Set<Vertex>) in.readObject();
        Map<Edge, VertexPair> edgeMap = (Map<Edge, VertexPair>) in.readObject();


        for (Vertex vertex : vertexes) {
            try {
                vertex.attach(this);
            } catch (DuplicateVertexException ex) {
                throw new RuntimeException(ex);
            }
        }


        for (Entry<Edge, VertexPair> entry : edgeMap.entrySet()) {
            Edge edge = entry.getKey();

            VertexPair pair = entry.getValue();
            try {
                edge.attach(this, pair.getSource(), pair.getTarget());
            } catch (DuplicateEdgeException ex) {
                throw new RuntimeException(ex);
            }
        }

    }

    /**
     * Searches in the underlying graph for vertexes conflicting with the specified vertex.
     * Two vertexes are conflicting if they are equal AND at different memory addresses.
     * @param vertex The vertex.
     * @return
     */
    boolean hasConflictingVertex(V vertex) {
        for (Vertex currentVertex : graph.vertexSet()) {
            if ((currentVertex != vertex) && currentVertex.equals(vertex)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Gets the edge between two vertexes
     * @param sourceVertex The source vertex
     * @param targetVertex The target vertex
     * @return The edge
     */
    public E getEdge(Vertex sourceVertex, Vertex targetVertex) {
        return (E) graph.getEdge(sourceVertex, targetVertex);
    }

    /**
     * Returns the distance between 2 vertexes, if the underlying edge class is or subclasses WeightedEdge.
     * @param startVertex The start vertex
     * @param stopVertex The target vertex
     * @return The weight of the edge between the 2 vertexes, or an infinite value if there is no edge between them.
     */
    public WeightQuantity getDistanceBetween(V startVertex, V stopVertex) {
        if (!WeightedEdge.class.isAssignableFrom(getEdgeClass())) {
            throw new RuntimeException("Cannot compute vertex distance if the graph does not support weights!");
        }

        WeightedEdge edge = (WeightedEdge) graph.getEdge(startVertex, stopVertex);

        if (edge == null) {
            return WeightQuantity.PLUS_INF;
        } else {
            return edge.getWeight();
        }
    }
}
