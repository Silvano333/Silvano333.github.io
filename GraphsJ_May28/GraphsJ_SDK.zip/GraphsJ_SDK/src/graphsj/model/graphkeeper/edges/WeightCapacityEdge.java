/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.edges;

import graphsj.gui.components.GraphCanvas;
import graphsj.gui.utils.MessageProvider;
import graphsj.model.graphkeeper.exceptions.GraphException;

/**
 * Edge having a weight and a capacity. It always has 0 <= weight <= capacity.
 * @author Gianluca Costa
 */
public class WeightCapacityEdge extends NonNegativeWeightedEdge {

    private WeightQuantity capacity = WeightQuantity.ZERO;

    /**
     * Sets the edge weight.
     * @param weight The new weight. It must be 0 <= weight <= capacity.
     * @throws graphsj.model.graphkeeper.edges.InvalidWeightException Thrown if the new weight is invalid.
     */
    @Override
    public void setWeight(WeightQuantity weight) throws InvalidWeightException {

        if (weight.getValue() > capacity.getValue()) {
            throw new InvalidWeightException("You must set Weight <= Capacity");
        }

        super.setWeight(weight);
    }

    /**
     *
     * @return The edge capacity.
     */
    public WeightQuantity getCapacity() {
        return capacity;
    }

    /**
     * Sets the edge capacity.
     * @param capacity The new capacity. It must be capacity >= weight.
     * @throws graphsj.model.graphkeeper.edges.InvalidCapacityException Thrown if the new capacity is invalid.
     */
    public void setCapacity(WeightQuantity capacity) throws InvalidCapacityException {
        if (capacity.getValue() < getWeight().getValue()) {
            throw new InvalidCapacityException("You must set Capacity >= Weight");
        }

        this.capacity = capacity;
    }

    @Override
    public boolean edit(GraphCanvas canvas) throws GraphException {

        WeightQuantity newWeight = MessageProvider.getInstance().askForWeightQuantity("Weight:", "Edit edge...", getWeight());

        if (newWeight == null) {
            return false;
        }

        WeightQuantity newCapacity;
        while (true) {
            newCapacity = MessageProvider.getInstance().askForWeightQuantity("Capacity:", "Edit edge...", newWeight);

            if (newCapacity == null) {
                return false;
            }

            if (newCapacity.getValue() < newWeight.getValue()) {
                MessageProvider.getInstance().showWarningBox("You must set Weight <= Capacity");
                continue;
            }

            break;
        }


        WeightQuantity oldCapacity = capacity;
        capacity = newCapacity;

        try {
            setWeight(newWeight);
        } catch (InvalidWeightException ex) {
            capacity = oldCapacity;
            throw ex;
        }

        return true;
    }

    /**
     *
     * @return A string containing, in order, the edge weight and the edge capacity.
     */
    @Override
    public String toString() {
        return String.format("(%s, %s)", getWeight().toString(), capacity.toString());
    }
}
