/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.gui.components.GraphCanvas;
import graphsj.gui.utils.MessageProvider;
import graphsj.model.graphkeeper.exceptions.DuplicateVertexException;
import graphsj.model.graphkeeper.exceptions.GraphException;
import graphsj.model.graphkeeper.utils.NameValidator;
import java.util.HashSet;
import java.util.Set;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.graph.DefaultListenableGraph;

/**
 * The generic graph vertex.
 * 
 * @author Gianluca Costa
 */
public class Vertex extends GraphObject implements Comparable<Vertex> {

    private String name;

    /**
     * Creates the vertex.
     * @param name The vertex name. It should uniquely identify the vertex in a graph.
     */
    public Vertex(String name) {
        this.name = name;
    }

    /**
     *
     * @return The vertex name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the vertex name.
     * @param name The vertex name
     * @throws graphsj.model.graphkeeper.exceptions.DuplicateVertexException Thrown if the vertex is attached to a graph keeper containing a vertex with the same name
     */
    public void setName(String name) throws DuplicateVertexException {
        GraphKeeper parentKeeper = getParentKeeper();


        if (parentKeeper != null && parentKeeper.hasConflictingVertex(this)) {
            throw new DuplicateVertexException();
        }

        this.name = name;
    }

    /**
     * Attaches the vertex to a graph keeper.
     * @param graphKeeper The GraphKeeper object to attach the vertex to.
     * @throws graphsj.model.graphkeeper.exceptions.DuplicateVertexException Thrown if a vertex equal to this already belongs to the graph.
     */
    public void attach(GraphKeeper graphKeeper) throws DuplicateVertexException {
        if (graphKeeper.getVertexClass() != getClass()) {
            throw new IllegalArgumentException("The vertex class of the GraphKeeper does not match");
        }


        if (getParentKeeper() != null) {
            throw new RuntimeException(String.format("Could not attach vertex '%s', since it's already attached to a graph", name));
        }


        if (graphKeeper.hasConflictingVertex(this)) {
            throw new DuplicateVertexException(String.format("Vertex '%s' already belongs to the graph.", name));
        }


        if (!graphKeeper.getGraph().addVertex(this)) {
            throw new DuplicateVertexException();
        }


        setParentKeeper(graphKeeper);

    }

    /**
     * Detaches the vertex from the GraphKeeper it is currently attached to.
     */
    @Override
    public void detach() {
        GraphKeeper parentKeeper = getParentKeeper();

        if (parentKeeper == null) {
            throw new RuntimeException(String.format("Vertex '%s' is already detached", name));
        }


        if (!parentKeeper.getGraph().removeVertex(this)) {
            throw new RuntimeException("Could not detach the vertex from the graph");
        }


        setParentKeeper(null);
    }

    @Override
    public boolean edit(GraphCanvas canvas) throws GraphException {

        String newVertexName = MessageProvider.getInstance().askForString("Vertex name:", "Edit vertex name...", name);
        if (newVertexName == null || newVertexName.equals(name)) {
            return false;
        }

        NameValidator.getInstance().validateName(newVertexName);


        setName(newVertexName);
        return true;
    }

    /**
     *
     * @return The vertex name
     */
    @Override
    public String toString() {
        return name;
    }

    /**
     * By default, vertexes are sorted according to their names.
     * @param o The other vertex
     * @return A suitable integer value.
     */
    @Override
    public int compareTo(Vertex o) {
        return name.compareTo(o.name);
    }

    

    /**
     *
     * @param <V> The vertex class
     * @return A set containing the source vertex of each incoming edge
     */
    public <V extends Vertex> Set<V> getIncomingVertexes() {
        Set<V> result = new HashSet<V>();

        Set<Edge> incomingEdges = getParentKeeper().getGraph().incomingEdgesOf(this);

        for (Edge edge : incomingEdges) {
            result.add((V) getParentKeeper().getGraph().getEdgeSource(edge));
        }

        return result;
    }

    /**
     *
     * @param <V> The vertex class
     * @return A set containing the target vertex of each outcoming edge
     */
    public <V extends Vertex> Set<V> getOutgoingVertexes() {
        Set<V> result = new HashSet<V>();
        Set<Edge> outgoingEdges = getParentKeeper().getGraph().outgoingEdgesOf(this);

        for (Edge edge : outgoingEdges) {
            result.add((V) getParentKeeper().getGraph().getEdgeTarget(edge));
        }

        return result;
    }

    /**
     *
     * @param <E> The edge class
     * @return The set of all the outgoing edges
     */
    public <E extends Edge> Set<E> getOutgoingEdges() {
        return (Set<E>) getParentKeeper().getGraph().outgoingEdgesOf(this);
    }

    /**
     * @return The number of outgoing edges
     */
    public int getOutDegree() {
        return getParentKeeper().getGraph().outDegreeOf(this);
    }

    /**
     *
     * @param <E> The edge class
     * @return The set of incoming edges
     */
    public <E extends Edge> Set<E> getIncomingEdges() {
        return (Set<E>) getParentKeeper().getGraph().incomingEdgesOf(this);
    }

    /**
     *
     * @return The number of incoming edges
     */
    public int getInDegree() {
        return getParentKeeper().getGraph().inDegreeOf(this);
    }

    /**
     *
     * @return The number of incoming edges plus the number of outgoing edges
     */
    public int getDegree() {
        DefaultListenableGraph<Vertex, Edge> graph = getParentKeeper().getGraph();
        if (graph instanceof UndirectedGraph) {
            return graph.degreeOf(this);
        } else {
            return graph.inDegreeOf(this) + graph.outDegreeOf(this);
        }

    }

    /**
     *
     * @param <E> The edge class
     * @return The set of the incoming and outgoing edges
     */
    public <E extends Edge> Set<E> getEdges() {
        return (Set<E>) getParentKeeper().getGraph().edgesOf(this);
    }

    /**
     * Two vertexes are equal if they have the same name.
     * @param obj The other vertex
     * @return True if the vertexes have the same name
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Vertex)) {
            return false;
        }

        Vertex other = (Vertex) obj;


        return this.name.equals(other.name);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
