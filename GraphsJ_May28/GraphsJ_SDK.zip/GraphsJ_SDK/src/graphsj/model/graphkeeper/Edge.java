/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.gui.components.GraphCanvas;
import graphsj.model.graphkeeper.exceptions.DuplicateEdgeException;
import graphsj.model.graphkeeper.exceptions.GraphException;

/**
 * The generic graph edge.
 *
 * @author Gianluca Costa
 */
public class Edge extends GraphObject implements Comparable<Edge> {

    /**
     * Attaches the edge to a GraphKeeper.
     * @param graphKeeper The keeper to attach the edge to
     * @param sourceVertex The edge source vertex
     * @param targetVertex The edge target vertex
     * @throws graphsj.model.graphkeeper.exceptions.DuplicateEdgeException Thrown if an other vertex equal to this was already attached to the same graph keeper
     */
    public void attach(GraphKeeper graphKeeper, Vertex sourceVertex, Vertex targetVertex) throws DuplicateEdgeException {

        if (getParentKeeper() != null) {
            throw new IllegalStateException("Could not attach the edge, since it's already attached to a GraphKeeper");
        }


        if (graphKeeper.getEdgeClass() != getClass()) {
            throw new IllegalArgumentException("The edge class of the GraphKeeper does not match");
        }

        if (!graphKeeper.getGraph().addEdge(sourceVertex, targetVertex, this)) {
            throw new DuplicateEdgeException();
        }

        setParentKeeper(graphKeeper);
    }

    @Override
    public void detach() {
        GraphKeeper parentKeeper = getParentKeeper();

        if (parentKeeper == null) {
            throw new IllegalStateException("The edge is already detached");
        }

        if (!parentKeeper.getGraph().removeEdge(this)) {
            throw new IllegalStateException("Could not detach the edge from the graph");
        }

        setParentKeeper(null);
    }

    /**
     * @return A string containing - in order - the source vertex and the target vertex.
     */
    public String toVertexString() {
        verifyParentKeeperNotNull();

        return String.format("(%s, %s)", getSource().getName(), getTarget().getName());
    }

    /**
     *
     * @param <V> The vertex class
     * @return The source vertex
     */
    public <V extends Vertex> V getSource() {
        verifyParentKeeperNotNull();

        return (V) getParentKeeper().getGraph().getEdgeSource(this);
    }

    /**
     *
     * @param <V> The vertex class
     * @return The target vertex
     */
    public <V extends Vertex> V getTarget() {
        verifyParentKeeperNotNull();

        return (V) getParentKeeper().getGraph().getEdgeTarget(this);
    }

    /**
     * By default, the edges are sorted according to:
     * <ol>
     *  <li>The comparison of each source vertex</li>
     *  <li>The comparison of each target vertex</li>
     * </ol>
     * @param o The other edge
     * @return The required integer value (see description above)
     */
    @Override
    public int compareTo(Edge o) {
        int sourceComparison = getSource().compareTo(o.getSource());

        if (sourceComparison == 0) {
            return getTarget().compareTo(o.getTarget());
        }

        return sourceComparison;
    }
    

    /**
     * By default, two edges are equal if both their source and target vertex are equal.
     * @param obj The other edge
     * @return True if the edges are equal.
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Edge)) {
            return false;
        }

        Edge other = (Edge) obj;

        return (this.getSource().equals(other.getSource()) && this.getTarget().equals(other.getTarget()));
    }

    /**
     * @return The edge's hash code
     */
    @Override
    public int hashCode() {
        return super.hashCode();
    }

    /**
     * By default, just a refresh happens when the user tries to edit the edge
     * @param canvas
     * @return True
     * @throws graphsj.model.graphkeeper.exceptions.GraphException
     */
    @Override
    public boolean edit(GraphCanvas canvas) throws GraphException {
        return true;
    }

    
}
