/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.extension.GraphInputStream;
import graphsj.extension.GraphOutputStream;
import java.awt.Color;
import java.awt.Font;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.List;
import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.GraphConstants;
import org.jgrapht.ext.JGraphModelAdapter;

/**
 * Enables a GraphKeeper to be shown on a GraphCanvas, and adds some useful graphical features.
 * In order to serialize/deserialize an adapter, you must use the specific methods provided by GraphInputStream and GraphOutputStream, NOT
 * the default writeObject()/readObject() methods.
 * @author Gianluca Costa
 * @param <V> The vertex class
 * @param <E> The edge class
 */
public class SafeAdapter<V extends Vertex, E extends Edge> extends JGraphModelAdapter<V, E> implements Cloneable, Externalizable {

    private final GraphKeeper<V, E> graphKeeper;

    /**
     * Creates the adapter, and sets some default values for both vertex cells and edge cells.
     * @param graphKeeper The GraphKeeper to show via this adapter.
     */
    public SafeAdapter(GraphKeeper<V, E> graphKeeper) {
        super(graphKeeper.getGraph());
        this.graphKeeper = graphKeeper;

        AttributeMap defaultEdgeAttributes = getDefaultEdgeAttributes();
        GraphConstants.setEditable(defaultEdgeAttributes, false);
        GraphConstants.setConnectable(defaultEdgeAttributes, false);
        GraphConstants.setDisconnectable(defaultEdgeAttributes, false);
        GraphConstants.setMoveable(defaultEdgeAttributes, false);
        GraphConstants.setFont(defaultEdgeAttributes, new Font("Arial", Font.BOLD, 15));        
        GraphConstants.setForeground(defaultEdgeAttributes, Color.BLACK);

        AttributeMap defaultVertexAttributes = getDefaultVertexAttributes();        
        GraphConstants.setFont(defaultVertexAttributes, new Font("Arial", Font.BOLD, 15));
        GraphConstants.setAutoSize(defaultVertexAttributes, true);
        GraphConstants.setEditable(defaultVertexAttributes, false);
        GraphConstants.setInset(defaultVertexAttributes, 5);
    }

    /**
     *
     * @return The underlying graph keeper.
     */
    public GraphKeeper<V, E> getGraphKeeper() {
        return graphKeeper;
    }

    /**
     * Resets the style of every edge in the graph to the default values, except a few elements such as the edge points.
     */
    public void resetEdgesToDefaultStyle() {
        AttributeMap defaultEdgeAttributes = getDefaultEdgeAttributes();


        for (E edge : graphKeeper.edgeSet()) {
            DefaultEdge edgeCell = getEdgeCell(edge);

            AttributeMap oldEdgeAttributes = edgeCell.getAttributes();
            AttributeMap newEdgeAttributes = (AttributeMap) defaultEdgeAttributes.clone();


            List edgePoints = GraphConstants.getPoints(oldEdgeAttributes);
            if (edgePoints != null) {
                GraphConstants.setPoints(newEdgeAttributes, edgePoints);
            }
            edgeCell.setAttributes(newEdgeAttributes);
        }

        cellsChanged();

    }

    /**
     * Clones the adapter, but NOT its listeners.
     * @return A clone of the adapter, WITHOUT the original listeners.
     */
    @Override
    public SafeAdapter<V, E> clone() {
        try {
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            GraphOutputStream outputStream = new GraphOutputStream(byteStream);
            outputStream.writeAdapter(this);

            GraphInputStream inputStream = new GraphInputStream(new ByteArrayInputStream(byteStream.toByteArray()));
            return (SafeAdapter<V, E>) inputStream.readAdapter();

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Refreshes the specified cell.
     * @param cell The cell (of a vertex or an edge) to refresh.
     */
    public void cellChanged(DefaultGraphCell cell) {
        cellsChanged(new Object[]{cell});
    }

    /**
     * Refreshes all the cells (both of vertexes and edges) of the adapter.
     */
    public void cellsChanged() {
        cellsChanged(getRoots().toArray());
    }

    /**
     * Sets the width and the color of the specified edge
     * @param edge The edge IN THE MODEL to make up.
     * @param width The requested width.
     * @param color The requested color.
     */
    public void makeUpEdge(E edge, int width, Color color) {

        DefaultEdge edgeCell = getEdgeCell(edge);

        AttributeMap edgeAttributes = (AttributeMap) edgeCell.getAttributes().clone();
        GraphConstants.setLineWidth(edgeAttributes, width);
        GraphConstants.setLineColor(edgeAttributes, color);
        edgeCell.setAttributes(edgeAttributes);

        cellChanged(edgeCell);
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        throw new UnsupportedOperationException("You must serialize your adapter by using the writeAdapter() method of a GraphOutputStream");
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        throw new UnsupportedOperationException("You must deserialize your adapter by using the readAdapter() method of a GraphInputStream.");
    }
}
