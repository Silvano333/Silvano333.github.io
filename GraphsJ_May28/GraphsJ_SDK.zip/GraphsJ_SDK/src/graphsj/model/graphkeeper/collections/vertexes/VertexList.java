/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */

package graphsj.model.graphkeeper.collections.vertexes;

import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.collections.GraphObjectList;
import java.util.Collection;
import java.util.Collections;

/**
 * A list of vertexes.
 * @param <V> The vertex class.
 * @author Gianluca Costa
 */
public class VertexList<V extends Vertex> extends GraphObjectList<V> {
    /**
     * Creates a new vertex list, which is NOT kept sorted.
     */
    public VertexList() {
        super();
    }


    /**
     * Creates a new vertex list.
     * @param keepSorted If true, calls to the overridden insertion methods will cause the list to be automatically sorted.
     */
    public VertexList(boolean keepSorted) {
        super(keepSorted);
    }


    /**
     * Creates a new vertex list with the elements of another collection. The list is NOT kept sorted.
     * @param sourceCollection The source collection.
     */
    public VertexList(Collection<V> sourceCollection) {
        super(sourceCollection);
    }


    /**
     * Creates a new vertex list with the elements of another collection.
     * @param sourceCollection The source collection.
     * @param keepSorted If true, calls to the overridden insertion methods will cause the list to be automatically sorted.
     */
    public VertexList(Collection<V> sourceCollection, boolean keepSorted) {
        super(sourceCollection, keepSorted);
    }

   

    
    /**
     * @return A string representation of the list of just the vertex names
     */
    public String toNamesString() {
        if (isEmpty()) {
            return "[]";
        }

        StringBuilder builder = new StringBuilder();
        builder.append("[");

        for (V vertex : this) {
            builder.append(vertex.getName());
            builder.append(", ");
        }
       
        builder.delete(builder.length() - 2, builder.length());        

        builder.append("]");
        return builder.toString();

    }

    @Override
    public void sort() {
        Collections.sort(this);
    }

}
