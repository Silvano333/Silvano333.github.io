/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.collections.edges;

import graphsj.model.graphkeeper.*;
import java.util.Collection;
import java.util.HashSet;

/**
 * A set of edges.
 * 
 * @param <E> The edge class.
 * @author Gianluca Costa
 */
public class EdgeSet<E extends Edge> extends HashSet<E> {

    /**
     * Creates an empty edge set
     */
    public EdgeSet() {
        super();
    }

    /**
     * Create an edge set with the same edge instances contained in the collection argument.
     * @param edgeCollection The source collection.
     */
    public EdgeSet(Collection<E> edgeCollection) {
        super(edgeCollection);
    }


    /**
     * @return A list of the sorted edges.
     * The edges in the list are exactly the instances contained in this collection.
     * The returned list is not kept sorted.
     */
    public EdgeList<E> getSortedList() {
        EdgeList<E> sortedEdges = new EdgeList<E>(this, false);
        sortedEdges.sort();
        return sortedEdges;
    }


    /**
     * @param keepSorted True if the returned list must be kept sorted when using its overridden insertion methods.
     * @return A list of the sorted edges.
     * The edges in the list are exactly the instances contained in this collection.
     */
    public EdgeList<E> getSortedList(boolean keepSorted) {
        EdgeList<E> sortedEdges = new EdgeList<E>(this, keepSorted);
        if (!keepSorted) {
            sortedEdges.sort();
        }
        return sortedEdges;
    }

    /**
     * @return A string in the form [edge1.toVertexString(), ..., edgeN.toVertexString()]
     */
    public String toVertexString() {
        if (isEmpty()) {
            return "[]";
        }
        
        StringBuilder builder = new StringBuilder();
        builder.append("[");

        for (E edge : this) {
            builder.append(edge.toVertexString());
            builder.append(", ");
        }

        
        builder.delete(builder.length() - 2, builder.length());
        
        builder.append("]");
        return builder.toString();
    }

}
