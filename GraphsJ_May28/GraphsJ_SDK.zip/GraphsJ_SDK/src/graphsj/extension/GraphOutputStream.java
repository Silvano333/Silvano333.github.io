/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.extension;

import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import org.jgraph.graph.AttributeMap;
import org.jgraph.graph.DefaultEdge;
import org.jgraph.graph.DefaultGraphCell;

/**
 * Special ObjectOutputStream which adds a method to write a SafeAdapter to the stream.
 * @author Gianluca Costa
 */
public class GraphOutputStream<V extends Vertex, E extends Edge> extends ObjectOutputStream {

    public GraphOutputStream(OutputStream out) throws IOException {
        super(out);

        ClassLoader currentLoader = ClassLoaderKeeper.getDynamicLoader();
        if (currentLoader instanceof GraphClassLoader) {
            GraphClassLoader graphClassLoader = (GraphClassLoader) currentLoader;
            String jarURLString = graphClassLoader.getURLs()[0].toString();
            writeUTF(jarURLString);
        } else {
            writeUTF("");
        }
    }

    /**
     * Writes the specified adapter to the stream.
     * <b>Note: </b>The listeners in the adapter are NOT saved. Just its graph is serialized.
     * @param adapter The adapter,
     * @throws java.io.IOException
     */
    public void writeAdapter(SafeAdapter<V, E> adapter) throws IOException {

        GraphKeeper<V, E> graphKeeper = adapter.getGraphKeeper();
        writeObject(graphKeeper);

        Map<Vertex, AttributeMap> vertexToAttributesMap = new HashMap<Vertex, AttributeMap>();

        for (Vertex vertex : graphKeeper.vertexSet()) {
            DefaultGraphCell vertexCell = adapter.getVertexCell(vertex);
            AttributeMap cellAttributes = vertexCell.getAttributes();
            vertexToAttributesMap.put(vertex, cellAttributes);
        }


        Map<Edge, AttributeMap> edgeToAttributesMap = new HashMap<Edge, AttributeMap>();

        for (E edge : graphKeeper.edgeSet()) {
            DefaultEdge edgeCell = adapter.getEdgeCell(edge);
            AttributeMap edgeAttributes = edgeCell.getAttributes();
            edgeToAttributesMap.put(edge, edgeAttributes);
        }


        writeObject(vertexToAttributesMap);
        writeObject(edgeToAttributesMap);
    }
}
