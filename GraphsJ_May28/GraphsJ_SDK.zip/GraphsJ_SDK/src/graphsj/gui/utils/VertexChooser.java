/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.utils;

import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.Vertex;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.exceptions.EmptyGraphException;
import javax.swing.JOptionPane;

/**
 * This class enables the user to interactively choose a vertex in a graph.
 * It is very useful during algorithm execution.
 * @author Gianluca Costa
 * @param <V> The vertex class
 */
public class VertexChooser<V extends Vertex> {

    private final GraphKeeper graphKeeper;

    /**
     * Creates the chooser.
     * @param graphKeeper The underlying graph keeper.
     */
    public VertexChooser(GraphKeeper<V, ? extends Edge> graphKeeper) {
        this.graphKeeper = graphKeeper;
    }

    /**
     * Asks the user to choose a vertex name from the sorted list of all the graph keeper vertexes.
     * @param message The dialog prompt
     * @param title The dialog title
     * @return The chosen vertex, or null if the dialog was cancelled.
     * @throws graphsj.model.graphkeeper.exceptions.EmptyGraphException Thrown if the graph has no vertexes.
     */
    public V askForVertex(String message, String title) throws EmptyGraphException {
        Object[] vertexes = graphKeeper.vertexSet().getSortedList().toArray();

        if (vertexes.length == 0) {
            throw new EmptyGraphException();
        }

        return (V) JOptionPane.showInputDialog(null, message, title, JOptionPane.QUESTION_MESSAGE, null, vertexes, vertexes[0]);
    }
}
