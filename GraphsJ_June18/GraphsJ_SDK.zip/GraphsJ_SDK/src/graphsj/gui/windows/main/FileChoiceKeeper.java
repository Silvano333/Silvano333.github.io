/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.windows.main;

import graphsj.Application;
import graphsj.gui.utils.MessageProvider;
import java.io.File;
import javax.swing.JFileChooser;

/**
 * This class asks the user to open/save files, keeping track of the last directory in which a file was opened/saved via the same keeper.
 * Additionally, if the user has selected the default filter (passed to the constructor), and did not specify its extension in the file name, the extension will automatically be added.
 * @author Gianluca Costa
 */
public class FileChoiceKeeper {
    private File lastDir;
    private final EnhancedFileFilter fileFilter;

    public FileChoiceKeeper(EnhancedFileFilter fileFilter) {
        this.fileFilter = fileFilter;
    }


    /**
     * Shows the user an "open" dialog
     * @return The file chosen by the user, or null if the dialog was cancelled
     */
    public File askToOpen() {
        return askForFile(JFileChooser.OPEN_DIALOG);
    }
    

    /**
     * Shows the user a "save" dialog.
     * @return The file chosen by the user, or null if the dialog was cancelled. If the user selected the default filter, its extension will be added if missing in the user input.
     */
    public File askToSave() {
        return askForFile(JFileChooser.SAVE_DIALOG);
    }


    /**
     * Asks the user for a file path. If the user is saving and chooses the default filter, its default document extension is automatically added if not provided by the user.
     * @param dialogMode Tells the dialog how to appear and behave. It can only be either JFileChooser.OPEN_DIALOG or JFileChooser.SAVE_DIALOG.
     * @return The file chosen by the user, or null if the user cancelled the dialog.
     */
    private File askForFile(int dialogMode) {
        if (dialogMode != JFileChooser.OPEN_DIALOG && dialogMode != JFileChooser.SAVE_DIALOG) {
            throw new IllegalArgumentException("Illegal dialog mode");
        }

        
        JFileChooser chooser = new JFileChooser();
        chooser.addChoosableFileFilter(fileFilter);


        if (lastDir != null) {
            chooser.setCurrentDirectory(lastDir);
        }



        for(;;) {
            int dialogResult;

            switch (dialogMode) {
                case JFileChooser.OPEN_DIALOG:
                    chooser.setDialogTitle("Open graph document...");
                    dialogResult = chooser.showOpenDialog(null);
                    break;


                case JFileChooser.SAVE_DIALOG:
                    chooser.setDialogTitle("Save graph document...");
                    dialogResult = chooser.showSaveDialog(null);
                    break;

                default:
                    throw new IllegalArgumentException("Invalid dialog mode for the JFileChooser!");
            }


            if (dialogResult != JFileChooser.APPROVE_OPTION) {
                return null;
            }

            File chosenFile = chooser.getSelectedFile();
            lastDir = chosenFile.getParentFile();

            
            if (dialogMode == JFileChooser.OPEN_DIALOG) {
                return chosenFile;
            }

            if (chooser.getFileFilter() == fileFilter && !chosenFile.getName().endsWith(fileFilter.getExtension())) {
                chosenFile = new File(chosenFile.getAbsolutePath() + fileFilter.getExtension());
            }


            if (chosenFile.exists()) {
                Boolean overwriteResult = MessageProvider.getInstance().askQuestion(String.format("File '%s' already exists.\nWould you really like to overwrite it?", chosenFile.getName()), Application.TITLE, false, false);

                if (!overwriteResult) {
                    continue;
                }
            }

            return chosenFile;
        }        
    }
}
