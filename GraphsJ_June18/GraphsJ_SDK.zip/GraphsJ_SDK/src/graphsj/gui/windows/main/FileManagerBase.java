/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.gui.windows.main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * The base class for FileManager. It grants proper encapsulation of its state fields.
 * @author Gianluca Costa
 */
class FileManagerBase {

    /**
     * The default extension for the files created by the application.
     */
    public static final String GRAPH_FILE_EXT = ".grj";
    private boolean empty = true;
    private File currentFile;
    private boolean modified;
    private final List<ActionListener> stateChangeListeners = new ArrayList<ActionListener>();

    /**
     * Adds a listener which is called when the file manager changes its state.
     * @param listener The listener.
     */
    public synchronized void addStateChangeListener(ActionListener listener) {
        stateChangeListeners.add(listener);
    }

    /**
     * Removes a listener which is called when the file manager changes its state.
     * @param listener The listener.
     */
    public synchronized void removeStateChangeListener(ActionListener listener) {
        stateChangeListeners.remove(listener);
    }

    /**
     * Sets the internal state of the file manager.
     * @param empty True if no document is active.
     * @param currentFile The file name related with the document. It MUST be null if "empty" == true.
     * @param modified True if the document has been modified since the last time it was saved.
     */
    protected void setState(boolean empty, File currentFile, boolean modified) {
        if (empty && currentFile != null) {
            throw new IllegalArgumentException("Cannot set up the file name if there is no document!");
        }

        boolean stateChanged = (empty != this.empty) || (currentFile != this.currentFile) ||
                (currentFile != null && !currentFile.equals(this.currentFile)) ||
                (this.currentFile != null && !this.currentFile.equals(currentFile)) ||
                (modified != this.modified);

        this.empty = empty;
        this.currentFile = currentFile;
        this.modified = modified;

        if (stateChanged) {
            ActionEvent event = new ActionEvent(this, 0, null);

            for (ActionListener listener : stateChangeListeners) {
                listener.actionPerformed(event);
            }
        }
    }

    /**
     * @return The file currently open.
     */
    public File getCurrentFile() {
        return currentFile;
    }

    /**
     * @return True if no document is open
     */
    public boolean isEmpty() {
        return empty;
    }

    /**
     * @return True if the document was modified since the last save.
     */
    public boolean isModified() {
        return modified;
    }

    /**
     * Makes the file manager modified, provided that it is not empty (an exception is thrown in this case).
     * If it is already modified, it does nothing.
     */
    public void makeModified() {
        if (empty) {
            throw new IllegalStateException("Cannot make the document modified, since it's empty!");
        }

        setState(empty, currentFile, true);
    }
}
