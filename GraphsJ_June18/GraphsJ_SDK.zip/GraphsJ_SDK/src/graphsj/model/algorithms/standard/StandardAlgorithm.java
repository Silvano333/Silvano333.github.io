/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.algorithms.standard;

import graphsj.model.algorithms.Algorithm;
import graphsj.model.algorithms.AlgorithmEndedException;
import graphsj.model.algorithms.AlgorithmInterruptedException;
import graphsj.model.algorithms.AlgorithmOutput;
import graphsj.model.algorithms.AlgorithmRunException;
import graphsj.model.graphkeeper.Edge;
import graphsj.model.graphkeeper.GraphKeeper;
import graphsj.model.graphkeeper.SafeAdapter;
import java.awt.Color;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * This descendant extends the raw Algorithm class, providing many useful features, in particular:
 * <ul>
 *  <li>The algorithm won't run if the graph is empty or at least one vertex is unconnected</li>
 *  <li>A standard options dialog is provided</li>
 *  <li>At the end of each step, you can choose a set of edges to graphically enhance in order to show the user a partial solution</li>
 *  <li>At the end of the algorithm, the edges making up the final solution are enhanced with a different color</li>
 *  <li>Some automated console output (e.g: The algorithm name is written to console, vertex labels are shown at the end of each step in verbose output, etc.)</li>
 * </ul>
 *
 * @param <V> The vertex class.
 * @param <E> The edge class.
 * 
 * @author Gianluca Costa
 */
public abstract class StandardAlgorithm<V extends StandardVertex<V, E>, E extends Edge<V, E> & StandardEdge<V, E>> extends Algorithm<V, E> {

    /**
     * The default color used to enhance the edges contained in the partial (step-by-step) solutions of an algorithm.
     */
    protected static final Color DEFAULT_STEP_SOLUTION_EDGE_COLOR = Color.GREEN;
    /**
     * The default color used to enhance the edges contained in the final solution.
     */
    protected static final Color DEFAULT_SOLUTION_EDGE_COLOR = Color.RED;
    /**
     * The default width used to enhance edges.
     */
    protected static final int ENHANCED_EDGE_WIDTH = 4;

    private StandardOptionsDialog<V, E> optionsDialog;

    
    //These fields must be saved with the algorithm, since they contain user-defined options.
    private Color stepSolutionEdgeColor = DEFAULT_STEP_SOLUTION_EDGE_COLOR;
    private Color solutionEdgeColor = DEFAULT_SOLUTION_EDGE_COLOR;


    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        super.writeExternal(out);
        out.writeObject(stepSolutionEdgeColor);
        out.writeObject(solutionEdgeColor);
    }


    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        super.readExternal(in);
        stepSolutionEdgeColor = (Color) in.readObject();
        solutionEdgeColor = (Color) in.readObject();
    }

    /**
     * 
     * @return The color of the edges contained in the final solution.
     */
    protected Color getSolutionEdgeColor() {
        return solutionEdgeColor;
    }

    /**
     *
     * @return The color of the edges contained in partial (step-by-step) solutions.
     */
    protected Color getStepSolutionEdgeColor() {
        return stepSolutionEdgeColor;
    }

    @Override
    public void initializeRun(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        output.printSeparator();
        output.printLine(getAlgorithmName().toUpperCase());
        output.printLine();


        if (graphKeeper.vertexSet().isEmpty()) {
            throw new AlgorithmRunException("Cannot run the algorithm - the graph is empty!");
        }

        adapter.resetEdgesToDefaultStyle();

        for (V vertex : graphKeeper.vertexSet()) {
            if (vertex.getDegree() == 0) {
                throw new AlgorithmRunException(String.format("Vertex '%s' is not connected to other vertexes", vertex.getName()));
            }
        }
    }

    @Override
    protected void postInitializeRun(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {

        for (V vertex : graphKeeper.vertexSet()) {
            vertex.setAlgorithm(this);
        }


        for (E edge : graphKeeper.edgeSet()) {
            edge.setAlgorithm(this);
        }
    }

    @Override
    protected void runStep(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun, int currentStep) throws AlgorithmRunException, AlgorithmInterruptedException, AlgorithmEndedException {
        adapter.resetEdgesToDefaultStyle();

        Iterable<E> stepSolutionEdges = getStepSolutionEdges(currentStep);


        if (stepSolutionEdges != null) {
            adapter.beginUpdate();

            try {
                for (E edge : stepSolutionEdges) {
                    adapter.makeUpEdge(edge, ENHANCED_EDGE_WIDTH, stepSolutionEdgeColor);
                }
            } finally {
                adapter.endUpdate();
            }
        }

        if (verboseRun) {
            output.printLine();

            output.printLine("Vertex labels at the end of the current step are:");
            output.printLine();
            for (V vertex : graphKeeper.vertexSet().getSortedList()) {
                output.printLine(vertex.toString());
            }
            output.printLine();

        }
    }

    @Override
    protected void onEndRun(SafeAdapter<V, E> adapter, GraphKeeper<V, E> graphKeeper, AlgorithmOutput<V, E> output, boolean verboseRun, int currentStep) throws AlgorithmRunException {
        adapter.resetEdgesToDefaultStyle();

        Iterable<E> solutionEdges = getSolutionEdges();

        if (solutionEdges != null) {
            try {
                adapter.beginUpdate();

                if (solutionEdges != null) {
                    for (E edge : solutionEdges) {
                        adapter.makeUpEdge(edge, ENHANCED_EDGE_WIDTH, solutionEdgeColor);
                    }
                }
            } finally {
                adapter.endUpdate();
            }
        }

        output.printLine();
        output.printSeparator();
    }

    @Override
    public boolean showOptionsDialog() {
        if (optionsDialog == null) {
            optionsDialog = new StandardOptionsDialog<V, E>(this);
            optionsDialog.setTitle(String.format("Options for '%s'...", getAlgorithmName()));
        }

        optionsDialog.setVisible(true);
        boolean result = optionsDialog.isConfirmed();

        if (result) {
            stepSolutionEdgeColor = optionsDialog.getStepSolutionColor();
            solutionEdgeColor = optionsDialog.getSolutionColor();
        }

        return result;
    }

    /**
     *
     * @return The edges contained in the final solution, or null if you don't want to enhance edges.
     * They will be drawn thicker and in a different color.
     */
    protected abstract Iterable<E> getSolutionEdges();

    /**
     *
     * @param currentStep The step currently executing, whose solution edges we must now provide.
     * @return The edges contained in the partial solution related with the current step, or null if you don't want to enhance edges.
     * They will be drawn thicker and in a different color.
     */
    protected abstract Iterable<E> getStepSolutionEdges(int currentStep);

    /**
     *
     * @param completedStepNumber The number of the step just completed by the RunController. Steps are numbered from 1 (step number 0 is reserved to the initialization pseudo-step).
     * @return By default, it returns null.
     */
    @Override
    protected String getCompletedStepDescription(int completedStepNumber) {
        return null;
    }
}
