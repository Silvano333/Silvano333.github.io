/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.extension.GraphInputStream;
import graphsj.extension.GraphOutputStream;
import graphsj.gui.components.GraphCanvas;
import graphsj.model.graphkeeper.exceptions.GraphException;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The generic graph element. It can be assigned to a GraphKeeper.
 * 
 * @param <V> The vertex class
 * @param <E> The edge class
 *
 * @author Gianluca Costa
 */
public abstract class GraphObject<V extends Vertex<V, E>, E extends Edge<V, E>> implements Externalizable, Cloneable {

    /**
     * The parent keeper must NOT be serialized. The GraphKeeper itself will serialize its objects, then will reattach them when deserializing.
     */
    private GraphKeeper<V, E> parentKeeper;

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        if (!(out instanceof GraphOutputStream)) {
            throw new IllegalArgumentException("GraphObject instances must be serialized via a GraphOutputStream");
        }
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        if (!(in instanceof GraphInputStream)) {
            throw new IllegalArgumentException("GraphObject instances must be deserialized via a GraphInputStream");
        }
    }


    /**
     * @return The parent keeper.
     */
    protected GraphKeeper<V, E> getParentKeeper() {
        return parentKeeper;
    }

    /**
     * Assigns the parent keeper. If the object is already assigned to a keeper, you have to detach it before assigning it to a different keeper.
     * @param parentKeeper The new parent keeper     
     */
    void setParentKeeper(GraphKeeper<V, E> parentKeeper) {
        if (parentKeeper != null && this.parentKeeper != null) {
            throw new IllegalStateException("You have to detach the object from its keeper before assigning it to another keeper");
        }
        this.parentKeeper = parentKeeper;
    }

    /**
     * Clones the object.
     * @return The clone of the object, <b>detached from any keeper</b>
     */
    @Override
    protected GraphObject<V, E> clone() {
        try {
            GraphObject<V, E> result = (GraphObject<V, E>) super.clone();
            result.parentKeeper = null;
            return result;
        } catch (CloneNotSupportedException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Enables the user to interactively edit the object. This is a final method because it provides a transactional behaviour.
     * More precisely, you have to implement the method askUserForEditData(), in which you must ask the user for the data AND change the object's state.
     * If your method returns false, or throws a GraphException, this method will do the same, but before that it will restore the object's initial state
     * by using an internal clone of the object and the method restoreFromObject(), that you have to implement/override, too.
     * @param canvas The canvas on which the user is currently working.
     * @return True if the object has been changed (and the GUI needs to be refreshed), false otherwise.
     * @throws graphsj.model.graphkeeper.exceptions.GraphException Thrown if the user inputs invalid data.
     */
    public final boolean edit(GraphCanvas<V, E> canvas) throws GraphException {
        GraphObject<V, E> initialStateObject = clone();
      
        try {
            if (!askUserForEditData(canvas)) {
                restoreFromObject(initialStateObject);
                return false;
            }

            return true;
        } catch (GraphException ex) {
            restoreFromObject(initialStateObject);
            throw ex;
        }        
    }

    /**
     * Override this method to restore the object's core fields from a clone.
     * @param obj The object's clone.
     */
    protected abstract void restoreFromObject(GraphObject<V, E> obj);

    /**
     * Override this method to ask the user for the data needed to interactively edit this object.
     * @param canvas The canvas on which the user is currently working.
     * @return True if the object has been changed (and the GUI needs to be refreshed), false otherwise.
     * @throws graphsj.model.graphkeeper.exceptions.GraphException Thrown if the user inputs invalid data.
     */
    protected abstract boolean askUserForEditData(GraphCanvas<V, E> canvas) throws GraphException;
    

    /**
     * Detaches the object from its current keeper.
     */
    public abstract void detach();

    /**
     * Throws an exception if the parent keeper is null
     */
    protected void verifyParentKeeperNotNull() {
        if (parentKeeper == null) {
            throw new IllegalStateException("The graph object's parent keeper must not be null");
        }
    }
}
