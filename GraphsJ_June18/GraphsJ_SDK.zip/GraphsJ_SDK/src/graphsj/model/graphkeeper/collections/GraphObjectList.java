/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper.collections;

import graphsj.model.graphkeeper.GraphObject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 * A list of graph objects.
 * 
 * @param <O> The graph object class.
 *
 * @author Gianluca Costa
 */
public abstract class GraphObjectList<O extends GraphObject<?, ?> & Comparable<O>> extends ArrayList<O> {

    private boolean keepSorted;

    /**
     * Creates a new list, which is NOT kept sorted.
     */
    public GraphObjectList() {
        this(false);
    }

    /**
     * Creates a new list.
     * @param keepSorted If true, calls to the overridden insertion methods will cause the list to be automatically sorted.
     */
    public GraphObjectList(boolean keepSorted) {
        this.keepSorted = keepSorted;
    }

    /**
     * Creates a new list with the elements of another collection. The list is NOT kept sorted.
     * @param sourceCollection The source collection.
     */
    public GraphObjectList(Collection<O> sourceCollection) {
        this(sourceCollection, false);
    }

    /**
     * Creates a new list with the elements of another collection, and immediately sorts it if "keepSorted" is true.
     * @param sourceCollection The source collection.
     * @param keepSorted If true, calls to the overridden insertion methods will cause the list to be automatically sorted.
     */
    public GraphObjectList(Collection<O> sourceCollection, boolean keepSorted) {
        super(sourceCollection);
        this.keepSorted = keepSorted;

        if (keepSorted) {
            sort();
        }
    }

    @Override
    public boolean add(O e) {
        return tryToSort(super.add(e));
    }

    @Override
    public void add(int index, O element) {
        super.add(index, element);
        tryToSort(true);
    }

    /**
     * Receives the result of the call to a boolean superclass method.
     * If this result is true AND the list must be kept sorted, it sorts the list.
     * @param superCallResult The result of a superclass method call.
     * @return The value of superCallResult itself.
     */
    private boolean tryToSort(boolean superCallResult) {
        if (superCallResult && keepSorted) {
            sort();
        }

        return superCallResult;
    }

    /**
     * @return True if the list must be kept sorted.
     */
    public boolean isKeepSorted() {
        return keepSorted;
    }

    /**
     * Sorts the list.
     */
    public final void sort() {
        Collections.sort(this);
    }
}
