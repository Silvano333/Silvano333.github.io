/*
 * Copyright © 2009 Gianluca Costa
 *
 * This file is part of GraphsJ.
 *
 * GraphsJ is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GraphsJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GraphsJ. If not, see <http://www.gnu.org/licenses/>.
 */
package graphsj.model.graphkeeper;

import graphsj.model.graphkeeper.exceptions.DuplicateEdgeException;
import graphsj.model.graphkeeper.utils.VertexPair;

/**
 * The generic graph edge.
 *
 * @param <V> The vertex class
 * @param <E> The edge class
 * 
 * @author Gianluca Costa
 */
public abstract class Edge<V extends Vertex<V, E>, E extends Edge<V, E>> extends GraphObject<V, E> implements Comparable<E> {

    /**
     * Attaches the edge to a GraphKeeper.
     * 
     * @param graphKeeper The keeper to attach the edge to
     * @param sourceVertex The edge source vertex
     * @param targetVertex The edge target vertex
     *
     * @throws graphsj.model.graphkeeper.exceptions.DuplicateEdgeException Thrown if an edge conflicting with this one was already attached to the same graph keeper
     */
    public void attach(GraphKeeper<V, E> graphKeeper, V sourceVertex, V targetVertex) throws DuplicateEdgeException {

        if (graphKeeper.getEdgeClass() != getClass()) {
            throw new IllegalArgumentException("The edge class of the GraphKeeper does not match");
        }
        

        if (getParentKeeper() != null) {
            throw new IllegalStateException("Could not attach the edge, since it's already attached to a GraphKeeper");
        }

        
        
        if (graphKeeper.hasConflictingEdge((E)this)) {
            throw new DuplicateEdgeException();
        }

        if (!graphKeeper.getGraph().addEdge(sourceVertex, targetVertex, (E) this)) {
            throw new DuplicateEdgeException("Cannot add the edge to the internal graph");
        }

        setParentKeeper(graphKeeper);
    }

    
    @Override
    public void detach() {
        GraphKeeper<V, E> parentKeeper = getParentKeeper();

        if (parentKeeper == null) {
            throw new IllegalStateException("The edge is already detached");
        }        

        if (!parentKeeper.getGraph().removeEdge((E)this)) {
            throw new IllegalStateException("Could not detach the edge from the graph");
        }

        setParentKeeper(null);
    }

    /**
     * @return A string containing - in order - the source vertex and the target vertex.
     */
    public String toVertexString() {
        verifyParentKeeperNotNull();

        return String.format("(%s, %s)", getSource().getName(), getTarget().getName());
    }

    /**
     *
     * @return The source vertex
     */
    public V getSource() {
        verifyParentKeeperNotNull();

        return getParentKeeper().getGraph().getEdgeSource((E)this);
    }

    /**
     *
     * @return The target vertex
     */
    public V getTarget() {
        verifyParentKeeperNotNull();

        return getParentKeeper().getGraph().getEdgeTarget((E) this);
    }


    /**
     * @return The vertex pair containing the edge bounds
     */
    public VertexPair<V> getBounds() {
        return new VertexPair<V>(getSource(), getTarget());
    }

    /**
     * By default, the edges are sorted according to:
     * <ol>
     *  <li>The comparison of each source vertex</li>
     *  <li>The comparison of each target vertex</li>
     * </ol>
     * @param o The other edge
     * @return The suitable integer value (see description above)
     */
    @Override
    public int compareTo(E o) {
        int sourceComparison = getSource().compareTo(o.getSource());

        if (sourceComparison == 0) {
            return getTarget().compareTo(o.getTarget());
        }

        return sourceComparison;
    }
      
    
}
