package mainProject;



import dataLogic.XmlDataLogic;
import presentation.ApplicationStatusManager;
import presentation.PresentationMatrix;
import userInterface.*;

/**
 * Classe che contiene il main dell'applicazione
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class MainClass 
{
	
	public static void main(String[] args)
	{
		
		XmlDataLogic dataLogic = new XmlDataLogic();
		dataLogic.load();
		int[][] c = dataLogic.getData();
		
		
		
		PresentationMatrix presMatr = new PresentationMatrix(c);
		
		ApplicationStatusManager statusManager = new ApplicationStatusManager(presMatr);
		MainForm form=statusManager.getForm();
		form.init();
		form.show();
		
	}
	
}
