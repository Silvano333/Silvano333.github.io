package userInterface;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


/**
 * Form per l`immisione della dimensione della matrice dei
 * costi da interfaccia
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class MatrixDimInputForm extends JDialog{
	protected JTextField matDimTF;
	protected JButton ok;
	protected int matDim;
	
	/**Costruttore
	 * @param owner chi e' il proprietario della finestra
	 * @param modal se la finestra e' modale
	 */
	public MatrixDimInputForm(JFrame owner, boolean modal){
		super(owner,modal);
		
		this.matDim=-1;
		
		//pannello della finestra
		Container c = this.getContentPane();
		c.setLayout(new BorderLayout());
		JPanel panel=new JPanel();
		panel.setLayout(new BorderLayout());
		c.add("Center",panel);
		
		//creo un box dati che mi contenga le informazioni
		Box dati=new Box(BoxLayout.Y_AXIS);
		
		//Campo per Dimensione matrice
		JLabel matDim=new JLabel("Matrix dimension:");
		this.matDimTF=new JTextField();
		dati.add(matDim);
		dati.add(matDimTF);
		
		//label nascosta che compare in caso di errori
		JLabel error=new JLabel();
		error.setVisible(false);
		dati.add(error);
		
		//metto il bottone ok in fondo
		ok=new JButton("ok");
		ok.addActionListener(new OKListener(error,this));
		
		panel.add(dati,BorderLayout.NORTH);
		panel.add(ok,BorderLayout.SOUTH);
		
		this.pack();
		this.show();
	}
	
	/**
	 * Metodo che ritorna una stringa che rappresenta la dimensione della matrice
	 * @return stringa con la dimensione della matrice
	 */
	public String getMatDimValue(){
		return this.matDimTF.getText();
	}

	/**
	 * Metodo che ritorna il vaore intero della matrice dei costi dato in input,
	 * se il valore non � ben formato, perch� negativo o non un numero, ritorna -1
	 * @return intero con la dimensione della matrice dei costi
	 */
	public int getMatDim(){
		return this.matDim;
	}
	/**
	 * Mette il valore intero positivo della matrice dei costi
	 * @param value valore intero su cui si fa un controllo di
	 * positivita' della dimensione 
	 */
	protected void setMatDim(int value){
		if(value>0)
			this.matDim=value;
	}
}

/**
 * Classe Listener del bottone ok, che deve dare errore attraverso
 * una label se il valore immesso dall`utente e' errato
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
class OKListener implements ActionListener{
	protected JLabel error;
	protected MatrixDimInputForm form;
	public OKListener(JLabel error,MatrixDimInputForm f){
		this.error=error;
		this.form=f;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent arg0) {
		try{
			int value=Integer.parseInt(this.form.getMatDimValue());
			if(value>0){
				this.form.setMatDim(value);
				form.hide();
				return;
			}
			this.error.setText("Matrix dimension must be positive");
			
		}
		catch(Exception e){
			this.error.setText("Matrix dimension must be an interger");
		}
		this.error.setVisible(true);
		this.form.pack();
		
	}
	
}
