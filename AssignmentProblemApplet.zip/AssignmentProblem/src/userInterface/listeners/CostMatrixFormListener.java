package userInterface.listeners;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import presentation.ApplicationStatusManager;

import userInterface.SimpleDialog;
import userInterface.table.AssignmentTablePanel;


/**
 * Listener che apre la matrice dei costi e la mostra
 * all`utente
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class CostMatrixFormListener implements ActionListener{
	protected ApplicationStatusManager statusManager;
	/**
	 * Costruttore di CostMatrixFormListener
	 * @param status riferimento a un'istanza della classe ApplicationStatusManager
	 * da cui derivare la matrice dei costi che deve poi essere visualizzata
	 */
	public CostMatrixFormListener(ApplicationStatusManager status){
		this.statusManager=status;
	}
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) 
	{
		
		SimpleDialog dialog=new SimpleDialog("Cost matrix",new Dimension(380,350));
		
		//aggiungo al simple dialog un bottone per chiudere la finestra
		JButton ok=new JButton("ok");
		ok.addActionListener(new CloseListener(dialog));
		dialog.addButton(ok);
		
		//aggiungo al simple dialog un pannello con visualizzata la matrice dei costi
		AssignmentTablePanel view = new AssignmentTablePanel
				(this.statusManager.getCostMatrix(),null,false);
		dialog.addPanel(view);
		dialog.show();
	}
}
