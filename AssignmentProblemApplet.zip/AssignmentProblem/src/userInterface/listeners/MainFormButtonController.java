package userInterface.listeners;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import presentation.ApplicationStatusManager;

import userInterface.MainForm;
import application.steps.AStep;
import application.steps.StepNewAssign;

/**
 * Listener dei bottoni della MainForm per visualizzare
 * i passi dell`algoritmo
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 * 
 */
public class MainFormButtonController  extends MouseAdapter
{
	public final static int OPTIMAL=0,
							STOP=1,
							REVFAST=2,
							REV=3,
							PREVIOUS=4,
							NEXT=5,
							FWD=6,
							FWDFAST=7;
	
    protected ApplicationStatusManager  status;
    protected MainForm form;
    protected int sourceType;
    /**
     * Costruttore
     * @param status riferimento ad un'istanza di ApplicationStatusmanager
     * @param sourceType un intero che indica il bottone che � stato premuto e di cui la classe si deve occupare
     * @param form riferimento ad un'istanza di MainForm
     */
    public MainFormButtonController(ApplicationStatusManager status,int sourceType,MainForm form) 
    {
        this.status = status;
        this.sourceType = sourceType;
        this.form=form;
        
        
    }   
    
    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
     */
    public void mouseClicked(MouseEvent e)
    {
            switch(sourceType)
		{
        	case MainFormButtonController.OPTIMAL:
        		AStep step=status.goal();
        		if(step!=null)
        			status.getForm().updateFormComponents(step);
        		break;
        	
        	case MainFormButtonController.STOP:
        		this.form.init();
        		this.form.getOptionsMenuBar().setCostMatDimItemEnable(true);
        		this.form.setfileOpenBtnEnable(true);
        		this.form.getApplicationStatusManager().resetcurAlgo();
        		break;
        	case MainFormButtonController.REVFAST:
        		do{
        			step=status.previous();
            		if(step==null)
            			return;
        		}while(!this.status.getButtonCondition().revFastCondition(step));
        		status.getForm().updateFormComponents(step);
        		break;
        		
        	case MainFormButtonController.REV:
        		AStep curStep=status.currentStep();
        	
        		step=status.previous();
        		if(step==null || curStep==null)
        			return;
        		
        		if(curStep.getName().equals(StepNewAssign.name)){
        			while(step.getName().equals(StepNewAssign.name)){
            			step=status.previous();
                		if(step==null)
                			return;
            		}
        		}
        		
        		while(!this.status.getButtonCondition().revCondition(step)){
        			step=status.previous();
            		if(step==null)
            			return;
        		}
        		
        		status.getForm().updateFormComponents(step);
        		
        		
        		
        		break;
        	case MainFormButtonController.PREVIOUS:
        		step=status.previous();  
    			if(step!=null)
    				status.getForm().updateFormComponents(step);
    			break;
        	
        	case MainFormButtonController.NEXT:
        		step=status.next();
    			if(step!=null)
    				status.getForm().updateFormComponents(step);
    			break;
    			
        	case MainFormButtonController.FWD:
        		do{
        			step=status.next();
            		if(step==null)
            			return;
        		}while(!this.status.getButtonCondition().fwdCondition(step));
        		
        		if(step.getName().equals(StepNewAssign.name)){
        			do{
            			step=status.next();
                		
            		}while(step.getName().equals(StepNewAssign.name));
        			step=status.previous();
        		}
        		status.getForm().updateFormComponents(step);
				break;
        	case MainFormButtonController.FWDFAST:
        		do{
        			step=status.next();
            		if(step==null)
            			return;
        		}while(!this.status.getButtonCondition().fwdFastCondition(step));
        		status.getForm().updateFormComponents(step);
        		break;
        	
		}
    }
}
