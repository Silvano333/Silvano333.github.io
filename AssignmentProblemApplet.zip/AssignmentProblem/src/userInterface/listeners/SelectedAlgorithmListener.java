package userInterface.listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import presentation.ApplicationStatusManager;
import presentation.configuration.AppConfig;


/**
 * Listener che ascolta quale algoritmo viene selezionato
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class SelectedAlgorithmListener implements ActionListener {

	ApplicationStatusManager status;
	/**
	 * Costruttore
	 * @param status istanza di ApplicationStatusManager
	 */
	public SelectedAlgorithmListener(ApplicationStatusManager status) 
	{
		this.status = status; 
	}
    
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) 
	{
	    JMenuItem item = (JMenuItem) e.getSource();
	    String cmd = item.getActionCommand();
	    	    
	    String algoNames[] = AppConfig.getAlgoShortNames();
	    for(int i=0;i<algoNames.length;i++)
	    if(cmd.equalsIgnoreCase(algoNames[i]))
	    {
	    	status.selectAlgorithm(cmd);
		    return;
	    }	
	    
	}

}
