package userInterface.listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import presentation.ApplicationStatusManager;


/**
 * Classe che resta in ascolto dell'inizio della computazione
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public class StartAlgorithmListener implements ActionListener {

	ApplicationStatusManager status;
	/**
	 * Costruttore
	 * @param status istanza di ApplicationStatusManager
	 */
	public StartAlgorithmListener(ApplicationStatusManager status) 
	{
		this.status = status; 
	}
    
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) 
	{
	    JMenuItem item = (JMenuItem) e.getSource();
	    String cmd = item.getActionCommand();
	    	    
	    if(cmd.equalsIgnoreCase("start"))
	    {
	    	status.startAlgo();
	    	return;
	    }	
	    
	}
}
