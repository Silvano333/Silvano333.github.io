package userInterface.listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import presentation.PresentationMatrix;


import userInterface.MainForm;
import userInterface.MatrixDimInputForm;
import userInterface.table.AssignmentTablePanel;


/**
 * Listener per la form che chiede all`utente
 * la dimensione della matrice dei costi
 * da creare in interfaccia grafica
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 */
public class CostMatrixDimensionListener implements ActionListener {
	protected MainForm mainForm;
	/**
	 * Costruttore con un parametro
	 * @param mf MainForm con cui la classe deve interagire per l'eventuale costruzione di una nuova matrice dei costi
	 */
	public CostMatrixDimensionListener(MainForm mf){
		this.mainForm=mf;
	}
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent arg0) {
		
		MatrixDimInputForm form =new MatrixDimInputForm(null,true);
		int matrixDim=form.getMatDim();
		form.dispose();
		
		if(matrixDim<1)
			return;
		
		int [][]costMatrix=new int[matrixDim][matrixDim];
		
		PresentationMatrix presMatr = new PresentationMatrix(costMatrix);
		AssignmentTablePanel view = new AssignmentTablePanel(presMatr,null,true);
		this.mainForm.setViewPanel(view);
		this.mainForm.getApplicationStatusManager().setCostMatrix(presMatr);
	}

}
