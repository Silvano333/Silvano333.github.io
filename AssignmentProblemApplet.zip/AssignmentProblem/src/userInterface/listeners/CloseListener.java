package userInterface.listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * Listener che permette di chiudere una finestra
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class CloseListener implements ActionListener {

	protected JDialog frame;
	/**
	 * Costruttore di CloseListener a un parametro
	 * @param f finestra che deve essere chiusa
	 */
	public CloseListener(JDialog f){
		this.frame=f;
	}
	
	/**
	 * Metodo che deve essere implementato per la gestione ad eventi e che mi chiude la finestra
	 */
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent arg0) {
		this.frame.dispose();

	}
}
