package userInterface.listeners;

import java.awt.FileDialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import presentation.PresentationMatrix;
import userInterface.MainForm;
import userInterface.table.AssignmentTablePanel;

import dataLogic.XmlDataLogic;

/**
 * Listener che si occupa di aprire un file contenente la matrice da input
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 * 
 * */
public class OpenListener implements ActionListener {
	protected MainForm parentFrame;
	
	/**
	 * Costruttore
	 * @param parentFrame MainFrame che possiede il FileDialog
	 */
	public OpenListener(MainForm parentFrame){
		this.parentFrame=parentFrame;
	}
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent arg0) {
		FileDialog fd = new FileDialog(this.parentFrame, "Please choose a file:", 
				 FileDialog.LOAD);
				 fd.show();

				 String selectedItem = fd.getFile();
				 if (selectedItem != null) {
				 	String fileName = fd.getDirectory();
					fileName += fd.getFile();

				    //try to read the file
				    XmlDataLogic dataLogic = new XmlDataLogic(fileName);
					boolean loadStatus=dataLogic.load();
					int[][] c = dataLogic.getData();
					if(c==null){
						JOptionPane.showMessageDialog(null, 
				    			"Cost matrix is null","Warning", JOptionPane.YES_NO_OPTION);
						return;
					}
					if(!loadStatus){
						JOptionPane.showMessageDialog(null, 
					    			"Cost matrix must be square","Warning", JOptionPane.YES_NO_OPTION);
						return;
							
					}
					PresentationMatrix presMatr = new PresentationMatrix(c);
					AssignmentTablePanel view = new AssignmentTablePanel(presMatr,null,true);
					this.parentFrame.setViewPanel(view);
					this.parentFrame.getApplicationStatusManager().setCostMatrix(presMatr);
				 }
		
	}
}
