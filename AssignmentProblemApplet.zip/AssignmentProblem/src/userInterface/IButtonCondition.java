package userInterface;

import application.steps.AStep;


/**
 * Contiene i metodi per le condizioni di terminazione dei 
 * bottoni presenti nella interfaccia grafica 
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 * 
 */
public interface IButtonCondition {

	/**
	 * Metodo che d� la condizione di terminazione del pulsante revFast
	 * @param step passo corrente di cui si vuole sapere la condizione di terminazione
	 * @return condizione di terminazione di revFast
	 */
	public boolean revFastCondition(AStep step);
	
	/**
	 * Metodo che d� la condizione di terminazione del pulsante rev
	 * @param step passo corrente di cui si vuole sapere la condizione di terminazione
	 * @return condizione di terminazione di rev
	 */
	public boolean revCondition(AStep step);
	

	/**
	 * Metodo che d� la condizione di terminazione del pulsante fwdFast
	 * @param step passo corrente di cui si vuole sapere la condizione di terminazione
	 * @return condizione di terminazione di fwdFast
	 */
	public boolean fwdFastCondition(AStep step);
	
	/**
	 * Metodo che d� la condizione di terminazione del pulsante fwd
	 * @param step passo corrente di cui si vuole sapere la condizione di terminazione
	 * @return condizione di terminazione di fwd
	 */
	public boolean fwdCondition(AStep step);

}
