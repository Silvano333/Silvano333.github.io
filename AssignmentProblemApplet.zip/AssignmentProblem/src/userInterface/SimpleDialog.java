
package userInterface;

import javax.swing.BoxLayout;
import java.awt.Container;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

import presentation.configuration.GUIVars;




/**
 * Classe per le comunicazioni semplici con l`utente
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */

public class SimpleDialog extends JDialog
{
    static final int WIDTH = 800,
	 HEIGHT = 300;
    private Vector panels;
    private JButton btn; 
     
   
   /**
    * Costruttore
 * @param title titolo
 * @param dim dimensione della finestra
 */
public SimpleDialog (String title,java.awt.Dimension dim)
   {
       super();
       this.getContentPane().setLayout(new BoxLayout(this.getContentPane(),BoxLayout.Y_AXIS));
       this.setSize(dim);
       this.setResizable(false);
       this.setBackground(GUIVars.COLOR_BACKGROUND_DARK);
       this.setForeground(GUIVars.COLOR_FOREGROUND);
       this.setModal(true);
       this.setTitle(title);
       panels = new Vector();
   }
   
   /**
 * rimuove tutti i pannelli presenti
 */
public void removeAllPanels()
   {
       panels = new Vector();
   }
   
   /**
    * aggiunge un array di pannelli p ai pannelli della finestra
 * @param p pannelli
 */
public void addPanels(JPanel[] p)
   {
       for(int i=0;i<panels.size();i++)
           panels.add(p[i]);
   }
   public void addPanel(JPanel p)
   {
       panels.add(p);
       buildPanels();
   }
   
   public void removePanel(JPanel p)
   {
       panels.remove(p);
       buildPanels();
   }
   
   /**
 * Metodo che rimuove tutti i pannelli precedenti e mette quelli nuovi
 */
private void buildPanels()
   {
       Container frame = this.getContentPane();
       frame.removeAll();
       
       for(int i=0;i<panels.size();i++)
       {
           JPanel p = (JPanel)panels.get(i); 
           frame.add(p);
       }
       if(btn!=null)
           frame.add(Utils.buttonPanel(btn));
   }
   
   public void addButton (JButton btn)
   {
       this.btn = btn;
       buildPanels();
   }
}