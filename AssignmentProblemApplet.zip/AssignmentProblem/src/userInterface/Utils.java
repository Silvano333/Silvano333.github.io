package userInterface;

import java.awt.Color;
import java.awt.Font;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

import presentation.configuration.GUIVars;

import java.awt.event.MouseAdapter;
/**
 * Classe con utilita'
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 */
public class Utils
{
    // JLabel message+font
    /**
     * crea una label con messaggio e font
     * @param msg messaggio label
     * @param font font label
     * @return label cosi' costruita
     */
    public static JLabel label(String msg,Font font)
    {
        JLabel label = new JLabel(msg,SwingConstants.LEFT);
        label.setFont(font);
        label.setForeground(GUIVars.COLOR_FOREGROUND);
        label.setBackground(GUIVars.COLOR_BACKGROUND);
        

        return label;
    }

    //  JLabels message+font+colors
    /**
     * Crea label
     * @param msg testo label
     * @param fore colore testo
     * @param back colore sfondo
     * @param font font
     * @return label cosi` costruita
     */
    public static JLabel label(String msg,Color fore,Color back,Font font)
    {
        JLabel label = new JLabel(msg,SwingConstants.LEFT);
        label.setFont(font);
        label.setForeground(fore);
        label.setBackground(back);
        return label;
    }
    
    //  JLabels message+font+colors+border
    /**
     * Costruisce label
     * @param msg
     * @param fore
     * @param back
     * @param font
     * @param border
     * @param swingConstant
     * @return label cos� costruita
     */
    public static JLabel label(String msg,Color fore,Color back,Font font,Border border,int swingConstant)
    {
        JLabel label = new JLabel(msg,swingConstant);
        label.setFont(font);
        label.setForeground(fore);
        label.setBackground(back);
        
        label.setBorder(border);
        return label;
    }
    
    //JButton text+adapter
    /**
     * Crea un bottone
     * @param txt testo
     * @param listen listener associato
     * @return ritorna il bottone costruito
     */
    public static JButton button(String txt,MouseAdapter listen)
    {
        JButton btn = new JButton(txt);
        btn.setFont(GUIVars.FONT_BTN);
        btn.addMouseListener(listen); 
        return btn;
    }
    
    /**
     * Crea bottone
     * @param image immagine
     * @param listen listenr
     * @return il bottone costruito
     */
    public static JButton button(ImageIcon image,MouseAdapter listen)
    {
        JButton btn = new JButton(image);
        btn.setFont(GUIVars.FONT_BTN);
        btn.addMouseListener(listen); 
        return btn;
    }
    
    //a button inside a panel
    /**
     * Ritorna un pannello con dentro un bottone
     * @param btn bottone
     * @return pannello con btn al centro
     */
    public static JPanel buttonPanel(JButton btn)
    {
        JPanel cont = new JPanel();
        cont.add(btn,SwingConstants.CENTER);
        return cont;
    }
    
    
     //JTables
    /**
     * metodo che crea una tabella
     * @param rowHeight
     * @param fore
     * @param back
     * @param font
     * @param border
     * @param swingConstant
     * @return la tabella costruita
     */
    public static JTable tableAndColors(int rowHeight,Color fore,Color back,Font font,Border border,int swingConstant)
    {
    	JTable table = new JTable();
		table.setForeground(fore);
		table.setBackground(back);
		table.setRowHeight(rowHeight);
		table.setFont(font);
		if(border!=null)
		    table.setBorder(border);
		   
		DefaultTableCellRenderer rnd = new DefaultTableCellRenderer();
		rnd.setHorizontalAlignment(swingConstant);
		table.setDefaultRenderer(Object.class,rnd);
		return table;
	 }
    
    /**
     * metodo che crea una tabella
     * @param rowHeight
     * @param font
     * @param border
     * @param swingConstant
     * @return la tabella costruita
     */
    public static JTable table(int rowHeight,Font font,Border border,int swingConstant)
	{
		return tableAndColors(rowHeight,GUIVars.COLOR_FOREGROUND,GUIVars.COLOR_BACKGROUND,font,border,swingConstant);
    }
    
}
