package userInterface.table;

import javax.swing.table.TableCellRenderer;

import java.awt.Component;


import javax.swing.BorderFactory;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


import presentation.PresentationMatrix;
import presentation.SelectionSchema;
import presentation.configuration.TableStyle;
;
/**
 * Classe che contiene il render e le selezioni della tabella
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class AssignmentTableRenderer implements TableCellRenderer
{
	private PresentationMatrix matrix;
	private SelectionSchema selSchema;
	/**
	 * Costruttore
	 * @param matrix istanza di PresentationMatrix
	 * @param selSchema istanza di SelctionSchema
	 */
	public AssignmentTableRenderer(PresentationMatrix matrix, SelectionSchema selSchema)
	{
		changeSelectionSchema(selSchema);
		this.matrix = matrix;
	}
	
	/**
	 * Metodo che permette di cambiare una selezione
	 * @param selSchema SelectionSchema nuovo da sostituire quello vecchio
	 */
	public void changeSelectionSchema(SelectionSchema selSchema)
	{
		this.selSchema = selSchema;
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.table.TableCellRenderer#getTableCellRendererComponent(javax.swing.JTable, java.lang.Object, boolean, boolean, int, int)
	 */
	public Component getTableCellRendererComponent(JTable table,Object value,
           									 boolean isSelected,boolean hasFocus,int row,int column)
	{
		JTextField txtField=null;
		if((row==0)&&(column==0))
			txtField = zeroComponent();
		 else
			if(column==0)
				txtField = rowHeaderComponent(row,column);
			else
				if(row==0)
					txtField = columnHeaderComponent(row,column);
		 		else
					txtField = elementComponent(row,column);
			
			
			txtField.setHorizontalAlignment(SwingConstants.CENTER);
			return txtField;
	}
	
	/**
	 * Metodo che setta lo stile dell'elemento 0,0 della tabella
	 * @return la JTextField associata all'elemento 0,0 e con lo stile prescelto
	 */
	private JTextField zeroComponent()
	{
		JTextField txtField = new JTextField("");
		txtField.setBackground(TableStyle.COLOR_TABLE_ZEROHEADER_BACKGROUND);
		
		return txtField;
			
	}
	
	//Stile righe
	/**
	 * Metodo che setta lo stile degli elementi della riga di header
	 * @param row indice della riga
	 * @param column indice della colonna
	 * @return JTextField associata alla riga
	 */
	private JTextField rowHeaderComponent(int row,int column)
	{
		JTextField txtField = new JTextField(matrix.getTitleFromPresentation(row,column));
		txtField.setBackground(TableStyle.COLOR_TABLE_ROWHEADER_BACKGROUND);
		txtField.setForeground(TableStyle.COLOR_TABLE_ROWHEADER_FOREGROUND);
		txtField.setFont(TableStyle.FONT_ROWHEADER);
		
		return txtField;
			
	}
	
	//Stile colonne
	/**
	 * Metodo che setta lo stile degli elementi della colonna di header
	 * @param row indice della riga
	 * @param column indice della colonna
	 * @return JTextField associata alla colonna
	 */
	private JTextField columnHeaderComponent(int row,int column)
	{
		JTextField txtField = new JTextField(matrix.getTitleFromPresentation(row,column));
		txtField.setBackground(TableStyle.COLOR_TABLE_COLUMNHEADER_BACKGROUND);
		txtField.setForeground(TableStyle.COLOR_TABLE_COLUMNHEADER_FOREGROUND);
		txtField.setFont(TableStyle.FONT_COLUMNHEADER);
		
		return txtField;
			
	}
	
	//Stile dati della tabella
	/**
	 * Metodo che setta lo stile degli elementi dato della tabella
	 * @param row indice della riga
	 * @param column indice della colonna
	 * @return JTextField associatO all'elemento dato della tabella
	 */
	private JTextField elementComponent(int row,int column)
	{
		JTextField txtField = new JTextField(matrix.getElementFromPresentation(row,column).toString());
		if(selSchema.isSelected(row,column))
		{
			txtField.setBackground(TableStyle.COLOR_TABLE_SELECTED_CELLS_BACKGROUND);
			txtField.setForeground(TableStyle.COLOR_TABLE_SELECTED_CELLS_FOREGROUND);
			txtField.setFont(TableStyle.FONT_SELECTED_CELLS);
			txtField.setBorder(BorderFactory.createLineBorder(TableStyle.BORDER_SELECTED_CELLS_COLOR,TableStyle.BORDER_SELECTED_CELLS_WIDTH));
		}
		else
		{
			txtField.setBackground(TableStyle.COLOR_TABLE_NORMAL_CELLS_BACKGROUND);
			txtField.setForeground(TableStyle.COLOR_TABLE_NORMAL_CELLS_FOREGROUND);
			txtField.setFont(TableStyle.FONT_NORMAL_CELLS);
			
		}
		
		return txtField;
	}
}
