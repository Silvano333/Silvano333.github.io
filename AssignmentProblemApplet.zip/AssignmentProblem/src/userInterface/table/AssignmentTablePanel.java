package userInterface.table;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.*;

import application.steps.AStep;

import presentation.PresentationMatrix;
import presentation.SelectionSchema;
import presentation.configuration.GUIVars;
import presentation.configuration.TableStyle;
import userInterface.Utils;
import userInterface.ViewPanel;


/**
 * Classe con il pannello per la tabella
 * presente nella MainForm
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class AssignmentTablePanel extends ViewPanel 
{
	private JTable table;
	private PresentationMatrix matrix;
	private final Dimension dim;
	
	/**
	 * Costruttore
	 * @param matrix istanza di PresentationMatrix da visualizzare nel pannello della classe
	 * @param curStep Istanza di una classe di AStep, che contiene le info dello step corrente da visualizzare nel pannello
	 * @param editable booleano che vale true se la tabella � editabile, false altrimenti
	 */
	public AssignmentTablePanel(PresentationMatrix matrix,AStep curStep, boolean editable)
	{
		super();
		this.matrix = matrix;
		dim = new Dimension(TableStyle.WIDTH_CELLS*(matrix.getRows()+1),TableStyle.HEIGHT_CELLS*(matrix.getRows()+1));
		this.setPreferredSize(dim);
		
		
		//Inserire lo schema di selezione dipendente dallo stato
		SelectionSchema selSchema = new SelectionSchema(matrix,curStep);
		
		table = Utils.table(TableStyle.HEIGHT_CELLS,GUIVars.FONT_TABLE,GUIVars.BORDER_TABLE,SwingConstants.CENTER);
		//table.setPreferredScrollableViewportSize(new Dimension(,TableStyle.HEIGHT_CELLS*(matrix.getRows()+1)));
		fillTable(matrix);
		setUpTableEditor(table);
		table.setDefaultRenderer(String.class,new AssignmentTableRenderer(matrix,selSchema));
		table.setDefaultRenderer(Integer.class,new AssignmentTableRenderer(matrix,selSchema));
		
		//Per far sparire l'orribile selezione di tutta la riga
		table.setSelectionBackground(table.getBackground());
		table.setSelectionForeground(table.getForeground());
		
		this.setLayout(new BorderLayout());
		this.add(table,BorderLayout.CENTER);
		this.table.setEnabled(editable);
		
	}
	
	
	/**
	 * @param table
	 */
	private void setUpTableEditor(JTable table) 
	{
        //Set up the editor for the integer cells.
        final TableField tableField = new TableField(0);
        tableField.setHorizontalAlignment(TableField.CENTER);

        DefaultCellEditor integerEditor = 
            new DefaultCellEditor(tableField) {
                //Override DefaultCellEditor's getCellEditorValue method
                //to return an Integer, not a String:
                public Object getCellEditorValue() {
                    return new Integer(tableField.getValue());
                }
            };
        table.setDefaultEditor(Integer.class, integerEditor);
	}
	
	/**
	 * Metodo che riempie la tabella creando il relativo modello
	 * @param matrix istanza di PresentationMatrix contenente la matrice da visualizzare nella tabella
	 */
	public void fillTable(PresentationMatrix matrix)
	{
		TableModel tm = new AssignmentTableModel(matrix);
	   
	   table.setModel(tm);
	}
	/**
	 * Metodo che setta se una tabella � editabile o meno
	 * @param editable true se la tabella � editabile, false altrimenti
	 */
	public void setTableEditable(boolean editable){
		this.table.setEnabled(editable);
    }
}

/**
 * Classe per il controllo di un valore presente nella tabella
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
class TableField extends JTextField {
    private Toolkit toolkit;
    private NumberFormat integerFormatter;
    
    /**
     * Costruttore
     * @param value intero associato alla classe, di cui si dovr� controllare se davvero un valore intero
     */
    public TableField(int value) {
        super(value);
        toolkit = Toolkit.getDefaultToolkit();
        integerFormatter = NumberFormat.getNumberInstance(Locale.US);
        integerFormatter.setParseIntegerOnly(true);
        setValue(value);
    }

    /**
     * Metodo che ritorna il valore della cella della tabella contenuta nella classe.
     * Se il valore era un intero positivo ritorna il valore della cella altrimenti il valore 0.
     * @return valore dell'intero positivo della cella o zero altrimenti
     */
    public int getValue() {
        int retVal = 0;
        try {
            retVal = integerFormatter.parse(getText()).intValue();
            if (retVal>0)
            	return retVal;
            else
            	retVal=0;
        } catch (ParseException e) {
        }
        return retVal;
    }

    /**
     * Metodo che inserisce un nuovo intero nella cella della tabella
     * che incapsula la classe
     * @param value valore intero da inserire nella tabella
     */
    public void setValue(int value) 
    {
    	setText(integerFormatter.format(value));
    }
}
	
