package userInterface.table;


import javax.swing.table.AbstractTableModel;

import presentation.PresentationMatrix;


/**
 * Modello per la tabella
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
class AssignmentTableModel extends AbstractTableModel 
{
	PresentationMatrix matrix;
	/**
	 * Costruttore
	 * @param matrix istanza di PresentationMatrix che contiene la matrice.
	 * 	In java per ogni tabella, in questo caso che contiene una matrice ho bisogno di un modello
	 * Questo � il modello per una tabella di assegnamento
	 */
	public AssignmentTableModel(PresentationMatrix matrix)
	{
		this.matrix = matrix;
	}
	 
	// Cerca alla riga 1 poich� nella riga 0 c'� la stringa con la descrizione del Job
	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#getColumnClass(int)
	 */
	public Class getColumnClass(int c) {
	     
	    if(matrix.getRows()>0)
	        return getValueAt(1, c).getClass();
	    return Object.class;
    }
	 
	 /* (non-Javadoc)
	 * @see javax.swing.table.TableModel#getValueAt(int, int)
	 */
	public Object getValueAt(int row, int col) {
        if((row==0)||(col==0))
        	return matrix.getTitleFromPresentation(row,col);
	 	return matrix.getElementFromPresentation(row,col);
    }
	 
	 /* (non-Javadoc)
	 * @see javax.swing.table.TableModel#getColumnCount()
	 */
	public int getColumnCount() {
        return matrix.getColumns();
    }
    
    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#getRowCount()
     */
    public int getRowCount() {
        return matrix.getRows();
    }
    
    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#isCellEditable(int, int)
     */
    public boolean isCellEditable(int row, int col) 
    {
    	return ((row>0)&&(col>0));
    }
    
    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#setValueAt(java.lang.Object, int, int)
     */
    public void setValueAt(Object value, int row, int col) 
    {
    	
    	if((row==0)||(col==0))
        	matrix.setTitleFromPresentation(row,col,(String)value);
	 	else
	 		matrix.setElementFromPresentation(row,col,(Integer)value);
	 
        fireTableCellUpdated(row, col);
    }
}
	

