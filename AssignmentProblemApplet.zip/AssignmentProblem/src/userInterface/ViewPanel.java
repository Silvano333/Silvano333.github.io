package userInterface;



import javax.swing.JPanel;


/**
 * Classe contenente il pannello della view della form
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class ViewPanel extends JPanel 
{
	private MainForm form = null;
	
	/**
	 *Costruttore di default 
	 */
	public ViewPanel()
	{
	}
	
	/**
	 * Setta la form associata alla view
	 * @param form
	 */
	public void setForm(MainForm form)
	{
		this.form = form;
	}
}
