package userInterface;

import application.steps.AStep;

import java.awt.*;
import javax.swing.*;

import presentation.ApplicationStatusManager;
import presentation.PresentationMatrix;
import presentation.StepVisitor;
import presentation.configuration.AppConfig;
import presentation.configuration.GUIVars;
import userInterface.listeners.MainFormButtonController;
import userInterface.listeners.OpenListener;
import userInterface.table.AssignmentTablePanel;


/**
 * Classe con la form principale
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 */
public class MainForm  extends JFrame
{
	private ApplicationStatusManager statusManager;
	
	private ViewPanel viewPanel=null;
	private StatusPanel statusPanel= null;
	private ButtonsPanel buttonsPanel=null;
	private ButtonsPanel buttonPanel=null,fileButtonPanel=null;
	private JButton rev,previous,stop,next,fwd,fwdFast,revFast,optimal,fileOpenBtn;
	private ImageIcon imgFirst,imgPrevious,imgStop,imgNext,imgLast,imgFwdFast,imgRevFast;
	private JPanel labelPanel,supportPanel2 = null;
	private JPanel supportPanel,buttonPane,filePanel;
	private OptionsMenuBar menubar;
	private PresentationMatrix matrix;
	
	/**
	 * Costruttore
	 * @param statusManager gestore della finestra
	 * @param title titolo della finestra
	 */
	public MainForm(ApplicationStatusManager statusManager,String title)
    {
        super(title);
        
        this.statusManager = statusManager;
        createPanels();
        
        loadImages();
        buildButtons();
		
		this.getContentPane().setLayout(new BoxLayout(this.getContentPane(),BoxLayout.Y_AXIS));
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.invalidate();
        
        menubar = new OptionsMenuBar(statusManager,this);
        this.setJMenuBar(menubar); 
    	
    }
	
	/**
	 * Metodo che crea i pannelli
	 */
	private void createPanels()
	{
		//pannello per il bottone per caricare la matrice dei costi e la matrice dei costi
		this.filePanel=new JPanel();
		this.filePanel.setLayout(new BorderLayout());
		
		this.fileButtonPanel=new ButtonsPanel();
		
		//pannello con i bottoni stop,fwd...
		this.buttonsPanel = new ButtonsPanel();
		
		//pannello con il bottone optimal
		this.buttonPanel=new ButtonsPanel();
		
		this.labelPanel = new JPanel();
		
		//pannello totale
		supportPanel = new JPanel();
		supportPanel.setLayout(new BorderLayout()); 
		
		//pannello con i bottoni in basso
		this.buttonPane=new JPanel();
		this.buttonPane.setLayout(new BorderLayout());
        
        //pannello di sinistra
		supportPanel2 = new JPanel();
        supportPanel2.setLayout(new BorderLayout());
	}
	
	//override se si voglino visualizzazioni personalizzate dei tre componenti con un layout diverso
	/**
	 * Metodo per aggiornare una visualizzazione della form
	 */
	public void loadViewLayout()
	{
	 	Container frame = this.getContentPane(); 
        frame.removeAll();
        supportPanel.removeAll();
        supportPanel2.removeAll();
        filePanel.removeAll();
        buttonPane.removeAll();
        
        this.filePanel.add(this.fileButtonPanel,BorderLayout.NORTH);
        this.filePanel.add(viewPanel,BorderLayout.SOUTH);
        
        supportPanel2.add(filePanel,BorderLayout.NORTH);
        supportPanel2.add(labelPanel,BorderLayout.CENTER);
        
        this.buttonPane.add(buttonsPanel,BorderLayout.NORTH);
        this.buttonPane.add(buttonPanel,BorderLayout.SOUTH);
        
        supportPanel2.add(buttonPane,BorderLayout.SOUTH);
        
        
        ((BorderLayout)(supportPanel.getLayout())).setHgap(50);
        supportPanel.add(supportPanel2,BorderLayout.CENTER);
        supportPanel.add(statusPanel,BorderLayout.EAST);
        
        frame.add(new JScrollPane(supportPanel,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
        		JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED),BorderLayout.CENTER);
        
    	//Faccio in modo che il form abbia una dimensione minima, ma che comunque non "tagli" i suoi elementi
        this.pack();
        Dimension dim = this.getSize();
        int maxHeight,maxWidth;
        maxHeight = dim.height > GUIVars.DIM_MINFORM.height ? dim.height : GUIVars.DIM_MINFORM.height;   
        maxWidth= dim.width > GUIVars.DIM_MINFORM.width ? dim.width : GUIVars.DIM_MINFORM.width;   
        this.setSize(new Dimension(maxWidth,maxHeight));
   
        
        
	}
	
	
	
	/**
	 * Metodo che costruisce tutti i bottoni della finestra
	 */
	private void buildButtons()
	{
		//bottoni in alto per aprire file
		this.fileOpenBtn =new JButton("Open");
		this.fileOpenBtn.addActionListener(new OpenListener(this));
		this.fileButtonPanel.add(this.fileOpenBtn);
		
		//bottoni in basso
		buttonsPanel.setSize(GUIVars.DIM_BUTTONS);
		
		this.stop=addButton(imgStop,new MainFormButtonController(statusManager,MainFormButtonController.STOP,this));
		this.revFast=addButton(imgRevFast,new MainFormButtonController(statusManager,MainFormButtonController.REVFAST,this));
		this.rev=addButton(imgFirst,new MainFormButtonController(statusManager,MainFormButtonController.REV,this));
		this.previous=addButton(imgPrevious,new MainFormButtonController(statusManager,MainFormButtonController.PREVIOUS,this));
		this.next=addButton(imgNext,new MainFormButtonController(statusManager,MainFormButtonController.NEXT,this));
		this.fwd=addButton(imgLast,new MainFormButtonController(statusManager,MainFormButtonController.FWD,this));
		this.fwdFast=addButton(imgFwdFast,new MainFormButtonController(statusManager,MainFormButtonController.FWDFAST,this));
		
		this.optimal=Utils.button("Optimal",new MainFormButtonController(statusManager,MainFormButtonController.OPTIMAL,this));
		this.buttonPanel.add(this.optimal);
		
		//metto le tool tip ai bottoni
		this.fileOpenBtn.setToolTipText("Load Cost Matrix From A XML File");
		this.stop.setToolTipText("Stop Algorithm");
		this.revFast.setToolTipText("Previous Not Assigned Vertex");
		this.rev.setToolTipText("Previous Iteration");
		this.previous.setToolTipText("Previous Step");
		this.next.setToolTipText("Next Step");
		this.fwd.setToolTipText("Next Iteration");
		this.fwdFast.setToolTipText("Next Not Assigned Vertex");
		this.optimal.setToolTipText("Show The Optimal Solution");
		
		
	}
	
	/**
	 * Metodo per creare un bottone
	 * @param img immagine associata al bottone
	 * @param listener listener associato al bottone
	 * @return bottone creato grazie all-immagin e il listener
	 */
	private JButton addButton(ImageIcon img,MainFormButtonController listener)
	{
		JButton btn = Utils.button(img,listener);
		btn.setPreferredSize(new Dimension(img.getIconWidth(),img.getIconHeight()));
		buttonsPanel.addButton(btn);
		return btn;
	}
	
	/**
	 * Carica tutte le immagini dei vari bottoni
	 */
	private void loadImages()
	{
		imgFirst = new ImageIcon("images/first.gif");
		imgRevFast=new ImageIcon("images/revVeloce.gif");
		imgPrevious = new ImageIcon("images/previous.gif");
		imgStop = new ImageIcon("images/stop1.gif");
		imgNext = new ImageIcon("images/next.gif");
		imgLast = new ImageIcon("images/last.gif");
		imgFwdFast=new ImageIcon("images/fwdVeloce.gif");
			
	}
	
	/**
	 * Metodo che visualizza sulla form tutte le label
	 * @param text array di label da visualizzare
	 */
	public void setLabels(String[] text)
	{
		this.labelPanel.removeAll();
		labelPanel.setLayout(new BoxLayout(labelPanel,BoxLayout.Y_AXIS));
		for(int i=0;i<text.length;i++)
			labelPanel.add(Utils.label(text[i],GUIVars.COLOR_FOREGROUND,GUIVars.COLOR_BACKGROUND,GUIVars.FONT_LBL));
	}
	
	/**
	 * Metodo da chiamare all-inzio, quando non e' ancora in
	 * esecuzione alcun algoritmo, visualizza
	 * la finestra base
	 */
	public void init(){
		
		StatusPanel statusPanel = new StatusPanel();
		this.statusPanel = statusPanel;
		
		PresentationMatrix presMatr = statusManager.getCostMatrix();
		AssignmentTablePanel view = new AssignmentTablePanel(presMatr,null,true);
		
		this.setViewPanel(view);
		this.getStatusPanel().setForm(this);
		this.setLabels(new String[]{"Algorithm not started yet"});
		
		OptionsMenuBar bar = this.getOptionsMenuBar();
		bar.clearAlgorithmBar();
		for(int i=0;i<AppConfig.getAlgorithmsCount();i++)
			bar.addAlgorithm(AppConfig.getAlgorithmFulName(i),""+AppConfig.getAlgorithmShortName(i));
	
		this.loadViewLayout();
	}
	
	/**
	 * Metodo che viene chiamato ad ogni aggiornamento
	 * dopo che la computazione dell`algoritmo e' iniziata
	 * @param step informazioni del passo, che causeranno tutta
	 * la visualizzazione della form
	 */
	public void updateFormComponents(AStep step)
	{
		
		StatusPanel statusPanel = new StatusPanel(step);
		this.statusPanel = statusPanel;
		
		PresentationMatrix presMatr = new PresentationMatrix(step.getStepMatrix());
		AssignmentTablePanel view = new AssignmentTablePanel(presMatr,step,false);
		
		this.viewPanel = view;
		this.getViewPanel().setForm(this);
		this.getStatusPanel().setForm(this);
		
		StepVisitor visitor=new StepVisitor();
		step.accept(visitor);
		this.setLabels(visitor.getLabels());
		
		OptionsMenuBar bar = this.getOptionsMenuBar();
		bar.clearAlgorithmBar();
		for(int i=0;i<AppConfig.getAlgorithmsCount();i++)
			bar.addAlgorithm(AppConfig.getAlgorithmFulName(i),""+AppConfig.getAlgorithmShortName(i));
	
		this.loadViewLayout();
		
	}
	
	/**
	 * Metodo che ritorna la ViewPanel
	 * @return la viewPanel della form
	 */
	public ViewPanel getViewPanel()
	{
		return this.viewPanel;
	}
	
	/**
	 * Setta un nuovo viewPanel alla form
	 * @param view nuovo viewPanel della form
	 */
	public void setViewPanel(ViewPanel view){
		if(view!=null){
			this.viewPanel=view;
			this.getViewPanel().setForm(this);
			this.loadViewLayout();
		}
	}
	
	/**
	 * Metodo che ritorna la StatusPanel della MainForm
	 * @return StatusPanel della form
	 */
	public StatusPanel getStatusPanel()
	{
		return this.statusPanel;
	}
	
	/**
	 * Metodo che ritorna la ButtonsPanel della MainForm
	 * @return ButtonsPanel della form
	 */
	public ButtonsPanel getButtonsPanel()
	{
		return this.buttonsPanel;
	}
	
	/**
	 * Metodo che ritorna la matrice dei costi ridotti
	 * @return matrice dei costi ridotti
	 */
	public PresentationMatrix getReducedCostmatrix(){
		return this.matrix;
	}
	
	/**
	 * Metodo che ritorna ApplicationStatusManager associata alla MainForm
	 * @return gestore della form ApplicationStatusManager
	 */
	public ApplicationStatusManager getApplicationStatusManager(){
		return this.statusManager;
	}
	
	/**
	 * Metodo che ritorna OptionsMenuBar della MainForm
	 * @return OptionsMenuBar della form
	 */
	public  OptionsMenuBar getOptionsMenuBar()
	{
		return this.menubar;
	}
	
	/**
	 * metodo che setta se il bottone per aprire nuovi
	 * file contenenti matrici dei costi e' enable oppure no
	 * @param enable true se l-utente puo` aprire nuovi file
	 * false altrimenti
	 */
	public void setfileOpenBtnEnable(boolean enable){
		this.fileOpenBtn.setEnabled(enable);
	}
	
	
}



