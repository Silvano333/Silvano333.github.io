package userInterface;


import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import presentation.ApplicationStatusManager;

import userInterface.listeners.*;




/**
 * Classe contenente la barra dei menu' della MainForm
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class OptionsMenuBar extends JMenuBar
{
	protected ApplicationStatusManager status;
	protected JMenu options,algo,actions;
	
	/**
	 * Costruttore
	 * @param status gestore dello stato
	 * @param mainForm form
	 */
	public OptionsMenuBar(ApplicationStatusManager status,MainForm mainForm)
	{

		this.status=status;
		actions = new JMenu("Actions");
		actions.setMnemonic('C');
		actions.add(menuItem("Start", new StartAlgorithmListener(status), "start"));
	    
	    
	    algo = new JMenu("Algorithm");
	    algo.setMnemonic('L');
	    
	    options = new JMenu("Options");
	    
	    options.setMnemonic('O');
	    options.add(menuItem("Cost Matrix", new CostMatrixFormListener(status), "costMat"));
	    options.add(menuItem("Cost matrix dimension", new CostMatrixDimensionListener(mainForm), "dim"));
	    

	    this.add(actions);
	    this.add(algo);
	    this.add(options);
	  }
	
	/**
	 * aggiunta di un nuovo algoritmo nel menu' algorithm
	 * @param name nome completo dell`algoritmo
	 * @param shortName nome abbreviato dell`algoritmo 
	 */
	public void addAlgorithm(String name,String shortName)
	{
		algo.add(menuItem(name,new SelectedAlgorithmListener(status),shortName));
	    
	}
	
	/**
	 * Metodo che setta se e' enable l`opzione di immettere
	 * la dimensione della matrice dei costi
	 * @param enable
	 */
	public void setCostMatDimItemEnable(boolean enable){
		options.getItem(1).setEnabled(enable);
	}
	
	/**
	 *Cancella tutti gli algoritmi dal menu' 
	 */
	public void clearAlgorithmBar()
	{
		algo.removeAll();
	}
		
	
	/**
	 * Crea un menu` 
	 * @param label nome del menu`
	 * @param listener listener del menu`
	 * @param command commando associato al menu`
	 * @return il\menu` creato
	 */
	private static JMenuItem menuItem(String label,ActionListener listener, String command) 
	{
	    JMenuItem item = new JMenuItem(label);
	    item.addActionListener(listener);
	    item.setActionCommand(command);
	    return item;
   }
}
