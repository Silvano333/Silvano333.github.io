package userInterface;

import application.hungarian3.*;
import application.steps.AStep;
import application.steps.StepGoal;
import application.steps.StepInitial;
import application.steps.StepNewAssign;
import application.steps.StepPathEdgesReass;
import application.steps.StepPreprocessing;

/**
 * Classe che implementa le condizioni di terminazione dei bottoni 
 * nel caso dell'algoritmo ungherese o(n^3)
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class Hungarian3ButtonCondition implements IButtonCondition {

	/* (non-Javadoc)
	 * @see userInterface.IButtonCondition#revFastCondition(AStep step)
	 */
	public boolean revFastCondition(AStep step) {
		if(step.getName().equals(StepVertexH3.name) ||
				step.getName().equals(StepInitial.name))
			return true;
		return false;
	}

	/* (non-Javadoc)
	 * @see userInterface.IButtonCondition#revCondition(AStep step)
	 */
	public boolean revCondition(AStep step) {
		String stepName=step.getName();
		if(stepName.equals(StepPathEdgesReass.name)||
			stepName.equals(StepUpdateDualVarH3.name) ||
			stepName.equals(StepNewAssign.name)||
			stepName.equals(StepInitial.name)||
			stepName.equals(StepPreprocessing.name))
				return true;
		
		return false;
	}


	/* (non-Javadoc)
	 * @see userInterface.IButtonCondition#fwdFastCondition(AStep step)
	 */
	public boolean fwdCondition(AStep step) {
		String stepName=step.getName();
		if(stepName.equals(StepPathEdgesReass.name)||
			stepName.equals(StepUpdateDualVarH3.name) ||
			stepName.equals(StepNewAssign.name)||
			stepName.equals(StepGoal.name)||
			stepName.equals(StepPreprocessing.name))
				return true;
		return false;
	}

	/* (non-Javadoc)
	 * @see userInterface.IButtonCondition#fwdCondition(AStep step)
	 */
	public boolean fwdFastCondition(AStep step) {
		String stepName=step.getName();
		if(stepName.equals(StepVertexH3.name)||
			stepName.equals(StepGoal.name))
				return true;
		return false;
	}

}
