package userInterface;

import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import presentation.configuration.GUIVars;
import presentation.graphics.GraphPainter;

import application.steps.AStep;



/**
 * Classe con lo stato della Form, cambia ad ogni step
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class StatusPanel extends JPanel 
{
	private MainForm form = null;
	private GraphPainter painter;
	private AStep step;
	
	/**
	 * Costruttore di default
	 */
	public StatusPanel()
	{}
	/**
	 * Costruttore
	 * @param step step associato allo StatusPanel
	 */
	public StatusPanel(AStep step)
	{
		setPreferredSize(GUIVars.DIM_GRAPH_STATUS);
		this.step = step;
		painter = new GraphPainter(step);
		this.invalidate();
	}
	
	/**
	 * Setta la form associata allo StatusPanel
	 * @param form form associata allo StatusPanel
	 */
	public void setForm(MainForm form)
	{
		this.form = form;
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 */
	public void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		
		if(painter==null)
			return;
		
		painter.paintComponent((Graphics2D)g);
	}
	
}

