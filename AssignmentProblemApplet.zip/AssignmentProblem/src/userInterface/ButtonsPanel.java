package userInterface;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;



/**
 * Classe che gestisce una lista di bottoni. Aggiunge,elimina,visualizza bottoni
 * Consente anche di nascondere bottoni su richiesta
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 * 
 *  
 */
public class ButtonsPanel extends JPanel
{
    protected Vector buttons; 
    
    /**
     * Costruttore di default
     */
    public ButtonsPanel()
    {
        buttons = new Vector();
    }
    /**
     * Costruttore
     * @param dim dimensione pannello
     */
    public ButtonsPanel(Dimension dim)
    {
        this.setSize(dim);
        buttons = new Vector();
    }
    
    /**
     * metodo che aggiunge un bottone al pannello
     * @param text testo del bottone
     * @param listener listener del bottone
     */
    public void addButton(String text,MouseAdapter listener)
    {
        JButton btn = Utils.button(text,listener);
        buttons.add(new MaskedButton(btn,true));
        buildPanel();
    }
    
    /**
     * Metodo cheaggiunge un bottone al pannelo 
     * @param btn bottone da aggiungere
     */
    public void addButton(JButton btn)
    {
        buttons.add(new MaskedButton(btn,true));
        buildPanel();
    }
    
    /**
     * Metodo che rimuove tutti i bottoni con un dato testo
     * @param text testo del bottone
     */
    public void removeButton(String text)
    {
        for(int i=0;i<buttons.size();i++)
        {
            MaskedButton maskBtn = (MaskedButton)buttons.get(i);
            if(maskBtn.button.getText().equals(text))
               buttons.remove(i);
        }
        buildPanel();
    }
    
    /**
     * Metodo che rimuove i bottoni btn
     * @param btn bottone da rimuovere 
     */
    public void removeButton(JButton btn)
    {
    	for(int i=0;i<buttons.size();i++)
        {
            MaskedButton maskBtn = (MaskedButton)buttons.get(i);
            if(maskBtn.button.equals(btn))
               buttons.remove(i);
        }
    }
    
    /**
     * Rendere visibile o meno il bottone con il testo text
     * @param text testo del bottone
     * @param isVisible true se deve essere visibile, false altrimenti
     */
    public void setVisible(String text,boolean isVisible)
    {
        for(int i=0;i<buttons.size();i++)
        {
            MaskedButton maskBtn = (MaskedButton)buttons.get(i);
            if(maskBtn.button.getText().equals(text))
            {   maskBtn.visible = isVisible;
                break;
            }
        }
        buildPanel();
    }
    
    
    /**
     *Aggiorna il pannello dei bottoni 
     */
    public void buildPanel()
    {
        this.removeAll();
        for(int i=0;i<buttons.size();i++)
        {
            MaskedButton maskBtn = (MaskedButton)buttons.get(i);
            if(maskBtn.visible)
                this.add(maskBtn.button);
        }
        this.invalidate();
    }
}

class MaskedButton
{
    public boolean visible;
    public JButton button;
    public MaskedButton(JButton button,boolean visible)
    {
        this.button = button;
        this.visible = visible;
    }
}
