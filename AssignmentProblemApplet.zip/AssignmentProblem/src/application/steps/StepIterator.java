package application.steps;


/**
 * Classe che permette di iterare sulla gerarchia ad albero
 * degli step
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public class StepIterator 
{
	public final static boolean TO_NEXT = true,
								TO_PREVIOUS=false;
	private AStep root;
	private AStep currentStep;
	
	/**
	 * Costruttore
	 * @param root step root 
	 */
	public StepIterator(AStep root)
	{
		this.root = root;
		this.currentStep = root;
	}
	
	/**
	 * Metodo che ritorna il primo step e quindi la radice
	 * @return il primo step, cio� la radice
	 */
	public AStep getFirst()
	{
		currentStep = root;
		return currentStep;
	}
	
	/**
	 * Metodo che ritorna lo step precedente a quello corrente
	 * @return lo step precedente
	 */
	public AStep getPrevious()
	{
		if(isRoot(currentStep))
			return null;
		
		AStep parentStep = currentStep.getParentStep();
		if(parentStep==null)
		{
			System.out.println("Root must not be null");
			System.exit(-4);
		}
		if(parentStep.indexOf(currentStep)==0) //E' il primo elemento: il precedente � il suo parent
			currentStep = parentStep;
		else
		{
			int childIndex = parentStep.indexOf(currentStep);
			currentStep = parentStep.getChild(childIndex-1);
			while(currentStep.getChildCount()>0)
			{
				currentStep=currentStep.getChild(currentStep.getChildCount()-1);
			}
		}
		
		return currentStep;
	}
	
	/**
	 * Metodo che ritorna lo step successivo a quello corrente
	 * @return lo step successivo a quello corrente
	 */
	public AStep getNext()
	{
		if(isGoal())
			return null;
		if(currentStep.getChildCount()>0)
			currentStep = currentStep.getChild(0);
		else
		{
			int childPos=-1;
			AStep parentStep=null; 
			
			do
			{
				parentStep = currentStep.getParentStep(); 
				if(parentStep==null)
				{
					System.out.println("Error: step without sons and father");
					System.exit(-3);
				}
				childPos = parentStep.indexOf(currentStep);
				currentStep = parentStep;
			}while(childPos==currentStep.getChildCount()-1); //Non ci sono altri figli da scandire
			currentStep = parentStep.getChild(childPos+1);
		}
		return currentStep;	
	}
	
	/**
	 * Metodo che ritorna l'ultimo step della gerarchia, come se 
	 * gli step fossero sequenziali
	 * @return l'ultimo step
	 */
	public AStep getLast()
	{
		currentStep = root.getChild(root.getChildCount()-1);
		return currentStep;
	}
	
	/**
	 * Metodo che si chiede se lo step corrente � il goal
	 * @return true se lo step corrente � il goal, false altrimenti
	 */
	private boolean isGoal()
	{
		AStep parent = currentStep.getParentStep(); 
		if(parent!=null)
			if((isRoot(parent))&&(parent.indexOf(currentStep)==parent.getChildCount()-1))
				return true; //Goal raggiunto
		return false;
	}
	

	/**
	 * Metodo che chiede se uno step � quello radice
	 * @param step di cui vedere se � la radice
	 * @return true se � la radice, false altrimenti
	 */
	private boolean isRoot(AStep step)
	{
		return step==root;
		
	}
	
	/**
	 * Metod che ritorna lo step corrente
	 * @return lo step corrente
	 */
	public AStep getCurrentStep()
	{
		return this.currentStep;
	}
	
}
