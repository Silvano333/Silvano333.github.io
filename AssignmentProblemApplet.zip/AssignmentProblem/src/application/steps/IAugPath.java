package application.steps;

/**
 * Interfaccia tramite la quale si pu� vedere 
 * il valore della variabile sink.
 * Qualunque metodo che abbia questa variabile e 
 * se questa deve poter essere reperita all'esterno dovr�
 * implementare questa interfaccia.
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public interface IAugPath {
	
	/**
	 * Metodo che ritorna sink
	 * @return sink di un augmenting path
	 */
	public int getSink();
}
