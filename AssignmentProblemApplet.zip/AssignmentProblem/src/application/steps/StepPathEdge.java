package application.steps;
import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import application.common.Edge;
import presentation.IVisitor;


/**
 * Classe che memorizza un nuovo arco che compare
 * a seguito di una procedura che produca archi,
 * semmai per trovare cammini aumentanti
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public class StepPathEdge extends AStep 
{
	public static final String name="PathEdge";
	protected boolean isFwd;
	protected int i,j;
   
	/**
	 * Costruttore
	 * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param i vertice di partenza dell'arco da creare
	 * @param j vertice di arrivo dell'arco da creare
	 * @param isFwd parametro che indica se l'arco � in avanti
	 * @param path l'eventuale cammino associato all'arco
	 * @param aN nome dell'algoritmo
	 */
	public StepPathEdge(GraphInfo graph,AssignmentMatrix matrix,
    				EdgeCollection edgeColl,int i,int j,boolean isFwd,int path,String aN)
	{
		super(graph,matrix,edgeColl,aN);
		this.i=i;
		this.j=j;
		
		this.isFwd=isFwd;
 		//aggiorno gli archi in avanti e quindi gli step dell'algoritmo
		if(isFwd)
			edgeColl.addForwardEdge(new Edge(i,j,path,Edge.DIR_viTOvj));
		else
			edgeColl.addBackEdge(new Edge(i,j,path,Edge.DIR_vjTOvi));
		
		//Aggiorno le variabili di stato
		this.graph = new GraphInfo(graph);
		this.matrix = new AssignmentMatrix(matrix);
		this.edgeColl = new EdgeCollection(edgeColl);
		
	}
    
    /**
     * Metodo che ritorna il vertice di partenza dell'arco
     * @return il vertice di partenza dell'arco
     */
    public int getI(){
    	return this.i;
    }
    
    /**
     * Metodo che ritorna il vertice di arrivo dell'arco
     * @return il vertice di arrivo dell'arco
     */
    public int getVertexNum(){
    	return this.j;
    }
    
    /**
     * Metodo che dice se l'arco � in avanti
     * @return true se la'rco � in avanti, false altrimenti
     */
    public boolean isFwd(){
    	return this.isFwd;
    }
      
    /* (non-Javadoc)
     * @see application.steps.AStep#getName()
     */
    public String getName(){
		return StepPathEdge.name;
	}
    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString(){
		return " FINDING AN ALTERNATING TREE";
	}
	
    /* (non-Javadoc)
     * @see application.steps.AStep#accept(presentation.IVisitor)
     */
    public void accept(IVisitor visitor){
		visitor.visit(this);
	}
}
