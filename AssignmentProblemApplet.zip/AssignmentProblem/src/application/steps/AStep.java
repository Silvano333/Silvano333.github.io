package application.steps;

import java.util.Vector;

import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;

import presentation.IVisitor;


/**
 * Classe astratta che rappresenta gli step che memorizzano passi dello
 * svolgimento dell'algoritmo che deve essere memorizzato
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public abstract class AStep 
{
	public static GraphInfo STATIC_GRAPH;
	public static AssignmentMatrix STATIC_MATRIX;
	public static EdgeCollection STATIC_EDGECOLL;
	
	protected GraphInfo graph;
	protected AssignmentMatrix matrix;
	protected EdgeCollection edgeColl;
	protected String algoName;
	
	private Vector subSteps;
	private AStep parent = null;

	/**
	 * Costruttore
	 * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param aN nome dell'algoritmo
	 */
	public AStep(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,String aN)
	{
		this.graph = new GraphInfo(graph);
		this.matrix = new AssignmentMatrix(matrix);
		this.edgeColl = new EdgeCollection(edgeColl);
		this.subSteps = new Vector();
		this.algoName = aN;
	}
	
	/**
	 * Metodo che ritorna lo step figlio i-esimo dello step corrente
	 * @param i indice del figlio dello step cercato
	 * @return lo step figlio alla posizione i
	 */
	public AStep getChild(int i)
	{
	    return (AStep)subSteps.get(i);
	}
	
	/**
	 * Metodo che aggiunge un step figlio allo step corrente
	 * @param step step figlio da aggiungere allo step corrente
	 */
	public void addChild(AStep step)
	{
	    this.subSteps.add(step);
	    step.parent = this;
	}
	
	/**
	 * Metodo che ritorna lo step padre dello step corrente
	 * @return step padre dello step corrente
	 */
	public AStep getParentStep()
	{
	    return this.parent;
	}
	
	/**
	 * Metodo che ritorna il numero dei figli dello step corrente
	 * @return numero dei figli dello step corrente
	 */
	public int getChildCount()
	{
	    return this.subSteps.size();
	}
	
	/**
	 * metodo che ritorna l'indice di un dato step dato in ingresso
	 * @param child step figlio di cui si cerca l'indice a cui � posizionato
	 * @return intero che rappresenta l'indice dello step d'ingresso
	 */
	public int indexOf(AStep child)
	{
		return this.subSteps.indexOf(child);
	}
	
	/**
	 * Metodo che ritorna la parte di stato memorizzata in GraphInfo
	 * @return la parte di stato dello step memorizzata in GraphInfo
	 */
	public GraphInfo getGraphInfo()
	{
		return this.graph;
	}
	
	/**
	 * Metodo che ritorna la parte di stato memorizzata in AssignmentMatrix
	 * @return la parte di stato dello step memorizzata in AssignmentMatrix
	 */
	public AssignmentMatrix getAssignmentMatrix()
	{
		return this.matrix;
	}
	
	/**
	 * Metodo che ritorna una copia della matrice dei costi ridotti
	 * propria dello step
	 * @return una copia della matrice dei costi ridotti
	 * propria dello step
	 */
	public int[][]getStepMatrix(){
		return this.matrix.getReducedCostM();
	}
	
	/**
	 * Metodo che ritorna la parte di stato memorizzata in EdgeCollection
	 * @return la parte di stato dello step memorizzata in EdgeCollection
	 */
	public EdgeCollection getEdgeCollection()
	{
	    return this.edgeColl;
	}
	
	/**
	 * Metodo che ritorna il nome dell'algoritmo di cui il passo fa parte
	 * @return il nome dell'algoritmo di cui il passo fa parte
	 */
	public String getAlgoName(){
		return this.algoName;
	}
	
	/**
	 * Metodo che accetta un visitor come da pattern visitor
	 * Per separare da questa parte il modo con cui questa
	 * classe verr� visualizzata all'esterno, in interfaccia
	 * grafica
	 * @param visitor istanza di IVisitor
	 */
	public abstract void accept(IVisitor visitor);
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public abstract String toString();
	
	/**
	 * Ritorna il nome associato a ciascuna classe AStep
	 * @return nome della classe
	 */
	public abstract String getName();
	
	
}
