package application.steps;

import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import presentation.IVisitor;

/**
 * Step che contiene la soluzione dell'algoritmo di assegnamento
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class StepGoal extends AStep {
	public static final String name="Goal";
	
	/**
	 * Costruttore
	 * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param aN nome dell'algoritmo
	 */
	public StepGoal(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,String aN)
	{
		super(graph,matrix,edgeColl,aN);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return " OPTIMAL SOLUTION";
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#getName()
	 */
	public String getName(){
		return StepGoal.name;
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#accept(presentation.IVisitor)
	 */
	public void accept(IVisitor visitor){
		visitor.visit(this);
	}
	
}
