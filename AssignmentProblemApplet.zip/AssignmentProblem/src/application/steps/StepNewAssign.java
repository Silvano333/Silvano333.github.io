
package application.steps;

import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import application.common.Edge;
import presentation.IVisitor;
/**
 * Classe che assegna il vertice j appartenente a V al
 * vertice i appartenente a U, che lo precede  
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */

public class StepNewAssign extends AStep 
{
	private int i;
	private int j;
	public static final String name="NewAssign";
    
	/**
	 * @param  graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param j vertice appartenente a V da cui trovo il nuovo assegnamento
	 * @param aN nome dell'algoritmo
	 */
	public StepNewAssign(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,int j,String aN)
	{
		super(graph,matrix,edgeColl,aN);
		this.j=j;
		AssignmentMatrix mat =matrix;
		this.i=graph.getPred(j);
		
		mat.setRow(j,i);
		int h=mat.getFi(i);
		mat.setFi(i,j);
		this.j=h;
		
		//Avendo eseguito una assegnazione, alcuni
		//archi del path potrebbero essere inutili e quindi possono essere rimossi
		
		for(int x=0;x<edgeColl.forwardEdgesNumber();x++){
			
			//Cerco l'arco sotto l'assegnamento di i e j
			Edge forEdge=(Edge)edgeColl.getForwardEdge(x);
			int ii=forEdge.getVi();
			int jj=forEdge.getVj();
			if((ii==i)&&(jj==j)){
				int path=forEdge.getPath();
				edgeColl.removeForwardEdge(x);
				
				//ho rimosso l'arco avanti, controllo che non ci sia 
				//anche un arco indietro dello stesso cammino e se c'� lo elimino
				for(int y=0;y<edgeColl.backwardEdgesNumber();y++){
					Edge backEdge=edgeColl.getBackwardEdge(y);
					if(backEdge.getPath()==path){
						if(forEdge.getVi()==backEdge.getVi()){
							//inizio dell'arco in avanti e fine arco indietro coincidono
							edgeColl.removeBackwardEdge(y);
							break;//mi fermo perch� l'arco se esiste ce n'� uno solo
						}
					}	
				}//end for dei backedge
				
				break;//ad ogni assegnamento tolgo al pi� un arco	
			}//end if
		}//end for archi avanti
		
		//StepAssignmentInfo.NAS_STATE
		
		//Aggiorno le variabili di stato
		this.graph = new GraphInfo(graph);
		this.matrix = new AssignmentMatrix(matrix);
		this.edgeColl = new EdgeCollection(edgeColl);
	}
	
    /**
     * Metodo che ritorna il vertice i appartenente a U, 
     * che precede il vertice j dato in ingresso al costruttore
     * @return intero del vertice di U dell'arco di cui creo l'assegnamento
     */
    public int geti(){
    	return this.i;
    }
    
    /**
     * Metodo che ritorna il vertice j appartenente a V, 
     * dato in ingresso al costruttore, di cui devo fare
     * l'assegnamento
     * @return il vertice j appartenente a V, dato in ingresso al costruttore
     */
    public int getj(){
    	return this.j;
    }
    
    /* (non-Javadoc)
     * @see application.steps.AStep#getName()
     */
    public String getName(){
		return StepNewAssign.name;
	}
    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString(){
		return " INCREASE THE PRIMAL SOLUTION";
	}
	
    /* (non-Javadoc)
     * @see application.steps.AStep#accept(presentation.IVisitor)
     */
    public void accept(IVisitor visitor){
		visitor.visit(this);
	}

	
}
