package application.steps;

import java.util.Vector;

import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import application.common.Edge;

import presentation.IVisitor;
import presentation.configuration.GraphStyle;

/**
 * Step di riassunto dopo un procedura che abbia cercato
 * cammini aumentanti, se non ne sono stati trovati, mostra
 *  semplicemente l'albero trovato, altrimenti
 * cambia il valore del cammino agli archi che appartengono 
 * a un cammino aumentante
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public class StepPathEdgesReass extends AStep {
	public static final String name="PathEdgesReass";
	protected int k;
	protected int sink;
	protected boolean isThereAugPath;
	
	/**
	 * Costruttore
	 * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param k vertice di partenza
	 * @param stepAugPath riferimento a una classe che implementa l'interfaccia IAugPath
	 * @param aN nome dell'algoritmo
	 */
	public StepPathEdgesReass(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,int k,IAugPath stepAugPath,String aN)
	{
		super(graph,matrix,edgeColl,aN);
		
		this.k=k;
		this.isThereAugPath=false;
		this.sink=stepAugPath.getSink();
		if(sink>0){
			this.changeGoodPathNum(k,sink);
		}
		
	}
	
	/**
	 * Metodo che ritorna una EdgeCollection in cui sono stati eliminati
	 * tutti gli archi che non appartenessero ad un
	 * cammino aumentante
	 * @return una EdgeCollection con solo gli archi del
	 * cammino aumentante
	 */
	private EdgeCollection removeNotGoodPathEdges() {
		//Creo due variabili temporanee che mi contengano 
		//gli archi in avanti e quelli indietro da eliminare
		Vector eraseableFwdE=new Vector();
		Vector eraseableBwdE=new Vector();
		
		//Eseguo due cicli per trovare gli archi da eliminare
		EdgeCollection edgeC=new EdgeCollection(this.edgeColl);
		for (int i=0;i<edgeC.forwardEdgesNumber();i++){
			Edge e=(Edge)edgeC.getForwardEdge(i);
			if(e.getPath()!=GraphStyle.AUGMENTING_PATH){
				eraseableFwdE.add(e);
			}
		}
		
		for(int k=0;k<edgeC.backwardEdgesNumber();k++){
			Edge e=(Edge)edgeC.getBackwardEdge(k);
			
			if(e.getPath()!=GraphStyle.AUGMENTING_PATH){
				eraseableBwdE.add(e);
			}
		}
		
		//Eseguo due cicli per eliminare gli archi trovati
		for (int i=0;i<eraseableFwdE.size();i++){
			edgeC.removeForwardEdge((Edge) eraseableFwdE.get(i));
		}
		
		for(int k=0;k<eraseableBwdE.size();k++){
			edgeC.removeBackwardEdge((Edge) eraseableBwdE.get(k));
		}
		
		
		
		return edgeC;
		
	}
	public String getName(){
		return StepPathEdgesReass.name;
	}
	
	/**
	 * Metodo che cambia il valore del cammino a tutti gli archi 
	 * che appartengono al cammino aumentante
	 * @param k vertice di partenza del cammino
	 * @param sink vertice di arrivo del cammino
	 */
	protected void changeGoodPathNum(int k,int sink){
		int i=-1;int j=sink;
		do
		{
			i=graph.getPred(j);
			this.findEdge(i,j,true);
			j=matrix.getFi(i);
			this.findEdge(i,j,false);
		  	
		}while(i!=k);
		
		
		
		
	}
	
	/**
	 * Metodo che cambia il valore del cammino dell'arco
	 * (i,j) appartente al cammino aumentante
	 * @param i vertice di partenza dell'arco
	 * @param j vertice di arrivo dell'arco
	 * @param isFwdEdge booleano che mi dice se l'arco � in avanti
	 */
	protected void findEdge(int i,int j,boolean isFwdEdge){
		if(isFwdEdge){
			for(int k=0;k<edgeColl.forwardEdgesNumber();k++){
				Edge e=(Edge)edgeColl.getForwardEdge(k);
				if((e.getVi()==i)&&(e.getVj()==j)){
					e.setPath(GraphStyle.AUGMENTING_PATH);
					this.isThereAugPath=true;
					break;
				}
					
			}
		}
		else{
			for(int k=0;k<edgeColl.backwardEdgesNumber();k++){
				Edge e=(Edge)edgeColl.getBackwardEdge(k);
				if((e.getVi()==i)&&(e.getVj()==j)){
					e.setPath(GraphStyle.AUGMENTING_PATH);
					break;
				}
			}
		}
	}
	
	/**
	 * Metodo che ritorna il vertice di partenza appartenente
	 * a U del cammino aumentante
	 * @return il vertice di partenza del cammino aumentante
	 */
	public int getSxVertexNum(){
    	return this.k;
    }
	
	/**
	 * Metodo che ritorna il vertice di arrivo appartenente
	 * a V del cammino aumentante
	 * @return il vertice di arrivo del cammino aumentante
	 */
	public int getDxVertexNum(){
    	return this.sink;
    }
	 
	 /**
	  * Metodo che controlla se � stato trovato un cammino
	  * aumentante
	 * @return true se c'� un cammino aumentante, false altrimenti
	 */
	public boolean isThereAugPath(){
	 	return this.isThereAugPath;
	 }
	 
	 /**
	  * Metodo che rimuove tutti gli archi non appartenenti al 
	  * cammino aumentante
	 * @return una nuova istanza di EdgeCollection
	 */
	public EdgeCollection updateEdgeCollection(){
	 	//Elimino gli archi inutili per i passi successivi, gli passo la variabile edgeColl
		//data in ingresso e non quella propria della classe
	 	return this.removeNotGoodPathEdges();
		
	 }
	
	/* (non-Javadoc)
	 * @see application.AStep#accept(presentation.IVisitor)
	 */
	public void accept(IVisitor visitor) {
		visitor.visit(this);

	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return null;
	}

}
