package application.steps;

import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import application.common.Function;
import presentation.IVisitor;

/**
 * Classe che contiene lo stato inziale, quella alla
 * partenza di un algoritmo di risoluzione
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public class StepInitial extends AStep {
	public static final String name="Initial";
	
	/**
	 * Costruttore
	 * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param aN nome dell'algoritmo
	 */
	public StepInitial(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,String aN){
		super(graph,matrix,edgeColl,aN);
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#getStepMatrix()
	 */
	public int[][]getStepMatrix(){
		return this.matrix.getCostMatrix();
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#getAssignmentMatrix()
	 */
	public AssignmentMatrix getAssignmentMatrix()
	{
		int matDim=this.matrix.getCostMatrixDim();
		return new AssignmentMatrix
					(this.matrix.getCostMatrix(),
						new Function(matDim,-1,1),new Function(matDim,-1,1),
						new Function(matDim,0,0),new Function(matDim,0,0));
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#accept(presentation.IVisitor)
	 */
	public void accept(IVisitor visitor){
		visitor.visit(this);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return this.algoName+" computing...";
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#getName()
	 */
	public String getName(){
		return StepInitial.name;
	}

}
