package application;

import application.steps.AStep;
import application.steps.StepInitial;



/**
 * Classe astratta padre di tutti gli algoritmi che risolvono problemi di assegnamento
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public abstract class AssignmentProblemAlgorithm 
{
    private IPreprocessingAlgorithm preProcAlgo;
    protected AStep preProcStep =null;
    protected AStep goal=null;
	private AStep root;
	protected AssignmentMatrix matrix;
	protected GraphInfo graph;
	protected EdgeCollection edgeColl;
	protected String algoName;
	
	
	/**
	 * Costruttore a due parametri
	 * @param preProcAlgo riferimento a un'interfaccia di tipo 
	 * 			IPreprocessingAlgorithm
	 * @param aN stringa che contiene il nome dell'algoritmo
	 */
	public AssignmentProblemAlgorithm(IPreprocessingAlgorithm preProcAlgo,String aN)
	{
		this.algoName=aN;
		this.preProcAlgo = preProcAlgo;
		matrix =preProcAlgo.getAssignmentMatrix();
		graph = new GraphInfo(matrix.getCostMatrixDim());
	    edgeColl = new EdgeCollection();
	    
		this.root = new StepInitial(graph,matrix,edgeColl,this.algoName);
		
		
		
		AStep.STATIC_GRAPH=new GraphInfo(graph);
		AStep.STATIC_MATRIX=new AssignmentMatrix(matrix);
		AStep.STATIC_EDGECOLL=new EdgeCollection(edgeColl);
		
		this.preProcStep = preProcAlgo.getPreprocessingStep();
		this.getRootStep().addChild(preProcStep);
		
		buildFromAlgorithm();

		goal=this.getRootStep().getChild(this.getRootStep().getChildCount()-1);
	
	}
	
	/**
	 * Metodo che deve essere implementato dalle sottoclassi,
	 * conterr� l'algoritmo vero e proprio di risoluzione che
	 * contrastinguer� le varie sottoclassi
	 */
	protected abstract void buildFromAlgorithm();
	
	/**
	 * Ogni algoritmo conterr� al proprio interno una gerarchia
	 * di istanze di classe di tipo AStep, che insieme
	 * formeranno l'algoritmo di risoluzione
	 * Questo metodo permette di ritornare lo step root
	 * @return step root della gerarchia
	 */
	public AStep getRootStep()
	{
	    return root;
	}
	
	/**
	 * Metodo che permette di accedere allo step del preprocessing
	 * @return lo Step di preprocessing dell'algoritmo
	 */
	public AStep getPreProcessingStep()
	{
	    return preProcStep;
	}
	
	/**
	 * Metodo che permette di raggiungere velocemente lo step
	 * contenente la soluzione del problema di assegnamento
	 * @return step goal
	 */
	public AStep getGoalStep()
	{
	    return this.goal;
	}
	
	
	
}
