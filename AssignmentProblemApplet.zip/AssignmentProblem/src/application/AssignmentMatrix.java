package application;

import application.common.Function;

/**
 * Classe che contiene la matrice dei costi ridotti e le funzioni fi e row
 * @author Letizia Cheng Cheng Sun 
 * @version 1.0
 *
 */
public class AssignmentMatrix {
	protected int[][]costMatrix;
	protected int[][]costRelMatrix;
	protected Function fi;
	protected Function row;
	protected Function u;
	protected Function v;
	
	/**
	 * Costruttore di AssignmentMatrix a 5 parametri
	 * @param c matrice dei costi
	 * @param r funzione riga
	 * @param f funzione fi
	 * @param u funzione u
	 * @param v funzione v
	 */
	
	public AssignmentMatrix(int[][]c,Function r,Function f,Function u,Function v){
		
		this.row=new Function(r);
		this.fi=new Function(f);
		this.u=new Function(u);
		this.v=new Function(v);
		this.costMatrix=new int[c.length][c.length];
		this.costRelMatrix=new int[c.length][c.length];
		for(int i=0;i<c.length;i++){
			for(int j=0;j<c.length;j++){
				this.costMatrix[i][j]=c[i][j];
				this.costRelMatrix[i][j]=c[i][j]-u.get(i)-v.get(j);
			}
		}
	}
	
	
	/**
	 * Cotruttore di AssignmentMatrix conin ingresso un'istanza
	 * di AssignmentMatrix. Crea una copia di tutti i parametri
	 * dall'istanza in input
	 * @param m istanza di AssignmentMatrix di cui  si crea un nuova copia
	 */
	public AssignmentMatrix(AssignmentMatrix m)
	{
	    this.row=new Function(m.row);
		this.fi=new Function(m.fi);
		this.u=new Function(m.u);
		this.v=new Function(m.v);
		
		if(m.getCostMatrix()!=null){
			int costMatDim=m.getCostMatrix().length;
			this.costMatrix=m.getCostMatrix();
			this.costRelMatrix=
				new int[costMatDim][costMatDim];
			for(int i=0;i<costMatDim;i++){
				for(int j=0;j<costMatDim;j++){
					this.costRelMatrix[i][j]=m.getReducedCostM(i,j);
				}
			}
		}
		
		if(m.getFi()!=null){
			this.fi=new Function(m.getFi());
		}
		
		if(m.getRow()!=null){
			this.row=new Function(m.getRow());
		}
		
		if(m.getu()!=null){
			this.u=new Function(m.getu());
		}
		
		if(m.getv()!=null){
			this.v=new Function(m.getv());
		}
	}
	
	/**
	 * Metodo che ritorna la matrice dei costi
	 * @return matrice dei costi
	 */
	public int [][]getCostMatrix(){
		if(this.costMatrix==null) 
			return null;
		int[][] costMat=new int[this.costMatrix.length][this.costMatrix.length];
		
		for(int i=0;i<this.costMatrix.length;i++){
			for(int j=0;j<this.costMatrix[0].length;j++){
				costMat[i][j]=this.getCostMatrix(i,j);
			}
		}
		return costMat;
	}
	
	/**
	 * Metodo che ritorna il valore i,j della matrice dei costi
	 * @return il valore i,j della matrice dei costi
	 */
	public int getCostMatrix(int i,int j){
		return this.costMatrix[i][j];
	}
	
		
	/**
	 * Metodo che ritorna la funzione fi associata alla matrice
	 * @return l'array con la funzione fi
	 */
	public Function getFi(){
		return this.fi;
	}

	/**
	 * Metodo che ritorna la funzione row associata alla matrice
	 * @return l'array con la funzione row
	 */
	public Function getRow(){
		return this.row;
	}
	
	/**
	 * Metodo che ritorna a che colonna � associata la riga i;
	 * il valore ritornato � pari a -1, se la riga non � associata e
	 * -2 nel caso i sia > della dimensione della funzione
	 * @param i riga di cui voglio sapere la colonna a cui � associata
	 * @return la colonna a cui � assegnata o -1 se la colonna non � assegnata
	 */
	public int getFi(int i){
		if(i<this.fi.length())
			return this.fi.get(i);
		else return -2;
	}

	/**
	 * Metodo che ritorna a che riga � associata la colonna j;
	 * il valore ritornato � pari a -1, se la colonna non � associata
	 * e -2 nel caso j sia maggiore della dimensione della funzione
	 * @param j colonna di cui voglio sapere la riga a cui � associata
	 * @return la riga a cui � assegnata o -1 se la riga non � assegnata
	 */
	public int getRow(int j){
		if(j<this.row.length())
			return this.row.get(j);
		else return -2;
	}
	
	/**
	 * Metodo che ritorna il vettore u
	 * @return il vettore u
	 */
	public Function getu(){
		return this.u;
	}
	
	/**
	 * Metodo che ritorna il vettore v
	 * @return il vettore v
	 */
	public Function getv(){
		return this.v;
	}
	
	/**
	 * Metodo che ritorna l'elemento i del vettore u, se i non supera la dimensione di u,
	 * se la supera ritorna -2
	 * @param i indice dell'elemento da ritornare del vettore u
	 * @return valore dell'elemento della funzione u nella posizione i
	 */
	public int getu(int i){
		if(i<this.u.length())
			return this.u.get(i);
		else return -2;
	}
	
	/**
	 * Metodo che ritorna l'elemento j del vettore v, se j non supera la dimensione di v,
	 * se la supera ritorna -2
	 * @param j indice dell'elemento da ritornare del vettore v
	 * @return valore dell'elemento della funzione v nella posizione j
	 */
	public int getv(int j){
		if(j<this.v.length())
			return this.v.get(j);
		else return -2;
	}
	
	/**
	 * Metodo che l'elemento (i,j) della matrice dei costi ridotti
	 * @param i riga dell'elemento da trovare
	 * @param j colonna dell'elemento da trovare
	 * @return l'elemento (i,j) della matrice dei costi ridotti
	 */
	public int getReducedCostM(int i,int j){
		return this.costRelMatrix[i][j];
	}
	
	/**
	 * Metodo che ritorna una copia della matrice dei costi ridotti
	 * e non il riferimento alla matrice originale
	 * @return matrice dei costi ridotti
	 */
	public int [][]getReducedCostM(){
		if(this.costRelMatrix==null) 
			return null;
		int[][] costRedMat=new int[this.costMatrix.length][this.costMatrix.length];
		
		for(int i=0;i<this.costRelMatrix.length;i++){
			for(int j=0;j<this.costRelMatrix[0].length;j++){
				costRedMat[i][j]=this.getReducedCostM(i,j);
			}
		}
		return costRedMat;
	}
	
	
	
	/**
	 * Metodo che assegna il valore value alla posizione j della funzine row
	 * @param j indice della funzione row
	 * @param value valore da assegnare alla funzione row alla posizione j
	 */
	public void setRow(int j,int value){
		if(j<this.row.length())
			this.row.set(j,value);
	}
	
	/**
	 * Metodo che assegna il valore value alla posizione i della funzine fi
	 * @param i indice della funzione fi
	 * @param value valore da assegnare alla funzione fi alla posizione i
	 */
	public void setFi(int i,int value){
		if(i<this.fi.length())
			this.fi.set(i,value);
	}
	
	/**
	 * Metodo che assegna il valore value alla posizione j della funzine v
	 * @param j indice della funzione v
	 * @param value valore da assegnare alla funzione v alla posizione j
	 */
	public void setv(int j,int value){
		if(j<this.v.length()){
			this.v.set(j,value);
			this.updateReducedCostM();
		}
	}
	
	/**
	 * Metodo che assegna il valore value alla posizione i della funzine u
	 * @param i indice della funzione u
	 * @param value valore da assegnare alla funzione u alla posizione i
	 */
	public void setu(int i,int value){
		if(i<this.u.length()){
			this.u.set(i,value);
			this.updateReducedCostM();
		}
	}
	

		
	/**
	 * Metodo che ritorna la dimensione della matrice quadrata dei costi
	 * @return intero che rappresenta la dimensione della matrice dei costi
	 */
	public int getCostMatrixDim(){
		return this.costMatrix.length;
	}
	
	protected void updateReducedCostM(){
		for(int i=0;i<costRelMatrix.length;i++){
			for(int j=0;j<costRelMatrix.length;j++){
				this.costRelMatrix[i][j]=this.costMatrix[i][j]-this.u.get(i)-this.v.get(j);
			}
		}
	}
	
	
	public void setCosts(GraphInfo graph,int delta)
	{
		for(int i=0;i<graph.getSU().length();i++)
		{
			if(graph.getSU().isElementPresent(i))
				setu(i,getu(i)+delta);
			if(graph.getLV().isElementPresent(i))
				setv(i,getv(i)-delta);
		}
	}
	
	
	/**
	 * Metodo che ritorna la dimensione della matrice dei costi
	 * @return la dimensione della matrice dei costi
	 */
	public int size()
	{
		return this.costMatrix.length;
	}
}
