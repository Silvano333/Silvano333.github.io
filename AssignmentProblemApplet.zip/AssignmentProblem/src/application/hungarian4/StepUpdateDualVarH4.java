package application.hungarian4;

import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import application.common.Set;
import application.common.Utils;
import application.steps.AStep;
import presentation.IVisitor;

/**
 * Classe che contiene il codice dell'aggiornamento delle variabili
 * duali in Hungarian
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class StepUpdateDualVarH4 extends AStep {
	private int delta;
	public static final String name="UpdateDualVarH4";
	
	 /**
	 * Costruttore
	 * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param aN nome dell'algoritmo
	 */
	public StepUpdateDualVarH4(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,String aN)
	{
		super(graph,matrix,edgeColl,aN);
		this.delta = getMinimumReducedCost();
		matrix.setCosts(graph,delta);
		
		//Aggiorno le variabili di stato
		this.graph = new GraphInfo(graph);
		this.matrix = new AssignmentMatrix(matrix);
		this.edgeColl = new EdgeCollection(edgeColl);
	}
	
	/**
	 * metodo che ritorna all'esterno il valore di delta
	 * @return il valore aggiornato di delta 
	 */
	public int getDelta(){
		return this.delta;
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#getName()
	 */
	public String getName(){
		return StepUpdateDualVarH4.name;
	}
	
	 //	creo il vettore di tutti i valori di cui devo trovare il minimo
	/**
	 * Metodo che ritorna il minimo costo ridotto con cui
	 * effettuare l'aggiornamento
	 * @return il valore del nuovo delta
	 */
	private int getMinimumReducedCost()
	{
	    GraphInfo graphInfo = AStep.STATIC_GRAPH;
	    AssignmentMatrix mat =AStep.STATIC_MATRIX;
		//aggiorno le variabili duali
		Set VminusLV=graphInfo.getV().difference(graphInfo.getLV());
		
		int cardSU=graphInfo.getSU().getCardinality();
		int cardVminusLV=VminusLV.getCardinality();
		
		int[] vettReducedCost=new int[cardSU*cardVminusLV];
		int p=0;//indice per scorrere il vettore vettReducedCost
	
		for(int i=0;i<graphInfo.getSU().length();i++)
		{
			for(int j=0;j<VminusLV.length();j++)
			{
				if(graphInfo.getSU().isElementPresent(i) && VminusLV.isElementPresent(j))
				{
					vettReducedCost[p]=mat.getReducedCostM(i,j);
					p++;
				}
			}
		}
		return Utils.min(vettReducedCost);
		
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#accept(presentation.IVisitor)
	 */
	public void accept(IVisitor visitor){
		visitor.visit(this);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return " UPDATE THE DUAL SOLUTION";
	}

}
