
package application.hungarian4;

import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import application.common.Set;
import application.steps.AStep;
import application.steps.IAugPath;
import application.steps.StepPathEdge;
import presentation.IVisitor;
import presentation.configuration.GraphStyle;

/**
 * Step con tutti i cammini aumentanti
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */

public class StepAugPathH4 extends AStep implements IAugPath 
{
	public static final String name="AugPathH4";
    private int sink;
    private int initialSink;
    private int k;
    private boolean fail;
	
    /**
     * Costruttore
     * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param k vertice k di partenza
	 * @param aN nome della classe
     */
    public StepAugPathH4(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,int k,String aN)
	{
		super(graph,matrix,edgeColl,aN);
		this.k=k;
		graph.reset();
		this.fail=false;
		this.initialSink = this.sink = 0;
		int i=k;
		while(fail==false && sink==0)
		{
			graph.getSU().add(i);
			//creo la variabile per l'insieme V\LV
			Set VminusLV = graph.getV().difference(graph.getLV());
			for(int j=0;j<VminusLV.length();j++)
			{
				//se VminusLV[i]==0, l'elemento non c'� e quindi non devo fare nulla
				if(VminusLV.isElementPresent(j))
				{
					if(matrix.getReducedCostM(i,j)==0)
					{
						graph.getPred().set(j,i);
						graph.getLV().add(j);
						StepPathEdge pathEdge=new StepPathEdge(graph,matrix,edgeColl,i,j,true,GraphStyle.ALTERNATING_TREE,this.algoName );
						this.addChild(pathEdge);
					}
				}
			}
			Set LVminusSV = graph.getLV().difference(graph.getSV());
			if(LVminusSV.isEmpty())
			{
				return;
			}
			
			
			//trovo ora il primo j, se esiste, dei vertici appartenenti a LV\SV
			int j;
			j=LVminusSV.firstElement();
			
			
			//se j esisteva continuo con l'algoritmo
			if (j!=-1)
			{
				graph.getSV().add(j);
				if(matrix.getRow(j)==-1)
				{
					sink=j;
					
				}
				else 
				{
					//Ho scelto il cammino,	aggiorno gli archi all'indietro
 
					i=matrix.getRow(j);
					this.addChild(new StepPathEdge(graph,matrix,edgeColl,i,j,false,GraphStyle.ALTERNATING_TREE,this.algoName));
					
				}
			
			}
			else return;
		}
	}
	
    /**
	 * Metodo che ritorna il vertice di partenza della procedura 
	 * Alternate(k), k appunto
	 * @return il vertice iniziale
	 */
    public int getVertexNum(){
    	return this.k;
    }
	
    /**
	 * Metodo che ritorna il valore con cui � inizializzato sink
	 * all'inizio della procedura
	 * @return il valore iniziale della variabile sink
	 */
    public int getInitialSink(){
		return this.initialSink;
	}
	
    /**
     * Metodo che ritorna all'esterno il valore della variabile fail della
     * procedura Alternate(k), che indica se si � trovato o meno un cammino
     * aumentante
     * @return valore della variabile fail
     */
    public boolean getFail(){
		return this.fail;
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#accept(presentation.IVisitor)
	 */
	public void accept(IVisitor visitor){
		visitor.visit(this);
	}
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#getName()
	 */
	public String getName(){
		return StepAugPathH4.name;
	}
	

	/* (non-Javadoc)
	 * @see application.steps.IAugPath#getSink()
	 */
	public int getSink()
	{
	    return this.sink;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return " PROCEDURE ALTERNATE("+(this.k+1)+")";
	}
	
}
