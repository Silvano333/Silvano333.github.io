package application.hungarian4;

import application.AssignmentProblemAlgorithm;
import application.IPreprocessingAlgorithm;
import application.common.Set;
import application.steps.AStep;
import application.steps.StepGoal;



/**
 * Classe che implementa l'algoritmo Hungarian
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class Hungarian4Algorithm extends AssignmentProblemAlgorithm 
{
	/*
	 * Eredita:
	 * Step preProcStep;
	 * Step rootStep;
	 * Step goal;
	 */
	private IPreprocessingAlgorithm preProcAlgo;
    
	/**
     * @param preProcAlgo riferimento a una classe di tipo IPreprocessing che contiene la fase di preprocessing
	 * @param aN nome dell'algoritmo
     */
    public Hungarian4Algorithm(IPreprocessingAlgorithm preProcAlgo,String aN)
	{
		super(preProcAlgo,aN);
	}
	
	
	
	/* (non-Javadoc)
	 * @see application.AssignmentProblemAlgorithm#buildFromAlgorithm()
	 */
	protected void buildFromAlgorithm()
	{
		
		Set U=new Set(matrix.getCostMatrixDim(),1);
		Set Usign=Set.setAssigned(matrix.getFi());
		
		while(Usign.getCardinality()<matrix.getCostMatrixDim())
			assignElement(U,Usign);
		
		//aggiorno lo step con la soluzione
		AStep goal=new StepGoal(AStep.STATIC_GRAPH,
				AStep.STATIC_MATRIX,AStep.STATIC_EDGECOLL,this.algoName);
		this.getRootStep().addChild(goal);			
	}
	
	/**
	 * Metodo che si occupa di scegliere un vertice non ancora assegnato
	 * e cerca di assegnarlo
	 * @param U insieme di tutti i vertici
	 * @param Usign insieme dei vertici gi� assegnati
	 */
	protected void assignElement(Set U,Set Usign)
	{
		//nuovo ciclo principale quindi avr� un nuovo vettore dei cammini in avanti
		
		Set UminusUsign=U.difference(Usign);
		int k=UminusUsign.firstElement();
		
		StepVertexH4 stepVertex = new StepVertexH4(AStep.STATIC_GRAPH,AStep.STATIC_MATRIX,AStep.STATIC_EDGECOLL,Usign,k,this.algoName);
		this.getRootStep().addChild(stepVertex);
		
		
	}
	
}
