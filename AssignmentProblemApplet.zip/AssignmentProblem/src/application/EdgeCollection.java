package application;

import java.util.Vector;

import application.common.Edge;



/**
 * Classe che contiene tutti gli archi in avanti e indietro di uno step
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class EdgeCollection 
{
	private Vector back,fwd;
	
	/**
	 * Costruttore base della classe che crea due vettori di archi
	 * uno in avanti e uno indietro, ancora vuoti
	 */
	public EdgeCollection()
	{
		this.back = new Vector();
		this.fwd  = new Vector();
	}
	
	/**
	 * Costruttore che permette di creare un EdgeCollection
	 * partendo da un'istanza della stessa classe. La costruzione 
	 * avviene sempre per copia  
	 * @param edgeColl istanza della classe EdgeCollection con cui si crea la nuova istanza
	 */
	public EdgeCollection(EdgeCollection edgeColl)
	{
		this.back = new Vector();
		this.fwd  = new Vector();
		
		for(int i=0;i<edgeColl.backwardEdgesNumber();i++){
			Edge e=(Edge)edgeColl.getBackwardEdge(i);
			this.back.add(new Edge(e));
		}
		
		for(int i=0;i<edgeColl.forwardEdgesNumber();i++){
			Edge e=(Edge)edgeColl.getForwardEdge(i);
			this.fwd.add(new Edge(e));
		}
	}
	
	/**
	 * Metodo che permette di aggiungere un nuovo arco
	 * al vettore degli archi in avanti
	 * @param edge arco in avanti da inserire nel vettore degli archi in avanti
	 */
	public void addForwardEdge(Edge edge)
	{
		fwd.add(edge);
	}
	
	/**
	 * Metodo che permette di aggiungere un nuovo arco
	 * al vettore degli archi indietro
	 * @param edge arco indietro da inserire nel vettore degli archi indietro
	 */
	public void addBackEdge(Edge edge)
	{
		back.add(edge);
	}
	
	/**
	 * Metodo che permette di estrarre l'arco alla posizione i
	 * del vettore degli archi in avanti
	 * @param i indice della posizione dell'arco da estrarre
	 * @return arco in avanti nella posizione i del vettore degli archi
	 */
	public Edge getForwardEdge(int i)
	{
		return (Edge)this.fwd.get(i);
	}
	
	/**
	 * Metodo che permette di estrarre l'arco alla posizione i
	 * del vettore degli archi indietro
	 * @param i indice della posizione dell'arco da estrarre
	 * @return arco indietro nella posizione i del vettore degli archi
	 */
	public Edge getBackwardEdge(int i)
	{
		return (Edge)this.back.get(i);
	}
	
	
	
	/**
	 * Metodo che permette di ritornare tutti gli archi in avanti
	 * @return vettore degli archi in avanti
	 */
	public Vector getForwardEdges()
	{
		return this.fwd;
	}
	
	/**
	 * Metodo che permette di ritornare tutti gli archi indietro
	 * @return vettore degli archi indietro
	 */
	public Vector getBackEdges()
	{
		return this.back;
	}
	
	
	
	
	/**
	 * Metodo che permette di rimuovere l'arco e dal vettore degli archi
	 * in avanti
	 * @param e arco in avanti da rimuovere
	 */
	public void removeForwardEdge(Edge e)
	{
		this.fwd.remove(e);
	}
	
	/**
	 * Metodo che permette di rimuovere l'arco e dal vettore degli archi
	 * indietro
	 * @param e arco indietro da rimuovere
	 */
	public void removeBackwardEdge(Edge e)
	{
		this.back.remove(e);
	}
	
	/**
	 * Metodo che permette di rimuovere l'arco alla posizione i
	 * dal vettore degli archi in avanti
	 * @param i posizione dell'arco in avanti da rimuovere
	 */
	public void removeForwardEdge(int i)
	{
		this.fwd.remove(i);
	}
	
	/**
	 * Metodo che permette di rimuovere l'arco alla posizione i
	 * dal vettore degli archi indietro
	 * @param i posizione dell'arco indietro da rimuovere
	 */
	public void removeBackwardEdge(int i)
	{
		this.back.remove(i);
	}
	
	
	/**
	 * metodo che ritorna la dimensione del vettore
	 * degli archi in avanti
	 * @return dimensione del vettore degli archi in avanti
	 */
	public int forwardEdgesNumber()
	{
		return this.fwd.size(); 
	}
	
	/**
	 * metodo che ritorna la dimensione del vettore
	 * degli archi indietro
	 * @return dimensione del vettore degli archi indietro
	 */
	public int backwardEdgesNumber()
	{
		return this.back.size(); 
	}
	
	/**
	 * Metodo che resetta i vettori degli archi in aventi e indietro
	 * riportandoli ad essere vuoti
	 * 
	 */
	public void reset(){
		this.back=new Vector();
		this.fwd=new Vector();
	}

}
