package application.common;



/**
 * Classe che realizza il concetto di insieme
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 */
public class Set
{
    protected int[]set;
    
    
    /**
     * Costruttore della classe Set con un array di interi che mi rappresenter� 
     * l'insieme
     * @param s array di interi che mi rappresenta l'insieme
     */
    public Set(int[] s){
        set = new int[s.length]; 
        for(int i=0;i<s.length;i++)
            set[i] = s[i];
    }
    
    /**
     * Costruttore a due parametri di Set
     * @param n dimensione dell'insieme
     * @param value valore con cui inizializzo l'insieme
     */
    public Set(int n,int value){
        set = new int[n];
        for(int i=0;i<n;i++)
            set[i] = value;
    }
    
    /**
     * Costruttore che crea un nuovo insieme uguale all'insieme dati in ingresso
     * @param s insieme di cui fare la copia
     */
    public Set(Set s){
    	if(s.isNull())
            return;
    	set = new int[s.length()]; 
        for(int i=0;i<s.length();i++){
        	if(s.isElementPresent(i))
        		this.set[i]=1;
        	else
        		this.set[i]=0;
        }
    }
    
    /**
	 * Metodo che ritorna un insieme con i vertici assegnati, dato in ingresso
	 * una funzione di assegnamento dei vertici, che come ha valore -1 a un dato indice,
	 * se quel vertice non � assegnato a nessuno e il valore del vertice a cui � 
	 * assegnato altrimenti.
	 * @param funz una funzione di assegnamento dei vertici
	 * @return insieme contenente i vertici assegnati
	 */
	public static Set setAssigned(Function funz){
		int []set=new int[funz.length()];
		for(int i=0;i<funz.length();i++){
			if(funz.get(i)==-1) //elemento non assegnato
				set[i]=0;
			else //elemento assegnato
				set[i]=1;
		}
		Set ris=new Set(set);
		return ris;
	}
    
	/**
	 * Metodo che contolla se nell'insieme � presente un dato valore
	 * @param index valore da verificare se presente nell'insieme
	 * @return true se l'elemente � presente, false altrimenti
	 */
	public boolean isElementPresent(int index){
        if(this.isNull())
            return false;
        if(index>=set.length)
            return false;
        if(this.set[index]==1)
            return true;
        else 
            return false;
    }
   
    /**
     * Metodo che ritorna la dimensione del modo di rappresentare l'insieme,
     * ritorna il valore pi� uno dell'elemento maggiore che l'insieme pu� contenere 
     * @return la dimesione della rappresentazione dell'insieme
     */
    public int length()
    {
        if(this.isNull())
            return 0;
        return this.set.length;
    }
    
    
    /**
	 * Metodo che esegue la differenza fra due insiemi, 
	 * ogni insieme � di una certa dimensione e ha come 
	 * elemento 1 se possiede l'elemento di tale indice o 
	 * zero se non possiede l'elemento di tale indice.
	 * L'insieme risultante � lungo quanto l'insieme di partenza 
	 * e contiene il risultato della sottrazione in senso
	 * insiemistico.
	 * esempio: l'insieme a={1,3,4,5} � rappresentato dal vettore
	 * a={0,1,0,1,1,1}, se gli sottraggo b={1,1,1,0,1} (che rappresenta 
	 * l'insieme {0,1,2,4}) ottengo il vettore {0,0,0,1,0,1} 
	 * @param b insieme sottraendo
	 * @return true se l'operazione � andata a buon fine
	 */
	public Set difference(Set b){
	    Set ris = new Set(this.set);
	    try{
	        if(this.isNull())
	            return null;
	        for(int i=0;i<this.set.length;i++){
	            
	            //se set[i]=0 il risultato � uguale a zero quindi guardo l'altro caso
	            if(this.isElementPresent(i)){
	                if(b.isElementPresent(i))
	                    ris.resetElement(i);
	                else
	                    ris.setElement(i);
	            }
	            else{
	                ris.resetElement(i);
	            }
	        }
	        return ris;
	    }catch(Exception e){
	        return null;
	    }
	}
	
	
	/**
	 * Metodo che aggiunge all'insieme un valore in senso insiemistico,
	 * cio� lo fa solo se il valore era assente dall'insieme,
	 * per semplificare la sua realizzazione, si � scelto di creare un array delle dimensioni 
	 * dell'elemento con valore pi� elevato dell'insieme e mettere zero se l'elemento, 
	 * rappresentato dall'indice del vettore, � assente e 1 se l'elemento � presente.
	 *
	 * @param value valore da aggiungere all'insieme
	 */
	
	public boolean add(int value){
		try{
			set[value]=1;
			return true;
		}
		catch(Exception e){
			//creo un vettore abbastanza grande da contenere anche il valore dato
			int[]ris=new int[value+1];
			
			//per i valori minori del set, avr� i valori dell'insieme set
			//per l'indice value verr� messo un 1 e saranno a zero tutti gli altri valori
			for(int i=0;i<ris.length;i++){
				if(i<set.length){
					ris[i]=set[i];
				}
				else if(i==value)
					ris[i]=1;
				else
					ris[i]=0;
			}
			set=ris;
			return true;
		}
		
		
	}
	
	/**
	 * Metodo che controlla se l'insieme della classe sia nullo
	 * @return true se l'insieme non � null, false altrimenti
	 */
	protected boolean isNull(){
	    if(this.set==null)
	        return true;
	    else
	        return false;
	}
	
	/**
	 * Metodo che controlla se l'insieme, rappresentato da un vettore, � vuoto.
	 * L'insieme � vuoto se tutti i suoi elementi sono nulli, non lo � altrimenti
	 * @return true se l'insieme � vuoto, false altrimenti
	 */
	public boolean isEmpty(){
	    if(this.isNull())
            return false;
		for(int i=0;i<set.length;i++){
			if(this.isElementPresent(i)) return false;
		}
		return true;
	}
	
	/**
	 * Metodo che ritorna la cardinalit� dell'insieme
	 * @return cardinalit� dell'insieme
	 */
	public int getCardinality(){
		int cardinality=0;
		if(this.isNull())
            return cardinality;
		for(int i=0;i<set.length;i++){
			if(this.isElementPresent(i))
				cardinality++;
		}
		return cardinality;
	}
	
	/**
	 * Metodo che ritorna il primo elemento, inteso come quello di valore pi� basso,
	 * dell'insieme, valore che se l'insieme non � vuoto � >=0, il metodo ritorna
	 * -1 nel caso l'insieme sia vuoto.
	 * @return il primo elemento se l'insieme non � vuoto, -1 altrimenti
	 */
	public int firstElement(){
		int first=-1;
		if(this.isNull())
            return first;
		for(int i=0;i<set.length;i++){
			if(this.isElementPresent(i)){ 
				first=i;
				break;
			}
		}
		return first;
	}
	
	/**
	 * Metodo che ritorna l'elemento successivo all'elemento dato in ingresso
	 * @param index indice dell'elemento successivo a questo
	 * @return il primo elemento dopo index se esiste, -1 altrimenti
	 */
	public int nextElement(int index){
		int element=-1;
		if(this.isNull()||(index+1>this.set.length-1))
            return element;
		if(index<0)
			return firstElement();
		else{
			for(int i=index+1;i<set.length;i++){
				if(this.isElementPresent(i)){ 
					element=i;
					break;
				}
			}
		}
		return element;
	}
	
	/**
	 * Metodo che verifica se un elemento k � contenuto nell'insieme.
	 * Se l'elelemento � contenuto il metodo ritorna true, ritorna false altrimenti.
	 * @param k elemento di cui si vuole conoscere l'apparteneza o meno all'insieme
	 * @return true se k appartiene all'insieme, false altrimenti
	 */
	public boolean isElementContained(int k){
		try{
			if(this.isElementPresent(k)) return true;
			else return false;
		}
		catch(Exception e){
			return false;
		}
	}
	
	/**
	 * metodo che mette il valore all'elemento index a presente
	 * @param index indice dell'elemento
	 */
	public void setElement(int index){
	    if(this.isNull())
	        return;
	    if(this.set.length>index)
	        this.set[index]=1;
	    
	}
	
	/**
	 * metodo che mette il valore all'elemento index a assente
	 * @param index indice dell'elemento
	 */
	public void resetElement(int index){
	    if(this.isNull())
	        return;
	    if(this.set.length>index)
	        this.set[index]=0;
	    
	}
	
	/**
	 * metodo che fa diventare l'insieme, un insieme vuoto
	 */
	public void resetSet(){
	    if(this.isNull())
	        return;
	    for(int i=0;i<set.length;i++){
	    	this.resetElement(i);
		}
	    
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
	    if(this.isNull())
	        return "insieme vuoto";
	    String res="{";
	    for(int i=0;i<set.length;i++)
	    {
	        if(isElementPresent(i)){
	        	if(res.equalsIgnoreCase("{"))
	        		res +=(i+1);
	        	else
	        		res +=", "+(i+1);
	        }
	    }
	    res+="}";
	    return res;  
	        
	}
}
