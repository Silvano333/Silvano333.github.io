package application.common;

/**
 * Classe che modella il concetto di arco
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 *
 */
public class Edge {
	public static final int DIR_viTOvj=0,
							DIR_vjTOvi=1,
							NO_DIR=2;
	private int path;
	private int vi;
	private int vj;
	private int dir;
	
	/**
	 * Costruttore di Edge
	 * @param i vertice di arrivo dell'arco orientato
	 * @param j vertice di partenza dell'arco orientato
	 * @param path numero che dice a che path appartiene l'arco, � pari a 0 se l'arco non appartiene ad alcun cammino
	 * @param direction direzione dell'arco, valori possibili DIR_viTOvj=0,DIR_vjTOvi=1,NO_DIR=2
	 */
	public Edge(int i,int j,int path,int direction){
		this.vi=i;
		this.vj=j;
		this.path=path;
		this.dir=direction;
	}
	
	/**
	 * Costruttore che mi crea un arco come copia dell'altro arco dato in ingresso
	 * @param e arco di cui fare la copia
	 */
	public Edge(Edge e){
		this.vi=e.getVi();
		this.vj=e.getVj();
		this.path=e.getPath();
		this.dir=e.getDir();
	}
	
	/**
	 * Metodo che ritorna il vertice vi
	 * @return il vertice vi, punto di partenza dell'arco orientato
	 */
	public int getVi(){
		return this.vi;
	}
	
	
	/**
	 * Metodo che ritorna il vertice vj
	 * @return il vertice vj, punto di arrivo dell'arco orientato
	 */
	public int getVj(){
		return this.vj;
	}
	
	/**
	 * Metodo che ritorna il cammino associato all'arco
	 * @return intero che rappresenta il cammino associato all'arco
	 */
	public int getPath(){
		return this.path;
	}
	
	/**
	 * Metodo che permette di cambiare il path dell'arco
	 * @param p path dell'arco
	 */
	public void setPath(int p){
		this.path=p;
	}
	
	/**
	 * Metodo che ritorna orientamento dell'arco
	 * @return orientamento dell'arco, valori possibili DIR_viTOvj=0,DIR_vjTOvi=1,NO_DIR=2
	 */
	public int getDir(){
		return this.dir;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		if(this.dir==Edge.NO_DIR){
			return "Arco non orientato "+this.vi+"->"+this.vj;
		}
		if(this.dir==Edge.DIR_viTOvj){
			return "Arco orientato avanti "+this.vi+"->"+this.vj;
		}
		return "Arco orientato indietro"+this.vj+"->"+this.vi;
	}

}
