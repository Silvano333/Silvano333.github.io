package application.common;

/**
 * Classe che incapsula il concetto di funzione e ne facilita l'accesso
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class Function {
	protected int[]function;
	protected int addPrintValue;
	
	/**
	 * Costruttore della funzione che ha in ingresso la dimensione della funzione
	 * e il valore con cui inizializzare la funzione
	 * @param dim dimensione della funzione
	 * @param startValue valore iniziale della funzione
	 * @param addPV valore che deve essere eventualmente aggiunto al valore della funzione per le stampe
	 * 	a video
	 */
	public Function(int dim,int startValue,int addPV){
		this.function=new int[dim];
		for(int i=0;i<dim;i++){
			this.function[i]=startValue;
		}
		this.addPrintValue=addPV;
	}
	
	/**
     * Costruttore della classe Function con un array di interi che mi rappresenter� 
     * la funzione
     * @param f array di interi che mi rappresenta la funzione
     */
    public Function(Function f){
        this.function = new int[f.length()]; 
        for(int i=0;i<this.function.length;i++)
            this.function[i] = f.get(i);
        this.addPrintValue=f.addPrintValue;
    }
	
	/**
	 * Metodo che ritorna il valore della funzione alla posizione index.
	 * Esce dal sistema in caso di errore
	 * @param index indice della posizione della funzione da conoscere
	 * @return valore della funzione in quel punto o -1000 in caso di errore
	 */
	public int get(int index){
		if(this.function==null){
			System.out.println("Function null, get failed.");
			System.exit(-1);
		}
        if((index>=this.function.length)||(index<0)){
			System.out.println("Function.get(index):index out of range="+index);
			System.exit(-1);
		}
        return this.function[index];
	}
	
	/**
	 * metodo che mette il valore value all'elemento index 
	 * @param index indice dell'elemento
	 * @param value valore della funzione nella posizione index
	 */
	public void set(int index,int value){
	    if(this.function==null)
	        return;
	    if((this.function.length>index)&&(index>-1))
	        this.function[index]=value;
	    
	}
	
	/**
	 * Metodo, che se la Function non � nulla
	 * rinizializza tutta la funzione con il valore value
	 * @param value valore attribuito ad ogni elemento della Function
	 */
	public void reset(int value){
		if(this.function==null)
	        return;
		for(int i=0;i<this.function.length;i++){
			this.function[i]=value;
		}
	}
	
	/**
	 * Metodo che ritorna la dimensione della funzione
	 * @return dimensione della Function
	 */
	public int length(){
		return this.function.length;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		if(this.function==null)
	        return "funzione nulla";
	    String res="{";
	    for(int i=0;i<this.function.length-1;i++)
	    {
	        res +=" "+(this.function[i]+addPrintValue)+",";
	    }
	    res+=" "+(this.function[this.function.length-1]+addPrintValue)+"}";
	    return res;  
	}

}
