package application.common;

/**
 * Classe che Contiene metodi di utilit� comune
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class Utils {
	/**
     * Metodo che dato un array di valori ritorna il valore minimo.
     * Se l'array dato in ingresso � vuoto, ritorna il valore -1
     * @param values array di valori di cui si vuiole trovare il valore minimo
     * @return il minimo dei valori dati in ingresso
     */
    public static int min(int[]values)
    {
    	int minimum;
    	/*
    	 * inizializzo minimum con il primo valore dell'array se esiste altrimenti con -1
    	 */
    	if(values.length!=0) minimum=values[0];
    	else minimum=-1;
    	
    	/*
    	 * Calcolo il minimo dell'array
    	 */
    	for(int i=1;i<values.length;i++)
    		if(values[i]<minimum)
    			minimum=values[i];
    		
    	return minimum;
    }
}
