package application.hungarian3;


import presentation.IVisitor;
import presentation.configuration.GraphStyle;
import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import application.common.Set;
import application.steps.AStep;
import application.steps.IAugPath;
import application.steps.StepPathEdge;

/**
 * Classe che contiene la procedura Augment(k) dell'algoritmo ungherese
 * con complessit� O(n^3)
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 */
public class StepAugPathH3 extends AStep implements IAugPath {

	public static final String name="AugPathH3";
    protected int sink, initialSink;
    private int k;
    
	/**
	 * Costruttore che riceve in ingresso lo stato, il vertice di partenza
	 * e il nome dell'algoritmo
	 * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param k vertice k di partenza
	 * @param aN nome della classe
	 */
	public StepAugPathH3(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,int k,String aN)
	{
		super(graph,matrix,edgeColl,aN);
		
		//inizializzo piGreco con il valore pi� grande possibile 
		//per la variabile locale e quella globale
		graph.resetPiGreco();
		this.graph.resetPiGreco();
		this.graph.reset();
		
		this.k =k;
		graph.reset();
		this.initialSink = this.sink = 0;
		int i=k;
		
		while(sink==0)
		{
			//metto un booleano per vedere se prima di passare
			//all'update var duali ho fatto almeno un passo
			//con il for each realizzato con il for
			//in questo caso quando mostro update var duali
			//faccio vedere anche il StepEndIteration
			//altrimenti no
			boolean oneOp=false;
			
			graph.getSU().add(i);
			
			//creo la variabile per l'insieme V\LV
			Set VminusLV = graph.getV().difference(graph.getLV());
			for(int j=0;j<VminusLV.length();j++)
			{
				//se VminusLV[i]==0, l'elemento non c'� e quindi non devo fare nulla
				if(VminusLV.isElementPresent(j))
				{
					if(matrix.getReducedCostM(i,j)<graph.getPi(j))
					{
						graph.getPred().set(j,i);
						graph.getPi().set(j,matrix.getReducedCostM(i,j));
						if(graph.getPi(j)==0){
							graph.getLV().add(j);
							StepPathEdge pathEdge=new StepPathEdge(graph,matrix,edgeColl,i,j,true,GraphStyle.ALTERNATING_TREE,this.algoName );
							this.addChild(pathEdge);
						}
						oneOp=true;
						
					}
				}
			}//end for
			
			Set LVminusSV = graph.getLV().difference(graph.getSV());
			
			
			if(LVminusSV.isEmpty()) //update dual varibles
			{
				if(oneOp)
					this.addChild(new StepEndIteration(graph,matrix,edgeColl, i,-1,this.algoName));
				
				StepUpdateDualVarH3 stepUpdateDV=new StepUpdateDualVarH3(graph,
					       matrix,edgeColl,this.algoName);
					
				this.addChild(stepUpdateDV);
				for(int j=0;j<VminusLV.length();j++){
					if(VminusLV.isElementPresent(j))
					{
						if(graph.getPi(j)==0){
							graph.getLV().add(j);
						
							for(int w=0;w<graph.getSU().length();w++){
								if(graph.getSU().isElementPresent(w) &&
										matrix.getReducedCostM(w,j)== 0){
									StepPathEdge pathEdge=new StepPathEdge(graph,matrix,edgeColl,w,j,true,GraphStyle.ALTERNATING_TREE,this.algoName );
									this.addChild(pathEdge);
								}
							}//endfor	
						}//endif
					}//endif
				}//endfor
			}
			
			
			//trovo ora il primo j, se esiste, dei vertici appartenenti a LV\SV
			int j;
			LVminusSV = graph.getLV().difference(graph.getSV());
			j=LVminusSV.firstElement();
			
			//se j esisteva continuo con l'algoritmo
			if (j!=-1)
			{
				graph.getSV().add(j);
				this.addChild(new StepEndIteration(graph,matrix,edgeColl, i,j,this.algoName));
				if(matrix.getRow(j)==-1)
				{
					sink=j;
					
				}
				else 
				{
					//Ho scelto il cammino,	aggiorno gli archi all'indietro
 
					i=matrix.getRow(j);
					this.addChild(new StepPathEdge(graph,matrix,edgeColl,i,j,false,GraphStyle.ALTERNATING_TREE,this.algoName));
					
				}
			
			}
			else return;
		}
		
	}
	
	/**
	 * Metodo che ritorna il vertice di partenza della procedura 
	 * Augment(k), k appunto
	 * @return il vertice iniziale
	 */
	public int getVertexNum(){
    	return this.k;
    }
	
	/**
	 * Metodo che ritorna il valore con cui � inizializzato sink
	 * all'inizio della procedura
	 * @return il valore iniziale della variabile sink
	 */
	public int getInitialSink(){
		return this.initialSink;
	}
	
	/* (non-Javadoc)
	 * @see application.steps.IAugPath#getSink()
	 */
	public int getSink()
	{
	    return this.sink;
	}
	
	
	/* (non-Javadoc)
	 * @see application.AStep#accept(presentation.IVisitor)
	 */
	public void accept(IVisitor visitor) {
		visitor.visit(this);

	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return " PROCEDURE AUGMENT("+(this.k+1)+")";
	}

	/* (non-Javadoc)
	 * @see application.AStep#getName()
	 */
	public String getName() {
		return StepAugPathH3.name;
	}

}
