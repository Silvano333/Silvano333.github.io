package application.hungarian3;


import presentation.IVisitor;
import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import application.common.Function;
import application.common.Set;
import application.common.Utils;
import application.steps.AStep;

/**
 * Classe che contiene il codice dell'aggiornamento delle variabili
 * duali in Hungarian^3
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class StepUpdateDualVarH3 extends AStep {
	private int delta;
	public static final String name="UpdateDualVarH3";
	
	/**
	 * Costruttore
	 * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param aN nome dell'algoritmo
	 */
	public StepUpdateDualVarH3(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,String aN)
	{
		super(graph,matrix,edgeColl,aN);
		
		Set VminusLV=graph.getV().difference(graph.getLV());
		
		this.delta=this.getMinPi(VminusLV,graph.getPi());
		matrix.setCosts(graph,delta);
		for(int j=0;j<VminusLV.length();j++){
			if(VminusLV.isElementPresent(j))
			{
				//pij=pij-delta
				graph.getPi().set(j,graph.getPi(j)-delta);
			}
		}
		
		//Aggiorno le variabili di stato
		this.graph = new GraphInfo(graph);
		this.matrix = new AssignmentMatrix(matrix);
		this.edgeColl = new EdgeCollection(edgeColl);
	}
	
	
	/**
	 * Metodo che ritorna il valore del minimo pi, che
	 * rappresenta il valore delta dell'aggiornamento
	 * @param VminusLV l'insieme contentente i vertici di V non ancora etichettati
	 * @param pi Function pi
	 * @return il valore di delta dell'aggiornamento
	 */
	protected int getMinPi(Set VminusLV,Function pi){
		//delta=min{pigrecoj : j e V\LV}
		
		//vettore che contiene i pigreco di cui devo trovare il minimo
		int []vettPi=new int[VminusLV.getCardinality()];
		int vettPiIndex=0;
		for(int j=0;j<VminusLV.length();j++){
			if(VminusLV.isElementPresent(j))
			{
				vettPi[vettPiIndex]=pi.get(j);
				vettPiIndex++;
			}
		}
		
		return Utils.min(vettPi);
	}
	
	/**
	 * metodo che ritorna all'esterno il valore di delta
	 * @return valore di delta
	 */
	public int getDelta(){
		return this.delta;
	}
	
	
	/* (non-Javadoc)
	 * @see application.AStep#accept(presentation.IVisitor)
	 */
	public void accept(IVisitor visitor) {
		visitor.visit(this);

	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return " UPDATE THE DUAL SOLUTION";
	}

	/* (non-Javadoc)
	 * @see application.AStep#getName()
	 */
	public String getName() {
		return StepUpdateDualVarH3.name;
	}

}
