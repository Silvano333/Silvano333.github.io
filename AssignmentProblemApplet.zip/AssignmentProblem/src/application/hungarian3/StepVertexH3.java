package application.hungarian3;


import presentation.IVisitor;
import application.*;
import application.common.Set;
import application.steps.AStep;
import application.steps.StepNewAssign;
import application.steps.StepPathEdgesReass;

/**
 * Classe che trova l'assegnamento per un vertice non assegnato k, dato
 * in ingresso per l'algoritmo Hungarian^3
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 */
public class StepVertexH3 extends AStep {
	public static final String name="VertexH3";
	private int k;
    
	
	/**
	 * Costruttore
     * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
     * @param Usign insieme dei vertici assegnati
     * @param k vertice non assegnato da assegnare
     * @param aN nome dell'algoritmo
     */
    public StepVertexH3(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,Set Usign,int k,String aN)
	{
		super(graph,matrix,edgeColl,aN);
		this.k = k;
		
		edgeColl.reset();
		StepAugPathH3 pathStep = new StepAugPathH3(graph,
			       matrix,edgeColl,k,this.algoName);
		
		
		this.addChild(pathStep);
		
		StepPathEdgesReass stepReass=new StepPathEdgesReass(graph,
			       matrix,edgeColl,k,pathStep,this.algoName);
		this.addChild(stepReass);
		
		edgeColl=stepReass.updateEdgeCollection();
		
		int sink=pathStep.getSink();	
		Usign.add(k);
				
		int i=-1;int j=sink;
		do
		{
			StepNewAssign stepNewAssign=new StepNewAssign(graph,
					       matrix,edgeColl,j,this.algoName);
					
			this.addChild(stepNewAssign);
			i=stepNewAssign.geti();
			j=stepNewAssign.getj();
				  	
		}while(i!=k);
				
				
	}

	/* (non-Javadoc)
	 * @see application.AStep#accept(presentation.IVisitor)
	 */
	public void accept(IVisitor visitor) {
		visitor.visit(this);

	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return " NEW UNASSIGNED VERTEX OF U";
	}

	 /**
	  * Metodo che ritorna il vertice non assegnato, da assegnare
	 * @return vertice non assegnato da assegnare
	 */
	public int getVertexNum(){
    	return this.k;
    }
	
	/* (non-Javadoc)
	 * @see application.AStep#getName()
	 */
	public String getName() {
		return StepVertexH3.name;
	}

}
