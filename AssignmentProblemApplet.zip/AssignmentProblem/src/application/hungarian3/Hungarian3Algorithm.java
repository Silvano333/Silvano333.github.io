package application.hungarian3;


import application.IPreprocessingAlgorithm;
import application.common.Set;
import application.hungarian4.Hungarian4Algorithm;
import application.steps.AStep;

/**
 * Classe che deriva da Hungarian4Algorithm e che implementa
 * l'algoritmo ungherese^3
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class Hungarian3Algorithm extends Hungarian4Algorithm {
	
	/**
	 * Costruttore a 2 parametri
	 * @param preProcAlgo riferimento a una classe di tipo IPreprocessing che contiene la fase di preprocessing
	 * @param aN nome dell'algoritmo
	 */
	public Hungarian3Algorithm(IPreprocessingAlgorithm preProcAlgo,String aN)
	{
		super(preProcAlgo,aN);
	}
	
	/* (non-Javadoc)
	 * @see application.hungarian4.Hungarian4Algorithm#assignElement(application.common.Set, application.common.Set)
	 */
	protected void assignElement(Set U,Set Usign)
	{
		//nuovo ciclo principale quindi avr� un nuovo vettore dei cammini in avanti
		
		Set UminusUsign=U.difference(Usign);
		int k=UminusUsign.firstElement();
		
		StepVertexH3 stepVertex = new StepVertexH3(AStep.STATIC_GRAPH,AStep.STATIC_MATRIX,AStep.STATIC_EDGECOLL,Usign,k,this.algoName);
		this.getRootStep().addChild(stepVertex);
		
		
	}
}
