package application.hungarian3;

import presentation.IVisitor;
import application.AssignmentMatrix;
import application.EdgeCollection;
import application.GraphInfo;
import application.steps.AStep;

/**
 * Classe di step riassunto per vedere la situazione alla fine 
 * di un ciclo della procedura Augment(k)
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class StepEndIteration extends AStep {

	public static final String name="EndUpdatePi";
	protected int i,j;
	
	/**
	 * Costruttore
	 * @param graph istanza di GraphInfo
	 * @param matrix istanza di AssignmentMatrix
	 * @param edgeColl istanza di EdgeCollection
	 * @param i vertice iniziale appartenente a U del passo di cui si riassume l'andamento
	 * @param j vertice finale appartenente a V del passo di cui si riassume l'andamento
	 * @param aN nome dell'algoritmo
	 */
	public StepEndIteration(GraphInfo graph,AssignmentMatrix matrix,EdgeCollection edgeColl,int i,int j,String aN)
	{
		super(graph,matrix,edgeColl,aN);
		this.i=i;
		this.j=j;
	}
	
	/**
	 * Metodo che ritorna vertice iniziale appartenente a U del passo di cui si riassume l'andamento
	 * @return vertice iniziale appartenente a U del passo di cui si riassume l'andamento
	 */
	public int getI(){
		return this.i;
	}
	
	/**
	 * Metodo che ritorna vertice finale appartenente a V del passo di cui si riassume l'andamento
	 * @return vertice finale appartenente a V del passo di cui si riassume l'andamento
	 */
	public int getJ()
	{
		return this.j;
	}
	
	
	/* (non-Javadoc)
	 * @see application.steps.AStep#accept(presentation.IVisitor)
	 */
	public void accept(IVisitor visitor) {
		visitor.visit(this);

	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return " PROCEDURE AUGMENT(K): END OF AN ITERATION";
	}

	/* (non-Javadoc)
	 * @see application.steps.AStep#getName()
	 */
	public String getName() {
		return StepEndIteration.name;
	}

}
