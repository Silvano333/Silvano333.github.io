package application;

import application.common.Function;
import application.common.Utils;
import application.steps.AStep;
import application.steps.StepPreprocessing;

/**
 * Classe che implementa la procedura base di preprocessing per un algoritmo primale - duale
 * che risolve un problema dell'assegnamento.
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class BasicPreprocessing implements IPreprocessingAlgorithm{

	/**
	 * Metodo che trova una soluzione duale possibile e una parziale soluzione primale 
	 * ad un problema dell'assegnamento di cui � nota la matrice dei costi
	 * @param costMatrix matrice dei costi in ingresso
	 * @return un'istanza della classe AssignmentMatrix  
	 */
    protected int[][] costMatrix;
	protected Function u;
	protected Function v;
	protected Function row;
	protected Function fi;
	public BasicPreprocessing(int[][] costMatrix)
	{
	    this.costMatrix = costMatrix;
		int n=costMatrix.length;
		u=new Function(n,0,0);
		v=new Function(n,0,0);
		row=new Function(n,-1,1);
		fi=new Function(n,-1,1);
		
		/*
		 * riduzione delle righe e delle colonne della matrice in ingresso
		 */
		for(int i=0;i<n;i++){
			u.set(i,Utils.min(costMatrix[i]));
		}
		
		/*
		 * Creazione della tabella con i costi ridotti
		 */
		int[][]reducedCostMat=new int[n][n];
		for(int i=0;i<n;i++)
			for( int j=0;j<n;j++)
				reducedCostMat[i][j]=costMatrix[i][j]-u.get(i);
		
		
		for( int j=0;j<n;j++){
			int[]col=new int[n];
			for(int i=0;i<n;i++)
				col[i]=reducedCostMat[i][j];
			v.set(j,Utils.min(col));
		}
		/*
		 * Aggiornamento della tabella con i costi ridotti
		 */
		for(int i=0;i<n;i++)
			for( int j=0;j<n;j++)
				reducedCostMat[i][j]-=v.get(j);
		
		
		/*
		 * ricerca della soluzione parziale ammissibile
		 */
		for(int i=0;i<n;i++)
			for( int j=0;j<n;j++){
				if(row.get(j)==-1 && (reducedCostMat[i][j]==0)){
					row.set(j,i);
					//Aggiungo la parte di assegnamento della fi
					fi.set(i,j);
					break;
				}
			}
		
				
	}
	
	/* (non-Javadoc)
	 * @see application.IPreprocessingAlgorithm#getPreprocessingStep()
	 */
	public AStep getPreprocessingStep()
	{
		return new StepPreprocessing(new GraphInfo(costMatrix.length),
		        new AssignmentMatrix(costMatrix,row,fi,u,v),
		        new EdgeCollection(),null);
	}
	
	/* (non-Javadoc)
	 * @see application.IPreprocessingAlgorithm#getAssignmentMatrix()
	 */
	public AssignmentMatrix getAssignmentMatrix()
	{
	    return new AssignmentMatrix(costMatrix,row,fi,u,v);
	}
	
	
}