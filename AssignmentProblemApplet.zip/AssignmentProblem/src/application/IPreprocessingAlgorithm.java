package application;

import application.steps.AStep;


/**
 * Interfaccia per l'algoritmo di preprocessing utilizzata negli
 * algoritmi con approccio primale - duale, la quale determina una soluzione 
 * ammissibile per il problema duale e una soluzione parziale del problema primale 
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public interface IPreprocessingAlgorithm {
	
	/**
	 * Metodo che ritorna lo step di Preprocessing
	 * @return step di preprocessing 
	 */
	public AStep getPreprocessingStep();
	
	
	/**
	 * Metodo che ritorna una instanza della classe AssignmentMatrix
	 * contenente le informazioni che si sono ricavate attraverso
	 * lo step di preprocessing
	 * @return una instanza della classe AssignmentMatrix
	 */
	public AssignmentMatrix getAssignmentMatrix();
}
