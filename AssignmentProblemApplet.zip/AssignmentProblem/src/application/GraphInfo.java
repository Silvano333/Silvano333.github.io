package application;

import application.common.Function;
import application.common.Set;

/**
 * Classe che contiene tutte le informazioni relative ad un grafo bipartito
 * (U,V,E)
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public class GraphInfo
{
	//vettore di vertici non assegnati u
	protected Set U;
	
	//vettore di vertici non assegnati v
	protected Set V;
	
	//funzione pred realizzata tramite il vettore pred
	protected Function pred;
	
	//vertici di V visitati
	protected Set  SV;
	
	//vertici di V etichettati
	protected Set  LV;
	
	//vertici di U visitati
	protected Set  SU;
	
	//vertici di U etichettati
	protected Set  LU;
	
	//funzione dei pigreco
	protected Function pi;
	
	
	/**
	 * Costruttore della classe GraphInfo che vuole in ingresso una delle dimensioni
	 * della matrice quadrata dei costi e che grazie a questa
	 * auto-inizializza un p� di variabili
	 * @param n dimensione della matrice dei costi
	 */
	public GraphInfo(int n){
		this.U=new Set(n,1);
		this.V=new Set(n,1);
		this.LU=new Set(n,0);
		this.LV=new Set(n,0);
		this.SU=new Set(n,0);
		this.SV=new Set(n,0);
		this.pred=new Function(n,-1,1);
		this.pi=new Function(n,java.lang.Integer.MAX_VALUE,0);
		
	}
	
	/**
	 * Costruttore che crea una copia del GraphInfo g dato in ingresso 
	 * @param g GraphInfo di cui fare una copia
	 */
	public GraphInfo(GraphInfo g)
	{
		this.U=new Set(g.getU());
		this.V=new Set(g.getV());
		this.SU=new Set(g.getSU());
		this.SV=new Set(g.getSV());
		this.LU=new Set(g.getLU());
		this.LV=new Set(g.getLV());
		this.pred=new Function(g.getPred());
		this.pi=new Function(g.getPi());
	}
	
	/**
	 * Metodo che ritorna la funzione pi
	 * @return funzione pi
	 */
	public Function getPi(){
		return this.pi;
	}
	
	/**
	 * Metodo che ritorna l'elemento j della funzione pi, 
	 * se j non eccede la dimensione di pred, ritorna -2 altrimenti
	 * @param j indice del valore della funzione pi richiesta
	 * @return valore della funzione pi o -2 in caso di errori
	 */
	public int getPi(int j){
		if(j<this.pi.length()&& j>-1)
			return this.pi.get(j);
		else return -2;
	}
	
	
	/**
	 * Metodo che ritorna il numero di elementi del vettore U del grafo bipartito
	 * @return il numero di elementi del vettore U del grafo bipartito
	 */
	public int getNu(){
		return this.U.length();
	}
	
	/**
	 * Metodo che ritorna il numero di elementi del vettore V del grafo bipartito
	 * @return il numero di elementi del vettore V del grafo bipartito
	 */
	public int getNv(){
		return this.V.length();
	}

	/**
	 * Metodo che ritorna la funzione pred del grafo bipartito
	 * @return la funzione pred del grafo bipartito
	 */
	public Function getPred(){
		return pred;
	}
	
	/**
	 * Metodo che ritorna l'elemento i della funzione pred, 
	 * se i non eccede la dimensione di pred, ritorna -2 altrimenti
	 * @param i indice del valore della funzione pred richiesta
	 * @return valore della funzione pred o -2 in caso di errori
	 */
	public int getPred(int i){
		if(i<this.pred.length())
			return this.pred.get(i);
		else return -2;
	}
	
	/**
	 * Metodo che ritorna il vettore contenente i vertici U del grafo bipartito
	 * @return il vettore contenente i vertici U del grafo bipartito
	 */
	public Set getU(){
		return U;
	}
	
	/**
	 * Metodo che ritorna il vettore contenente i vertici V del grafo bipartito
	 * @return il vettore contenente i vertici V del grafo bipartito
	 */
	public Set getV(){
		return V;
	}
	
	/**
	 * Metodo che ritorna il vettore contenente i vertici esplorati di U del grafo bipartito
	 * @return il vettore contenente i vertici esplorati di U del grafo bipartito
	 */
	public Set getSU(){
		return this.SU;
	}
	
	/**
	 * Metodo che ritorna il vettore contenente i vertici esplorati di V del grafo bipartito
	 * @return il vettore contenente i vertici esplorati di V del grafo bipartito
	 */
	public Set getSV(){
		return this.SV;
	}
	
	/**
	 * Metodo che ritorna il vettore contenente i vertici etichettati di U del grafo bipartito
	 * @return il vettore contenente i vertici etichettati di U del grafo bipartito
	 */
	public Set getLU(){
		return this.LU;
	}
	
	/**
	 * Metodo che ritorna il vettore contenente i vertici etichettati di V del grafo bipartito
	 * @return il vettore contenente i vertici etichettati di V del grafo bipartito
	 */
	public Set getLV(){
		return this.LV;
	}

	/**
	 * Metodo che resetta gli insiemi SU, SV, LV a zero e pred a -1
	 */
	public void reset()
	{
		SU.resetSet();
		SV.resetSet();
		LV.resetSet();
		pred.reset(-1);
		
	}
	
	/**
	 * Metodo che resetta al valore pi� grande possibile la funzione piGreco
	 */
	public void resetPiGreco(){
		this.pi=new Function(this.getU().length(),java.lang.Integer.MAX_VALUE,0);
	}
}
