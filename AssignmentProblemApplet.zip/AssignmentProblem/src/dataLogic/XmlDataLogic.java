package dataLogic;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Classe che importa una matrice dei costi da file xml
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */


public class XmlDataLogic 
{
	public final static String  TAG_ROOT = "Matrice",
								TAG_ROW  = "R",
							  	ATTR_ELEM= "e";

	 private int[][] data=null;
	private String fileName;
	    
	/**
	 *Costruttore di default che usa il file "userData/costMatrix.xml"  
	 */
	public XmlDataLogic()
	{
		
		fileName = "userData/costMatrix.xml";
	}
	
	
	/**Costruttore
	 * @param fileN nome del file da caricare
	 */
	public XmlDataLogic(String fileN)
	{
		fileName = fileN;
	}
	
	/**
	 * Metodo che carica la matrice e ritorna se il caricamento
	 * � andato a buon fine
	 * @return true se il caricamento ha avuto successo, false altrimenti
	 */
	public boolean load()
    {
		int i=0;
		
		Node root = loadRootNode();
        if(root==null)
        	return false;
       
       	NodeList rows =root.getChildNodes();
       	
       	for(int k=0;k<rows.getLength();k++)
       	{ 
       		Node row = rows.item(k);
       		if((row.getNodeType()==(Node.ELEMENT_NODE))&&(row.getNodeName().startsWith(TAG_ROW)))
       		 {
       			String[] elems = XmlUtils.getAttributesValues(row,fileName);
       			if(i==0)
       				data = new int[elems.length][elems.length];
               	
       		   for(int j=0;j<elems.length;j++)
       		   	data[i][j] = Integer.parseInt(elems[j]);
       		   i++;
       		 }
        }
       	
       	if(data==null)
       		return false;
       	
       	if(i!=data.length)
       		return false;
       
       
       return true;
    }
	
	/**
	 * Metodo che carica il nodo radice
	 * @return il nodo radice
	 */
	private Node loadRootNode()
    {
        Document doc = XmlUtils.documentLoad(fileName);
        if(doc==null)
            return null;
        Node root = (Element)doc.getFirstChild(); //doc contains only 1 root element
        if(!root.getNodeName().equals(TAG_ROOT))
        {
            System.err.println("Document "+fileName+" don t contain root "+TAG_ROOT);
            return null;
        }
        
  	return root;
    }
	
	/**
	 * Metodo che permette di leggere la matrice dei costi caricata
	 * @return matrice dei costi caricata
	 */
	public int[][] getData()
	{
		return this.data;
	}
}
