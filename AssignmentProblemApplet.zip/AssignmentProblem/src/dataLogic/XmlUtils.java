
package dataLogic;

import java.io.*;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;

import javax.xml.parsers.*;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
 * Utilit� per file xml
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */


public class XmlUtils
{
    /**
     * Metodo che ritorna il valore di un attributo
     * dato il riferimento ad un documento, il nodo e 
     * il nome del tag dell'attributo
     * @param node nodo dell'attributo
     * @param attribName nome del tag dell'attributo
     * @param docName riferimento ad un documento
     * @return valore dell'attributo in attribName
     */
    public static String getAttributeValue(Node node,String attribName,String docName)
    {
        NamedNodeMap attrs = node.getAttributes();
        Attr attrib = (Attr) attrs.getNamedItem(attribName);
        if(attrib==null)
        {
            System.out.println(attribName+" null in document"+docName);
            return null;
        }
       return attrib.getValue();
    }
    
    /**
     * Metodo che ritorna tutti i valori degli attributi di un nodo
     * @param node nodo di cui sio vogliono conoscere i valori degli attributi
     * @param docName documento di cui il nodo fa parte
     * @return array di stringhe contenente i valori degli attributi di node
     */
    public static String[] getAttributesValues(Node node,String docName)
    {
        NamedNodeMap attrs = node.getAttributes();
        String[] attrValues = new String[attrs.getLength()];
        for(int i=0;i<attrs.getLength();i++)
        {    
	        Attr attrib = (Attr) attrs.item(i);
	        if(attrib==null)
	        {
	            System.out.println(attrib.getName()+" null in document"+docName);
	            return null;
	        }
	        attrValues[i] = attrib.getValue();
        }
       return attrValues;
    }
    
    /**
     * Metodo che ritorna tutti gli attributi di un nodo
     * @param node nodo di cui si vogliono conoscere gli attributi
     * @param docName documento di cui il nodo fa parte
     * @return array di stringhe contenente gli attributi di node
     */
    public static String[] getAttributesNames(Node node,String docName)
    {
        NamedNodeMap attrs = node.getAttributes();
        String[] attrNames = new String[attrs.getLength()];
        for(int i=0;i<attrs.getLength();i++)
        {    
	        Attr attrib = (Attr) attrs.item(i);
	        if(attrib==null)
	        {
	            System.out.println(attrib.getName()+" null in document"+docName);
	            return null;
	        }
	        attrNames[i] = attrib.getName();
        }
       return attrNames;
    }
    
    /**
     * Metodo che ritorna un DocumentBuilder
     * @return un DocumentBuilder
     */
    private static DocumentBuilder documentBuilderLoader()
    {
        DocumentBuilder builder=null;
        try
        {
            builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        }
        catch (Exception e)
        {
            System.err.println("Unable to create Xml DocumentBuilder");
            System.exit(25);
        }
        return builder;
    }
    
    /**
     * Metodo che carica un documento dato il suo nome completo
     * @param completefileName nome del file
     * @return documento caricato
     */
    public static Document documentLoad(String completefileName)
    {
        DocumentBuilder builder = documentBuilderLoader();
        
        Document doc=null;
        try
        {
            doc = builder.parse(new File(completefileName));
        }
        catch (org.xml.sax.SAXException saxExc)
        {
            System.out.println("Unable to read xml file or invalid document "+completefileName+ " eccezione: "+saxExc.getMessage());
            System.exit(26);
        }
        catch (IOException ioExc)
        {
            return null;
        }
        return doc;
    }
    
    /**
     * Metodo che crea un nuovo documento
     * @return un nuovo documento vuoto
     */
    public static Document documentCreateNew()
    {
        DocumentBuilder builder = documentBuilderLoader();
        
        Document doc=null;
        try
        {
            doc = builder.newDocument();
        }
        catch (Exception e)
        {
            System.out.println("Unable to create new xml file or invalid document ");
            System.exit(26);
        }
        return doc;
    }
    
    /**
     * Metodo che salva un documento nel file completeFileName
     * @param doc rioferimento del documento da salvare
     * @param completeFileName nome del file in cui salvare il documento
     * @return true se il salvataggio ha avuto esito positivo, false altrimenti
     */
    public static boolean documentSave(Document doc,String completeFileName)
    {
        try
        {
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new FileOutputStream(completeFileName));
	
            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();

            transformer.transform(source, result);	

       } catch (Exception e) 
       {
           System.err.println("Unable to save Xml "+completeFileName);
           return false;
       }
       return true;
    }
}
