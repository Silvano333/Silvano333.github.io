package presentation;

import java.awt.Dimension;
import java.lang.reflect.Constructor;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import application.AssignmentProblemAlgorithm;
import application.BasicPreprocessing;
import application.IPreprocessingAlgorithm;
import application.steps.AStep;
import application.steps.StepIterator;

import presentation.configuration.AppConfig;


import userInterface.Hungarian3ButtonCondition;
import userInterface.Hungarian4ButtonCondition;
import userInterface.IButtonCondition;
import userInterface.MainForm;
import userInterface.SimpleDialog;
import userInterface.listeners.CloseListener;

/**
 * Classe che gestisce tutta l'interfaccia grafica
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class ApplicationStatusManager 
{
	protected AssignmentProblemAlgorithm currentAlgo;
	protected IPreprocessingAlgorithm preprocAlgo;
	protected PresentationMatrix costMatrix ;
	protected MainForm form;
	protected int selectedAlgorithm;
	protected StepIterator iter;
	protected IButtonCondition bCond;
    
	/**
	 * Costruttore
	 * @param costMatrix matrice dei costi
	 */
	public ApplicationStatusManager(PresentationMatrix costMatrix)
	{
		selectedAlgorithm = 0;
		this.costMatrix = costMatrix;
		form = new MainForm(this,"Assignment Problem");
	}
	
	
	/**
	 * Metodo che setta l'algoritmo selezionato, 
	 * attraverso il suo nome breve. Questo sar� l'algoritmo che
	 * deve partire quando si preme start, il valore di default � 0
	 * @param shortName nome breve dell'algoritmo selezionato
	 */
	public void selectAlgorithm(String shortName)
	{
		for(int i=0;i<AppConfig.getAlgorithmsCount();i++)
		{
			if(AppConfig.getAlgorithmShortName(i).equals(shortName)){
				selectedAlgorithm = i;
			}
				

		}
		
	}
	
	/**
	 * Metodo che viene chiamato quando deve partire un algoritmo.
	 * Setta tutti i parametri e lancia l'istanza di algoritmo
	 * che � stata selezionata
	 */
	public void startAlgo()
	{
	    
		try
		{
			form.getOptionsMenuBar().setCostMatDimItemEnable(false);
			form.setfileOpenBtnEnable(false);
			this.preprocAlgo =new BasicPreprocessing(this.costMatrix.toIntMatrix());
			
			String algName=AppConfig.getAlgorithmFulName(this.selectedAlgorithm);
			//creo IButtonCondition del caso
			switch(this.selectedAlgorithm){
				case 0:
					this.bCond=new Hungarian4ButtonCondition();
					break;
				case 1:
					this.bCond=new Hungarian3ButtonCondition();
					break;
			}
			
			Class algoClass = AppConfig.getAlgorithmClass(selectedAlgorithm);
			Constructor constr = algoClass.getConstructor(new Class[]{IPreprocessingAlgorithm.class, String.class});
			currentAlgo = (AssignmentProblemAlgorithm)constr.newInstance(new Object[]{preprocAlgo,algName});
			
			
		}
		catch (Exception e)
		{
			SimpleDialog dialog=new SimpleDialog("Warning",new Dimension(450,100));
			
			//aggiungo al simple dialog un bottone per chiudere la finestra
			JButton ok=new JButton("ok");
			ok.addActionListener(new CloseListener(dialog));
			dialog.addButton(ok);
			
			//aggiungo al simple dialog un pannello con visualizzato l'errore
			JLabel label=new JLabel("Unable to load the class:"+AppConfig.getAlgorithmClass(selectedAlgorithm));
			JPanel panel = new JPanel();
			panel.add(label);
			dialog.addPanel(panel);
			dialog.show();
			return;
		}
		
		iter = new StepIterator(currentAlgo.getRootStep());
		form.updateFormComponents(iter.getCurrentStep());
		
		form.updateFormComponents(iter.getCurrentStep());
		form.show();

	}
	
	/**
	 * Metodo che mette l'algoritmo corrente in esecuzione a null
	 * Viene chiamato sicuramente allo stop
	 */
	public void resetcurAlgo(){
		this.currentAlgo=null;
	}
	
	/**
	 * metodo che ritorna lo step goal, ottenuto
	 * tramite l'iteratore che contiene
	 * @return lo step goal
	 */
	public AStep goal()
	{
		if(currentAlgo==null)
			return null;
		AStep currentStep = iter.getLast();
		return iter.getCurrentStep();

	}
	
	/**
	 * Metodo che ritorna il primo step
	 * @return primo step
	 */
	public AStep first()
	{
		if(currentAlgo==null)
			return null;
		AStep currentStep = iter.getFirst();
		if(currentStep==null)
			return null;
		return iter.getCurrentStep();

	}
	
	/**
	 * Metodo che ritorna lo step precedente a quello corrente
	 * @return step precedente
	 */
	public AStep previous()
	{
		if(currentAlgo==null)
			return null;
		
		AStep currentStep = iter.getPrevious();
		if(currentStep==null)
			return null;
		return iter.getCurrentStep();
	}
	
	/**
	 * Metodo che ritorna lo step successivo a quello corrente
	 * @return step successivo
	 */
	public AStep next()
	{
		if(currentAlgo==null)
			return null;
		
		AStep currentStep = iter.getNext();
		if(currentStep==null)
			return null;
		return iter.getCurrentStep();
	}
	
	/**
	 * Metodo che ritorna l'ultimo step
	 * @return l'ultimo step
	 */
	public AStep last()
	{
		if(currentAlgo==null)
			return null;
		
		AStep currentStep = iter.getLast();
		if(currentStep==null)
			return null;
		return iter.getCurrentStep();

	}
	
	/**
	 * Metodo che ritorna lo step corrente
	 * @return lo step corrente
	 */
	public AStep currentStep(){
		if(currentAlgo==null)
			return null;
		
		AStep currentStep = iter.getCurrentStep();
		if(currentStep==null)
			return null;
		return currentStep;
	}
	
	
	/**
	 * Metodo che ritorna un riferimento a una classe che
	 * implementa l'interfaccia IButtonCondition, che
	 * conterr� le condizioni di terminazione delle
	 * computazioni legate ai singoli bottoni dell'interfaccia
	 * grafica. L'istanza varia a seconda dell'algoritmo lanciato
	 * @return un riferimento a una classe che
	 * implementa l'interfaccia IButtonCondition
	 */
	public IButtonCondition getButtonCondition(){
		return this.bCond;
	}
	
	
	/**
	 * Metodo che ritorna il riferimento all'algoritmo corrente
	 * @return il riferimento all'algoritmo corrente
	 */
	public AssignmentProblemAlgorithm getCurrentAlgorithm()
	{
	    return this.currentAlgo;
	}
	
	/**
	 * Metodo che ritorna la matrice dei costi
	 * @return istanza della classe PresentationMatrix, con la matrice dei costi
	 */
	public PresentationMatrix getCostMatrix(){
		return this.costMatrix;
	}
	
	/**
	 * Metodo contenente la nuova matrice dei costi ridotti
	 * @param newCostMat la matrice dei costi ridotti
	 */
	public void setCostMatrix(PresentationMatrix newCostMat){
		if(newCostMat!=null)
			this.costMatrix=newCostMat;
	}
	
	/**
	 * Metodo che ritorna la form che la classe gestisce
	 * @return istanza di MainForma che la classe gestisce
	 */
	public MainForm getForm()
	{
		return this.form;
	}
	
	
}

