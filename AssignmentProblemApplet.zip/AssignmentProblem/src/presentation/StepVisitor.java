package presentation;

import presentation.configuration.AppConfig;
import presentation.configuration.GraphStyle;

import application.EdgeCollection;
import application.common.Edge;
import application.common.Function;
import application.hungarian3.StepAugPathH3;
import application.hungarian3.StepEndIteration;
import application.hungarian3.StepUpdateDualVarH3;
import application.hungarian3.StepVertexH3;
import application.hungarian4.StepAugPathH4;
import application.hungarian4.StepUpdateDualVarH4;
import application.hungarian4.StepVertexH4;
import application.steps.AStep;
import application.steps.StepGoal;
import application.steps.StepInitial;
import application.steps.StepNewAssign;
import application.steps.StepPathEdge;
import application.steps.StepPathEdgesReass;
import application.steps.StepPreprocessing;

/**
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 */
public class StepVisitor implements IVisitor {
	protected NodeRelations nodeRel;
	protected String[] labels;
	protected int vertexNum;
	protected int secondVertex;
	protected boolean isSelected;
	protected int whichVertex;
	
	/**
	 * Costruttore di default
	 */
	public StepVisitor(){
		this.vertexNum=-1;
		this.secondVertex=-1;
		this.isSelected=false;
		this.whichVertex=-1;		
	}
	
	
	/* (non-Javadoc)
	 * @see presentation.IVisitor#isSelected()
	 */
	public boolean isSelected(){
		return this.isSelected;
	}
	
	/* (non-Javadoc)
	 * @see presentation.IVisitor#getVertexNum()
	 */
	public int getVertexNum(){
		return this.vertexNum;
	}
	
	/* (non-Javadoc)
	 * @see presentation.IVisitor#getSecondVertexNum()
	 */
	public int getSecondVertexNum(){
		return this.secondVertex;
	}
	
	/* (non-Javadoc)
	 * @see presentation.IVisitor#whichVertex()
	 */
	public int whichVertex(){
		return this.whichVertex;
	}

	/* (non-Javadoc)
	 * @see presentation.IVisitor#getNodeRelations()
	 */
	public NodeRelations getNodeRelations() {
		return this.nodeRel;
	}

	/* (non-Javadoc)
	 * @see presentation.IVisitor#getLabels()
	 */
	public String[] getLabels() {
		return this.labels;
	}

	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.steps.StepPathEdgesReass)
	 */
	public void visit(StepPathEdgesReass step){
		if(step.isThereAugPath()){
			this.isSelected=true;
			this.vertexNum=step.getSxVertexNum();
			this.secondVertex=step.getDxVertexNum();
			this.whichVertex=GraphStyle.BOTH_NODE;
		}
		
		this.showAll(step);
		
		//labels
		this.labels=this.basicLabels(step);
	}
	
	
	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.StepGoal)
	 */
	public void visit(StepGoal step) {
		int costMatDim=step.getAssignmentMatrix().getCostMatrixDim();
		this.nodeRel= new NodeRelations(costMatDim);
		
		boolean [][]usedEdge=this.createUsedEdgeMat(costMatDim);
		
		this.addThickLineNodeRelations(step,usedEdge);
		

		//labels
		String []support=this.basicLabels(step);
		this.labels=new String[support.length-1];
		for(int i=0;i<this.labels.length;i++){
			this.labels[i]=support[i];
		}

	}

	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.StepInitial)
	 */
	public void visit(StepInitial step) {
		this.nodeRel=new NodeRelations(step.getAssignmentMatrix().getCostMatrixDim());
		

		//labels
		this.labels=new String[]{step.toString()};

	}

	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.StepNewAssign)
	 */
	public void visit(StepNewAssign step) {
		this.showAll(step);

		//labels
		this.labels=this.basicLabels(step);
	}

	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.StepPathEdge)
	 */
	public void visit(StepPathEdge step) {
		if(!step.isFwd()){
			this.isSelected=true;
			this.vertexNum=step.getVertexNum();
			this.whichVertex=GraphStyle.RIGHT_NODE;
		}
		this.showAll(step);

		//labels
		
		//se siamo nel caso di hungherese O(n^3)
		if(step.getAlgoName()!=null && step.getAlgoName().equals(AppConfig.getAlgorithmFulName(1))){
			this.labels=new String[]{
					step.toString(),
					" i = "+(step.getI()+1)+":",
					"  SU = "+step.getGraphInfo().getSU().toString(),
					"  Pred = "+step.getGraphInfo().getPred(),
					"  pi = "+step.getGraphInfo().getPi(),
					"  LV = "+step.getGraphInfo().getLV().toString(),
					
			};
		}
		else{
			String[]label=this.basicLabels(step);
			this.labels=new String[label.length+3];
			int i=0;
			for(;i<label.length;i++){
				labels[i]=label[i];
			}
			
			labels[i]=" SU = "+step.getGraphInfo().getSU().toString();i++;
	  		labels[i]=" SV = "+step.getGraphInfo().getSV().toString();i++;
	  		labels[i]=" LV = "+step.getGraphInfo().getLV().toString();i++;
		}
	}

	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.StepPreprocessing)
	 */
	public void visit(StepPreprocessing step) {
		this.showOnlyLine(step);

		//labels
		this.labels=this.basicLabels(step);

	}

	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.StepUpdateDualVar)
	 */
	public void visit(StepUpdateDualVarH4 step) {
		this.showOnlyLine(step);
		
		//labels
		String []l=this.basicLabels(step);
		this.labels=new String[l.length+1];
		int i=0;
		for(;i<l.length;i++){
			labels[i]=l[i];
		}
		
		labels[i]=" delta = "+step.getDelta();
  			
	}

	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.StepVertex)
	 */
	public void visit(StepVertexH4 step) {
		this.isSelected=true;
		this.vertexNum=step.getVertexNum();
		this.whichVertex=GraphStyle.LEFT_NODE;
		this.showOnlyLine(step);

		//labels
		this.labels=new String[]{
			step.toString(),
			" Vertex: k = "+(step.getVertexNum()+1),
			" u = "+step.getAssignmentMatrix().getu(),
			" v = "+step.getAssignmentMatrix().getv()
		};

	}


	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.StepAugPath)
	 */
	public void visit(StepAugPathH4 step) {
		this.isSelected=true;
		this.vertexNum=step.getVertexNum();
		this.whichVertex=GraphStyle.LEFT_NODE;
		this.showOnlyLine(step);
		
		//labels
		this.labels=new String[]{
				step.toString(),
				" SU = "+step.getGraphInfo().getSU().toString(),
		  		" SV = "+step.getGraphInfo().getSV().toString(),
		  		" LV = "+step.getGraphInfo().getLV().toString(),
				" fail = "+step.getFail(),
				" sink = "+step.getInitialSink()
			};
	}
	
	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.hungarian3.StepUpdateDualVarH3)
	 */
	public void visit(StepUpdateDualVarH3 step) {
		this.showAll(step);
		
		//labels
		this.labels=new String[]{
				step.toString(),
				" delta = "+step.getDelta(),
				" u = "+step.getAssignmentMatrix().getu(),
				" v = "+step.getAssignmentMatrix().getv(),
				" pi = "+step.getGraphInfo().getPi()
		};
	}
	
	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.hungarian3.StepAugPathH3)
	 */
	public void visit(StepAugPathH3 step) {
		this.isSelected=true;
		this.vertexNum=step.getVertexNum();
		this.whichVertex=GraphStyle.LEFT_NODE;
		this.showOnlyLine(step);
		
		//labels
		this.labels=new String[]{
				step.toString(),
				" pi = "+step.getGraphInfo().getPi(),
				" SU = "+step.getGraphInfo().getSU().toString(),
		  		" SV = "+step.getGraphInfo().getSV().toString(),
		  		" LV = "+step.getGraphInfo().getLV().toString(),
				" sink = "+step.getInitialSink()
			};
	}
	
	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.hungarian3.StepVertexH3)
	 */
	public void visit(StepVertexH3 step) {
		this.isSelected=true;
		this.vertexNum=step.getVertexNum();
		this.whichVertex=GraphStyle.LEFT_NODE;
		this.showOnlyLine(step);

		//labels
		this.labels=new String[]{
			step.toString(),
			" Vertex: k = "+(step.getVertexNum()+1),
			" u = "+step.getAssignmentMatrix().getu(),
			" v = "+step.getAssignmentMatrix().getv()
		};
		
	}
	
	/* (non-Javadoc)
	 * @see presentation.IVisitor#visit(application.hungarian3.StepEndIteration)
	 */
	public void visit(StepEndIteration step) {
		this.showAll(step);

		//labels
		
		//se siamo nel caso di hungherese O(n^3)
		if(step.getAlgoName()!=null && step.getAlgoName().equals(AppConfig.getAlgorithmFulName(1))){
			this.labels=new String[]{
					step.toString(),
					" i = "+(step.getI()+1)+":",
					"  SU = "+step.getGraphInfo().getSU().toString(),
					"  Pred = "+step.getGraphInfo().getPred(),
					"  pi = "+step.getGraphInfo().getPi(),
					"   ",
					"   "
					
			};
			int j=step.getJ();
			if(j>=0){
				this.labels[this.labels.length-2]="  LV = "+step.getGraphInfo().getLV().toString();
				this.labels[this.labels.length-1]="      j = "+(j+1)+":  SV = "+step.getGraphInfo().getSV();
			}
		}
		else{
			String[]label=this.basicLabels(step);
			this.labels=new String[label.length+3];
			int i=0;
			for(;i<label.length;i++){
				labels[i]=label[i];
			}
			
			labels[i]=" SU = "+step.getGraphInfo().getSU().toString();i++;
	  		labels[i]=" SV = "+step.getGraphInfo().getSV().toString();i++;
	  		labels[i]=" LV = "+step.getGraphInfo().getLV().toString();i++;
		}
		
	}
	
	/**
	 * Metodo che aggiunge alle nodeRelations sia tutti
	 * gli assegnamenti parziali sia gli archi a costo nullo
	 * sia tutti gli archi presenti nel passo
	 * @param step istanza del passo di cui creo le noderelations
	 */
	protected void showAll(AStep step){
		int costMatDim=step.getAssignmentMatrix().getCostMatrixDim();
		this.nodeRel= new NodeRelations(costMatDim);
		
		boolean [][]usedEdge=this.createUsedEdgeMat(costMatDim);
		
		this.addArrowNodeRelations(step,usedEdge);
		this.addThickLineNodeRelations(step,usedEdge);
		this.addThinLineNodeRelations(step,usedEdge,costMatDim);
	}


	

	/**
	 * Metodo che aggiunge alle nodeRelations sia tutti
	 * gli assegnamenti parziali sia gli archi a costo nullo
	 * @param step istanza del passo di cui creo le noderelations
	 */
	protected void showOnlyLine(AStep step){
		int costMatDim=step.getAssignmentMatrix().getCostMatrixDim();
		this.nodeRel= new NodeRelations(costMatDim);
		
		boolean [][]usedEdge=this.createUsedEdgeMat(costMatDim);
		
		//in questo stato quello che devo tenere conto sono solo gli assegnamenti
		//gli assegnamenti sono contenuti nella funzione fi
		
		this.addThickLineNodeRelations(step,usedEdge);
		this.addThinLineNodeRelations(step,usedEdge,costMatDim);
	}
	
	/**
	 * Metodo che aggiunge una linea sottile al noderelations,
	 * quindi un arco a costo nullo
	 * @param step passo di cui creo il noderelations
	 * @param usedEdge archi gia' utilizzati e quindi da non
	 * 	riempire nuovamente 
	 * @param costMatDim dimensione della matrice dei costi
	 */
	protected void addThinLineNodeRelations(AStep step,boolean[][]usedEdge,int costMatDim ){
		
		//mostro gli archi a costo relativo nullo nelle celle rimaste libere; 
		//questi archi sono non orientati e sottili
				
		for(int i=0;i<costMatDim;i++){
			for(int j=0;j<costMatDim;j++){
				//mi interessano solo quelli con costi ridotti nulli e non ancora occupati
				if((step.getAssignmentMatrix().getReducedCostM(i,j)==0)&& (!usedEdge[i][j])){	
					this.nodeRel.setRelation(i,j,
						NodeRelationElement.THIN_LINE,GraphStyle.ASSIGN_PATH);
				}
			}	
		}	
	}
	
	/**
	 * Metodo che aggiunge una linea grossa al noderelations,
	 * quindi un assegnamento
	 * @param step passo di cui creo il noderelations
	 * @param usedEdge archi gia' utilizzati e quindi da non
	 * 	riempire nuovamente 
	 * @param costMatDim dimensione della matrice dei costi
	 */
	protected void addThickLineNodeRelations(AStep step,boolean[][]usedEdge){
		
		//mostro gli assegnamenti
		Function fi=step.getAssignmentMatrix().getFi();
		
		for(int i=0;i<fi.length();i++){
			int j=fi.get(i);
			if((j>=0)&&(!usedEdge[i][j])){
				//ho un assegnamento per la riga i, segno l'assegnamento da disegnare
				//e che l'arco � stato utilizzato
				this.nodeRel.setRelation(i,j,
						NodeRelationElement.THICK_LINE,GraphStyle.ASSIGN_PATH);
				
				usedEdge[i][j]=true;
			}
		}
	}
	
	/**
	 * Metodo che aggiunge un arco al noderelations,
	 * quindi un arco di un albero alternante
	 * @param step passo di cui creo il noderelations
	 * @param usedEdge archi gia' utilizzati e quindi da non
	 * 	riempire nuovamente 
	 * @param costMatDim dimensione della matrice dei costi
	 */
	protected void addArrowNodeRelations(AStep step,boolean[][]usedEdge){
		
		//parto quindi dagli archi in avanti e poi quelli indietro
		//segnando anche quindi gli archi occupati
		EdgeCollection edgeColl = step.getEdgeCollection();
		for(int i=0;i<edgeColl.forwardEdgesNumber();i++){
			Edge forEdge= edgeColl.getForwardEdge(i);
			int ii=forEdge.getVi();
			int jj=forEdge.getVj();
			if(!usedEdge[ii][jj]){
				this.nodeRel.setRelation(ii,jj,
						NodeRelationElement.ARROW,forEdge.getPath());
				usedEdge[ii][jj]=true;
			}
		}
		
		for(int i=0;i<edgeColl.backwardEdgesNumber();i++){
			Edge bacEdge=edgeColl.getBackwardEdge(i);
			int ii=bacEdge.getVi();
			int jj=bacEdge.getVj();
			if(!usedEdge[ii][jj]){
				this.nodeRel.setRelation(ii,jj,
						NodeRelationElement.BACKARROW,bacEdge.getPath());
				usedEdge[ii][jj]=true;
			}
		}
	}
	
	/**
	 * metodo che crea una matrice della dimensione della
	 * matrice dei costi, inizializzata a false che contiene
	 * se la relazione i,j � presente
	 * @param costMatDim dimensione della matrice
	 * @return matrice booleana delle relazioni presenti nella
	 * 	noderelations
	 */
	protected boolean[][] createUsedEdgeMat(int costMatDim){
		boolean [][]usedEdge=new boolean[costMatDim][costMatDim];
		for(int i=0;i<costMatDim;i++){
			for(int j=0;j<costMatDim;j++){
				usedEdge[i][j]=false;
			}
		}
		return usedEdge;
	}
	
	/**
	 * Crea per un passo delle etichette base: u, v, fi, row, pred
	 * @param step passo di cui voglio evidendiare le etichette
	 * @return array di etichette del passo
	 */
	protected String[] basicLabels(AStep step){
		String []l={
				step.toString(),
				" u = "+step.getAssignmentMatrix().getu(),
				" v = "+step.getAssignmentMatrix().getv(),
				" Fi = "+step.getAssignmentMatrix().getFi(),
				" Row = "+step.getAssignmentMatrix().getRow(),
				" Pred = "+step.getGraphInfo().getPred(),
				
		};
		return l;
	}


	
	

}
