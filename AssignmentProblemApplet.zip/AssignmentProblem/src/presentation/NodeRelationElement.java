package presentation;

/**
 * Classe che contiene la relazione da un nodo sinistro a un nodo dx del
 * grafo del sistema
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class NodeRelationElement
{
	public final static int NONE = -1,
	THIN_LINE = 1,
	THICK_LINE = 2,
	ARROW = 3,
	BACKARROW = 4;

	private int first;
	private int second;
	private int relation;
	private int path;
	
	/**
	 * Costruttore
	 * @param first nodo appartenente a U
	 * @param second nodo appartenente a V
	 * @param relation assegnamento, arco a costo nullo o arco
	 * @param path tipo di cammino, che serve per il colore
	 * 	da associare alla linea
	 */
	public NodeRelationElement(int first,int second,int relation,int path)
	{
		this.first = first;
		this.second = second;
		this.relation = relation;
		this.path = path;
	}
	
	/**
	 * Metodo che ritorna il nodo di U della relazione
	 * @return il nodo di U della relazione
	 */
	public int getFirst()
	{
		return this.first;
	}
	
	/**
	 * Metodo che ritorna il nodo di V della relazione
	 * @return il nodo di V della relazione
	 */
	public int getSecond()
	{
		return this.second;
	}
	
	/**
	 * Metodo che ritorna la relazione del nodo
	 * @return la relazione del nodo
	 */
	public int getRelation()
	{
		return this.relation;
	}
	
	/**
	 * Metodo che ritorna il cammino per il colore del nodo
	 * @return il cammino per il colore del nodo
	 */
	
	public int getPath()
	{
		return this.path;
	}
	
	/**
	 * metodo che setta il valore di una relazione
	 * @param value il valore di una relazione del NodeRealtionElement
	 */
	public void setRelation(int value)
	{
		this.relation = value;
	}
	
	/**
	 * metodo che setta il valore di un cammino
	 * @param value il valore di un cammino del NodeRealtionElement
	 */
	public void setPath(int value)
	{
		this.path = value;
	}
}
