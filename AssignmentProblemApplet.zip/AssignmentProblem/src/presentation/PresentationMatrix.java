package presentation;

import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import presentation.configuration.TableStyle;
import userInterface.SimpleDialog;
import userInterface.listeners.CloseListener;

/**
 * Classe che incapsula una matrice di numeri interi
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 */

//Matrice come da visualizzare, con "titoli" in prima riga e prima colonna
public class PresentationMatrix 
{
	private Object[][] matrix;
	private int rows,columns;
	
	
	/**
	 * Costruttore
	 * @param intMatrix matrice di interi
	 */
	public PresentationMatrix(int[][] intMatrix)
	{
		rows = intMatrix.length+1;
		if(rows==1)
		{
			SimpleDialog dialog=new SimpleDialog("Warning",new Dimension(200,200));
			
			//aggiungo al simple dialog un bottone per chiudere la finestra
			JButton ok=new JButton("ok");
			ok.addActionListener(new CloseListener(dialog));
			dialog.addButton(ok);
			
			//aggiungo al simple dialog un pannello con visualizzata la matrice dei costi
			JLabel label=new JLabel("Invalid data import: null matrix");
			JPanel panel = new JPanel();
			panel.add(label);
			dialog.addPanel(panel);
			dialog.show();
		}
		columns = intMatrix[0].length+1;
		
		
		this.matrix = new Object[rows][columns];
		
		for(int i=1;i<rows;i++)
		{
			matrix[i][0] = new String(TableStyle.TITLE_ROWS+i); 
			for(int j=1;j<columns;j++)
				this.matrix[i][j] = new Integer(intMatrix[i-1][j-1]);
		}
		for(int j=1;j<columns;j++)
			matrix[0][j] = new String(TableStyle.TITLE_COLUMNS+j); 
		matrix[0][0]= new String("");
	}
	
	/**
	 * Costruttore che copia una matrice gia' esistente data
	 * in ingresso
	 * @param presMat istanza di PresentationMatrix con cui inizializzo
	 * la nuova istanza
	 */
	public PresentationMatrix(PresentationMatrix presMat)
	{
		if(presMat==null){
			return;
		}
			
		rows = presMat.getRows();
		columns = presMat.getColumns();
		
		this.matrix = new Object[rows][columns];
		
		for(int i=1;i<rows;i++)
		{
			matrix[i][0] = new String(TableStyle.TITLE_ROWS+i); 
			for(int j=1;j<columns;j++)
				this.matrix[i][j] = new Integer(presMat.getElementFromApplication(i,j));
		}
		for(int j=1;j<columns;j++)
			matrix[0][j] = new String(TableStyle.TITLE_COLUMNS+j); 
		matrix[0][0]= new String("");
	}
	
	/**
	 * Trasforma la matrice in una matrice di Interger
	 * @return la matrice di Interger della classe
	 */
	public Integer[][] toIntegerMatrix()
	{
		Integer[][] integerMatrix = new Integer[this.getRows()-1][this.getColumns()-1];
		for(int i=0;i<this.getRows()-1;i++)
			for(int j=0;j<this.getColumns()-1;j++)
				integerMatrix[i][j] = (Integer)(this.matrix[i+1][j+1]);
		return integerMatrix;
	}
	
	/**
	 * Matrice di int della matrice dell`istanza
	 * @return la matrice di int della matrice dell`istanza
	 */
	public int[][] toIntMatrix()
	{
		int[][] intMatrix = new int[rows-1][columns-1];
		
		for(int i=0;i<intMatrix.length;i++)
			for(int j=0;j<intMatrix.length;j++)
				intMatrix[i][j]  = ((Integer)(this.matrix[i+1][j+1])).intValue();
		return intMatrix;
	}
	
	
	/**
	 * @param row riga
	 * @param col colonna
	 * @return valore int della matrice alla posizione row, col
	 */
	public int getElementFromApplication(int row,int col)
	{
		if((row>0)&&(row<rows))
			if((col>0)&&(col<columns))
				return ((Integer)(this.matrix[row][col])).intValue();			
		System.out.println("Invalid [row,col]:["+row+","+col+"] ");
		return -1;
	}
	
	/**
	 * @param presRow riga
	 * @param presCol colonna
	 * @return valore Integer della matrice alla posizione presRow, presCol
	 */
	public Integer getElementFromPresentation(int presRow,int presCol)
	{
		if((presRow>0)&&(presRow<rows))
			if((presCol>0)&&(presCol<columns))
				return (Integer)this.matrix[presRow][presCol];			
		System.out.println("Invalid [row,col]:["+presRow+","+presCol+"] ");
		return null;
	}
	
	/**
	 * Inserisce value alla posizione [presRow presCol] della matrice
	 * @param presRow riga della matrice
	 * @param presCol colonna della matrice
	 * @param value valore da inserire
	 */
	public void setElementFromPresentation(int presRow,int presCol,Integer value)
	{
		if((presRow>0)&&(presRow<=rows))
			if((presCol>0)&&(presCol<=columns))
				this.matrix[presRow][presCol] = value;			
	}
	
	/**
	 * Metodo che ritorna i titoli presenti
	 * nella matrice (o la riga o la colonna devono essere nulli)
	 * @param presRow riga
	 * @param presCol colonna
	 * @return intestazione della matrice sulle righe o sulle colonne
	 */
	public String getTitleFromPresentation(int presRow,int presCol)
	{
		if((presRow==0)||(presCol==0))
				return (String)this.matrix[presRow][presCol];			
		System.out.println("Invalid [row,col]:["+presRow+","+presCol+"] ");
		return null;
	}
	
	/**
	 * Metodo che setta i valori dei titoli
	 * @param presRow riga
	 * @param presCol colonna
	 * @param value valore
	 */
	public void setTitleFromPresentation(int presRow,int presCol,String value)
	{
		if((presRow==0)||(presCol==0))
			this.matrix[presRow][presCol] = value;			
	}
	
	/**
	 * Metodo che ritorna il numero di righe
	 * @return il numero di righe
	 */
	public int getRows()
	{
		return rows;
	}
	
	/**
	 * Metodo che ritorna il numero di colonne
	 * @return il numero di colonne
	 */
	public int getColumns()
	{
		return columns;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		String matrix="";
		int[][]costMat=this.toIntMatrix();
		for(int i=0;i<costMat.length;i++){
			for(int j=0;j<costMat.length;j++)
				matrix+="\t"+costMat[i][j];
			matrix+="\n";
		}
			
		return matrix;
	}
	
}
