package presentation;

import application.hungarian3.StepAugPathH3;
import application.hungarian3.StepEndIteration;
import application.hungarian3.StepUpdateDualVarH3;
import application.hungarian3.StepVertexH3;
import application.hungarian4.StepAugPathH4;
import application.hungarian4.StepUpdateDualVarH4;
import application.hungarian4.StepVertexH4;
import application.steps.StepGoal;
import application.steps.StepInitial;
import application.steps.StepNewAssign;
import application.steps.StepPathEdge;
import application.steps.StepPathEdgesReass;
import application.steps.StepPreprocessing;

/**
 * Interfaccia del pattern Visitor
 * @author Letizia Cheng Cheng
 * @version 1.0
 *
 * 
 */
public interface IVisitor {
	
	/**
	 * Metodo che ritorna i nodeRelations
	 * @return NOdeRelations dello step
	 */
	public NodeRelations getNodeRelations();
	
	/**
	 * Metodo che torna l`array di label dello step
	 * @return array di label dello step
	 */
	public String[] getLabels();
	
	/**
	 * Chiede se vi sono nodi da mostrare selezionati
	 * @return true se e` da selezionare, false altrimenti
	 */
	public boolean isSelected();
	
	/**
	 * metodo che ritorna il numero del vertice da selezionare
	 * se c`e` qualcosa da selezionare
	 * @return vertice da selezionare
	 */
	public int getVertexNum();
	/**
	 * Metodo che torna un eventuale secondo vertice da selzionare
	 * @return numero del secondo vertice
	 */
	public int getSecondVertexNum();
	
	/**
	 * Metodo che ritorna se deve essere selezionato
	 * un vertice di U e\o un vertice di V
	 * @return quali vertici devono essere selezionati
	 */
	public int whichVertex();
	
	/**
	 * Metodo che crea le noderelations per uno step StepPathEdgesReass
	 * @param step istanza di StepPathEdgesReass
	 */
	public void visit(StepPathEdgesReass step);
	
	/**
	 * Metodo che crea le noderelations per uno step StepAugPathH4
	 * @param step istanza di StepAugPathH4
	 */
	public void visit(StepAugPathH4 step);
	
	/**
	 * Metodo che crea le noderelations per uno step StepGoal
	 * @param step istanza di StepGoal
	 */
	public void visit(StepGoal step);
	
	/**
	 * Metodo che crea le noderelations per uno step StepInitial
	 * @param step istanza di StepInitial
	 */
	public void visit(StepInitial step);
	
	/**
	 * Metodo che crea le noderelations per uno step StepNewAssign
	 * @param step istanza di StepNewAssign
	 */
	public void visit(StepNewAssign step);
	
	/**
	 * Metodo che crea le noderelations per uno step StepPathEdge
	 * @param step istanza di StepPathEdge
	 */
	public void visit(StepPathEdge step);
	
	/**
	 * Metodo che crea le noderelations per uno step StepPreprocessing
	 * @param step istanza di StepPreprocessing
	 */
	public void visit(StepPreprocessing step);
	
	/**
	 * Metodo che crea le noderelations per uno step StepUpdateDualVarH4
	 * @param step istanza di StepUpdateDualVarH4
	 */
	public void visit(StepUpdateDualVarH4 step);
	
	/**
	 * Metodo che crea le noderelations per uno step StepVertexH4
	 * @param step istanza di StepVertexH4
	 */
	public void visit(StepVertexH4 step);
	
	/**
	 * Metodo che crea le noderelations per uno step StepEndIteration
	 * @param step istanza di StepEndIteration
	 */
	public void visit(StepEndIteration step);

	/**
	 * Metodo che crea le noderelations per uno step StepAugPathH3
	 * @param pathH3 istanza di StepAugPathH3
	 */
	public void visit(StepAugPathH3 pathH3);

	/**
	 *  Metodo che crea le noderelations per uno step StepUpdateDualVarH3
	 * @param varH3 istanza di StepUpdateDualVarH3
	 */
	public void visit(StepUpdateDualVarH3 varH3);

	/**
	 * Metodo che crea le noderelations per uno step StepVertexH3
	 * @param vertexH3 istanza di StepVertexH3
	 */
	public void visit(StepVertexH3 vertexH3);

}
