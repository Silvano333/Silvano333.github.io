package presentation.graphics;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import presentation.NodeRelations;
import presentation.configuration.GraphStyle;


/**
 * Classe che disegna i nodi
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class NodeDrawer
{
	//private int selectedX,selectedY;
	private int[]selectedX,selectedY;
	
	private int maxY; 
	
	
	/**
	 * Costruttore
	 * @param maxY numero di nodi
	 */
	public NodeDrawer(int maxY)
	{
		this.selectedX=new int[maxY];
		this.selectedY=new int[maxY];
		for(int i=0;i<maxY;i++){
			selectedX[i]=-1;
			selectedY[i]=-1;
		}
		this.maxY = maxY;
	}
	
	/**
	 * Metodo che seleziona nodi
	 * @param indexX 0 per i nodi a sinistra 1 per quelli a dx
	 * @param indexY numero del nodo
	 */
	public void selectElement(int indexX,int indexY)
	{
		for(int i=0;i<selectedX.length;i++){
			if((selectedX[i]==indexX)&&(selectedY[i]==indexY))
				return;
			if(selectedX[i]==-1){
				selectedX[i]=indexX;
				selectedY[i]=indexY;
				return;
			}		
		}
	}
	
	/**
	 * Metodo per vedere se un nodo e' selezionato
	 * @param indexX 0 nodo di sx 1 nodo di dx
	 * @param indexY numero del nodo
	 * @return true se il nodo � selezionato, false altrimenti
	 */
	public boolean isSelected(int indexX,int indexY)
	{
		for(int i=0;i<selectedX.length;i++){
			if((selectedX[i]==indexX)&&(selectedY[i]==indexY))
				return true;		
		}
		return false;
	}
	
	/**
	 * @return le relazioni del nodo
	 */
	public NodeRelations getNodeRelations()
	{
		return this.getNodeRelations();
	}
	
	
	//Disegno
//	 Metodi per il disegno dei singoli componenti
	
	/**
	 * Disegna tutti i nodi grazie a una classe Graphics2D
	 * @param graphics istanza di Graphics2D con cui disegno
	 */
	public void drawNodes(Graphics2D graphics)
	{
		for(int i=0;i<maxY;i++)
		{
		    drawNode(0,i,graphics);
		    drawNode(1,i,graphics);
		}	
	}
	
	/**
	 * Metodo per disegnare un nodo
	 * @param indexX
	 * @param indexY
	 * @param graphics
	 */
	public void drawNode(int indexX, int indexY,Graphics2D graphics)
	{
		int nodeStartX = getPositionX(indexX);
		int nodeStartY = getPositionY(indexY);
		int halfBorder = GraphStyle.NODE_BORDER_SIZE/2;
		
		
		Ellipse2D ell= new Ellipse2D.Float();
		ell.setFrame(nodeStartX+halfBorder,nodeStartY+halfBorder,GraphStyle.NODE_X,GraphStyle.NODE_Y);
		
		Ellipse2D ellBorder = ellBorder= new Ellipse2D.Float();
		ellBorder.setFrame(nodeStartX,nodeStartY,
				GraphStyle.NODE_X+GraphStyle.NODE_BORDER_SIZE,
				GraphStyle.NODE_Y+GraphStyle.NODE_BORDER_SIZE);

		Color textColor =null;
		if(!isSelected(indexX,indexY))
		{	
			graphics.setColor(GraphStyle.COLOR_NODE_FILL);
			graphics.fill(ell);
			
			graphics.setColor(GraphStyle.COLOR_NODE_BORDER);
			graphics.setStroke(new BasicStroke(GraphStyle.NODE_BORDER_SIZE+1));
			graphics.draw(ellBorder);
			textColor = GraphStyle.COLOR_NODE_FONT;
		}
		else
		{
			graphics.setColor(GraphStyle.COLOR_NODE_FILL);
			graphics.fill(ell);
			
			graphics.setColor(GraphStyle.COLOR_NODESEL_BORDER);
			graphics.setStroke(new BasicStroke(GraphStyle.NODE_BORDER_SIZE+1));
			graphics.draw(ellBorder);
			textColor = GraphStyle.COLOR_NODESEL_FONT;
		}	
		
		String text ="";
		if(indexX==0)
			text += GraphStyle.TEXT_FIRST_NODE;
		else
			text += GraphStyle.TEXT_SECOND_NODE;
		text+=(indexY+1);
		
		drawText(text,centerNodeX(indexX),centerNodeY(indexY),graphics,textColor);
		
	}
	
	/**
	 * Metodo per scrivere del testo all-interno del nodo
	 * @param text testo
	 * @param startX nodo di dx o nodo di sx
	 * @param startY numero nodo
	 * @param graphics componente grafico
	 * @param color colore del testo
	 */
	private void drawText(String text,int startX,int startY,Graphics2D graphics,Color color)
	{
		Font font = GraphStyle.FONT_NODE;
		graphics.setFont(font);
		graphics.setColor(color);
		
		Rectangle2D stringBounds = font.getStringBounds(text, graphics.getFontRenderContext());
		startX -= stringBounds.getCenterX();
		startY -=stringBounds.getCenterY();
		graphics.drawString(text,startX,startY);
	}
	
	
	
	
	public static int getPositionX(int indexX)
	{
		if(indexX>=0)
			return GraphStyle.STARTING_POINT_X+indexX*(GraphStyle.NODE_X+ GraphStyle.NODE_BORDER_SIZE +GraphStyle.NODE_X_INTERDISTANCE);
		return -1;
	}
	public static int getPositionY(int indexY)
	{
		if(indexY>=0)
			return GraphStyle.STARTING_POINT_Y+indexY*(GraphStyle.NODE_Y+GraphStyle.NODE_BORDER_SIZE+GraphStyle.NODE_Y_INTERDISTANCE);
		return -1;
	}
	
	
	/**
	 * @param indexX
	 * @return posizione centrale del nodo
	 */
	public static int centerNodeX(int indexX)
	{
	    return getPositionX(indexX)+GraphStyle.NODE_BORDER_SIZE/2+GraphStyle.NODE_X/2;
	}
	
	public static int centerNodeY(int indexY)
	{
	    return getPositionY(indexY)+GraphStyle.NODE_BORDER_SIZE/2+GraphStyle.NODE_Y/2;
	}
	
	
}
