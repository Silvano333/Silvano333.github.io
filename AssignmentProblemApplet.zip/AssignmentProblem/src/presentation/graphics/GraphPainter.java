package presentation.graphics;


import java.awt.Graphics2D;

import presentation.IVisitor;
import presentation.StepVisitor;
import presentation.configuration.GraphStyle;

import application.steps.AStep;

/**
 * Classe che si occupa di disegnare il grafo
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 */
public class GraphPainter 
{
	private AStep step;
	private IVisitor visitor;
	private ArcDrawer arcDrawer;
	private NodeDrawer nodeDrawer;
	
	public GraphPainter(AStep step)
	{
		this.visitor=new StepVisitor();
		step.accept(visitor);
		
		nodeDrawer = new NodeDrawer(step.getAssignmentMatrix().size()); 
		arcDrawer = new ArcDrawer(visitor.getNodeRelations(),nodeDrawer);
		
		this.step = step;
		
	}
	
	/**
	 * Metodo chiamato Per disegnare il grafo da un Graphics2D 
	 * @param g Graphics2D in ingresso
	 */
	public void paintComponent(Graphics2D g)
	{
		if(step==null)
			return;
		if(visitor.isSelected()){
			switch(visitor.whichVertex()){
				case GraphStyle.LEFT_NODE:
					nodeDrawer.selectElement(0,visitor.getVertexNum());
					break;
				case GraphStyle.RIGHT_NODE:
					nodeDrawer.selectElement(1,visitor.getVertexNum());
					break;
				case GraphStyle.BOTH_NODE:
					nodeDrawer.selectElement(0,visitor.getVertexNum());
					nodeDrawer.selectElement(1,visitor.getSecondVertexNum());
					break;
			}
		}
		arcDrawer.drawArcs(g);
		nodeDrawer.drawNodes(g);
		
			
	}
	
	/**
	 * Step associato al GraphPainter, ad ogni step
	 * avro' un disegno diverso
	 * @return lo step associato al GraphPainter
	 */
	public AStep getStep()
	{
		return this.step;
	}
	
	
}
