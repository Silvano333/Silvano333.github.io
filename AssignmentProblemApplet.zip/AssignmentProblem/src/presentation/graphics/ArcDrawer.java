package presentation.graphics;


import java.awt.BasicStroke;
import java.awt.Graphics2D;

import presentation.NodeRelationElement;
import presentation.NodeRelations;
import presentation.configuration.GraphStyle;




/**
 * Classe che si occupa di disegnare le relazioni tra nodi
 * @author Letizia Cheng Cheng
 * @version 1.0
 *
 */
public class ArcDrawer
{
	private NodeDrawer nodePainter;
	private NodeRelations relMatrix;
	
	
	/**
	 * COSTRUTTORE
	 * @param relMatrix insieme di relazioni presenti
	 * @param nodePainter riferimento a NodeDrawer
	 */
	public ArcDrawer(NodeRelations relMatrix,NodeDrawer nodePainter)
	{
		this.nodePainter= nodePainter;
		this.relMatrix= relMatrix;
	}
	

	
	//Metodi per il disegno dello stato complessivo
	/**
	 * Metodi per il disegno dello stato complessivo
	 * linee grosse e sottili e archi
	 * @param graphics
	 */
	public void drawArcs(Graphics2D graphics)
	{
		for(int i=0;i<relMatrix.getRows();i++)
		    for(int j=0;j<relMatrix.getRows();j++)
		    {
		    	NodeRelationElement elem = relMatrix.getElement(i,j);
		    	if(elem!=null)
			    	switch(elem.getRelation())
			        {
			        	case NodeRelationElement.BACKARROW:
		                drawArrowBetweenNodes(elem,i,j,true,graphics);
			        	break;
			        	case NodeRelationElement.ARROW:
			                drawArrowBetweenNodes(elem,i,j,false,graphics);
			            break;
			            
			        	case NodeRelationElement.THIN_LINE:
						case NodeRelationElement.THICK_LINE:
			                drawLineBetweenNodes(elem,i,j,graphics);
			            break;
			            
						default:
				        break;
			        }
		    }
	}
	
	
	
	
	
	
	/**
	 * Metodo per disegnare linee sottili o grosse
	 * @param elem NodeRelationElement
	 * @param n1 nodo di U
	 * @param n2 nodo di v
	 * @param graphics per disegnare
	 */
	private void drawLineBetweenNodes(NodeRelationElement elem,int n1,int n2,Graphics2D graphics)
	{
	    if(elem.getRelation()==NodeRelationElement.THIN_LINE)
	        graphics.setStroke(new BasicStroke(GraphStyle.THIN_LINE_WIDTH));
		else
		    graphics.setStroke(new BasicStroke(GraphStyle.THICK_LINE_WIDTH));
	    
	    graphics.setColor(GraphStyle.ARC_COLORS[elem.getPath()%GraphStyle.ARC_COLORS.length]);
	    graphics.drawLine(NodeDrawer.centerNodeX(0),
	    		NodeDrawer.centerNodeY(n1),
	            NodeDrawer.centerNodeX(1),
	            NodeDrawer.centerNodeY(n2));
	}
	
	//Per disegnare la freccia non posso arrivare al centro del nodo: mi devo fermare al bordo
	/**
	 * Metodo per archi
	 * @param elem NodeRelationElement
	 * @param n1 nodo di U
	 * @param n2 nodo di v
	 * @param isBack per sapere se l`arco e' indietro
	 * @param graphics per disegnare
	 * 
	 */
	private void drawArrowBetweenNodes(NodeRelationElement elem,int n1,int n2,boolean isBack,Graphics2D graphics)
	{
	    int startX,startY,endX,endY,l,deltaX,deltaY;
	    
	    graphics.setStroke(new BasicStroke(GraphStyle.ARROW_WIDTH));
	    graphics.setColor(GraphStyle.ARC_COLORS[elem.getPath()%GraphStyle.ARC_COLORS.length]);
	    
	    
	    startX = NodeDrawer.centerNodeX(0);
	    startY = NodeDrawer.centerNodeY(n1);
	    endX = NodeDrawer.centerNodeX(1);
	    endY = NodeDrawer.centerNodeY(n2);
	    
	    //Uso la proporzione tra due triangoli simili per trovare il triangolo con gli 
	    //stessi angoli e col lato lungo privato delle parti all'interno dei 2 nodi.
		l = new Double(Math.sqrt((endX-startX)*(endX-startX)+(endY-startY)*(endY-startY))).intValue();
	    
	    deltaX = (GraphStyle.NODE_BORDER_SIZE+GraphStyle.NODE_X)/2*(endX-startX)/l;
	    deltaY = (GraphStyle.NODE_BORDER_SIZE/2+GraphStyle.NODE_Y)/2*(endY-startY)/l;
	    
	    deltaX+=GraphStyle.ARROW_WIDTH;
		startX += deltaX;
		startY+= deltaY;
		endX -= deltaX;
		endY -=deltaY;
		
		if(isBack)
			drawArrow(endX,endY,startX,startY,GraphStyle.ARROW_HEIGHT,GraphStyle.ARROW_EDGE,graphics);
		else
			drawArrow(startX,startY,endX,endY,GraphStyle.ARROW_HEIGHT,GraphStyle.ARROW_EDGE,graphics);
	}
	
	
	
	
	
	/**
	 * Title:        drawArrow
	 * Description:  Draws an arrow
	 * Company:      Transparent Tools (http://transparenttools.com)
	 * @author       Jan Koeman (algorithm designer)
	 */

	// xy1 arrow base,xy2 arrow point
	// K   blade height, N   blade length (hypotenuse), L   blade width (distance from arrow line)
	private void drawArrow(int x1, int y1, int x2, int y2, double K, double N,Graphics2D graphics)
	{
		if( K >= N ) return; // draw nothing if height is greater than length
		double L = Math.sqrt(N * N - K * K);
		int x = x2 - x1;
		int y = y2 - y1;
		double A = Math.sqrt(x * x + y * y);

		int x3 = (int)(( (A - K) / A) * x - (L / A) * y);
		int y3 = (int)(( (A - K) / A) * y + (L / A) * x);
		int x5 = (int)(( (A - K) / A) * x + (L / A) * y);
		int y5 = (int)(( (A - K) / A) * y - (L / A) * x);

		int x4 = x1 + x3;
		int y4 = y1 + y3;
		int x6 = x1 + x5;
		int y6 = y1 + y5;

		graphics.drawLine(x1,y1,x2,y2); // line
		graphics.drawLine(x2,y2,x4,y4); // blade left
		graphics.drawLine(x2,y2,x6,y6); // blade right
	}
}

