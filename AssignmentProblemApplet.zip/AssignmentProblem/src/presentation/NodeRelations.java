package presentation;

import java.util.Vector;

/**
 * Contiene tutte le node relations del grafo del sistema
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */

//Relazioni sempre dal primo insieme al secondo. 
//Eventualmente, se necessario (non so se serve), uso una freccia indietro
public class NodeRelations 
{
	public final static int COLUMNS = 2;
	private int rows;
	private Vector vect;
	public NodeRelations(int rows)
	{
		this.rows = rows;
		this.vect = new Vector();
	}
	
		
	/**
	 * Metodo che crea una relazione tra nodi
	 * @param x vertice di U
	 * @param y vertice di V
	 * @param rel relazione dei nodi
	 * @param path cammino associato ai nodi, serve per il colore da associare alla relazione
	 */
	public void setRelation(int x,int y,int rel,int path)
	{
		if((rel<-1)||(rel>NodeRelationElement.BACKARROW))
			return;
		if((x<0)||(y<0))
			return;
		if((x>=rows)||(y>=rows))
			return;
		NodeRelationElement elem = getElement(x,y);
		if(elem!=null)
			vect.remove(elem);
		vect.add(new NodeRelationElement(x,y,rel,path));
	}
	
	/**
	 * Metodo che ritorna il primo NodeRelationElement
	 * che ha parte da x e arriva a y 
	 * @param x vertice di U
	 * @param y vertice di V
	 * @return il primo NodeRelationElement
	 * che ha parte da x e arriva a y
	 */
	public NodeRelationElement getElement(int x,int y)
	{
		for(int i=0;i<vect.size();i++)
		{
			NodeRelationElement elem = (NodeRelationElement)vect.get(i);
			if((elem.getFirst() == x)&&(elem.getSecond()==y))
					return elem;
		}
		return null;
	}
	
	/**
	 * Metodo che ritorna il numero di nodi 
	 * @return numero di nodi
	 */
	public int getRows()
	{
		return this.rows;
	}
	
}


