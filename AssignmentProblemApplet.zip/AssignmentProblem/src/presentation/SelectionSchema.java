package presentation;

import java.util.Vector;


import application.common.Function;
import application.steps.AStep;

/**
 * Classe per selezinare caselle all-interno di una PresentationMatrix
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class SelectionSchema 
{
	PresentationMatrix matrix;
	Vector v = null;
	
	/**
	 * Costruttore
	 * @param matrix istanza della matrice
	 * @param curStep step corrente da cui deduco cosa selezionare
	 */
	public SelectionSchema(PresentationMatrix matrix,AStep curStep)
	{
		v = new Vector();
		this.matrix = matrix;
		
		if(curStep==null)//non devo selezionare nulla
			return;
		
		Function fi=curStep.getAssignmentMatrix().getFi();
		for(int i=0;i<fi.length();i++){
			int j=fi.get(i);
			if(j>=0){
				addSelection(i+1,j+1);
			}
		}
	}
	
	/**
	 * Metodo che aggiunge una selezione per la riga row e 
	 * la colonna col
	 * @param row riga dove mostrare la selezione
	 * @param col colonna dove mostrare la selezione
	 */
	public void addSelection(int row,int col)
	{
		v.add(matrix.getElementFromPresentation(row,col));
	}
	
	/**
	 * Metodo che rimuove una selezione per la riga row e 
	 * la colonna col
	 * @param row riga dove rimuovere la selezione
	 * @param col colonna dove rimuovere la selezione
	 */
	public void removeSelection(int row,int col)
	{
		v.remove(matrix.getElementFromPresentation(row,col));
	}
	
	/**
	 * Selezione alla posizione i
	 * @param i indice della selezione da trovare
	 * @return la selezione cercata
	 */
	public Integer get(int i)
	{
		return (Integer) v.get(i);
	}
	
	/**
	 * Metodo che ritorna il numero delle selezioni
	 * @return il numero delle selezioni
	 */
	public int size()
	{
		return v.size();
	}
	
	/**
	 * Metodo che chiede se un elemento e' selezionato
	 * @param row riga matrice
	 * @param col colonna matrice
	 * @return true se l-elemento e' selezionato, false altrimenti
	 */
	public boolean isSelected(int row,int col)
	{
		Integer elem = matrix.getElementFromPresentation(row,col);
		for(int i=0;i<v.size();i++)
			if(v.get(i)==elem)
				return true;
		return false;
	}
}


