
package presentation.configuration;

import application.hungarian3.Hungarian3Algorithm;
import application.hungarian4.Hungarian4Algorithm;

/**
 * Classe che contiene le configurazioni dell-algoritmo
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public class AppConfig
{
	
	//Algoritmi
    /**
     * Comment for <code>ALGORITHS</code>
     * algoritmi presenti
     */
    private final static AlgoInfo[] ALGORITHS = 
    {
    		new AlgoInfo("Hungarian O(n^4) algorithm", "h4",Hungarian4Algorithm.class),
    		new AlgoInfo("Hungarian O(n^3) algorithm", "h3",Hungarian3Algorithm.class)
    };
    
    
    /**
     * 
     * @return numero di algoritmi presenti, realizzati
     */
    public static int getAlgorithmsCount()
    {
        return ALGORITHS.length;
    }
    
    /**
     * Metodo che ritorna il nome completo di un algoritmo
     * data la sua posizione
     * @param i indice della posizione dell-algoritmo di cui si vuole
     * conoscere il nome completo
     * @return il nome completo dell-algoritmo
     */
    public static String getAlgorithmFulName(int i)
    {
        return ALGORITHS[i].Name;
    }
    
    /**
     * Metodo che ritorna il nome abbreviato di un algoritmo
     * data la sua posizione
     * @param i indice della posizione dell-algoritmo di cui si vuole
     * conoscere il nome abbreviato
     * @return il nome abbreviato dell-algoritmo
     */
    public static String getAlgorithmShortName(int i)
    {
        return ALGORITHS[i].ShortName;
    }
    
    /**
     * Metodo che ritorna la classe associata all`algoritmo,
     * dato per posizione
     * @param i indice della posizione dell-algoritmo di cui si vuole
     * la classe 
     * @return la classe dell-algoritmo
     */
    public static Class getAlgorithmClass(int i)
    {
        return ALGORITHS[i].AlgorithmClass;
    }
    
    /**
     * @return tutti i nomi abbreviati degli algoritmi
     */
    public static String[] getAlgoShortNames()
	{
		String[] res = new String[getAlgorithmsCount()];
		for(int i=0;i<getAlgorithmsCount();i++)
			res[i] = getAlgorithmShortName(i);
		return res;
	}
    
 }
class PainterInfo
{
	public Class PainterClass;
	public Class StepClass;
	public PainterInfo(Class painterClass,Class stepClass)
	{
		PainterClass = painterClass;
		StepClass = stepClass;
	}
	
}
class AlgoInfo
{
	public String Name;
	public String ShortName;
	public Class AlgorithmClass;
	public AlgoInfo(String name,String shortName,Class algoClass)
	{
		Name = name;
		ShortName = shortName;
		AlgorithmClass = algoClass;
	}
}
