package presentation.configuration;

import java.awt.Color;
import java.awt.Font;

/**
 * Classe che contiene le informazioni di configurazione
 * sullo stile di realizzazione del grafo
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 */
public class GraphStyle 
{
    //User defined strings
	public final static String  TEXT_FIRST_NODE = "",
								TEXT_SECOND_NODE = "";
	
	//Lines width
    public final static int ARC_WIDTH = 5,
    						THICK_LINE_WIDTH=4,
    						ARROW_WIDTH=3,
    						THIN_LINE_WIDTH=2;
    //Heights and widths
	public final static int NODE_BORDER_SIZE = 2,
							NODE_X = 80,
							NODE_Y = 50,
							STARTING_POINT_X = 10,
							STARTING_POINT_Y = 50,
							NODE_X_INTERDISTANCE = 100,
							NODE_Y_INTERDISTANCE = 30,
							ARROW_EDGE = 10,
							ARROW_HEIGHT = 8;
	
	//Fonts
	public final static Font FONT_NODE = new Font("Arial",Font.PLAIN,18);
	
	//Colors
	public final static Color   COLOR_NODE_FILL = Color.CYAN,
							    COLOR_NODE_BORDER = Color.BLUE,
							    COLOR_NODE_FONT = Color.BLACK,
								COLOR_NODESEL_FILL = Color.RED,
								COLOR_NODESEL_BORDER = Color.YELLOW,
								COLOR_NODESEL_FONT = Color.BLUE;
	
	public final static Color[] ARC_COLORS =
	{
		Color.BLACK,Color.BLUE,Color.GREEN,Color.MAGENTA,Color.ORANGE,
		Color.PINK,Color.RED,Color.WHITE,Color.YELLOW
	};
	
	// Edge/Line color
	public final static int ASSIGN_PATH=0;
	public final static int ALTERNATING_TREE=1;
	public final static int AUGMENTING_PATH=6;
	
	
	//variables to switch selected nodes
	public final static int LEFT_NODE=0,
					RIGHT_NODE=1,
					BOTH_NODE=2;
	
}
