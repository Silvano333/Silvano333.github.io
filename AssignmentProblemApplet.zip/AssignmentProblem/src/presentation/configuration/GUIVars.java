package presentation.configuration;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.border.Border;
/**
 * Classe che contiene le informazioni di configurazione
 * sullo stile dell-applicazione
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public class GUIVars
{

	//Widths
	public final static int STATUS_VIEW_GAP = 50;
	//	Colors
    public final static Color 	COLOR_BACKGROUND = Color.GRAY,
    							COLOR_BACKGROUND_DARK = Color.DARK_GRAY,
    							COLOR_BACKGROUND_LIGHT = Color.LIGHT_GRAY,
    				    		COLOR_FOREGROUND = Color.WHITE,
    							COLOR_BORDER = Color.BLACK,
    							COLOR_OPTIONS_BACKGROUND = Color.GRAY,
    							COLOR_OPTIONS_FOREGROUND = Color.WHITE;
    							
    
//Fonts
    public final static Font  FONT_LBL = new Font("Arial",Font.BOLD,16),
    					      FONT_BTN = new Font("Arial",Font.BOLD,18),
    						  FONT_TABLE = new Font("Times New Romans",Font.PLAIN,14);
//Dimensions
   public final static Dimension   DIM_BUTTONS = new Dimension(800,200),
								   DIM_MINFORM = new Dimension(350,500),
								   DIM_GRAPH_STATUS = new Dimension(400,500),
								   DIM_H4_OPTIONDIALOG = new Dimension(400,150);
   
// Borders
   public final static Border BORDER_TABLE = BorderFactory.createLineBorder(Color.BLACK);
   
   
   

}
