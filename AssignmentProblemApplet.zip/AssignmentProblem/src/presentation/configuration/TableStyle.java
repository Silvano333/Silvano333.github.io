package presentation.configuration;

import java.awt.Color;
import java.awt.Font;

/**
 * Configurazioni per il Design della tabella 
 * @author Letizia Cheng Cheng Sun
 * @version 1.0
 *
 * 
 */
public class TableStyle 
{
	
	// Dimensione Celle
	public final static int HEIGHT_CELLS = 30,
							WIDTH_CELLS = 80;
	
	// 	Nomi di righe e colonne
	public final static String  TITLE_COLUMNS = "",
								TITLE_ROWS = "";
	
	//	Colors
    public final static Color 	COLOR_TABLE_ZEROHEADER_BACKGROUND = new Color(80,80,160),
								COLOR_TABLE_ROWHEADER_BACKGROUND = new Color(80,0,160),
    							COLOR_TABLE_ROWHEADER_FOREGROUND = Color.YELLOW,
    							COLOR_TABLE_COLUMNHEADER_BACKGROUND = new Color(0,80,160),
    							COLOR_TABLE_COLUMNHEADER_FOREGROUND = Color.YELLOW,
    							COLOR_TABLE_NORMAL_CELLS_BACKGROUND = new Color(160,160,255),
    							COLOR_TABLE_NORMAL_CELLS_FOREGROUND = Color.WHITE,
    							COLOR_TABLE_SELECTED_CELLS_BACKGROUND = Color.GREEN,
    							COLOR_TABLE_SELECTED_CELLS_FOREGROUND = Color.YELLOW;
	

    
    //Fonts
    public final static Font  FONT_ROWHEADER= new Font("Times New Romans",Font.PLAIN,18),
    						FONT_COLUMNHEADER= new Font("Times New Romans",Font.PLAIN,18),
    						FONT_NORMAL_CELLS  = new Font("Arial",Font.PLAIN,18),
							FONT_SELECTED_CELLS = new Font("Arial",Font.BOLD,18);
    
    //Selected Cells Border
    public final static Color BORDER_SELECTED_CELLS_COLOR = Color.YELLOW;
    public final static int BORDER_SELECTED_CELLS_WIDTH = 2;
  
}
